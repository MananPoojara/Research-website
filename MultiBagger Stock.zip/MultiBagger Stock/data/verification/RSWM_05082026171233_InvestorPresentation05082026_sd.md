Title: Microsoft Word - Covering Letter Investor Presenttion

URL Source: https://nsearchives.nseindia.com/corporate/RSWM_05082026171233_InvestorPresentation05082026_sd.pdf

Published Time: Wed, 05 Aug 2026 11:42:45 GMT

Number of Pages: 46

Markdown Content:
> (Formerly Rajasthan Spinning & Weaving Mills Limited)
> Corporate Office:
> Bhilwara Towers, A-12, Sector-1 Noida-201 301 (NCR-Delhi), India Tel. : +91-120-4390300 (EPABX) Fax : +91-120-4277841 Website : www.rswm.in GSTIN:09AAACR9700M1Z1
> Regd. Office:
> Kharigram, P.O. Gulabpura – 311 021 District Bhilwara, Rajasthan, India Tel.: +91-1483-223144 to 223150, 223478 Fax: +91-1483-223361, 223479 Website : www.rswm.in GSTIN:08AAACR9700M1Z3

Corporate Identification Number :L17115RJ1960PLC008216 

RSWM/SECTT/2026 August 5, 2026 BSE Limited Corporate Relationship Department, 1st Floor, New Trading Ring, Rotunda Building, P.J. Towers, Dalal Street, MUMBAI - 400 001 Scrip Code: 500350 National Stock Exchange of India Limited Listing Department, Exchange Plaza, C-1, Block - G, Bandra-Kurla Complex, Bandra (East), MUMBAI - 400 051 Scrip Code: RSWM 

Sub: Investors Presentation on the Unaudited Financial Results of the Company For the quarter ended 30 th June, 2026. 

Dear Sir, Please find enclosed a copy of Investors Presentation on the unaudited Financial Results of the Company for the quarter ended 30 th June, 2026 for your information and record. The above information is also made available on the website of the Company www.rswm.in This is for your information and record please. 

Thanking you, Yours faithfully, For RSWM LIMITED SURENDER GUPTA CHIEF COMPLIANCE OFFICER & COMPANY SECRETARY FCS – 2615 

rswm.investor@lnjbhilwara.com Encl.: As above YARN | DENIM | KNITS 

www.rswm. in  | June 2026 www.rswm.in 

www.rswm.in  2

Safe Harbor 

This presentation has been prepared by RSWM (“Company”) solely for informational purposes and does not take into account the specific objectives, financial situation, or needs of any particular person. It is confidential 

and may not be copied, distributed, or disseminated, directly or indirectly, in any manner. By accessing this 

material, you agree to comply with these restrictions and maintain strict confidentiality. 

This presentation does not constitute or form part of any offer, invitation, or solicitation to sell, issue, or subscribe to any securities of the Company in any jurisdiction, including India. It should not be relied upon as 

the basis for any investment decision or contractual commitment. 

The material may contain forward-looking statements, including statements regarding the Company’s 

expectations, plans, and financial condition. Such statements are based on current assumptions and involve known and unknown risks and uncertainties, including but not limited to fluctuations in earnings, growth management, competition, international operations, and regulatory changes. Actual results may differ materially from those expressed or implied. The Company undertakes no obligation to update or revise any forward-looking statements to reflect future events or developments. Accordingly, recipients should not place undue reliance on such statements. www.rswm.in 

www.rswm.in  4

CMD’s Message 

# “

> “

## Mr. Riju Jhunjhunwala, CMD 

The first quarter of FY27 has set a positive tone for the year, reflecting the 

resilience of our business and the strength of our strategic execution. During the quarter, we recorded revenue of ₹1,161 crore, EBITDA of ₹94 crore, and Profit After Tax (PAT) of ₹17 crore, driven by operational excellence, an improved product mix, and disciplined cost management. Our integrated business model, customer-centric approach, and continued focus on value-added and sustainable products have enabled us to navigate a dynamic business environment while strengthening our competitive position. 

Going forward, we remain committed to driving profitable growth, improving operational efficiencies, expanding our presence in high-value segments, and deepening customer partnerships. We are confident these strategic priorities will sustain our growth momentum, create long-term stakeholder value, and further reinforce RSWM's position as a leading integrated textile manufacturer. www.rswm.in 

www.rswm.in  5

JMD’s Message 

> “

## Mr. Rajeev Gupta, JMD 

# “ The encouraging turnaround in our performance reflects the collective efforts of 

our teams and the strength of our long-term strategic approach. Despite adynamic global business environment and evolving market conditions, we have remained focused on agility, operational excellence and delivering greater value to our customers. Our continued emphasis on innovation, sustainability and adifferentiated portfolio of value-added products has enabled us to strengthen our competitive position while responding effectively to changing customer requirements. 

As the industry gradually regains momentum, we remain committed to building a future-ready organisation through prudent investments, enhanced capabilities and responsible growth, creating sustainable value for all our stakeholders. www.rswm.in 

www.rswm.in  6

CFO’s Message 

> “

## Mr. Nitin Tulyani, President & CFO 

# “ We are pleased to begin the financial year with a resilient quarter despite a

dynamic global environment. The Indian textile industry benefited from stable cotton prices, improving export enquiries and gradual normalization of international demand. India's growing position as a preferred global sourcing destination, supported by its strong manufacturing ecosystem and favourable policy initiatives, continues to create significant long-term opportunities for the sector. 

Our Q1 performance reflects the steady execution of the RSWM 2.0 transformation strategy. Continued emphasis on value added products, manufacturing excellence, cost efficiency and disciplined capital allocation has strengthened our financial profile. With improving export prospects, stable raw material costs and increasing global sourcing opportunities, we remain well-positioned to sustain profitable growth and create long-term value for our shareholders and stakeholders. 1 Financial Performance 

▪ Profit & Loss Statement 

▪ Q1 FY27 Financials 

www.rswm.in www.rswm.in 

www.rswm.in  8

Standalone Profit & Loss Statement 

Parameters 

(₹ in Cr.) 

Quarterly  Yearly 

Q1 FY27  Q4 FY26  QoQ  Q1 FY26  YoY  FY26 

Total Income  1,170.10  1,158.82  1.0%  1,180.76  (0.9%)  4,605.21 

Raw Material Cost  727.35  669.04  741.93  2,791.90 

Changes in Inventory  (31.68)  39.26  (12.70)  9.30 

Employee Cost  144.02  130.51  136.75  539.87 

Power Cost  111.62  123.28  121.76  495.59 

Other Expenses  124.72  111.29  112.01  441.43 

EBITDA  94.07  85.44  10.1%  81.01  16.1%  327.12 

EBITDA Margin  8.0%  7.4%  67 bps  6.9%  118 bps  7.1% 

Depreciation  38.22  37.59  37.76  149.92 

Finance Cost  31.45  29.58  33.63  122.83 

Exceptional Items  - (0.36)  - (10.57) 

PBT  24.40  17.91  36.2%  9.62  2.5x  43.80 

Tax  7.66  (16.64)  2.66  (8.18) 

PAT  16.74  34.55  (51.6%)  6.96  2.4x  51.98 

PAT Margin  1.4%  3.0%  (155 bps)  0.6%  84 bps  1.1% www.rswm.in 

www.rswm.in  9

Q1 FY26 Q4 FY26 Q1 FY27 

1,169 1,142 1,161 

> Revenue

 19.3 Cr, 1.7% QoQ 

(₹ in Cr) 

Q1 FY27 Financial Performance 

Q1 FY26 Q4 FY26 Q1 FY27 

22.7% 21.2% 22.2% 77.3% 78.8% 77.8% 

> Segment Revenue*

Fabric Yarn 

* Includes Inter-Segment Revenue www.rswm.in 

www.rswm.in  10 

Q1 FY26 Q4 FY26 Q1 FY27 

47 56 63 

> PBDT

4.0% 4.8% 5.4% 

Q1 FY26 Q4 FY26 Q1 FY27 

81 85 94 

> EBITDA

6.9% 7.4% 8.0% 

 13.1 Cr, 16.1% YoY 

 8.6 Cr, 10.1% QoQ 

 15.2 Cr, 32.2% YoY 

 6.8 Cr, 12.1% QoQ 

Q1 FY27 Financial Performance 

(₹ in Cr) www.rswm.in 

www.rswm.in  11 

Q1 FY26 Q4 FY26 Q1 FY27 

735 17 

> PAT

0.6% 3.0% 1.4% 

Q1 FY26 Q4 FY26 Q1 FY27 

10 18 24 

> PBT

0.8% 1.6% 2.1% 

 14.8 Cr, 2.5x YoY 

 6.1 Cr, 33.5% QoQ 

 9.8 Cr, 2.4x YoY 

Q1 FY27 Financial Performance 

(₹ in Cr) 2 Growth Steps 

▪ LNJ GreenPET Acquisition 

▪ Expanding Knitting Operation 

www.rswm.in www.rswm.in 

www.rswm.in  13 

LNJ GreenPET Acquisition Overview 

Strategic Rationale & Fundraising 

❖ RSWM Limited has acquired 100% equity shareholding in LNJ GreenPET Private Limited for a total consideration of ₹20.01 crore, paid in cash. 

❖ The subsidiary has been allotted ~44 acres of land in Ratlam, Madhya Pradesh, and have received the construction approval and other necessary consent. Core machinery order has already been placed. Commercial production is expected to commence in Q1 FY28. 

❖ In line with its strategic growth plans, the company also proposes to raise ₹36.06 crore through the issuance of 24.70 lakh convertible warrants to the promoter group, LNJ Textiles Advisory LLP, at ₹146 per warrant. 

❖ The proceeds will be utilized for subsidiary projects and general corporate purposes, reflecting strong promoter confidence & supporting the company’s ongoing turnaround and expansion initiatives. 

Business Profile 

❖ LNJ GreenPET is a Greenfield Project to be set up in Ratlam, Madhya Pradesh, for the manufacturing of bottle-to-bottle granules, a recycled-PET recycling facility. 

❖ Core product: Food-grade recycled PET chips and granules, catering to FMCG, beverage, pharmaceutical, and packaging sectors. 

❖ Long-term value drivers include: Increasing adoption of rPET driven by regulatory mandates. Margin expansion through value-added, food-grade applications. 

❖ Strengthens RSWM’s ESG credentials and sustainability narrative, enhances investor perception and aligns with long-term value creation objectives www.rswm.in 

www.rswm.in  14 

Expanding Knitting Operation 

₹92 Cr Investment to Grow Knitting Capacity to Upgrade operations and Strengthen market position 

❖ The plan includes buying advanced machinery from Birla Advanced Knits Private Limited to enhance production efficiency and scale up its knitted fabric capabilities. This investment is expected to strengthen RSWM’s position in the knitted fabric segment through improved technology and higher capacity. 

❖ Machine acquisition has been completed in FY26, and the technology upgrade and expansion are underway, with completion expected by H1 FY27. The expected benefits are likely to start reflecting from Q3 FY27 onwards. www.rswm.in 

www.rswm.in  15 

Expanding Knitting Operation 3 Company Overview 

▪ About RSWM Limited 

▪ Milestone 

▪ Business Verticals 

▪ Strong Parentage 

www.rswm.in www.rswm.in 

www.rswm.in  17 

About RSWM Limited www.rswm.in 

www.rswm.in  18 

Plants Location 

Ringas 

a) Fibre Dyeing & Spinning 

b) Dyed Yarn Recycled Polyester Fibre (Green Fibre) 

Kharigram 

a) Fibre Dyeing, Greige & Dyed Yarn Spinning 

b) Melange Yarn Unit (HJ-21) 

Mandpam 

Fibre & Yarn Dyeing & Melange Yarn Spinning 

Mordi, Banswara 

a)  Denim Unit: Cotton Ring & Open End Spinning, Weaving & Rope Dyeing, Processing & Finishing Denim Fabric 

b)  Knits Unit 

Rishabhdev 

Spinning PV Blended Greige Yarn 

Mayur Nagar, Lodha 

Spinning Cotton, PV Blended 

& Open End Greige Yarn 

Kanyakheri 

Melange Yarn 

Chhata, Kosi Unit, Dist. Mathura 

Knitting & Processing 

SPINDLES 

## 5.47 Lac 

ROTORS 

## 6,120 

LOOMS 

## 178 

Knitted Machine 

## 96 www.rswm.in 

www.rswm.in  19 

Strong Parentage www.rswm.in 

www.rswm.in  20 

Milestone 

• 1960 - RSWM 

Limited started its 

journey 

• 1961 - First unit of RSWM 

• 1973 - The spinning unit was established at Gulabpura. 

1960 - 1973 

• 2000 – ERP System 

& HRMS functions 

implementation. 

• 2003 - Acquired the Rishabhdev plant from HEG Limited. 

2000 - 2003 

• LNJ Denim 

launched, along 

with a 46 MW thermal power plant. 

• Completed an expansion plan with a capital cost 

of ₹700 Cr. 

2007 

• Established a green 

fibre manufacturing 

unit at Ringas with a capacity of 18,000 MTs PA. 

2014 

• RSWM launched its 

new range of 

value-added yarns 

“RSWM EDGE”. 

• Upgraded to a modern, GUI-based, ERP system. 

2016 

• 1989 - Established a Greige yarn spinning unit at Banswara 

• 1994 - Established a Melange Yarn manufacturing unit at Bhilwara 

1989 - 1994 

• Acquired Jaipur Polyspin Ltd., 

Ringas and Mordi 

Textiles & Processors Ltd., Banswara 

2005 

• Expanded Automated Spinning plant. capacity at Kharigram (SJ-11), Banswara (Rotors), Denim (Spinning), Mordi (50 Looms) 

2012 

• Additional capacity at the Melange Yarn unit at Kanyakheri, Bhilwara 

2015 

• Installation of 

Sheet Dyeing facility at Denim 

• Commissioned 3.3 MW Rooftop Solar Power Plant at Mandpam and Kanyakheri Plant 

2017 www.rswm.in 

www.rswm.in  21 

Milestone 

• Modernization of Ringas Spinning Plant and also addition of 5,000 spindles 

2018 

• R-Value, a unique trading division of yarns, fabric and denim was launched. 

• HJ 21 Melange yarn Kharigram unit launched. 

2021 

• LNJ Knits launched a new range of knitted fabrics. 

• Kapaas 100% combed compact cotton yarn launched. 

2022 - 2023 

• Banswara, Lodha Unit Expansion, by the 

addition of 51,072 

Spindles of Compact Cotton Yarn. 

• Acquisition of BG Wind Power Limited, having 20MW WTG. 

2024 

• 18.7 MW Solar Power Plant and 25,000 MTs PA Green Fibre 

• 3.3 MW Solar Power Plant. 

2020 

• 2021 - Established a comprehensive 

Disaster Recovery 

(DR) Site. 

• 2022 - Added 4 MW of solar power; total capacity increased to 28 MW of solar power. 

2021 - 2022 

• 30k Spindles at Operations at HJ-21, Kharigram. 

• 4.8k MT PA Knitted Fabric & 8.4 Mn Mtr. PA Denim Fabric by adding in 19,584 spindles to Denim Plant, Mordi. 

2023 

• Acquisition of 

Spinning, Knitting &

Processing Undertaking of Ginni Filaments Limited at Chhata, Kosi, Mathura (UP) which has 80,016 spindles, 720 rotors with 4,300 MT PA Knitting 

Capacity 

2024 

• RSWM 2.0 was launched with a new 

management team 

under the vision: 

• REFLECT 

• RESTORE 

• RESHAPE 

2025 

• 2025 - Partnered with Adani Energy Solutions Ltd. to secure 60 MW of hybrid renewable power. 

• 2026 - Acquired 100% equity in LNJ 

GreenPET Pvt. Ltd. 

2025 - 2026 www.rswm.in 

www.rswm.in  22 

Business Vertical 

RSWM is committed to strengthening its core business, accelerating innovation and unlocking efficiencies while 

exploring new opportunities to build for the future… 

# Yarn 

Since 1960 

# Denim 

Since 2007 

# Knitted Fabric 

Since 2023 

Capacity: 154K MT PA 

Spindles: 5.47 Lakhs  Rotors: 6,120 

Capacity: 32.4 Million meters PA 

Looms: 178  Variants: 3,000+ 

Capacity: 9,360 MT PA 

Needles: 2.54 Lakhs  Machines: 96 www.rswm.in 

www.rswm.in  23 

Business Vertical - Yarn 

1. Synthetic Yarn 

• For over 60 years, the Synthetic Yarn Division has driven RSWM Ltd. ’s growth through innovation, quality, and technical mastery. Delivering advanced yarn solutions for fashion, performance, and industry, the division stays ahead of global trends and leads in both domestic and international markets. 

• Key Contributor of RSWM’s revenue, it remains a key pillar of the company’s long-term 

vision, built on agility, customer focus, and scalable excellence. 

2. Cotton Yarn 

• RSWM has expanded from manmade to cotton yarns, positioning itself as a complete yarn solutions provider serving diverse customer needs. 

• Renowned for innovation, versatility, and customer focus, RSWM’s cotton yarn powers 

leading looms across India and international markets. www.rswm.in 

www.rswm.in  24 

Business Vertical - Yarn 

3. Melange Yarn 

• RSWM is a pioneer in premium mélange yarns, known for creating rich visual effects and textures in woven and knit fabrics under its flagship brand Melantra .

• Operating through state-of-the-art facilities in Mandpam, Kanyakheri, and Kharigram 

(Rajasthan), the division delivers superior quality across diverse applications. 

• Trusted by top fashion and home textile manufacturers, RSWM’s mélange yarns are valued for their depth, texture, and high-end aesthetic appeal. 

4. Combed Compact Yarn 

• ‘Kapaas’ is a premium combed compact yarn that setting a new standard in the Asian 

textile market. It embodies authenticity and refinement. Engineered through advanced 

spinning methods, it offers a smooth texture, light touch, and excellent moisture absorbency of up to 8%, making it ideal for high-end applications. 

• With a focus on environmental responsibility, it has a superior fibre structure that ensures lasting comfort and an elegant finish, while its eco-conscious production 

process reflects RSWM’s dedication to sustainable excellence and quality craftsmanship. www.rswm.in 

www.rswm.in  25 

Yarn Clients 

## YARNS 

## …www.rswm.in 

www.rswm.in  26 

Business Vertical: Denim 

▪ LNJ Denim, a denim-manufacturing facility established in 2007 under RSWM Limited, has a manufacturing capacity of 32.4 Million Meters Annually  and can process 3,000+ Denim 

Variants .

▪ LNJ Denim division offers a comprehensive range of denim products from Timeless indigo styles to Distinctive washes , serving a diverse clientele including fashion designers and everyday apparel manufacturers, enabling RSWM to stay responsive to Evolving market trends and Consumer preferences .

▪ RSWM’s denim operations emphasize High quality standards , Operational efficiency , and 

Sustainability . Supported by advanced manufacturing facilities and a skilled workforce, the division upholds ethical business practices and aligns with Environmental and Social responsibility goals .www.rswm.in 

www.rswm.in  27 

Denim Clients 

## DENIMS 

## …www.rswm.in 

www.rswm.in  28 

Business Vertical: Knitted Fabric www.rswm.in 

www.rswm.in  29 

Knits Clients 

## KNITS 

## …4 Sustainability 

▪ ESG Framework 

▪ Certifications & Recognitions 

▪ Sustainability Performance 

www.rswm.in www.rswm.in 

www.rswm.in  31 

ESG Framework www.rswm.in 

www.rswm.in  32 

Certifications & Recognitions www.rswm.in 

www.rswm.in  33 

Sustainability Performance 5 MANAGEMENT TEAM 

▪ Key Managerial Personnel 

▪ Corporate Team 

▪ Awards & Events 

www.rswm.in www.rswm.in 

www.rswm.in  35 

Key Managerial Personnel www.rswm.in 

www.rswm.in  36 

Corporate Team www.rswm.in 

www.rswm.in  37 

Awards & Recognition www.rswm.in 

www.rswm.in  38 

Awards & Recognition 6 HISTORICAL GROWTH 

▪ Historical Financial Data 

▪ Historical Financial Ratio 

www.rswm.in www.rswm.in 

www.rswm.in 

FY22 FY23 FY24 FY25 FY26 

1,681 1,475 1,448 1,729 1,753 

Gross Profit 

FY22 FY23 FY24 FY25 FY26 

3,850 3,880 4,093 4,855 4,605 

Total Income 

FY22 FY23 FY24 FY25 FY26 

3,817 3,789 4,057 4,825 4,554 

Revenue 

40 

Historical Financial Data 

43.7% 38.0% 35.4% 35.6% 38.1% www.rswm.in 

www.rswm.in 

FY22 FY23 FY24 FY25 FY26 

240 110 35 

(41) 

52 

PAT 

FY22 FY23 FY24 FY25 FY26 

397 266 40 98 

204 

PBDT 

FY22 FY23 FY24 FY25 FY26 

464 340 132 233 327 

EBITDA 

41 

Historical Financial Data 

6.2% 2.8% 0.9% 1.1% 

12.1% 8.7% 3.2% 4.8% 7.1%  10.3% 

6.8% 1.0% 2.0% 4.4% www.rswm.in 

www.rswm.in 

FY22 FY23 FY24 FY25 FY26 

999 1,268 1,309 1,308 1,372 

Net Worth 

FY22 FY23 FY24 FY25 FY26 

210 89 

(72) 

410 428 

Net Operational Cash Flow 

FY22 FY23 FY24 FY25 FY26 

407 509 421 248 254 

Net Working Capital 

42 

Historical Financial Data www.rswm.in 

www.rswm.in 

FY22 FY23 FY24 FY25 FY26 

2,537 2,841 3,593 3,525 3,468 

Capital Employed 

FY22 FY23 FY24 FY25 FY26 

1,103 1,151 1,777 1,622 1,510 

Total Debt 

43 

Historical Financial Data www.rswm.in 

www.rswm.in 

FY22 FY23 FY24 FY25 FY26 

13.8% 7.5% 3.3% 2.2% 5.1% 

ROCE 

44 

Historical Financial Ratio 

FY22 FY23 FY24 FY25 FY26 

24.0% 8.6% 2.7% 

(3.2%) 

3.8% 

ROE 

FY22 FY23 FY24 FY25 FY26 

3.8 3.2 2.9 3.2 3.1 

FIXED ASSET TURNOVER (x) Instagram Logo and their History | LogoMyWay 

www.rswm.in 

rswm.investor@lnjbhilwara.com 

skg@lnjbhilwara.com
