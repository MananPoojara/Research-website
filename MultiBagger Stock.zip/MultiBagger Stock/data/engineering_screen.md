# Precision engineering screen (Screener.in, 5 Nov 2026)

35 names in `engineering_screen.csv`. Debt/equity marked `*` is derived from borrowings / (equity + reserves). Promoter change is Dec 2023 to Sep 2026. Pledge shown only for Setco (30.1%). Band Rs 250 to 6,000 cr.

## Top five in band

1. **Talbros Automotive** - Rs 2,396 cr, P/E 21, ROCE 18%, D/E 0.11, OPM 13% to 16%, 3y profit CAGR 23%, promoter 58.4% unchanged, exports and JVs.
2. **Rolex Rings** - Rs 5,249 cr, P/E 24, ROCE 21%, zero debt, OPM 22% steady, TTM profit +24% after a flat three years, promoter 54% (+2% last quarter), bearing-ring exports, wind and rail.
3. **Uniparts India** - Rs 3,405 cr, P/E 17, ROCE 22%, D/E 0.17, OPM back to 21% from 15%, TTM profit +71% off a trough, promoter 65.9% steady, 125 customers in 25 countries.
4. **Carraro India** - P/E 21, ROCE 29%, OPM 6% to 10%, 3y profit CAGR 42%. Held back: Italian parent 68.8%, Dec 2024 IPO, thin margin.
5. **Steelcast** - ROCE 32%, zero debt, OPM 24% to 27%, mining and defence exports. Held back: P/E 41, 3y sales CAGR -4%, promoter 45%.

Near misses: Automotive Axles (Meritor JV, flat margin); Balu Forge (above band); Menon, Macpower (P/E 35-53).

## Send to full due diligence

**Talbros, Rolex Rings, Uniparts.** All clear the ROCE, P/E, debt and promoter gates with export revenue and no governance flag. Talbros is the cleanest compounder, Rolex Rings the purest bearings play, Uniparts the cheapest; DD must test whether Uniparts' TTM rebound is durable.

## Set aside

- Too large: Happy Forgings, RK Forgings, Jyoti CNC, Craftsman, Sansera, Elecon, Precision Wires, aerospace references (Unimech, Azad, MTAR, Dynamatic, PTC).
- ROCE under 15% or falling profit: Harsha, GNA, Hi-Tech Gears (CIRP petition), Igarashi, Precision Camshafts, Bimetal, Sundaram Brake.
- Promoter selling: NRB (-6.8 pts), RACL (-10.6), GNA (-9.7).
- Governance: Setco (pledge, negative net worth), Bharat Gears (auditor flagged CMD).
- Parent-controlled: Shanthi Gears, Carraro, Automotive Axles, Igarashi.

## Unverifiable cells

- HAPPYFORG and STEELCAST 404; used HAPPYFORGE and STEELCAS.
- Standalone used (consolidated blank): Rolex Rings, Shanthi Gears, Sundaram Brake, Bharat Gears, Macpower, Igarashi, Precision Wires, Pradeep Metals, Steelcast, Automotive Axles.
- Kross numerics blank; Amic Forging 404, not included.
- 5y CAGRs not shown: Menon, Carraro, Unimech. Setco ROE not shown.
