# Logistics watchlist, 5 Nov 2026

Trigger: Substack note by The Megatrend Investor (4 Nov 2026) arguing logistics is where defence was five years ago. The note names no companies. Universe screened: 24 listed logistics names (data/logistics_screen.csv); four reviewed in full (source/dd/TCI.md, TCIEXP.md, VRLLOG.md, WESTERN.md); verdicts in data/dd_verdicts.csv. Gateway Distriparks is already a portfolio selection; Snowman was rejected earlier.

| Rank | Company | Verdict | Gates G1/G2/G3/G4 | CMP (Rs) | P/E | Why it is on the list | Trigger to buy |
|---|---|---|---|---|---|---|---|
| 1 | Transport Corporation of India (TCI) | HOLD | WATCH/WATCH/PASS/PASS | 877 | 14x | Only name passing fundamentals and valuation: multimodal with coastal ships that earn 60% of segment EBIT, ROCE 19%, cash conversion 99%, AA+, no pledge, 14x against a 16-24x own band | Q3 FY27 (Feb 2027): PAT growth back to 10%+ with both new ships in service, Seaways margin >= 35%, debtor days <= 60 |
| 2 | VRL Logistics | HOLD | WATCH/WATCH/PASS/WATCH | 341 | 18.6x | Best current momentum (Q2 PAT +106%, margin 23%), ROCE 25%, promoters not tendering into the buyback; but at a 52-week high and promoters sold Rs 511 cr of stock in 2022-23 | Pullback toward Rs 280 (15x) with margin >= 21% and tonnage growth >= 8% at Q3 FY27 |
| 3 | TCI Express | HOLD | WATCH/FAIL/WATCH/WATCH | 511 | 23x | Net cash, zero pledge, AA-, 23x against a 35x own average; a margin recovery to 15% would double profit, but it has been promised for seven quarters and not delivered | Two consecutive quarters of margin >= 12.5% and revenue growth >= 12% (Q2 FY27 prints 5 Nov 2026, Q3 in Feb 2027) |
| x | Western Carriers (WCIL) | REJECT | WATCH/FAIL/FAIL/WATCH | 95 | 26x | Negative operating cash flow over five years, receivables reported to banks below books, son as CEO and CFO, loans to promoter companies | None; structural |

Not reviewed in full and why: Gujarat Pipavav (APM Terminals 44%, concession expires Sep 2028), Blue Dart (DHL subsidiary, Rs 10,000 cr), Delhivery and CONCOR (large caps), Allcargo Gati, Mahindra Logistics, TVS SCS (losses or 32% pledge), AVG Logistics (67% pledge), Ritco, Tejas, Om Freight (SME-scale, ROCE 10%), Aegis Logistics (Rs 38,000 cr, gas terminals).

Multibagger odds assigned by the reviewers (3x in five years): TCI 15% (2x 40%), VRL 10-15%, TCI Express 15%, Western Carriers 10%. None is a buy today under the four-gate standard; all three holds have a dated trigger.
