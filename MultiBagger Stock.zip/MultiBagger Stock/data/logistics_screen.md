# Logistics comparison screen (Screener.in, 5 Nov 2026)

One Screener consolidated page per company. Debt/equity marked `*` in the CSV is derived from borrowings / (equity + reserves). Empty cells: not shown on Screener. AFCOM returned 404 on every attempt (unverified). ACLGATI data frozen at Nov 2025 (merged into Allcargo).

## Worth a closer look (outside TCI, TCI Express, VRL, Western Carriers)

1. **Gujarat Pipavav Port (GPPL)** - Rs 7,829 cr, P/E 13.8, ROCE 28%, ROE 21%, no debt, TTM sales +20% / profit +28%, flat 1-year price. Caveats: 44% owned by APM Terminals (foreign parent, related-party fees) and the concession ends Sep 2028, so renewal is the thesis.
2. **SEAMEC** - Rs 3,824 cr, P/E 13, ROCE 20%, D/E ~0.1, 5-year profit CAGR 46%, promoter 73%. But offshore oilfield services (ONGC-dependent), not logistics, cyclical, and already +78% in a year.
3. **Om Freight Forwarders** - Rs 360 cr, P/E 18, ROCE 10%, D/E ~0.24, TTM sales +24% / profit +23%, promoter 75%. ROCE below 15% and a 2025 SME listing.

Blue Dart (ROCE 16%, TTM profit +31%, price -30%) also clears the ROCE bar but is a DHL subsidiary just above Rs 10,000 cr.

## Set aside

- Too large: Delhivery, CONCOR, JSW Infra, Aegis, GE Shipping, SCI, Blackbuck.
- ROCE under 10% or losses: Delhivery, Allcargo, Allcargo Gati, Mahindra Logistics, Navkar, Snowman, Sical, Jupiter Wagons.
- Pledge or balance sheet: TVS SCS (pledge 32%, D/E 1.4), AVG (pledge 67%), Ritco (D/E 1.3), Allcargo Terminals (D/E 2.2), Tejas Cargo (D/E 1.1, SME).
- PSU or foreign parent: CONCOR, SCI, Blue Dart, Snowman, GPPL (flagged).
- Not logistics: Jupiter Wagons, SEAMEC, Blackbuck.
- Unverifiable: Afcom Holdings.

Nothing displaces the four under review; only GPPL justifies a full DD-gate pass, after checking the 2028 concession renewal.
