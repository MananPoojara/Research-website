# Pharma API / CDMO / intermediates screen (Screener.in, 5 Nov 2026)

Screener consolidated pages (standalone for SUPRIYA, BAJAJHCARE, ANUHPHR, BLUEJET). Debt/equity marked `*` is derived from borrowings / (equity + reserves). Promoter change is Dec 2023 to Sep 2026. 1-year return is Screener's 1-year price CAGR. 404 after retries: AMIORG, SUVENPHAR, SEQUENT, KRISHNAPHARMA.

## Top five in band (Rs 250 to 6,000 cr)

1. **Windlas Biotech** - Rs 1,891 cr, P/E 28.4, ROCE 15.9%, D/E 0.06, promoter rising to 63.3%, 3y profit CAGR 17%, no flag. OPM flat at 12%.
2. **NGL Fine-Chem** - Rs 1,784 cr, P/E 31.2, ROCE 18.6%, D/E 0.37, promoter steady 72.5%, OPM 13 to 16%, 3y profit CAGR 37%. 5y profit CAGR -1%; GST notice Rs 6.2 cr.
3. **Innova Captab** - Rs 5,951 cr, P/E 38.6, ROCE 15.0%, D/E 0.32, promoter steady 50.9%, OPM 12 to 15%, 3y profit CAGR 28%. Over 30x; Dec 2023 IPO; possible interest capitalisation.
4. **IOL Chemicals** - Rs 5,564 cr, P/E 26.3, D/E 0.10, promoter up to 62.3%. ROCE 11%; 3y profit CAGR 2%; stock +98%.
5. **Anuh Pharma** - Rs 833 cr, P/E 17.4, debt-free, promoter rising. ROCE 14.9%; OPM 10 to 8%.

## Send to full four-gate DD

- **Windlas Biotech**: the only name clearing every bar.
- **NGL Fine-Chem**: best growth with margin expansion in band; P/E marginally over 30 is the only miss.
- **Innova Captab**: consistent growth, margin expansion, steady promoter; DD must test valuation and interest capitalisation. IOL is the alternate.

## Set aside

- Too large: Neuland, Shilpa, Caplin Point, Jubilant Ingrevia, Concord, Aarti Pharmalabs, Blue Jet, Granules, Akums; Supriya (Rs 6,994 cr, plus an NDPS case with a Supreme Court stay).
- Losses or ROCE under 10%: Hikal, Solara, Indoco, Themis, Kopran, Morepen, Bajaj Healthcare.
- Pledge: Solara (52%), Themis (45.8%).
- Promoter falling: Beta Drugs (-7.8 pts), Kilitch (-5.5 pts), Bajaj Healthcare (-9 pts).
- Over 30x with margin contraction or loss-base growth: SMS Pharma, Senores, Beta.
- Unverifiable: Ami Organics, Suven Pharma, Sequent, Krishna Pharma.

## Empty cells

Pledge % except Solara and Themis; P/E for Indoco and Themis (losses); 5y CAGRs for Solara (profit), Indoco (profit), Aarti Pharmalabs, Senores, IOL; 3y profit CAGR for Indoco; every field for the four 404 symbols.
