"""Shared data loading, numbers and styling for the two documents."""
import csv, html, json, os
e = html.escape

def load(base):
    d = {}
    d['funnel'] = json.load(open(os.path.join(base, 'stage1_funnel.json')))
    d['s2'] = json.load(open(os.path.join(base, 'stage2_funnel.json')))
    d['port'] = json.load(open(os.path.join(base, 'portfolio.json')))
    d['scored'] = list(csv.DictReader(open(os.path.join(base, 'stage2.csv'))))
    d['short'] = json.load(open(os.path.join(base, 'shortlist.json')))
    return d

CORPUS = 1_00_00_000  # illustrative Rs 1 crore
SCEN = [('Bear', .25, .05), ('Base', .50, .15), ('Bull', .25, .24)]  # (name, probability, 10-year CAGR)
YEARS = 10

def cr(x):
    """Indian digit grouping (12,34,567)."""
    n = f'{x:.0f}'
    if len(n) <= 3:
        return n
    last3, rest = n[-3:], n[:-3]
    parts = []
    while len(rest) > 2:
        parts.insert(0, rest[-2:]); rest = rest[:-2]
    if rest:
        parts.insert(0, rest)
    return ','.join(parts + [last3])

def rupees(x):
    return '₹' + cr(x)

def lakh(x):
    return f'₹{x/1e5:,.1f} lakh'

def scenarios():
    out = []
    for name, p, g in SCEN:
        out.append({'name': name, 'p': p, 'cagr': g, 'end': CORPUS * (1 + g) ** YEARS})
    ev = sum(p * g for _, p, g in SCEN)
    return out, ev

assert cr(10000000) == '1,00,00,000' and cr(996) == '996' and cr(4400) == '4,400'

FONTS = '<link href="fonts/fonts.css" rel="stylesheet">'  # local copies: headless Chrome here cannot verify fonts.gstatic.com

CSS = r"""
:root{
  --ink:#1E2230; --ink-2:#4A5163; --muted:#6B7283;
  --paper:#FFFFFF; --ledger:#A3161C; --ledger-soft:#F3E3E3;
  --rule:#D9DFE9; --rule-strong:#B9C2D1; --thread:#B8862B; --good:#2E6B4E;
}
@page{ size:A4; margin:0 }
*{ box-sizing:border-box }
html,body{ margin:0; background:var(--paper); color:var(--ink) }
body{ font-family:'Martel',Georgia,serif; font-weight:400; font-size:10pt; line-height:1.62;
      -webkit-print-color-adjust:exact; print-color-adjust:exact }
.page{ width:210mm; height:297mm; position:relative; overflow:hidden; page-break-after:always;
       padding:20mm 18mm 18mm 34mm }
.page:last-child{ page-break-after:auto }
/* the ledger margin: a double red rule like an account book */
.page::before{ content:''; position:absolute; top:0; bottom:0; left:24mm; width:3px;
       border-left:1px solid var(--ledger); border-right:1px solid var(--ledger) }
.page .folio{ position:absolute; bottom:10mm; left:34mm; right:18mm; display:flex; justify-content:space-between;
       font-family:'Hind',sans-serif; font-size:7.5pt; color:var(--muted) }
h1,h2,h3{ font-family:'Martel',Georgia,serif; color:var(--ink); margin:0 }
h1{ font-weight:800; font-size:25pt; line-height:1.15; letter-spacing:-.01em }
h2{ font-weight:800; font-size:16pt; line-height:1.25; margin:0 0 4mm }
h3{ font-weight:600; font-size:11pt; line-height:1.35; margin:5mm 0 1.5mm }
p{ margin:0 0 3mm; max-width:150mm }
.lede{ font-size:11.5pt; line-height:1.6; font-weight:300; color:var(--ink) }
.small{ font-size:8.5pt; line-height:1.5; color:var(--ink-2) }
.hand{ font-family:'Kalam',cursive; color:var(--ledger); font-size:11pt; line-height:1.3 }
.margin-note{ position:absolute; left:5mm; width:17mm; font-family:'Kalam',cursive; color:var(--ledger);
       font-size:8.5pt; line-height:1.2; transform:rotate(-4deg) }
table{ border-collapse:collapse; width:100%; font-family:'Hind',sans-serif; font-size:8.6pt;
       font-variant-numeric:tabular-nums; line-height:1.35 }
th{ text-align:left; font-weight:600; color:var(--ink-2); border-bottom:1.2px solid var(--ink);
    padding:1.6mm 1.6mm 1.4mm; vertical-align:bottom }
td{ padding:1.5mm 1.6mm; border-bottom:1px solid var(--rule); vertical-align:top }
td.n, th.n{ text-align:right } td.n{ white-space:nowrap }
tr.sum td{ border-top:1.2px solid var(--ink); border-bottom:none; font-weight:600 }
.neg{ color:var(--ledger) } .pos{ color:var(--good) }
.tag{ font-family:'Hind',sans-serif; font-size:7.5pt; font-weight:600; padding:.3mm 1.6mm; border-radius:2mm;
      border:1px solid currentColor; white-space:nowrap }
.tag.core{ color:var(--good) } .tag.watch{ color:var(--thread) } .tag.bench{ color:var(--muted) } .tag.veto{ color:var(--ledger) }
.grid2{ display:grid; grid-template-columns:1fr 1fr; gap:6mm }
.kv{ font-family:'Hind',sans-serif; font-size:8.6pt; display:grid; grid-template-columns:auto 1fr; gap:.6mm 3mm }
.kv dt{ color:var(--muted) } .kv dd{ margin:0; font-variant-numeric:tabular-nums }
.card{ border-top:1.2px solid var(--ink); padding-top:3mm; margin-bottom:9mm; break-inside:avoid }
.card .head{ display:flex; justify-content:space-between; align-items:baseline; gap:4mm }
.card .head h3{ margin:0 }
.card .w{ font-family:'Hind',sans-serif; font-weight:600; font-size:13pt; color:var(--ledger) }
.cols{ display:grid; grid-template-columns:1.55fr 1fr; gap:6mm; margin-top:1.5mm }
.cols p{ font-size:9.2pt; line-height:1.55; margin-bottom:2mm }
.label{ font-family:'Hind',sans-serif; font-weight:600; font-size:8.5pt; color:var(--ink-2); margin:0 0 .6mm }
.thread{ height:0; border-top:1.5px solid var(--thread); width:28mm; margin:4mm 0 }
svg text{ font-family:'Hind',sans-serif }
ul{ margin:0 0 3mm; padding-left:5mm; max-width:150mm } li{ margin:0 0 1.4mm }
table.tight td{ padding:.85mm 1.4mm } table.tight th{ padding:1mm 1.4mm }
.cover{ background:var(--ledger); color:#fff; padding:0 }
.cover::before{ display:none }
"""

def make_page(inner, n, label, cls=''):
    folio = f'<div class="folio"><span>{label}</span><span>{n}</span></div>' if n else ''
    return f'<section class="page {cls}">{inner}{folio}</section>'

def bar_svg(rows, w=150, unit='%', fmt=lambda v: f'{v:.1f}%', hi=None, h=7.2, lab_w=52):
    """horizontal bars, one series. rows: [(label, value)]"""
    top = 2
    mx = max(v for _, v in rows)
    H = top + h * len(rows) + 2
    s = [f'<svg viewBox="0 0 {w} {H}" width="{w}mm" height="{H}mm" role="img">']
    for i, (lab, v) in enumerate(rows):
        y = top + i * h
        bw = (w - lab_w - 18) * v / mx
        col = 'var(--ledger)' if hi and lab in hi else 'var(--ink)'
        s.append(f'<text x="0" y="{y+4.4}" font-size="3.3" fill="var(--ink)">{e(lab)}</text>')
        s.append(f'<rect x="{lab_w}" y="{y+1.4}" width="{bw:.2f}" height="3.6" rx="0.8" fill="{col}"/>')
        s.append(f'<text x="{lab_w+bw+2:.2f}" y="{y+4.4}" font-size="3.3" fill="var(--ink-2)">{fmt(v)}</text>')
    s.append('</svg>')
    return ''.join(s)

