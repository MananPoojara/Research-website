"""Parse a Screener.in company page into plain numbers."""
import re, html as H

def _txt(s):
    return re.sub(r'\s+', ' ', H.unescape(re.sub(r'<[^>]+>', ' ', s))).strip()

def _num(s):
    s = _txt(s).replace(',', '').replace('%', '').replace('₹', '').replace('Cr.', '').strip()
    try:
        return float(s)
    except ValueError:
        return None

def table(page, sec):
    """Return (headers, {row_label: [values...]}) for a financial section."""
    m = re.search(r'<section id="%s".*?</section>' % sec, page, re.S)
    if not m:
        return [], {}
    t = m.group(0)
    tm = re.search(r'<table.*?</table>', t, re.S)
    if not tm:
        return [], {}
    t = tm.group(0)
    hdr = [_txt(h) for h in re.findall(r'<th[^>]*>(.*?)</th>', t, re.S)][1:]
    rows = {}
    for tr in re.findall(r'<tr[^>]*>(.*?)</tr>', t, re.S):
        tds = re.findall(r'<td[^>]*>(.*?)</td>', tr, re.S)
        if not tds:
            continue
        label = _txt(tds[0]).replace('+', '').strip()
        label = label.split('  ')[0].strip()
        rows[label] = [_num(v) for v in tds[1:]]
    return hdr, rows

def top(page):
    m = re.search(r'id="top-ratios".*?</ul>', page, re.S)
    out = {}
    if not m:
        return out
    for li in re.findall(r'<li.*?</li>', m.group(0), re.S):
        name = re.search(r'class="name"[^>]*>(.*?)</span>', li, re.S)
        val = re.search(r'class="nowrap value"[^>]*>(.*?)</span>\s*</li>', li, re.S) or re.search(r'class="value"[^>]*>(.*?)</span>', li, re.S)
        if not name or not val:
            continue
        n = _txt(name.group(1))
        nums = [float(x.replace(',', '')) for x in re.findall(r'-?[\d,]+\.?\d*', _txt(val.group(1)))]
        if n == 'High / Low' and len(nums) >= 2:
            out['high52'], out['low52'] = nums[0], nums[1]
        elif nums:
            out[n] = nums[0]
    return out

def meta(page):
    d = {}
    t = re.search(r'<h1[^>]*>(.*?)</h1>', page, re.S)
    d['name'] = _txt(t.group(1)) if t else ''
    for key in ('Broad Sector', 'Sector', 'Broad Industry', 'Industry'):
        m = re.search(r'title="%s"[^>]*>(.*?)</a>' % key, page, re.S)
        if m:
            d[key.lower().replace(' ', '_')] = _txt(m.group(1))
    w = re.search(r'data-warehouse-id="(\d+)"', page)
    d['warehouse_id'] = w.group(1) if w else None
    c = re.search(r'data-company-id="(\d+)"', page)
    d['company_id'] = c.group(1) if c else None  # used by /api/company/<id>/chart/
    d['view'] = 'consolidated' if '<!--view:consolidated-->' in page[:40] else 'standalone'
    return d

def has_financials(page):
    _, pl = table(page, 'profit-loss')
    vals = [v for k, row in pl.items() if k.startswith(('Sales', 'Revenue')) for v in row if v is not None]
    return len(vals) >= 2

def parse(page):
    d = meta(page)
    d['top'] = top(page)
    for sec in ('profit-loss', 'balance-sheet', 'cash-flow', 'ratios'):
        d[sec] = dict(zip(('hdr', 'rows'), table(page, sec)))
    return d
