"""Stage 1 of the Yartseva screen on the full Screener export (all NSE + BSE companies).

usage: python3 screen2.py <research_dir> <usd_inr>
reads : screener_export.json (rows pulled from the logged-in Screener query), universe.json (liquid mainboard list)
writes: stage1.csv (every company with metrics + first gate failed), stage1_funnel.json, shortlist.json
"""
import csv, json, os, re, statistics, sys

base, usd_inr = sys.argv[1], float(sys.argv[2])
exp = json.load(open(os.path.join(base, 'screener_export.json')))
uni = json.load(open(os.path.join(base, 'universe.json')))
by_nse = {x['NSE']['sym']: x for x in uni if 'NSE' in x}
by_bse = {x['BSE']['code']: x for x in uni if 'BSE' in x}

COLS = ['company_id', 'href', 'name', 'cmp', 'mcap', 'ev', 'bv_ps', 'fcf', 'fcf3y', 'ebitda', 'ebitda_prev',
        'net_profit', 'assets', 'roa', 'high52', 'low52', 'ret3m', 'ret6m', 'debt', 'roce']
# lenders/insurers: FCF and EBITDA are not meaningful for them, so the paper's two key variables do not apply
FIN = re.compile(r'\b(bank|finance|financial|fincorp|finserv|finvest|fintrade|credit|capital|leasing|lending|'
                 r'insurance|assurance|housing fin|investments?|holdings?|securities|stock ?broking|broking|'
                 r'asset management|amc|muthoot|bajaj fin|shriram)\b', re.I)

def num(s):
    s = (s or '').replace(',', '').strip()
    try:
        return float(s)
    except ValueError:
        return None

recs = []
for row in exp:
    r = dict(zip(COLS, row))
    for k in COLS[3:]:
        r[k] = num(r[k])
    slug = r['href'].strip('/').split('/')[1]
    u = by_nse.get(slug) or by_bse.get(slug)
    r['slug'] = slug
    r['in_liquid_universe'] = u is not None
    if u:
        r.update(isin=u['isin'], nse=u.get('NSE', {}).get('sym', ''), bse=u.get('BSE', {}).get('code', ''), adtv_cr=u['adtv_cr'])
    r['name_looks_financial'] = bool(FIN.search(r['name'] or ''))
    m, p, bv = r['mcap'], r['cmp'], r['bv_ps']
    r['bm'] = bv / p if bv is not None and p else None
    r['book_equity'] = m * bv / p if m and bv is not None and p else None
    r['fcf_yield'] = r['fcf'] / m if r['fcf'] is not None and m else None
    r['op_prof'] = r['ebitda'] / r['book_equity'] if r['ebitda'] is not None and r['book_equity'] and r['book_equity'] > 0 else None
    r['ebitda_g'] = r['ebitda'] / r['ebitda_prev'] - 1 if r['ebitda'] is not None and r['ebitda_prev'] and r['ebitda_prev'] > 0 else None
    hi, lo = r['high52'], r['low52']
    r['price_range'] = (p - lo) / (hi - lo) * 100 if p and hi and lo is not None and hi > lo else None
    recs.append(r)

need = ('mcap', 'bm', 'fcf', 'fcf3y', 'ebitda', 'roa', 'price_range')
base_set = [r for r in recs if r['in_liquid_universe'] and not r['name_looks_financial'] and all(r[k] is not None for k in need)]
val_cut = sorted(r['bm'] for r in base_set)[int(len(base_set) * 2 / 3)]
prof_vals = [r['op_prof'] for r in base_set if r['op_prof'] is not None]
prof_cut = statistics.median(prof_vals)
START_USD_M = 500  # paper's median multibagger started near $348M in 2009, about $500M in today's dollars
size_cut = START_USD_M * 1e6 * usd_inr / 1e7  # ceiling in Rs crore
FLOOR = 250  # Rs crore: avoid shells and untradeable micro caps (paper used NYSE/Nasdaq listings, no OTC)

gates = [
    ('G0', 'Liquid NSE/BSE mainboard stock (>= Rs 25 lakh traded a day)', lambda r: r['in_liquid_universe']),
    ('G1', 'Not a lender, insurer or holding company; data complete', lambda r: r in base_set),
    ('G2', f'Small: market cap Rs {FLOOR:.0f} cr to Rs {size_cut:,.0f} cr (paper median start, ~$500M today)', lambda r: FLOOR <= r['mcap'] <= size_cut),
    ('G3', f'High value: book-to-market in top third of market (>= {val_cut:.2f}), positive equity', lambda r: r['bm'] >= val_cut and r['book_equity'] > 0),
    ('G4', f'Robust profitability: EBITDA / book equity >= market median ({prof_cut:.0%}) and ROA > 0', lambda r: r['op_prof'] is not None and r['op_prof'] >= prof_cut and r['roa'] > 0),
    ('G5', 'Cash generative: FCF > 0 last year and FCF over 3 years > 0', lambda r: r['fcf'] > 0 and r['fcf3y'] > 0),
]
for r in recs:
    r['first_failed_gate'] = next((gid for gid, _, g in gates if not g(r)), '')
funnel = [{'gate': 'All companies on Screener with market cap > Rs 50 cr', 'id': 'U', 'n': len(recs)}]
alive = recs
for gid, name, g in gates:
    alive = [r for r in alive if g(r)]
    funnel.append({'gate': name, 'id': gid, 'n': len(alive)})

cuts = {'usd_inr': usd_inr, 'size_ceiling_cr': size_cut, 'size_floor_cr': FLOOR, 'bm_top_third': val_cut,
        'ebitda_to_equity_median': prof_cut, 'base_set_n': len(base_set)}
json.dump({'funnel': funnel, 'cuts': cuts}, open(os.path.join(base, 'stage1_funnel.json'), 'w'), indent=1)
json.dump(alive, open(os.path.join(base, 'shortlist.json'), 'w'), indent=1)
keys = list(recs[0].keys())
keys += [k for r in recs for k in r if k not in keys]
keys = list(dict.fromkeys(keys))
with open(os.path.join(base, 'stage1.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(recs)
for s in funnel:
    print(f"{s['n']:>6}  {s['id']} {s['gate']}")
print(json.dumps(cuts))
