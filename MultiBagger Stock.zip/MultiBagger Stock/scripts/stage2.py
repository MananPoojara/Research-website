"""Stage 2: Yartseva investment dummy + composite rank + portfolio.

usage: python3 stage2.py <research_dir>
reads : shortlist.json (stage 1), company_pages.json (Screener company data for the shortlist)
writes: stage2.csv, portfolio.json, stage2_funnel.json
"""
import csv, json, os, sys

base = sys.argv[1]
short = json.load(open(os.path.join(base, 'shortlist.json')))
pages = json.load(open(os.path.join(base, 'company_pages.json')))

def fy_cols(hdr):
    """Fiscal-year column indexes: drop TTM and the single interim (half-year) column."""
    ms = [h[:3] for h in hdr if h[:3].isalpha() and h[-4:].isdigit()]
    if not ms:
        return []
    fy = max(set(ms), key=ms.count)
    return [i for i, h in enumerate(hdr) if h[:3] == fy and h[-4:].isdigit()]

def series(tab, prefix):
    for k, v in (tab or {}).get('rows', {}).items():
        if k.startswith(prefix):
            return v
    return None

pc = lambda v: 'n/a' if v is None else f'{v:.0%}'
recs, dropped = [], []
for r in short:
    p = pages.get(r['slug'], {})
    r.update(view=p.get('view'), broad_sector=p.get('broad_sector', ''), sector=p.get('sector', ''),
             industry=p.get('industry', ''), about=p.get('about', ''))
    if r['broad_sector'] == 'Financial Services' or series(p.get('pl'), 'Financing Profit'):
        dropped.append((r['slug'], 'G6a lender / financial (Screener sector)')); continue
    bs, pl = p.get('bs'), p.get('pl')
    bi, pi = fy_cols(bs['hdr']), fy_cols(pl['hdr'])
    ta, op = series(bs, 'Total Assets'), series(pl, 'Operating Profit')
    a1, a0 = ta[bi[-1]], ta[bi[-2]]
    e1, e0 = op[pi[-1]], op[pi[-2]]
    r['fy_assets'], r['fy_pl'] = bs['hdr'][bi[-1]], pl['hdr'][pi[-1]]
    r['asset_g'] = a1 / a0 - 1 if a0 and a0 > 0 else None
    r['ebitda_g_page'] = e1 / e0 - 1 if e0 and e0 > 0 else None
    # paper: Inv dummy = 1 if YoY asset growth > YoY EBITDA growth (returns 4-23 pts lower next year)
    r['inv_dummy'] = int(r['asset_g'] is None or r['ebitda_g_page'] is None or r['asset_g'] > r['ebitda_g_page'])
    if r['inv_dummy']:
        dropped.append((r['slug'], f"G6 assets grew faster than EBITDA ({pc(r['asset_g'])} vs {pc(r['ebitda_g_page'])})")); continue
    if r['asset_g'] <= 0:
        dropped.append((r['slug'], f"G6 assets shrinking ({r['asset_g']:.0%}): paper's worst group is conservative, shrinking firms")); continue
    sales = series(pl, 'Sales')
    if sales and len(pi) >= 4 and sales[pi[-4]] and sales[pi[-4]] > 0 and sales[pi[-1]] and sales[pi[-1]] > 0:
        r['sales_cagr3'] = (sales[pi[-1]] / sales[pi[-4]]) ** (1 / 3) - 1
    r['promoter'] = (series(p.get('sh'), 'Promoters') or [None])[-1]
    r['fcf_yield_3y'] = r['fcf3y'] / 3 / r['mcap']
    recs.append(r)

def pct_rank(vals, v, higher_better=True):
    s = sorted(vals)
    k = sum(1 for x in s if x < v) + 0.5 * sum(1 for x in s if x == v)
    p = k / len(s)
    return p if higher_better else 1 - p

# weights follow the size of the paper's dynamic-model coefficients: FCF/P and B/M largest, then price range,
# then 3/6-month reversal and size, ROA smallest. FCF blends last year with the 3-year average ("robust" cash yield).
W = {'fcf': .30, 'bm': .20, 'range': .20, 'm6': .10, 'm3': .05, 'size': .10, 'roa': .05}
for r in recs:
    r['fcf_blend'] = (r['fcf_yield'] + r['fcf_yield_3y']) / 2
col = lambda k: [x[k] for x in recs]
for r in recs:
    parts = {'fcf': pct_rank(col('fcf_blend'), r['fcf_blend']), 'bm': pct_rank(col('bm'), r['bm']),
             'range': pct_rank(col('price_range'), r['price_range'], False), 'm6': pct_rank(col('ret6m'), r['ret6m'], False),
             'm3': pct_rank(col('ret3m'), r['ret3m'], False), 'size': pct_rank(col('mcap'), r['mcap'], False),
             'roa': pct_rank(col('roa'), r['roa'])}
    r['score_parts'] = parts
    r.update({f'part_{k}': round(v, 3) for k, v in parts.items()})
    r['score'] = sum(W[k] * v for k, v in parts.items())
recs.sort(key=lambda r: -r['score'])
for i, r in enumerate(recs, 1):
    r['rank'] = i

# portfolio rules (diversification is ours, from Bessembinder's "winners are rare"; entry timing is the paper's):
#   one stock per industry, two per Screener sector, four per broad sector;
#   price must sit in the lower half of its 52-week range, otherwise the name goes on the watchlist
N, PER_IND, PER_SEC, PER_BROAD, MAX_RANGE = 12, 1, 2, 4, 50
port, watch, cnt = [], [], {}
def bump(k):
    cnt[k] = cnt.get(k, 0) + 1
# the one manual override: the paper removed "transitory" spike-and-collapse multibaggers from its sample
VETO = {'519477': 'analyst veto: spike-and-collapse profile (-58% in a month, Nov 2025), BSE volume clarification '
                  '(Apr 2026), standalone profit near zero vs Rs 223 cr consolidated; numbers we cannot reconcile'}
for r in recs:
    if r['slug'] in VETO:
        r['status'], r['skip_reason'] = 'veto', VETO[r['slug']]
        continue
    if r['price_range'] > MAX_RANGE:
        r['status'] = 'watchlist'
        r['skip_reason'] = f"price at {r['price_range']:.0f}% of its 52-week range; wait for the lower half"
        watch.append(r); continue
    keys = [('i', r['industry'], PER_IND), ('s', r['sector'], PER_SEC), ('b', r['broad_sector'], PER_BROAD)]
    full = next((f"{lvl}:{name}" for lvl, name, cap in keys if cnt.get((lvl, name), 0) >= cap), None)
    if full or len(port) == N:
        r['status'] = 'bench'
        r['skip_reason'] = {'i': 'a higher-ranked stock already holds this industry', 's': 'sector already has two holdings',
                            'b': 'broad sector already has four holdings'}[full[0]] if full else 'portfolio full'
        continue
    for lvl, name, _ in keys:
        bump((lvl, name))
    r['status'] = 'core'
    port.append(r)
# score-tilted weights: equal weight scaled by score, clipped to 7%-15% and renormalised
raw = [0.5 + r['score'] for r in port]
w = [x / sum(raw) for x in raw]
for _ in range(50):
    w = [min(max(x, .07), .15) for x in w]
    w = [x / sum(w) for x in w]
for r, x in zip(port, w):
    r['weight'] = round(x, 4)
assert abs(sum(r['weight'] for r in port) - 1) < 1e-3 and all(.069 <= r['weight'] <= .151 for r in port)
json.dump(watch, open(os.path.join(base, 'watchlist.json'), 'w'), indent=1)
json.dump(port, open(os.path.join(base, 'portfolio.json'), 'w'), indent=1)
json.dump({'stage2_in': len(short), 'dropped': dropped, 'scored': len(recs), 'weights': W, 'rules': {'N': N, 'per_industry': PER_IND, 'per_sector': PER_SEC, 'per_broad_sector': PER_BROAD, 'max_price_range': MAX_RANGE}},
          open(os.path.join(base, 'stage2_funnel.json'), 'w'), indent=1)
keys = list(dict.fromkeys(k for r in recs for k in r if k not in ('score_parts', 'about')))
with open(os.path.join(base, 'stage2.csv'), 'w', newline='') as fh:
    wr = csv.DictWriter(fh, fieldnames=keys, extrasaction='ignore'); wr.writeheader(); wr.writerows(recs)
print('dropped:'); [print('  ', s, why) for s, why in dropped]
print('scored', len(recs))
for r in recs:
    tag = f"{r['weight']*100:4.1f}%" if r in port else r['status'][:5].ljust(6)
    print(f"{r['rank']:>2} {tag} {r['slug']:<11}{r['broad_sector'][:22]:<23}{r['industry'][:28]:<29}score {r['score']:.3f} fcfb {r['fcf_blend']*100:5.1f} bm {r['bm']:.2f} rng {r['price_range']:5.1f} 6m {r['ret6m']:6.1f} ag {r['asset_g']*100:4.0f} eg {r['ebitda_g_page']*100:4.0f}")
