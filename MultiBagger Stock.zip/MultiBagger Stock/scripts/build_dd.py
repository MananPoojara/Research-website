"""Due-diligence verdicts and the revised portfolio. usage: python3 build_dd.py <data_dir> <out.html>"""
import csv, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import CSS, FONTS, make_page, e, cr

base, out = sys.argv[1], sys.argv[2]
V = list(csv.DictReader(open(os.path.join(base, 'dd_verdicts.csv'))))
P2 = list(csv.DictReader(open(os.path.join(base, 'portfolio_v2.csv'))))
quote = {r['nse']: r for r in json.load(open(os.path.join(base, 'raw', 'shortlist.json')))}
vby = {r['symbol']: r for r in V}
USE = 'Proprietary, for personal use only'
ORIG9 = ['KALAMANDIR', 'GATEWAY', 'TNPL', 'RSWM', 'BCLIND', 'DOLLAR', 'KOTHARIPET', 'REMSONSIND', 'AHLUCONT']
TAG = {'REJECT': 'veto', 'HOLD': 'watch', 'SELECT': 'core'}
GATE = {'PASS': 'core', 'WATCH': 'watch', 'FAIL': 'veto'}

def page(inner, n=None, cls=''):
    n = len(P) + 1  # folio number follows the order pages are appended
    return make_page(inner, n, f'Due diligence, November 2026 &nbsp; {USE}', cls)

def tag(v):
    return f'<span class="tag {TAG[v]}">{v}</span>'

def gates(r):
    return ''.join(f'<span class="tag {GATE[r[k]]}" title="{k}">{r[k][0]}</span>' for k in ('g1_governance', 'g2_guidance', 'g3_fundamentals', 'g4_valuation'))

n_rej = sum(r['verdict'] == 'REJECT' for r in V); n_hold = sum(r['verdict'] == 'HOLD' for r in V); n_sel = sum(r['verdict'] == 'SELECT' for r in V)
tiers = {t: [r for r in V if r['tier'] == t] for t in ('1', '2', '3')}
P = []

# ---- cover
P.append(f'''<section class="page">
<div style="position:absolute;left:34mm;right:20mm;top:58mm">
  <div class="hand" style="font-size:13pt">the second pass: company by company</div>
  <h1 style="font-size:32pt;margin:6mm 0 6mm">Due diligence verdicts</h1>
  <p class="lede" style="max-width:135mm">The screen found cheap, cash-generating small caps. This document asks the harder question of each one: who runs it, do they do what they say, are the numbers what they look like, and is it cheap for a reason. {len(V)} companies were put through four gates. {n_rej} failed, {n_hold} are held back as alternates, {n_sel} were selected.</p>
  <div class="thread"></div>
  <p class="small">Research 2 November 2026, prices 30 October 2026. Most Q2 FY27 results are due between 3 and 14 November and could change several verdicts. {USE}.</p>
</div></section>''')

# ---- why and how
P.append(page(f'''<div style="position:absolute;left:34mm;right:18mm;top:22mm">
<h2>Why a second pass</h2>
<p class="lede">The first proposal ranked Sai Silks (Kalamandir) first. It was cheap on every measure the screen used. It was also a shrinking business whose managing director had just appointed his son-in-law as chief executive, six days after an independent director resigned without explanation. No screen catches that. A person reading the filings does.</p>
<p>So every finalist, and then two further tiers of the screen's near-misses, went through the same four gates, each scored Pass, Watch or Fail, with the evidence written up in a separate note per company (in <b>source/dd/</b>).</p>
<table style="margin-top:3mm"><tr><th style="width:38mm">Gate</th><th>What we looked for</th><th style="width:40mm">Automatic fail</th></tr>
<tr><td><b>1. Governance</b></td><td>Promoter pledge and selling; relatives in executive roles and how they got there; related-party purchases and sales as a share of revenue; auditor changes, resignations and qualifications; SEBI or exchange action; promoter pay as a share of profit; independent-director exits.</td><td class="small">Money moving from the company to the family, or a board that cannot say no.</td></tr>
<tr><td><b>2. Guidance and delivery</b></td><td>What management told investors two and three years ago, and what happened. The latest guidance, and whether it was cut, deferred or quietly dropped.</td><td class="small">Repeated misses with a new excuse each time.</td></tr>
<tr><td><b>3. Fundamentals</b></td><td>Five-year sales and profit growth; the last two quarters; margins; return on capital; debt and interest cover; working-capital days; cash from operations against reported profit.</td><td class="small">Shrinking sales and falling margins with no credible turn.</td></tr>
<tr><td><b>4. Valuation</b></td><td>Earnings, book and EV/EBITDA multiples against the company's own history and its peers. Whether the cheapness is a cycle trough or a permanent discount, and whether the headline multiple hides a one-off.</td><td class="small">Not cheap once one-offs are removed.</td></tr></table>
<p class="small" style="margin-top:4mm">A company with a Fail on governance is out whatever the price. The default for a small cap with any governance smell is Reject; Hold is reserved for companies where the concern is specific, dated, and resolvable by a named event.</p>
</div>'''))

# ---- the original nine
P.append(page(f'''<div style="position:absolute;left:34mm;right:18mm;top:22mm">
<h2>What it did to the original nine</h2>
<p class="lede">Six of the nine are out. Three survive as Holds, each with a dated test. The screen's top pick was the first to fail.</p>
<table><tr><th>Holding</th><th>Verdict</th><th>The deciding fact</th></tr>{"".join(f'<tr><td><b>{e(vby[s]["name"])}</b><br><span class="small">{e(s)}</span></td><td>{tag(vby[s]["verdict"])}</td><td class="small">{e(vby[s]["key_reason"])}</td></tr>' for s in ORIG9)}</table>
<p class="small" style="margin-top:4mm">Every one of the six rejections was cheap on the screen's measures and stayed cheap on ours. The difference is that the screen could not see a son-in-law appointed as chief executive, a promoter's loss-making sugar company being merged in, a deferred-tax credit posing as profit, or a widow appointed to the board ten days after a death. Those are the facts that decide whether cheapness becomes a return or a trap.</p>
</div>'''))

# ---- funnel
rows = ''.join(f'<tr><td>Tier {t}: {lab}</td><td class="n">{len(tiers[t])}</td><td class="n">{sum(r["verdict"]=="REJECT" for r in tiers[t])}</td><td class="n">{sum(r["verdict"]=="HOLD" for r in tiers[t])}</td><td class="n">{sum(r["verdict"]=="SELECT" for r in tiers[t])}</td></tr>'
               for t, lab in (('1', 'the scored finalists (CIAN Agro already vetoed)'), ('2', 'stage-1 passers dropped by the asset-growth gate'), ('3', 'the remaining liquid stage-1 passers')) if tiers[t])
P.append(page(f'''<div style="position:absolute;left:34mm;right:18mm;top:22mm">
<h2>What survived</h2>
<table style="width:150mm"><tr><th>Group</th><th class="n">Reviewed</th><th class="n">Reject</th><th class="n">Hold</th><th class="n">Select</th></tr>{rows}
<tr><td><b>All</b></td><td class="n"><b>{len(V)}</b></td><td class="n"><b>{n_rej}</b></td><td class="n"><b>{n_hold}</b></td><td class="n"><b>{n_sel}</b></td></tr></table>
<div class="thread"></div>
<p class="lede">No company scored Pass on all four gates. That is the honest result of applying a governance standard to the cheapest tenth of the Indian small-cap market: the cheapness is usually earned. The {n_sel} selected are the ones where every open item is specific, small against the evidence for the business, and confirmed against the company's own filings. The {n_hold} Holds have an open item we are not willing to carry: a quarter that just failed, money stuck in overseas affiliates, a merger at an undisclosed price, a plant shut after a fatal accident.</p>
<h3>The most common reasons for rejection</h3>
<ul>
<li><b>Family money.</b> Relatives appointed to executive roles within days of a death or a resignation (Remsons, Sai Silks, KM Sugar); promoter companies merged in or bought at the company's expense (Kothari Petrochemicals, BCL, Kanpur Plastipack, Jay Bharat Maruti); pay equal to a fifth or more of profit (Rico Auto, Emami Paper, Jay Bharat).</li>
<li><b>Optical cheapness.</b> Headline P/E of 3 to 5 that becomes 10 to 22 once a deferred-tax credit or an asset-sale gain is removed (TNPL, Ashoka Buildcon, Jay Bharat); a 34% free-cash-flow yield that was a one-year working-capital release (RSWM).</li>
<li><b>Guidance nobody kept.</b> Growth of 15 to 18% guided, 0 to 5% delivered, two or three years running (20 Microns, Ashoka, Ganesh Consumer, Sai Silks, Rico Auto).</li>
<li><b>The business left the listed company.</b> Bhagyanagar's copper business and KM Sugar's distillery were both demerged out in September and October 2026; the screen was still looking at the old numbers.</li>
</ul></div>'''))

# ---- verdict table, all companies
def vrow(r):
    q = quote.get(r['symbol'], {})
    return (f'<tr><td><b>{e(r["name"])}</b><br><span class="small">{e(r["symbol"])}</span></td><td class="n small">{cr(float(q["mcap"])) if q else ""}</td>'
            f'<td style="white-space:nowrap">{gates(r)}</td><td>{tag(r["verdict"])}</td><td class="small">{e(r["key_reason"])}</td></tr>')
order = {'SELECT': 0, 'HOLD': 1, 'REJECT': 2}
VS = sorted(V, key=lambda r: (order[r['verdict']], r['name']))
for i, chunk in enumerate(VS[j:j + 10] for j in range(0, len(VS), 10)):
    P.append(page(f'''<div style="position:absolute;left:34mm;right:18mm;top:22mm">
{"<h2>Every verdict</h2><p class='small' style='margin-bottom:3mm'>Gates read left to right: governance, guidance, fundamentals, valuation. P pass, W watch, F fail. Market value in ₹ crore at 30 October 2026.</p>" if i == 0 else "<h2>Every verdict, continued</h2>"}
<table class="tight"><tr><th>Company</th><th class="n">Mkt value</th><th>Gates</th><th>Verdict</th><th>The deciding fact</th></tr>{"".join(vrow(r) for r in chunk)}</table></div>'''))

# ---- the portfolio
tot = sum(float(r['weight']) for r in P2)
prow = lambda r: (f'<tr><td><b>{e(r["name"])}</b><br><span class="small">{e(r["symbol"])}</span></td><td class="small">{e(r["industry"])}</td>'
                  f'<td class="n">{float(r["weight"])*100:.0f}%</td><td class="n">₹{float(quote[r["symbol"]]["cmp"]):,.2f}</td><td class="n small">{cr(float(quote[r["symbol"]]["mcap"]))}</td><td class="small">{e(r["trigger"])}</td></tr>')
P.append(page(f'''<div style="position:absolute;left:34mm;right:18mm;top:22mm">
<h2>The portfolio</h2>
<p class="lede">{len(P2)} companies, one per industry, each with its pledge, promoter pay, related-party dealings and audit opinion confirmed from its own filings, and each cheap against its own record. Six is fewer than the nine we started with; it is what survived. Each carries one watch item, named here, that we check at the next results and that would make us sell if it goes the wrong way.</p>
<table><tr><th>Company</th><th>Industry</th><th class="n">Weight</th><th class="n">Price</th><th class="n">Mkt value</th><th>Watch at next results</th></tr>{"".join(prow(r) for r in P2)}
<tr><td><b>Total</b></td><td></td><td class="n"><b>{tot*100:.0f}%</b></td><td colspan="3"></td></tr></table>
<p class="small" style="margin-top:3mm">Weights are tilted toward governance quality and cash conversion, not toward the screen score. Prices are Screener's close of 30 October 2026. Entry is in two halves: half now, half after the Q2 FY27 print, so that a bad print costs half a position. A name that fails its watch item is sold and replaced by the first alternate (last page) that has cleared its own.</p>
</div>'''))

# ---- holding cards, two per page
def card(r):
    v = vby[r['symbol']]; q = quote[r['symbol']]
    return (f'<div class="card"><div class="head"><h3>{e(r["name"])} <span class="small" style="font-weight:400">{e(r["symbol"])} · {e(r["industry"])}</span></h3><span class="w">{float(r["weight"])*100:.0f}%</span></div>'
            f'<div style="margin:1.5mm 0">{gates(v)} <span class="small">₹{float(q["cmp"]):,.2f} · {cr(float(q["mcap"]))} · ROCE {float(q["roce"]):.0f}%</span></div>'
            f'<p><b>Why it is in.</b> {e(v["key_reason"])}.</p>'
            f'<p><b>What worries us.</b> {e(v["second_reason"])}.</p>'
            f'<p><b>Watch at next results.</b> {e(r["trigger"])}.</p>'
            f'<p class="small"><b>Sell if.</b> {e(r["kill"])}</p></div>')
for i in range(0, len(P2), 2):
    P.append(page(f'<div style="position:absolute;left:34mm;right:18mm;top:22mm">{"<h2>The holdings</h2>" if i == 0 else ""}{"".join(card(r) for r in P2[i:i+2])}</div>'))

# ---- primary-source verification
VER = [r for r in V if r.get('verified')]
vrow2 = lambda r: f'<tr><td><b>{e(r["name"])}</b><br><span class="small">{e(r["symbol"])}</span></td><td>{tag(r["verdict"])}</td><td class="small">{e(r["verified"])}</td></tr>'
P.append(page(f'''<div style="position:absolute;left:34mm;right:18mm;top:22mm">
<h2>Checked against the filings</h2>
<p class="lede">The first-pass notes leaned on aggregator sites for some governance facts. Before anything was bought, every selected company and the leading alternates were re-checked against the FY26 annual report, the September 2026 shareholding pattern, the auditor's report and the latest results filing. Two selections did not survive it.</p>
<table class="tight"><tr><th>Company</th><th>Now</th><th>What the filings showed (sources in each note under source/dd/)</th></tr>{"".join(vrow2(r) for r in VER)}</table>
</div>'''))

# ---- alternates and caveats
P.append(page(f'''<div style="position:absolute;left:34mm;right:18mm;top:22mm">
<h2>Alternates, in order</h2>
<p class="small" style="margin-bottom:2mm">Companies held back because of one open item we will not carry. Each replaces a sold holding only after clearing its own test.</p>
<table><tr><th>Company</th><th>Why held back</th><th>Clears on</th></tr>{"".join(f'<tr><td><b>{e(r["name"])}</b><br><span class="small">{e(r["symbol"])}</span></td><td class="small">{e(r["second_reason"])}</td><td class="small">{e(r["review_trigger"])}</td></tr>' for r in V if r["verdict"]=="HOLD" and r["symbol"] not in {p["symbol"] for p in P2})}</table>
</div>'''))

# ---- caveats
P.append(page(f'''<div style="position:absolute;left:34mm;right:18mm;top:22mm">
<h2>What we could not verify</h2>
<ul>
<li>Q2 FY27 (September 2026 quarter) results were not yet published for most companies when this was written; they arrive between 3 and 14 November 2026. Each holding's watch item is checked against them, and the second half of each position is bought only after.</li>
<li>For the six holdings and the leading alternates, pledge, pay, related-party dealings and audit opinions were confirmed from the filings (previous page). For the rejected companies the first-pass notes stand: where the annual report PDF did not parse (Remsons, 20 Microns, Ashoka, Kalamandir), family relationships are inferred from exchange "is related to" disclosures and pay figures come from aggregator sites. Those names were rejected on more than one ground, so a correction would not readmit them.</li>
<li>Five-year median multiples are estimates from price and earnings history; the usual data vendors blocked automated access.</li>
<li>Peer multiples are from differently dated snapshots.</li>
</ul>
<div class="thread"></div>
<h3>What this changes about expectations</h3>
<p>The first proposal priced in a 15% base-case annual return over ten years. This portfolio is cheaper on governance-adjusted terms but has less headline growth, and it will sell names that fail their watch items, so expect a lower realised return in the early years and shallower drawdowns. We would rather own {len(P2)} businesses we have read the filings of than nine we have only measured.</p>
<h3>Files</h3>
<p class="small"><b>data/dd_verdicts.csv</b> holds every gate result and reason; <b>data/portfolio_v2.csv</b> the portfolio with weights, watch items and sell rules; <b>source/dd/*.md</b> the per-company notes with sources; <b>scripts/build_dd.py</b> rebuilds this document.</p>
</div>'''))

doc = f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Due diligence verdicts</title>{FONTS}<style>{CSS}</style></head><body>{"".join(P)}</body></html>'
open(out, 'w').write(doc)
print('pages', len(P))
