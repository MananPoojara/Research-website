"""Client proposal (HTML, printed to PDF by Chrome). usage: python3 build_proposal.py <research_dir> <out.html>"""
import html, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load, CSS, FONTS, CORPUS, YEARS, scenarios, cr, rupees, lakh, bar_svg, make_page

base, out = sys.argv[1], sys.argv[2]
D = load(base)
port = D['port']
by = {r['slug']: r for r in D['scored']}
USE = 'Proprietary, for personal use only'
DATE = '31 October 2026'
PRICED = 'closing prices of 30 October 2026'
e = html.escape

# what each company does, why it is in, what worries us, what we will watch. Written by hand from the data and filings news.
NOTES = {
 'KALAMANDIR': dict(name='Sai Silks (Kalamandir)', biz='Saree and ethnic-wear retailer, about 82 stores across the South under Kalamandir, Vara Mahalakshmi, KLM Fashion Mall and Valli.',
   why='It scores highest of everything that reached the final round. Last year it produced free cash of roughly a quarter of its market value, it trades below book, and the share price sits right at its 52-week low after falling 37% in six months. FY26 sales grew 13% to about ₹1,654 cr. Assets rose 13% while EBITDA rose 23%, so the new stores are paying their own way, which is exactly the pattern the paper rewards.',
   worry='Last year\'s cash flow was flattered by working capital; the three-year average yield is closer to 9%. Q1 FY27 profit fell about 15%, which is why the stock is where it is.',
   watch='Inventory days and FY27 free cash flow. If cash turns negative for the year, it fails our own test.',
   note='bottom of the range. good.'),
 'GATEWAY': dict(name='Gateway Distriparks', biz='Rail-linked inland container depots and freight stations, with its own train rakes moving boxes between ports and the hinterland.',
   why='The steadiest cash generator of the nine: free cash yield of about 16% last year and 15% averaged over three years, so this is not a one-year accident. It trades a little under book value, and the stock is at the bottom of its 52-week range. FY26 EBITDA grew 24% on assets that grew just 2%.',
   worry='Volumes are flat (Q2 FY27 throughput down about 3%) and the promoter holds only about 34%. Competition from larger rail logistics players is real.',
   watch='Quarterly container throughput. Cash flow we trust; volume is the open question.',
   note='most consistent cash in the book'),
 'TNPL': dict(name='Tamil Nadu Newsprint & Papers', biz='State-promoted maker of printing paper and packaging board, much of it from bagasse (sugarcane waste).',
   why='TNPL is the extreme case on the paper\'s two biggest variables. Price to book is 0.38, the cheapest of anything that survived our filters, and free cash yield is above 20% on both the one-year and three-year view. EBITDA grew 12% last year.',
   worry='Debt of about ₹1,600 cr is larger than the market value of the equity. FY26 net profit was inflated by a one-off deferred tax reversal of about ₹219 cr, so we ignore that line. Cheap imports from ASEAN are pressing on paper prices.',
   watch='Net debt falling year on year. If it does not, the cash yield is not reaching shareholders.',
   note='ignore the FY26 profit. look at cash.'),
 'RSWM': dict(name='RSWM', biz='LNJ Bhilwara group spinner: yarn, denim and knitted fabric, with a growing recycled-fibre (green PET) business.',
   why='A turnaround the market has not paid for yet. FY26 profit was about ₹52 cr against a ₹40 cr loss the year before, EBITDA rose 35% on flat assets, and Q1 FY27 profit more than doubled. It trades at 0.62x book with a strong cash yield.',
   worry='Debt is high, roughly 1.2x equity. It is also the least liquid holding, trading only about ₹30 lakh a day, so we will build the position over several sessions. Price is at 49% of its range, just inside our limit.',
   watch='Interest cover and debt. Textiles are cyclical; we want the upcycle used to repay borrowings.',
   note='buy slowly. thin volumes.'),
 'BCLIND': dict(name='BCL Industries', biz='Punjab-based grain distiller and ethanol producer. It has exited edible oils to focus on the distillery business.',
   why='Large capex is behind it (a 150 KLPD expansion was commissioned), and the cash has started to arrive: free cash yield was about 22% last year. FY26 profit grew 23% to about ₹126 cr. It trades at book value, with assets growing 6% against EBITDA growing 18%.',
   worry='The three-year cash yield is under 1%, because the earlier years were heavy capex. Ethanol pricing and allocations are set by government policy and oil companies, not the market.',
   watch='Whether FY27 free cash flow stays positive now the capex cycle is done, and the next ethanol allocation round.',
   note='capex done. now show me the cash.'),
 'DOLLAR': dict(name='Dollar Industries', biz='Kolkata hosiery and innerwear brand selling knitted innerwear, casual and thermal wear nationally.',
   why='A profitable branded business at a fair price, trading near the bottom of its range after a 23% fall in six months. FY26 revenue was about ₹1,881 cr and the business has grown sales about 11% a year for three years. Promoters own about 73%.',
   worry='Its cash conversion is the second weakest of the nine. Innerwear ties up a lot of money in inventory and dealer credit.',
   watch='Free cash flow over FY27. A branded business should convert profit to cash; this one has not done so reliably.',
   note='near tie with Monte Carlo. see notes.'),
 'KOTHARIPET': dict(name='Kothari Petrochemicals', biz='India\'s largest producer of polyisobutylene (PIB), used in lubricant and fuel additives, adhesives and sealants.',
   why='The cleanest balance sheet of the group: practically no debt and a return on assets near 18%. It is the textbook case of the paper\'s investment finding, with assets up 17% and EBITDA up 21%, so the expansion is fully funded by earnings.',
   worry='It is more expensive than the others on book value (1.7x). It is a one-product company and one of the least liquid names, trading about ₹34 lakh a day, on NSE only.',
   watch='Capital work in progress turning into capacity and sales. It bought land for expansion; we want to see the plant.',
   note='debt free. rare in this list.'),
 'REMSONSIND': dict(name='Remsons Industries', biz='Auto control cables, gear shifters and parking brake systems for two-wheeler, car and commercial vehicle makers in India and abroad.',
   why='The smallest company in the portfolio at about ₹300 cr, which is where the paper says the odds are best. FY26 revenue grew about 24% to a record. A seven-year Stellantis order worth about ₹300 cr starts delivering in FY27. EBITDA grew 35% while assets grew 12%.',
   worry='At about 2x book it is the most expensive of the nine on that measure. Auto parts margins are thin, and much rests on new orders being executed on time.',
   watch='Stellantis deliveries showing up in revenue from FY27, and margins holding.',
   note='smallest. most upside if it works.'),
 'AHLUCONT': dict(name='Ahluwalia Contracts', biz='Building contractor for hospitals, airports, institutional and commercial projects.',
   why='Almost no debt, and an unexecuted order book of about ₹20,700 cr, roughly four and a half years of revenue. The stock has fallen about 38% this year and sits at its 52-week low, which is where the paper says entries work best.',
   worry='Free cash yield was only 0.4% last year (3% over three years), the weakest of the nine on the paper\'s most important variable. Contractors get paid slowly, especially by state governments.',
   watch='Free cash flow in FY27. This is the first name we would cut if cash does not show up.',
   note='weakest cash. smallest weight.'),
}

def pct(x, d=0):
    return f'{float(x)*100:.{d}f}%'

def page(inner, n=None, cls=''):
    return make_page(inner, n, f'Small-cap portfolio proposal &nbsp; {USE}', cls)

pages = []

# ---- cover
pages.append(f'''<section class="page cover">
<div style="position:absolute;left:24mm;top:0;bottom:0;border-left:1.5px solid var(--thread)"></div>
<div style="position:absolute;left:34mm;right:20mm;top:62mm">
  <div class="hand" style="color:#F6D9A8;font-size:13pt">Shubh Labh. A new ledger for Samvat 2083.</div>
  <h1 style="color:#fff;font-size:34pt;margin:8mm 0 6mm">Nine small companies,<br>held for ten years</h1>
  <p class="lede" style="color:#F8EDEA;max-width:130mm">A long-term Indian small-cap portfolio, chosen with the method and evidence of Anna Yartseva's study <i>The Alchemy of Multibagger Stocks</i> (Birmingham City University, 2025).</p>
</div>
<div style="position:absolute;left:34mm;right:20mm;bottom:26mm;font-family:Hind,sans-serif;font-size:9pt;color:#F8EDEA;line-height:1.7">
  Private investment proposal<br>{USE}. Not for distribution.<br>{DATE}, using {PRICED}
</div></section>''')

# ---- letter
sc, ev = scenarios()
n_univ = D['funnel']['funnel'][0]['n']
pages.append(page(f'''
<h2>Before the numbers</h2>
<p class="lede">This proposal is for a portfolio we would expect you to hold for seven to ten years. It is small, it is concentrated, and some years it will be uncomfortable to own. We think it is also one of the more honest ways to go looking for multibaggers.</p>
<p>Most stocks do not create wealth. Hendrik Bessembinder's work on US markets found that about 4% of listed companies explain all of the market's gains over T-bills since 1926. So the question is not how to find a sure winner, because there isn't one. The question is how to buy a basket where the odds of holding one or two genuine winners are better than average, and where the losers are not the kind that wipe you out.</p>
<p>In 2025 Anna Yartseva studied 464 US stocks that went up at least ten times between 2009 and 2024 and asked what they looked like before they took off. Her answer surprised a lot of people, us included. Fast earnings growth did not predict anything. What did: being small, being cheap against book value and free cash flow, being profitable, investing in growth only when profits keep pace, and being bought near a 12-month low rather than a high.</p>
<p>We took those findings and applied them, as literally as Indian data allows, to all {cr(n_univ)} companies with a market value above ₹50 crore on Screener, covering both NSE and BSE. Nine companies came through. They are not famous. Most are down sharply this year. That is rather the point.</p>
<p>What to expect, plainly: our central case is around {sc[1]["cagr"]*100:.0f}% a year over ten years, with a realistic range of {sc[0]["cagr"]*100:.0f}% to {sc[2]["cagr"]*100:.0f}%. The first year may well be flat, because the RBI has just started raising rates again, and the paper finds that rising rates take 8 to 12 points off these stocks' next-year returns. That is why we suggest putting the money in over three instalments, not all at once.</p>
<p>One thing to be clear about. This is designed as your entire equity portfolio, so there is no large-cap or index fund underneath to cushion it. Nine small companies will at times fall 40 to 50% together, and that can happen in the same year you need the money. Please keep at least two to three years of expenses, and anything you need within five years, outside this portfolio.</p>
<p>The working behind every number here is in the companion document, <i>How we got here</i>. Nothing in it is hidden.</p>
<div class="thread"></div>
<p class="hand" style="font-size:12pt">31 October 2026</p>
''', 2))

# ---- the idea
pages.append(page('''
<h2>What the research found, and what we did with it</h2>
<p>Yartseva's study used 15 years of data on 464 enduring tenbaggers, tested more than 150 variables, and kept only those that predicted the following year's returns out of sample. Below is each finding next to the rule we built from it.</p>
<table>
<tr><th style="width:43%">What the paper found</th><th>Our rule for Indian stocks</th></tr>
<tr><td><b>Free cash flow yield</b> was the single strongest driver of future returns.</td><td>Free cash flow must be positive last year and over three years. It carries the largest weight (30%) in our ranking.</td></tr>
<tr><td><b>Value</b>: high book-to-market stocks beat expensive ones, and negative-equity firms lost money.</td><td>Book-to-market in the cheapest third of the Indian market (price to book about 2x or less), with positive equity.</td></tr>
<tr><td><b>Size</b>: smaller firms did better. The median tenbagger started near $350M, about $500M in today\'s money.</td><td>Market value between ₹250 cr and ₹4,400 cr.</td></tr>
<tr><td><b>Profitability</b> mattered; loss-makers dominated the worst portfolios.</td><td>Operating profit to equity above the market median, and positive return on assets.</td></tr>
<tr><td><b>Investment</b>: firms must grow assets, but if assets grow faster than EBITDA, next-year returns fall by 4 to 23 points.</td><td>Assets must be growing, and growing no faster than EBITDA. Shrinking firms are out.</td></tr>
<tr><td><b>Entry point</b>: the closer to the 12-month high, the worse the next year. Recent 3 to 6 month gains reverse.</td><td>Buy only in the lower half of the 52-week range. Better-placed stocks rank higher.</td></tr>
<tr><td><b>Rates</b>: a year of rising policy rates cut next-year returns by about 10 points.</td><td>Stagger the buying. The RBI raised the repo rate to 5.50% on 7 October.</td></tr>
<tr><td><b>Did not matter</b>: earnings, sales or cash flow growth; debt levels; dividends; buybacks; the P/E ratio.</td><td>We do not screen on growth or P/E at all. We do still tell you about debt.</td></tr>
</table>
<p class="small" style="margin-top:4mm">The paper is a working paper and not yet peer reviewed. It studies US winners after the fact, so it carries survivorship bias, and India is a different market. We treat it as the best available map, not a guarantee.</p>
''', 3))

# ---- portfolio table + weights
rows = ''
tw = 0
for r in port:
    s = by[r['slug']]; nt = NOTES[r['slug']]; w = r['weight']; tw += w
    amt = CORPUS * w
    rows += (f'<tr><td><b>{e(nt["name"])}</b><br><span class="small">{e(r["nse"] or "BSE " + r["bse"])}</span></td>'
             f'<td class="small">{e(s["industry"])}</td>'
             f'<td class="n"><b>{w*100:.1f}%</b></td><td class="n">{lakh(amt)}</td>'
             f'<td class="n">₹{float(r["cmp"]):,.2f}</td><td class="n">{cr(float(r["mcap"]))}</td>'
             f'<td class="n">{1/float(r["bm"]):.2f}</td><td class="n">{float(s["fcf_yield"])*100:.1f}%</td>'
             f'<td class="n">{float(r["price_range"]):.0f}%</td></tr>')
wavg = lambda k: sum(r['weight'] * float(by[r['slug']][k]) for r in port)
rows += (f'<tr class="sum"><td colspan="2">Portfolio</td><td class="n">{tw*100:.1f}%</td><td class="n">{lakh(CORPUS)}</td><td></td>'
         f'<td class="n">{cr(sorted(float(r["mcap"]) for r in port)[len(port)//2])}<br><span class="small">median</span></td>'
         f'<td class="n">{1/wavg("bm"):.2f}</td><td class="n">{wavg("fcf_yield")*100:.1f}%</td><td class="n">{wavg("price_range"):.0f}%</td></tr>')
chart = bar_svg([(NOTES[r['slug']]['name'], r['weight'] * 100) for r in port], w=150, h=5.4)
pages.append(page(f'''
<h2>The portfolio</h2>
<p>Nine holdings, one per industry, spread across five broad sectors. Weights tilt towards the stocks that score best on the paper's variables, between roughly 9% and 13%. Rupee amounts assume an illustrative ₹1 crore.</p>
<table>
<tr><th>Company</th><th>Industry</th><th class="n">Weight</th><th class="n">On ₹1 cr</th><th class="n">Price</th><th class="n">Mkt cap<br>₹ cr</th><th class="n">Price/<br>book</th><th class="n">FCF<br>yield</th><th class="n">In 52-wk<br>range</th></tr>
{rows}
</table>
<p class="small" style="margin-top:2mm">FCF yield is last year's free cash flow divided by market value. "In 52-week range" is 0% at the year's low and 100% at its high. Weighted averages, except market cap. Prices are Screener's last traded price at the close on 30 October 2026.</p>
<h3 style="margin-top:6mm">Weights</h3>
{chart}
''', 4))

# ---- stock cards, three per page
def card(r):
    s = by[r['slug']]; nt = NOTES[r['slug']]
    kv = (f'<dl class="kv"><dt>Price</dt><dd>₹{float(r["cmp"]):,.2f}</dd>'
          f'<dt>52-week range</dt><dd>₹{float(r["low52"]):,.0f} to ₹{float(r["high52"]):,.0f}</dd>'
          f'<dt>Market value</dt><dd>₹{cr(float(r["mcap"]))} cr</dd>'
          f'<dt>Price / book</dt><dd>{1/float(r["bm"]):.2f}</dd>'
          f'<dt>FCF yield, 1y / 3y avg</dt><dd>{float(s["fcf_yield"])*100:.1f}% / {float(s["fcf_yield_3y"])*100:.1f}%</dd>'
          f'<dt>Return on assets</dt><dd>{float(r["roa"]):.1f}%</dd>'
          f'<dt>Assets vs EBITDA growth</dt><dd>{float(s["asset_g"])*100:+.0f}% vs {float(s["ebitda_g_page"])*100:+.0f}%</dd>'
          f'<dt>Last 6 months</dt><dd>{float(r["ret6m"]):+.0f}%</dd>'
          f'<dt>Debt</dt><dd>₹{cr(float(r["debt"]))} cr</dd>'
          f'<dt>Rank / score</dt><dd>{s["rank"]} of {len(D["scored"])} / {float(s["score"]):.2f}</dd></dl>')
    return (f'<div class="card"><div class="head"><h3>{e(nt["name"])} <span class="small" style="font-weight:400">{e(r["nse"] or "BSE " + r["bse"])}</span></h3>'
            f'<span class="w">{r["weight"]*100:.1f}%</span></div>'
            f'<p class="small" style="margin:.5mm 0 0">{e(nt["biz"])}</p>'
            f'<div class="cols"><div><p class="label">Why it is in</p><p>{e(nt["why"])}</p>'
            f'<p class="label">What worries us</p><p>{e(nt["worry"])}</p>'
            f'<p class="label">What we will watch</p><p>{e(nt["watch"])}</p></div>'
            f'<div>{kv}<p class="hand" style="margin-top:3mm;font-size:10.5pt">{e(nt["note"])}</p></div></div></div>')

for i in range(0, len(port), 2):
    chunk = port[i:i + 2]
    title = '<h2>Why these nine</h2>' if i == 0 else ''
    extra = ''
    if len(chunk) == 1:
        mix = {}
        for r in port:
            mix[r['broad_sector']] = mix.get(r['broad_sector'], 0) + r['weight'] * 100
        extra = ('<h3 style="margin-top:6mm">The nine together, by broad sector</h3>'
                 + bar_svg(sorted(mix.items(), key=lambda x: -x[1]), w=150, h=6.4)
                 + '<p class="small" style="margin-top:3mm">Consumer discretionary is the largest block, but it holds four different businesses: a saree retailer, a yarn maker, an innerwear brand and an auto parts supplier. None of them shares an industry with another holding.</p>')
    pages.append(page(title + ''.join(card(r) for r in chunk) + extra, 5 + i // 2))

nxt = 5 + (len(port) + 1) // 2

# ---- returns
end_rows = ''.join(f'<tr><td>{s["name"]}</td><td class="n">{s["p"]*100:.0f}%</td><td class="n">{s["cagr"]*100:.0f}%</td>'
                   f'<td class="n">₹{s["end"]/1e7:,.2f} cr</td><td class="n">{s["end"]/CORPUS:.1f}x</td></tr>' for s in sc)
cash = sum(r['weight'] * min(float(by[r['slug']]['fcf_blend']), .12) for r in port)
chart2 = bar_svg([(s['name'] + ' case', s['end'] / 1e7) for s in sc], w=150, fmt=lambda v: f'₹{v:.2f} cr', hi={'Base case'})
pages.append(page(f'''
<h2>What we expect, and how sure we are</h2>
<p>Nobody can promise a return on small caps, and we won't. What we can do is show how we arrived at a range and what has to go right for each end of it.</p>
<table style="width:120mm">
<tr><th>Case</th><th class="n">Chance</th><th class="n">Yearly, 10 yrs</th><th class="n">₹1 cr becomes</th><th class="n">Multiple</th></tr>
{end_rows}
<tr class="sum"><td>Probability-weighted</td><td></td><td class="n">{ev*100:.1f}%</td><td></td><td></td></tr>
</table>
<div style="margin:5mm 0 2mm">{chart2}</div>
<h3>How the base case adds up</h3>
<p>The nine companies together throw off free cash of roughly {cash*100:.0f}% of their market value. We count that figure with every holding capped at 12% so one unusual year cannot carry the average. Add growth in line with India's nominal GDP, about 9 to 10%, and subtract 3 to 4 points for the holdings that will disappoint, which some will. Assume no re-rating at all. That lands in the mid-teens, matching the long-run return of Indian small caps plus a modest premium for buying cheap, cash-rich companies.</p>
<h3>What each end needs</h3>
<p><b>Bull:</b> two or three of the nine re-rate from below book towards fair value while still growing. One genuine tenbagger at a 10% weight adds about a full turn to the portfolio on its own. <b>Bear:</b> the rate cycle drags on, two or three holdings turn out to be value traps, and the market stays cold on small caps for years. That has happened before, from 2018 to 2020.</p>
<p><b>Year one:</b> do not judge this on the first twelve months. Rates are rising, and the paper's own estimate is that this takes 8 to 12 points off next-year returns for exactly this kind of stock. Because this is the whole equity portfolio, plan for a fall of 40 to 50% from a peak at some point. Bessembinder found that even the best-performing stocks of each decade fell more than 30% on average during their winning decade.</p>
''', nxt))

# ---- deployment and selling
pages.append(page(f'''
<h2>How we put the money in, and when we sell</h2>
<h3>Three instalments</h3>
<table style="width:150mm">
<tr><th>When</th><th class="n">Share</th><th>What happens</th></tr>
<tr><td>November 2026</td><td class="n">40%</td><td>Buy all nine at target weights. RSWM and Kothari are spread over several sessions because of thin trading.</td></tr>
<tr><td>February 2027</td><td class="n">30%</td><td>After the December RBI meeting and the Q3 results. Re-check every gate first, and add only to names still in the lower half of their 52-week range.</td></tr>
<tr><td>May 2027</td><td class="n">30%</td><td>After the full-year FY27 results. Same checks. Money not deployed waits in a liquid fund.</td></tr>
</table>
<p class="small" style="margin-top:2mm">Staggering serves two of the paper's findings at once: rising rates depress the next year, and entries near the 12-month low work better than entries near the high.</p>
<h3>Every year, after the March results</h3>
<p>We re-run the whole screen on fresh numbers, the same way, every June. Holdings are tested again against each gate. New names that qualify go on the bench first.</p>
<h3>We sell or trim when</h3>
<ul>
<li>Free cash flow turns negative for a full year and is negative over three years. That is the paper's main signal, now pointing the other way.</li>
<li>Assets grow faster than EBITDA for two years running: growth that is no longer paying for itself.</li>
<li>Operating profitability falls below the market median, or return on assets turns negative.</li>
<li>A single holding grows past 20% of the portfolio. We trim it back to 15% and keep the rest running.</li>
</ul>
<h3>We do not sell because</h3>
<ul>
<li>A stock has doubled. The paper studied companies that went up ten times; selling at two is how you never own one.</li>
<li>A quarter was bad, or the market had a bad month.</li>
<li>A company grew past our size limit. The size rule is about where we buy, not about when we sell.</li>
</ul>
''', nxt + 1))

# ---- watchlist, bench, risks
watch = [r for r in D['scored'] if r['status'] == 'watchlist']
bench = [r for r in D['scored'] if r['status'] in ('bench', 'veto')]
wl = ''.join(f'<tr><td><b>{e(r["name"])}</b></td><td class="small">{e(r["industry"])}</td><td class="n">{float(r["price_range"]):.0f}%</td><td class="n">{float(r["ret6m"]):+.0f}%</td></tr>' for r in watch)
short_reason = lambda r: ('Vetoed: spike-and-collapse trading history and figures we could not reconcile' if r['status'] == 'veto' else r['skip_reason'])
bl = ''.join(f'<tr><td>{e(r["name"])}</td><td class="small">{e(short_reason(r))}</td></tr>' for r in bench)
pages.append(page(f'''
<h2>Names we liked but did not buy</h2>
<p>Five companies passed every fundamental test but have already run. The paper is blunt about this: buying near the 12-month high costs you the next year. They wait until the price comes back into the lower half of the range.</p>
<table style="width:150mm"><tr><th>Watchlist</th><th>Industry</th><th class="n">In 52-wk range</th><th class="n">6 months</th></tr>{wl}</table>
<h3 style="margin-top:6mm">The bench</h3>
<p>These passed everything but lost out to a better-ranked company in the same industry, or a sector was already full. They are first in line if a holding is sold.</p>
<table style="width:150mm"><tr><th style="width:32%">Company</th><th>Why not now</th></tr>{bl}</table>
<h3 style="margin-top:6mm">Risks you should weigh</h3>
<ul class="small">
<li>Concentration: this is the whole equity portfolio, and it holds nine stocks, all small. A single bad holding can cost more than 10% of it, and there is no large-cap core to soften a bad year for small caps.</li>
<li>Liquidity: two holdings trade only ₹30 to 35 lakh a day. That is fine for a portfolio of a few crore, not for much more.</li>
<li>Debt: TNPL and RSWM borrow heavily. The paper found debt did not predict returns, but it does decide who survives a bad cycle.</li>
<li>Evidence: one working paper on US stocks. Our translation to India involves judgment calls, listed in the process document.</li>
</ul>
''', nxt + 2))

# ---- notes and disclaimer
pages.append(page(f'''
<h2>Sources and the fine print</h2>
<h3>Data</h3>
<p class="small">Fundamentals and prices: Screener.in, queried on {DATE} across all listed companies with a market value above ₹50 cr, plus individual company pages for the 59 that passed the first stage. Liquidity: NSE and BSE bhavcopies for 28 to 30 October 2026. Company news: exchange filings and press coverage of FY26 and Q1/Q2 FY27 results. Exchange rate assumed ₹88 to the US dollar.</p>
<h3>Research</h3>
<p class="small">Yartseva, A. (2025). <i>The Alchemy of Multibagger Stocks: An empirical investigation of factors that drive outperformance in the stock market.</i> CAFE Working Paper 33, Birmingham City University.<br>
Bessembinder, H. (2018). Do stocks outperform Treasury bills? <i>Journal of Financial Economics</i> 129(3).<br>
Bessembinder, H. (2020). Extreme stock market performers, Part 1: Expect some drawdowns. SSRN 3657604.<br>
Fama, E. and French, K. (2015). A five-factor asset pricing model. <i>Journal of Financial Economics</i> 116(1).<br>
Reserve Bank of India, Monetary Policy Statement, 7 October 2026.</p>
<h3>Important</h3>
<p class="small">This is a private research document for proprietary, personal use and is not to be distributed. It is not investment advice to anyone else, and it does not account for tax. Anyone acting on it for others, or seeking advice on it, should use a SEBI-registered investment adviser. Small-cap stocks are volatile and can lose a large part of their value. Past patterns, including those in the research cited, do not guarantee future results. Figures marked as expectations are estimates, not promises. Data has been checked carefully but may contain errors; please verify prices before acting.</p>
<div class="thread" style="margin-top:10mm"></div>
<p class="hand">The method is meant to be argued with. Re-run it every June.</p>
''', nxt + 3))

doc = f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Nine small companies</title>{FONTS}<style>{CSS}</style></head><body>{"".join(pages)}</body></html>'
open(out, 'w').write(doc)
print('pages', len(pages))
