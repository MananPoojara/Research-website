"""Robustness check: rebuild the portfolio with equal factor weights, same rules as stage2.py."""
import csv, sys
rows = list(csv.DictReader(open(sys.argv[1] + '/stage2.csv')))
K = ['fcf', 'bm', 'range', 'm6', 'm3', 'size', 'roa']
for r in rows:
    r['eq'] = sum(float(r['part_' + k]) for k in K) / len(K)
rows.sort(key=lambda r: -r['eq'])
port, cnt = [], {}
for r in rows:
    if r['status'] == 'veto' or float(r['price_range']) > 50:
        continue
    keys = [('i', r['industry'], 1), ('s', r['sector'], 2), ('b', r['broad_sector'], 4)]
    if any(cnt.get((l, n), 0) >= c for l, n, c in keys) or len(port) == 12:
        continue
    for l, n, _ in keys:
        cnt[(l, n)] = cnt.get((l, n), 0) + 1
    port.append(r['slug'])
base = [r['slug'] for r in csv.DictReader(open(sys.argv[1] + '/stage2.csv')) if r['status'] == 'core']
print('equal-weight portfolio:', port)
print('kept:', len(set(port) & set(base)), 'of', len(base), '| out:', sorted(set(base) - set(port)), '| in:', sorted(set(port) - set(base)))
