"""Process notebook: how the portfolio was built. usage: python3 build_process.py <research_dir> <out.html>"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load, CSS, FONTS, CORPUS, scenarios, cr, lakh, bar_svg, make_page, e

base, out = sys.argv[1], sys.argv[2]
D = load(base)
pages_json = json.load(open(os.path.join(base, 'company_pages.json')))
F = D['funnel']['funnel']; C = D['funnel']['cuts']
scored = D['scored']; port = D['port']
sc_by = {r['slug']: r for r in scored}
dropped = dict(D['s2']['dropped'])
USE = 'Proprietary, for personal use only'

def page(inner, n=None, cls=''):
    return make_page(inner, n, f'How we got here: working notes &nbsp; {USE}', cls)

P = []
# ---- cover (white, quieter than the proposal)
P.append(f'''<section class="page">
<div style="position:absolute;left:34mm;right:20mm;top:58mm">
  <div class="hand" style="font-size:13pt">working notes, not for the client deck</div>
  <h1 style="font-size:32pt;margin:6mm 0 6mm">How we got here</h1>
  <p class="lede" style="max-width:135mm">The full process behind the nine-stock proposal: what the paper says, every judgement call made in applying it to Indian stocks, every filter with its count, and why each stock beat the others in its sector.</p>
  <div class="thread"></div>
  <p class="small">Data as of 30 to 31 October 2026. {USE}.</p>
</div></section>''')

# ---- steps
steps = [
 ('Read the paper itself', 'Downloaded the open-access PDF of Yartseva (2025) from Birmingham City University and worked from its regression tables, not from blog summaries.'),
 ('Build the universe', f'Combined NSE and BSE bhavcopies for 28 to 30 October 2026 by ISIN, kept mainboard equity series only (no SME, no Z or BZ non-compliant series), and required at least ₹25 lakh of average daily trading.'),
 ('Pull fundamentals from Screener', f'Ran one query across every listed company above ₹50 cr market value ({cr(F[0]["n"])} companies), with columns set to the paper\'s variables: market cap, EV, book value, free cash flow (1 and 3 years), EBITDA this year and last, net profit, total assets, ROA, 52-week high and low, 3 and 6 month returns, debt.'),
 ('Stage 1: the Fama-French style gates', 'Size, value, profitability and cash flow, applied the way the paper sorts its sample.'),
 ('Stage 2: company pages for the survivors', 'For the 59 that passed, pulled each company page to measure asset growth against EBITDA growth (the paper\'s investment dummy) and to read Screener\'s sector tags.'),
 ('Rank', 'Scored the 22 finalists on the variables from the paper\'s final dynamic model, weighted by how large each effect was.'),
 ('Build the portfolio', 'One stock per industry, entry only in the lower half of the 52-week range, score-tilted weights.'),
 ('Check against the real world', 'Read the latest results and news for every holding, then checked the key claims against the companies\' own NSE investor presentations (read through the agent-reach web channel): Ahluwalia\'s ₹21,096 cr unexecuted order book, Remsons\' FY26 revenue of ₹469 cr and its ₹300 cr Stellantis order, RSWM\'s FY26 profit of ₹52 cr and Q1 FY27 profit of ₹16.7 cr. All nine prices were also matched to the official NSE closing prices of 30 October 2026 (no differences). This step also produced one veto and two corrections.'),
 ('Set expectations', 'Expected returns from scenario analysis, cross-checked against a cash-yield build-up, and adjusted for the current rate cycle.'),
]
lis = ''.join(f'<tr><td class="n" style="width:8mm"><b>{i}</b></td><td><b>{e(a)}</b><br><span class="small">{e(b)}</span></td></tr>' for i, (a, b) in enumerate(steps, 1))
P.append(page(f'''<h2>The route, in nine steps</h2>
<p>I wanted a process anyone could rerun next June and get the same answer from the same data. So almost every decision below is mechanical. Where I used judgement, it says so.</p>
<table>{lis}</table>''', 2))

# ---- what the paper's model contains
P.append(page('''<h2>What is actually in the paper's model</h2>
<p>Yartseva estimated seven versions of a dynamic panel model on 464 US stocks that rose at least tenfold from 2009 to 2024 (about 11,600 company-years), dropping variables that lost significance. These are the survivors, with coefficient ranges as reported in her Table 5 and the text around it.</p>
<table>
<tr><th style="width:30%">Variable</th><th>Effect on next year's return</th><th style="width:28%">How we use it</th></tr>
<tr><td>FCF / price (free cash flow yield)</td><td>Positive and the largest effect. With book-to-market, a 1% higher ratio goes with 7 to 52% higher returns. Called the most important driver.</td><td>Gate (positive) and 30% of the rank</td></tr>
<tr><td>Book-to-market</td><td>Positive, large, strongly significant. Negative-equity firms lost money.</td><td>Gate (top third) and 20% of rank</td></tr>
<tr><td>Price range in the 52-week band</td><td>Negative, about -0.67 to -0.92 per point. Nearer the high, worse.</td><td>Gate (below 50%) and 20% of rank</td></tr>
<tr><td>3 and 6 month momentum</td><td>Negative, about -0.24 to -0.81. Quick reversals.</td><td>15% of rank (10% six-month, 5% three-month)</td></tr>
<tr><td>Size (log enterprise value)</td><td>Negative in every model; magnitude uncertain.</td><td>Gate (₹250 to 4,400 cr) and 10% of rank</td></tr>
<tr><td>Return on assets</td><td>Positive but small, 0.4 to 1.9.</td><td>Gate (above zero) and 5% of rank</td></tr>
<tr><td>Investment dummy (assets growing faster than EBITDA)</td><td>Negative, 4 to 11 points lower excess return in dynamic models; larger in static ones.</td><td>Gate (must be 0)</td></tr>
<tr><td>Rising policy-rate year</td><td>Negative, about 8 to 12 points. Market-wide, so not a stock selector.</td><td>Staged buying</td></tr>
<tr><td>Market return</td><td>Positive, 0.54 to 0.93. These stocks move with the market.</td><td>Expectation setting</td></tr>
</table>
<h3>Tested and found not to matter</h3>
<p>Growth of sales, EBITDA, EPS and free cash flow, over one year or five. Debt-to-capital, debt cover, the Altman score. Buybacks, dividends, debt changes. R&amp;D intensity. The P/E ratio, which she dropped as unusable because it breaks for loss-makers and near-zero earnings. Some of these surprised me, especially growth. I followed the paper anyway.</p>
<p class="hand" style="margin-top:4mm">the "growth doesn't matter" finding is the one people will push back on. it's in her data.</p>''', 3))

# ---- judgement calls
calls = [
 ('Universe', 'NYSE and Nasdaq listed stocks', 'NSE and BSE mainboard, at least ₹25 lakh traded a day', 'The paper excluded OTC stocks. Our liquidity floor does the same job and keeps the portfolio investable.'),
 ('Lenders and insurers', 'Included', 'Excluded', 'Free cash flow and EBITDA, the two key variables, are not meaningful for a bank. Removed by name first, then by Screener\'s sector tag.'),
 ('Size', 'Terciles within the sample; median start about $348M', f'₹{C["size_floor_cr"]:.0f} cr to ₹{cr(C["size_ceiling_cr"])} cr market cap', 'Absolute, not relative: the size effect is about room to grow, which is measured in money. $500M (the median start in today\'s dollars) at ₹88/$.'),
 ('Value', 'Terciles by book-to-market', f'Top third of our universe, B/M ≥ {C["bm_top_third"]:.2f}', 'Relative, because Indian valuations sit structurally higher than US ones. Requiring B/M above 1 would leave mostly state-owned commodity firms.'),
 ('Profitability', 'Operating profit / book equity, median split; ROA in the dynamic model', f'EBITDA / book equity ≥ median ({C["ebitda_to_equity_median"]*100:.0f}%) and ROA > 0', 'Both of the paper\'s measures used.'),
 ('Free cash flow', 'FCF / price, continuous', 'FCF > 0 last year and over 3 years; ranked on the average of the 1-year and 3-year yields', 'The paper calls cash yield "robust". Averaging two windows stops one lucky year of working capital from dominating.'),
 ('Investment', 'Dummy = 1 if asset growth > EBITDA growth', 'Same rule on FY26 vs FY25 annual figures. Also require assets to be growing.', 'Shrinking firms were the worst group in her sorts (assets -6.8% a year, weak profits).'),
 ('Entry', 'Price range and momentum in the regression', 'Lower half of the 52-week range to buy; position in the range and recent returns in the score', 'Strong-fundamentals stocks above the line go to a watchlist rather than being dropped.'),
 ('Portfolio building', 'Not addressed by the paper', 'One stock per industry, two per sector, four per broad sector; one veto (CIAN Agro)', 'The two choices not taken from the paper, both kept deliberately. A paper-only top nine would swap Remsons and Ahluwalia for Banswara Syntex and Snowman Logistics, doubling up on textiles and logistics.'),
 ('Size measure', 'Enterprise value', 'Market cap for the gate; EV not used', 'Screener\'s EV is available, but cash is not netted consistently. Market cap is cleaner for a gate.'),
]
rows = ''.join(f'<tr><td><b>{e(a)}</b></td><td class="small">{e(b)}</td><td class="small">{e(c)}</td><td class="small">{e(d)}</td></tr>' for a, b, c, d in calls)
P.append(page(f'''<h2>Every judgement call in the translation</h2>
<p>A US study cannot be pasted onto Indian data. These are the places where I had to decide something, and why.</p>
<table><tr><th style="width:16%">Item</th><th style="width:22%">In the paper</th><th style="width:27%">What we did</th><th>Why</th></tr>{rows}</table>''', 4))

# ---- funnel
labels = ['Every company above ₹50 cr', 'Liquid mainboard (≥ ₹25 lakh/day)', 'Not a lender, data complete', 'Small (₹250 to 4,400 cr)',
          'High value (top third B/M)', 'Robust profitability', 'Positive free cash flow']
fun = [(lab, f['n']) for lab, f in zip(labels, F)]
s2_in = D['s2']['stage2_in']; n_scored = D['s2']['scored']
n_fin = sum(1 for _, why in D['s2']['dropped'] if why.startswith('G6a'))
n_shrink = sum(1 for _, why in D['s2']['dropped'] if 'shrinking' in why)
n_inv = sum(1 for _, why in D['s2']['dropped'] if 'faster' in why)
fun += [('Not a lender (sector check)', s2_in - n_fin), ('Assets growing, not faster than EBITDA', n_scored),
        ('In the portfolio', len(port))]
chart = bar_svg(fun, w=158, fmt=lambda v: cr(v), h=7.0, lab_w=66)
P.append(page(f'''<h2>The funnel</h2>
<p>From {cr(F[0]["n"])} companies to {len(port)}. The size cut removes the most, and that is deliberate: the paper's whole premise is that small companies have the room to multiply. The value and profitability gates then remove about seven in eight of what is left.</p>
{chart}
<table style="margin-top:6mm;width:150mm"><tr><th>Stage 2 outcome for the {s2_in} stage-1 survivors</th><th class="n">Companies</th></tr>
<tr><td>Lenders or holding companies caught by Screener's sector tag</td><td class="n">{n_fin}</td></tr>
<tr><td>Assets grew faster than EBITDA (the paper's investment dummy = 1)</td><td class="n">{n_inv}</td></tr>
<tr><td>Assets shrinking</td><td class="n">{n_shrink}</td></tr>
<tr><td>Scored and ranked</td><td class="n">{n_scored}</td></tr>
<tr><td style="padding-left:6mm">of which bought / watchlist / bench / vetoed</td><td class="n">{sum(r["status"]=="core" for r in scored)} / {sum(r["status"]=="watchlist" for r in scored)} / {sum(r["status"]=="bench" for r in scored)} / {sum(r["status"]=="veto" for r in scored)}</td></tr></table>''', 5))

# ---- the 59, two pages
def row59(r):
    s = r['slug']; pj = pages_json.get(s, {})
    if s in sc_by:
        st = sc_by[s]['status']; out = {'core': 'Bought', 'watchlist': 'Watchlist', 'bench': 'Bench', 'veto': 'Vetoed'}[st]
        out = f'<span class="tag {"watch" if st=="watchlist" else st}">{out}</span> rank {sc_by[s]["rank"]}'
    else:
        why = dropped.get(s, '')
        out = e(why.split(' ', 1)[1] if why.startswith('G6') else why)
    return (f'<tr><td>{e(r["name"])}</td><td>{e(pj.get("industry", ""))}</td><td class="n">{cr(r["mcap"])}</td>'
            f'<td class="n">{1/r["bm"]:.2f}</td><td class="n">{r["fcf_yield"]*100:.1f}%</td><td>{out}</td></tr>')
short = sorted(D['short'], key=lambda r: (int(sc_by[r['slug']]['rank']) if r['slug'] in sc_by else 99, r['name']))
head = '<tr><th>Company</th><th>Industry</th><th class="n">Mkt cap ₹ cr</th><th class="n">P/B</th><th class="n">FCF yld</th><th>Stage 2 outcome</th></tr>'
chunks = [short[i:i + 20] for i in range(0, len(short), 20)]
for k, chunk in enumerate(chunks):
    title = f'<h2>All {len(short)} stage-1 survivors and what happened to them</h2><p class="small">Sorted by final rank, then by name. Asset and EBITDA growth compare FY26 with FY25.</p>' if k == 0 else '<h2 style="font-size:12pt">Stage-1 survivors, continued</h2>'
    P.append(page(f'{title}<table class="tight" style="font-size:7.8pt">{head}{"".join(row59(r) for r in chunk)}</table>', 6 + k))

# ---- scoring
W = D['s2']['weights']
names = {'fcf': 'FCF yield (1y and 3y average)', 'bm': 'Book-to-market', 'range': 'Low in 52-week range', 'm6': 'Weak last 6 months',
         'm3': 'Weak last 3 months', 'size': 'Smaller market cap', 'roa': 'Return on assets'}
wt = ''.join(f'<tr><td>{names[k]}</td><td class="n">{v*100:.0f}%</td></tr>' for k, v in W.items())
sr = ''
for r in scored:
    parts = ''.join(f'<td class="n">{float(r["part_"+k])*100:.0f}</td>' for k in W)
    st = r['status']
    sr += (f'<tr><td class="n">{r["rank"]}</td><td>{e(r["name"])}</td>{parts}<td class="n"><b>{float(r["score"]):.2f}</b></td>'
           f'<td><span class="tag {"watch" if st=="watchlist" else st}">{ {"core":"Bought","watchlist":"Watch","bench":"Bench","veto":"Veto"}[st] }</span></td></tr>')
ph = ''.join(f'<th class="n">{h}</th>' for h in ['FCF', 'B/M', 'Range', '6m', '3m', 'Size', 'ROA'])
P.append(page(f'''<h2>How the finalists were ranked</h2>
<p>Each finalist gets a percentile (0 to 100) against the other {len(scored)} on each variable, and the score is a weighted sum. The weights follow the size of the paper's coefficients: cash yield and value first, then where the price sits in its range, then reversal, size and ROA. Percentiles rather than raw values, so one extreme number cannot run the ranking.</p>
<div class="grid2" style="grid-template-columns:70mm 1fr"><table><tr><th>Variable</th><th class="n">Weight</th></tr>{wt}</table>
<p class="small" style="margin:0">As a check I reran everything with all seven variables weighted equally. Eight of the nine holdings stay the same; the one change is Banswara Syntex in place of RSWM, its textile neighbour. With cash yield weighted most heavily, as the paper's results imply, RSWM wins, so the weighted version stands.</p></div>
<table class="tight" style="margin-top:4mm;font-size:7.8pt"><tr><th class="n">#</th><th>Company</th>{ph}<th class="n">Score</th><th></th></tr>{sr}</table>''', 9))

# ---- sector by sector
groups = {}
for r in scored:
    groups.setdefault(r['broad_sector'], []).append(r)
blocks = ''
for sec, rs in sorted(groups.items(), key=lambda x: -sum(float(r['weight'] or 0) for r in x[1] if r.get('weight'))):
    items = ''
    for r in rs:
        st = r['status']
        tag = f'<span class="tag {"watch" if st=="watchlist" else st}">{ {"core":"Bought","watchlist":"Watch","bench":"Bench","veto":"Veto"}[st] }</span>'
        why = {'core': f'rank {r["rank"]}, score {float(r["score"]):.2f}; best-ranked in {e(r["industry"])}'}.get(st, e(r['skip_reason']))
        items += f'<tr><td style="width:30%">{e(r["name"])}</td><td style="width:13%">{tag}</td><td class="small">{why}</td></tr>'
    blocks += f'<h3 style="margin:3.5mm 0 1mm">{e(sec)}</h3><table class="tight">{items}</table>'
P.append(page(f'''<h2>Sector by sector: why this one and not that one</h2>
<p>The rule is simple: within an industry, the higher score wins. A stock that passed everything can still lose to a better one next to it. These are the head-to-heads that decided the portfolio.</p>{blocks}''', 10))

# ---- close calls + construction + returns
sc, ev = scenarios()
cash = sum(r['weight'] * min(float(sc_by[r['slug']]['fcf_blend']), .12) for r in port)
P.append(page(f'''<h2>Close calls, weights and the return estimate</h2>
<h3>The close calls, honestly</h3>
<p><b>Dollar over Monte Carlo</b> (0.48 vs 0.47). Monte Carlo has slightly better cash; Dollar sits lower in its range and has a better ROA. This was nearly a coin toss and I would not argue hard either way.</p>
<p><b>RSWM over Banswara Syntex</b> (0.61 vs 0.60). Close on score, but RSWM's cash yield (about 23% blended) dwarfs Banswara's (about 4%). On the paper's most important variable it is not close.</p>
<p><b>Gateway over Snowman</b>. Snowman's ROA is 0.5% and its EBITDA grew 2%. Gateway wins on almost everything.</p>
<p><b>Sai Silks over Go Fashion and Credo (Mufti)</b>. Both rivals failed the investment test once current standalone figures were used. Their EBITDA fell 11% and 13% while assets still grew.</p>
<h3>Weights</h3>
<p>Start equal, scale each holding by (0.5 + score), clip between 7% and 15%, and renormalise. That gives {min(r["weight"] for r in port)*100:.1f}% to {max(r["weight"] for r in port)*100:.1f}%. The tilt is mild on purpose: the paper's model explains returns on average, not which single name wins.</p>
<h3>Expected return</h3>
<p>Scenarios: bear {sc[0]["cagr"]*100:.0f}%, base {sc[1]["cagr"]*100:.0f}%, bull {sc[2]["cagr"]*100:.0f}% a year over ten years, weighted 25/50/25, giving {ev*100:.1f}%. Cross-check: portfolio cash yield with each holding capped at 12% is {cash*100:.1f}%. Add 9 to 10% nominal growth and take off 3 to 4 points for failures, and you get roughly 15 to 16%. No re-rating assumed.</p>
<p>I did not plug the paper's coefficients in directly. They were estimated only on stocks that became tenbaggers, so they would wildly overstate what a forward-looking basket can expect. The paper's 30 to 40% average returns belong to the winners after the fact, not to us before it.</p>''', 11))

# ---- problems log + limitations
P.append(page('''<h2>What went wrong along the way, and what I did</h2>
<table>
<tr><th style="width:32%">Problem</th><th>Fix</th></tr>
<tr><td>Screener rate-limits logged-out access to about 2 to 3 company pages a minute.</td><td>Ran the screen as a single logged-in Screener query and export. That is faster, and it covers every company instead of a sample.</td></tr>
<tr><td>Screener has no "total assets preceding year" column, which the investment test needs.</td><td>Pulled the company pages for the 59 stage-1 survivors and computed it from the balance sheets.</td></tr>
<tr><td>For six companies the consolidated statements on Screener stopped years ago (Go Fashion's at FY18), so the first pass compared stale years.</td><td>Re-pulled standalone statements for those six. Result: Credo (Mufti), Go Fashion and Gulshan Polyols dropped out; Sai Silks and Kothari Petrochemicals came in.</td></tr>
<tr><td>A name filter for lenders missed two small finance banks, a broker, a holding company and an investment company.</td><td>Caught in stage 2 by Screener's own sector tag.</td></tr>
<tr><td>CIAN Agro scored eighth, but its standalone profit is near zero against ₹223 cr consolidated, it fell 58% in a month in late 2025, and BSE asked it to explain unusual volumes.</td><td>Vetoed. This is the only manual override. The paper itself removed spike-and-collapse "transitory" multibaggers from its sample.</td></tr>
<tr><td>TNPL's FY26 profit includes a one-off ₹219 cr deferred tax reversal.</td><td>Left in, because the gates rely on EBITDA and cash, not net profit. It only flatters ROA, which carries 5% of the score. Flagged in the proposal.</td></tr>
</table>
<h3>Limitations I would want a client to know</h3>
<ul class="small">
<li>One working paper, not peer reviewed, on US stocks. Its sample contains only winners, so it shows what winners looked like, not how often stocks that look like that go on to win.</li>
<li>India's market is younger, more promoter-controlled and more retail-driven. None of the paper's coefficients have been tested here.</li>
<li>Rupee conversion at ₹88/$ is approximate; the size ceiling moves about ±₹250 cr for ±₹5 on the exchange rate.</li>
<li>Screener data can contain errors, and annual figures lag. Prices are as of 30 October 2026.</li>
<li>Nine stocks is concentrated, and this is meant to be the whole equity portfolio. A twenty-stock version would need relaxing the one-per-industry rule; that is the first thing I would test if the drawdown risk feels too high.</li>
</ul>
<h3>Files</h3>
<p class="small">The full data sit next to this document: <b>stage1_all_companies.csv</b> (every company with every metric and the first gate it failed), <b>stage2_finalists.csv</b> (the scored 22 with factor percentiles), and the scripts in <b>scripts/</b> to rerun the whole thing.</p>''', 12))

doc = f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>How we got here</title>{FONTS}<style>{CSS}</style></head><body>{"".join(P)}</body></html>'
open(out, 'w').write(doc)
print('pages', len(P))
