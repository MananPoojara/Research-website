"""One-page notice prepended to the Oct-31 documents. usage: python3 build_superseded.py <out.html>"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import CSS, FONTS

doc = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Superseded</title>{FONTS}<style>{CSS}</style></head><body>
<section class="page"><div style="position:absolute;left:34mm;right:20mm;top:58mm">
<div class="hand" style="font-size:13pt">read this first</div>
<h1 style="font-size:32pt;margin:6mm 0 6mm">This document is superseded</h1>
<p class="lede" style="max-width:135mm">It describes the nine-stock portfolio built from the screen on 31 October 2026. On 2 November 2026 every holding was put through governance, guidance, fundamentals and valuation checks against company filings. Six of the nine failed, including the top-ranked Sai Silks (Kalamandir).</p>
<p class="lede" style="max-width:135mm">The current portfolio and the reasons for every change are in <b>Due Diligence Verdicts - Nov 2026.pdf</b>. The pages that follow are kept as the record of how the screen was built and what it found, not as a recommendation.</p>
<div class="thread"></div>
<p class="small">Proprietary, for personal use only.</p>
</div></section></body></html>'''
open(sys.argv[1], 'w').write(doc)
