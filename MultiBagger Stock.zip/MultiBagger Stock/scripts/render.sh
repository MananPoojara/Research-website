#!/usr/bin/env bash
# usage: render.sh <in.html> <out.pdf> <png-prefix>
set -e
google-chrome --headless=new --disable-gpu --no-pdf-header-footer --run-all-compositor-stages-before-draw --virtual-time-budget=15000 --print-to-pdf="$2" "$1" 2>/dev/null
rm -f "$3"-*.png; pdftoppm -r 60 -png "$2" "$3"; pdfinfo "$2" | grep Pages
