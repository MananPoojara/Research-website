# Antony Waste Handling Cell (NSE: AWHCL) — Due Diligence, 2 Nov 2026

**Snapshot (screener.in, 2 Nov 2026):** Price Rs 289 | Mcap Rs 820 cr | P/E 14.0 (TTM EPS 20.6) | P/B 1.1 (BV Rs 260) | ROCE 11.2% | ROE 10.9% | 52w 273–605 | Promoter 46.08% | Q2 FY27 results due 5 Nov 2026.
Business: municipal solid-waste collection & transport (62% of revenue), processing/tipping fees (28%), WtE (Pimpri-Chinchwad), C&D, mechanised sweeping; 23+ municipal clients, none >25% of revenue (CARE). Promoters Jose Jacob Kallarakal (CMD) and brother Shiju Jacob Kallarakal (ED).

## VERDICT: HOLD-FOR-REVIEW (re-check after 5 Nov Q2 print and PCMC restart in Dec 2026)

1. **The collapse is explained by earnings, not by lost contracts.** Q1 FY27 PAT Rs 0.7 cr (–97%), EBITDA margin 16.8% vs 24.4%; on 8 Jul 2026 a legacy landfill collapsed onto the PCMC WtE plant killing 9 employees — power generation suspended (Q2 FY27: zero vs 14 mn units), Rs 22–24 cr impairment flagged, processing volumes –7% YoY. FIIs cut from 14.8% to 10.8% in two quarters. Order book (~Rs 18,000 cr), BMC (Rs 1,330 cr/7y) and NMMC (Rs 908 cr/9y) wins are intact.
2. **Guidance credibility is damaged.** 22–23% EBITDA margin (Q3 FY26 call) → 20–22% (Q4 FY26) → 16.8% and 14.3% delivered; FY27 revenue target Rs 1,200 cr vs H1 core revenue +3.8% (run-rate ~Rs 1,080 cr). "One-offs" invoked in three consecutive quarters.
3. **Valuation already prices much of it.** P/B 1.1, EV/EBITDA ~6x on depressed TTM, ~8–9x P/E on normalised PAT; 5y CFO/PAT 1.4x. Governance is acceptable but not pristine (family executive board, 112 receivable days, Kanjurmarg litigation, e-bus SPV diversification).

## GATE 1 — GOVERNANCE: WATCH
- **Promoter holding:** flat at 46.1–46.2% since listing (Dec 2020); no pledge flagged by screener (BSE pledge table not independently verified). FII fall from 28.2% (Mar 21) to 11.8% (Mar 22) was the pre-IPO PE investors (Mauritius vehicles) exiting after lock-in — historic, not current.
- **Family KMP:** CMD Jose Jacob and brother Shiju Jacob are both named promoters (CARE); Shiju given a fresh 5-year executive term from 28 Jul 2026. Long-standing founder involvement rather than new nepotism, but no professional CEO layer. CEO pay ~Rs 2.2 cr (FY25) ≈ 2% of PAT — reasonable.
- **RPTs:** Jul 2026 acquisition of 26% in Arts EV Pvt Ltd (Delhi e-bus SPV under PM E-DRIVE) with Antony Group (automotive body-building) — related, "arm's length", outside core waste competence. Frequent corporate guarantees to subsidiaries (Oct 2026 x2). Antony Lara JV structures with minority partners.
- **Auditor/SEBI:** No auditor resignation, qualification or SEBI action found. Screener flags "tax rate seems low" — negative tax in Mar-24, Dec-25, Mar-26 (deferred-tax credits) flatters PAT.
- **Litigation:** Kanjurmarg (largest single site, concession to 2036): Bombay HC May 2025 order on de-notification of 120 ha; Supreme Court stayed it Aug 2025 on AWHCL's SLP — unresolved. PCMC fatalities: investigations ongoing; company says asset outside its perimeter, insured.

## GATE 2 — GUIDANCE & DELIVERY: WATCH (leaning FAIL)
| Period | Guided | Delivered |
|---|---|---|
| FY25 | 15–20% growth aspiration, margin 22–23% | TOI +8%, PBILDT 21.9% |
| FY26 | 20–22% margin | +13% revenue, 20% OPM; Q3 16.3% |
| Q3 FY26 call | FY27 revenue Rs 1,200 cr; 22–23% margin | Q1 FY27 16.8%; H1 core rev +3.8% |
| Q4 FY26 call | 15–20% revenue CAGR 5y; 20–22% margin; Rs 750 cr capex | Q1 PAT Rs 0.7 cr; Q2 revenue –1% |
- Latest (17 Oct 2026 business update): PCMC WtE "expected to be functional by December 2026"; C&T +11.5% on BMC/NMMC ramp; RDF +23%; no formal numeric guidance reinstated. No stated guidance cut — it has simply gone quiet.

## GATE 3 — FUNDAMENTALS: WATCH
| | FY21 | FY24 | FY25 | FY26 | TTM |
|---|---|---|---|---|---|
| Sales (Rs cr) | 465 | 866 | 934 | 1,053 | 1,067 |
| OPM | 25% | 20% | 21% | 20% | 18% |
| PAT | 64 | 100 | 101 | 92 | 70 |
| Interest / Depn | 28/31 | 40/53 | 56/70 | 61/86 | 66/87 |
| Borrowings | 154 | 447 | 505 | 459 | |
| Debtor days | 70 | 106 | 104 | 112 | 114 (Q1) |
| ROCE | 18% | 14% | 12% | 11% | |
| CFO | 112 | 140 | 188 | 143 | |
- 5y CAGR: sales 18%, PAT ~8%; 3y: sales 7%, PAT 3%. Last 2 qtrs: Mar-26 sales +18%/PAT –20%; Jun-26 sales +6%/PAT –97%.
- D/E 0.62 gross, 0.4 net; interest cover 3.25x (9M FY26, CARE) falling toward ~2.5x on Q1 run-rate — screener flags low coverage. Refinancing cut WtE loan to 8.25% (saves ~Rs 4 cr/yr).
- Working capital: receivables Rs 265 cr (Mar 25) incl ~Rs 70 cr retention; collection period 120–130 days; CARE wants <90. Municipal budget delays are structural.
- CFO 5y (FY22–26) Rs 666 cr vs PAT Rs 468 cr — strong conversion, but cumulative FCF –Rs 123 cr because contracts are capex-heavy (Rs 750 cr more planned FY27–29, debt-funded).
- Moat: entrenched incumbency with BMC/NMMC/PCMC, two decades of tender wins, 11.5x order-book/revenue; but tender-based, regulatory and counterparty risk, and WtE adds operating/safety risk.
- Ratings: CARE BBB+/Stable (Apr 2026), subsidiaries A–.

## GATE 4 — VALUATION: PASS (cheap, with reasons)
- P/E 14 on trough TTM; ~8–9x on normalised PAT Rs 90–100 cr. P/B 1.1 vs 2–3x in 2021–24. EV ≈ Rs 1,150 cr (820 + 459 – ~130 cash) / TTM EBITDA Rs 188 cr ≈ 6x vs own 10–15x history. Few listed Indian MSW peers; infra/EPC peers trade 8–12x EBITDA.
- 3-yr scenarios: bull — PCMC restarts Dec 2026, margin reverts to 20%, FY29 revenue ~Rs 1,350 cr, PAT ~Rs 110 cr at 12x ≈ Rs 1,320 cr (+60%); bear — impairment larger, margin stuck 16%, receivables stress, PAT ~Rs 50 cr at 10x ≈ Rs 500 cr (–40%). Roughly symmetric; needs confirmation before SELECT.

## What would move it to SELECT / REJECT
- SELECT: Q2 FY27 (5 Nov) EBITDA margin back ≥18% ex-PCMC, impairment ≤ Rs 25 cr, insurance recovery disclosed, debtor days <110, PCMC restart on schedule.
- REJECT: margin <16% again with new "one-offs", receivable write-offs, PCMC restart slips past FY27, or more capital diverted to non-waste SPVs.

## Sources
- screener.in/company/AWHCL/consolidated/ (financials, shareholding, announcements)
- CARE Ratings press release, 10 Apr 2026 (BBB+/A3+ reaffirmed; receivables Rs 265 cr, collection 120–130 days, interest cover 3.82x/3.25x, Kanjurmarg litigation)
- NSE: AWHCL Q1 FY27 press release (11 Aug 2026); Q2 FY27 business update (17 Oct 2026)
- multibagg.ai Q1 FY27 summary (impairment Rs 22–24 cr, employee cost 34%, Greater Noida Rs 243 cr contract)
- Arthneeti Q4 FY26 and Q3 FY26 call analyses (guidance: 20–22% margin, Rs 1,200 cr FY27 revenue, Rs 750 cr capex, order book Rs 18,000 cr)
- Trade Brains 13 Jul 2026 — landfill collapse, 9 deaths, Rs 25 lakh ex gratia; Univest/Swastika blogs (FII selling, de-rating)
- FilingReader 4 Aug 2025 — Supreme Court stays Bombay HC Kanjurmarg order; ScanX Jul 2026 — Shiju Jacob 5-yr ED term; Arts EV 26% stake
- Simply Wall St — CEO compensation Rs 2.2 cr FY25
- Not retrieved: FY26 annual report (full RPT schedule, auditor), Q1 FY27 transcript, BSE pledge table.
