# Bhagyanagar India (NSE: BHAGYANGR) — Due Diligence, 2 Nov 2026

**Verdict: REJECT** | G1 Governance: FAIL | G2 Guidance & delivery: WATCH | G3 Fundamentals: FAIL (for the listed stub) | G4 Valuation: FAIL

**The brief's premise is stale.** The copper business (all of the revenue, the ~20% ROCE and the Rs 5,000 cr FY30 target) was demerged into Tieramet Ltd (NCLT Hyderabad order 7 Sep 2026; record date 8 Oct 2026; 1:1, 3.35 cr Tieramet shares allotted 9 Oct 2026; Tieramet not yet listed as of 2 Nov). What trades as BHAGYANGR today is a **stub holding a windmill and three Hyderabad land parcels**. Price Rs 89.8 (5% upper circuit), mcap ~Rs 301 cr on 3.35 cr shares. Screener's P/E 4.8 / ROCE 20% describe the business that left.

## Gate 1 — Governance: FAIL
- **Criminal/PMLA cloud over the promoter family.** Narender Surana — brother of MD Devendra Surana, co-promoter with him of Surana Telecom & Power (where Devendra is a director) and of common vehicles Surana Infocom / Bhagyanagar Securities — was arrested by Cyberabad EOW in Nov 2024 (IPC 420/406/467/468/471, 120B) as MD of Bhagyanagar Properties in the Sai Surya Developers / "Green Meadows" plot-cheating case. ED registered a PMLA case, searched Surana group premises on 16-17 Apr 2025, seized Rs 74.5 lakh cash and alleges ~Rs 100 cr of unaccounted transactions. No chargesheet/bail outcome found. He is not on BIL's board, but the new BIL is a *real-estate monetisation vehicle* run by the same family whose real-estate arm is under ED investigation.
- **GST / fake-ITC exposure**: FY25 demand of **Rs 103.35 cr (incl. Rs 51.7 cr penalty)** for allegedly inadmissible input tax credit — Rs 8 cr deposited under protest, *no provision*; a second DGGI SCN (26 May 2026) for Rs 17.5 cr **names the MD**, paid under protest. Contingent liabilities Rs 108 cr vs the stub's book equity of ~Rs 21 cr. ITC disputes in copper-scrap trading are a classic circular-trading red flag.
- **Promoter holding fell 73.8% (Dec-23) to 65.9% (Sep-26)**, -8.5 pts in 3 years; forum explanation is reclassification of a group holding plus dilution. Preferential issue of 15.01 lakh shares at Rs 348 to 7 undisclosed non-promoter investors (Rs 52 cr, allotted 13 Aug 2026) two months before the demerger — they received Tieramet shares 1:1; lock-in ends 15 Mar 2027.
- **CFO Surendra Bhutoria ceased 7 Oct 2026, no successor named**; Executive Director V. Rao Nukala resigned within ~a year of appointment. Auditor Luharuka & Associates (small Hyderabad firm, term to 2027), unqualified. RPTs: power purchases from Surana Solar Systems, dealings with Surana Telecom & Power and the merged Bhagyanagar Copper Pvt Ltd — amounts not disclosed in any accessible filing (AOC-2 annexure unavailable). MD pay modest (5.56x median). No dividend despite profits.

## Gate 2 — Guidance & delivery: WATCH
- Copper-era guidance (Jan-May 2026): ~20% volume growth to ~30k MT, Rs 150 cr fundraise, Rs 5,000 cr revenue by FY30, AI data-centre busbar expansion. Delivered: FY26 revenue +46% to Rs 2,378 cr, PAT Rs 50 cr; Q1 FY27 revenue Rs 705 cr, PAT Rs 20.2 cr (+167%). Fundraise came in at Rs 52 cr vs Rs 150 cr talked. All of this now belongs to Tieramet.
- For the stub there is **no stated plan** beyond the 12 Oct 2026 MoU: 7,260 sq yd at IDA Uppal to Om Sree Builders & Developers LLP for Rs 60 cr (stated non-RPT); balance Uppal land into joint development. Unverified coverage cites a ~4 lakh sq ft eastern-Hyderabad parcel "worth Rs 200-300 cr" and 4 lakh sq ft of free built area from the Uppal JD. No timelines, no valuation report. Q2 FY27 results not yet published (no board-meeting intimation found as of 2 Nov).

## Gate 3 — Fundamentals: FAIL (stub)
- Pre-demerger consolidated: 5-yr sales CAGR 25%, PAT CAGR 68%, FY26 OPM 4.5%, ROCE 20%, but **CFO negative in 7 of 12 years** (FY21 -76, FY23 -40, FY25 -144 cr) — a working-capital-hungry trader; borrowings Rs 259 cr at Mar-26. Debt went with the copper business.
- Stub: net worth immediately pre-demerger Rs 198.7 cr, of which 10.64% (~Rs 21 cr) stays with BIL; retained assets (land + windmill) carried at ~Rs 30 cr book. No recurring operating business; earnings will be lumpy land-sale gains taxed at capital-gains rates. No moat; value depends entirely on Hyderabad land prices and the family's willingness to monetise for minorities.

## Gate 4 — Valuation: FAIL
- Mcap Rs 301 cr vs stub book ~Rs 21-30 cr (P/B ~10-14x). Implied stub value at demerger (10.64% of the ~Rs 430 pre-split price) was ~Rs 46; it has roughly doubled in three weeks on land-sale headlines and is on upper circuits.
- Rough SOTP: Uppal sale Rs 60 cr + remaining Uppal JD (optimistic Rs 100-150 cr NPV) + other parcel (unverified Rs 200-300 cr) = Rs 360-510 cr gross, less ~20% tax, less Rs 103-120 cr contested GST, less holding-company discount → **Rs 150-300 cr**. Current price is at/above the optimistic end. 3-yr upside case ~+30% if every parcel is sold at claimed prices and GST is won; downside -50%+ if GST demand sticks or the family sits on the land.

## Verdict: REJECT
1. Governance FAIL: promoter's brother and the group's real-estate arm are under EOW/ED investigation for plot fraud; Rs 103 cr unprovided GST-ITC demand plus a second SCN naming the MD; CFO exit with no replacement.
2. The listed entity is no longer the copper compounder in the brief — it is a thinly-disclosed land holding with ~Rs 21 cr book equity and no operating business or guidance.
3. Priced at 10x+ book on unverified land values after a post-demerger spike; asymmetric downside. If one wants the copper business, look at Tieramet when it lists — with the same promoter-group caveats.

## Sources
- https://www.screener.in/company/BHAGYANGR/consolidated/
- https://www.sahi.com/news/bhagyanagar-india-gets-nclt-approval-for-copper-split-1-1-share-exchange-approved-950-PE1_CORP
- https://www.multibagg.ai/market-pulse/articles/bhagyanagar-india-tieramet-demerger-dates-cmv11xab5000j39qpkznej2h2 ; https://www.multibagg.ai/market-pulse/articles/bhagyanagar-india-nclt-demerger-land-sale-cmv5a7wwp000z38ppeb63c3li
- https://www.arthneeti.com/announcements/bhagyanagar-ind-update-allotment-of-equity-shares-by-tieramet-limited-the-resulting-company-to-the-shareholders-of-bhagyanagar-india-limited-the-compa-09-oct-2026
- https://nsearchives.nseindia.com/corporate/BHAGYANGR_12102026175201_BIL-Board_Meeting_Outcome.pdf (Uppal land MoU)
- https://www.indiainfoline.com/company/bhagyanagar-india-ltd/directors-report/2329 (FY26 Directors' Report: board, GST demands, auditor)
- https://scanx.trade/stock-market-news/companies/bhagyanagar-india-faces-dggi-notice-over-17-50-crores-tax-liability/41437016
- https://www.sahi.com/news/bhagyanagar-india-cfo-surendra-bhutoria-to-cease-role-effective-october-7
- https://newsmeter.in/crime/cyberabad-sai-surya-developers-owner-arrested-for-cheating-rs-145-crores-in-the-guise-of-selling-plots-738295
- https://www.tribuneindia.com/news/india/ed-raids-in-hyderabad-surana-group-sai-surya-developers-under-lens-in-money-laundering-case/amp ; https://www.thenewsminute.com/telangana/ed-seizes-rs-74-lakh-cash-during-searches-at-hyderabad-firms-premises
- https://www.storyboard18.com/digital/mahesh-babu-summoned-by-ed-over-rs-100-crore-real-estate-scam-62943.htm
- https://www.marketscreener.com/quote/stock/SURANA-TELECOM-AND-POWER-46729329/news/ (Narender & Devendra Surana co-promoters of Surana Telecom)
- https://www.tribuneindia.com/news/business/bhagyanagar-india-ltd-targets-inr-5000-crore-revenue-by-fy-2029-30-amid-expansion-plans-spearheaded-by-devendra-surana/
- https://forum.valuepickr.com/t/bhagyanagar-india-ltd-copper-recycling-play/218879?page=2 (concall takeaways, unverified)
- https://www.kotakneo.com/financial-results/bhagyanagar-india-share-price-q1fy2026-27-results/
