# Siyaram Silk Mills (NSE: SIYSIL) — Due Diligence, 2 Nov 2026

**Snapshot:** CMP Rs 458 | Mcap Rs 2,076 cr | P/E 9.2 | P/B 1.75 | Div yield 2.6% | ROCE 18.8% | ROE 14.9% | Promoter 67.45% | 52w 433–850 (price -41% in 1 yr)
**Latest:** Q2 FY27 (Sep-26) reported 27 Oct 2026.

## GATE 1 — GOVERNANCE: WATCH

- **Promoter holding / pledge:** 67.45%, flat for 3 years; no pledge found. Minor promoter individuals have been exiting: Abhishek S. Poddar sold his entire 0.44% (Mar + Jun 2026); Harshit S. Poddar moved 1.28% to DPP Enterprises LLP (inter-se, Aug 2026). Small, but a 0.44% promoter selling to zero at a 52-week low is not a confidence signal.
- **Family KMP:** Board is Poddar-run: Ramesh D. Poddar (CMD), Pawan D. Poddar (Joint MD since 2014), Shrikishan D. Poddar (ED), Gaurav P. Poddar (President & ED, son of Pawan; fronts the concalls). Filings confirm all four are "related". Non-family professionals exist (Ashok Jalan, Sr President & Director; CFO Surendra Shetty; Dinesh Jaithliya elevated to Deputy CFO from 1 Nov 2026). Four promoter whole-time directors paid as a % of net profit. Family succession is in place but at least there is a professional operating layer.
- **Promoter remuneration:** Reg 23(9) filings show KMP managerial remuneration of ~Rs 8.7 cr (H1 FY22) and ~Rs 17.9 cr (H2 FY22) — ~Rs 26.6 cr for FY22, i.e. ~12% of that year's PAT (Rs 216 cr), mostly profit-linked commission to the four Poddar WTDs. High for a Rs 2,000 cr company. Should be re-checked in the FY26 annual report; the structure (commission on PBT) is the issue, not the year.
- **Related-party transactions:** nothing material beyond remuneration found in the Reg 23(9) extracts; the company does not source from promoter-owned mills. Positive vs. typical textile families.
- **Auditor:** DSM R & Co (formerly Songira & Associates) — a small Mumbai firm, no Big-4/Big-6. No qualifications or resignations found. Mild flag.
- **Capital-return track record (checked as requested):** 2023 buyback Rs 108 cr at Rs 650 (raised to Rs 720) — stock is now Rs 458, so the buyback destroyed value; FY26 dividend Rs 16/share (31% payout) incl. a Rs 4 special; FY27 first interim Rs 4 declared Oct-26. In Aug-2026 the NCLT-approved scheme issued **7 bonus 9% redeemable preference shares per equity share** out of general reserves — ~Rs 317 cr (reserves fell Rs 1,451→1,175 cr; borrowings jumped Rs 352→719 cr as prefs are classified as debt; Series I redeems Aug-2029, Series II Aug-2031). Pro-rata, so minorities get their share, but 67% of the ~Rs 28 cr/yr coupon and Rs 317 cr redemption flows to the family, ahead of equity, and preference dividend is not tax-deductible. It is a leveraged capital return engineered when the operating business was already slowing.
- **Diversification smell:** board approved a "one-off" Rs 45 cr, 18-storey residential project on company MIDC leasehold land at Dombivli (May 2026). Small (2% of mcap), but a textile company doing real estate is a classic small-cap drift.
- **SEBI / exchange actions, litigation, ID resignations:** none found.

## GATE 2 — MANAGEMENT GUIDANCE & DELIVERY: PASS

- FY26: management had guided double-digit growth; delivered revenue +15.7% (Rs 2,572 cr), PAT +17% (Rs 231 cr), 61 stores (38 ZECODE value-fashion + 23 DEVO).
- FY27 guidance (Jul-26 call, Gaurav Poddar / CFO Surendra Shetty): ~12% revenue growth, ~14% EBITDA margin (explicitly flagging a 150 bps drag from the new retail formats), capex ~Rs 100 cr (Rs 50–60 cr maintenance + ~Rs 40 cr stores), 70 stores by FY27-end.
- Delivery so far: H1 FY27 revenue +15.6% (ahead), EBITDA +11.3%, EBITDA margin 13.1% vs 13.6% (slightly below the 14% target; H2 is seasonally stronger). Q2 FY27 revenue +15.1%, EBITDA +8%, PAT Rs 75 cr -14% YoY — the PAT fall is mostly other income (Rs 15 cr vs Rs 37 cr LY) and higher finance cost from the preference shares, not operations. Store target reaffirmed.
- Flags: no written transcript for the Q2 FY27 call (audio only); margin guidance already carries a built-in excuse (retail drag). Otherwise guidance is specific and has been met or beaten for two years.

## GATE 3 — FUNDAMENTALS: WATCH

- **Growth:** 5-yr sales CAGR 19% is a Covid-base artefact (FY21 Rs 1,089 cr); 10-yr sales CAGR only 5%, 3-yr 5%. PAT: FY23 Rs 251 cr → FY24 185 → FY25 197 → FY26 231; 3-yr PAT CAGR -6%. TTM sales Rs 2,737 cr (+14%), PAT Rs 225 cr (+8%). This is a flat-profit business with a growth spurt in FY26–27.
- **Margins:** OPM 17% (FY22) → 16% → 14% → 12% → 13% (FY26) → 12% TTM. Structural drift down as fabric (77% of revenue) commoditises and retail scales. Garments/brands only 16%, yarn 7%. "Brand growth" is real at the store level (61→70 stores) but is not yet moving the mix.
- **Returns:** ROCE 29% → 28% → 21% → 20% → 19%; ROE 14.9%. Still decent, trending down.
- **Balance sheet:** Borrowings Rs 719 cr at Sep-26, of which ~Rs 317 cr is the bonus preference capital; underlying debt ~Rs 400 cr vs equity Rs 1,184 cr, investments Rs 299 cr. Interest coverage ~8–9x on TTM (EBIT ~Rs 333 cr / interest Rs 38 cr). Comfortable, but leverage rose in a year with Rs 100 cr capex, Rs 45 cr real estate and Rs 317 cr pref issue.
- **Working capital (checked as requested):** Debtor days 70 (FY23) → 92 (FY26); inventory days 143 → 161; cash-conversion cycle 148 → 184 days. Working-capital days 94→93 flat only because payables stretched. Direction is wrong, driven by own-retail inventory.
- **Cash conversion:** CFO FY22–26 Rs 757 cr vs PAT Rs 1,080 cr = 70%. FY26 CFO only Rs 93 cr vs PAT Rs 231 cr (40%) — worst year since FY22; FCF Rs 34 cr. FY25 was strong (CFO Rs 255 cr). Lumpy, average-quality conversion.
- **Moat:** 48-year-old mass fabric brands (Siyaram, J. Hampstead, Oxemberg, Cadini), 1,500+ dealer network, integrated weaving/processing. Pricing power is limited (margin trend proves it); value-retail (ZECODE) competes with Zudio/V-Mart with no evident edge.

## GATE 4 — VALUATION: PASS

- P/E 9.2 vs screener textile-peer median ~19x; branded apparel peers Kewal Kiran 17.7x, Arvind 29x. Own history: 8–14x band over the last 5 years; current is at the low end. P/B 1.75 (ROE 15%). EV/EBITDA ≈ (2,076 + 719 – 299) / 339 ≈ 7.4x (≈6.4x if prefs treated as equity). Dividend yield 2.6% plus the 9% pref coupon on ~Rs 70/share of preference capital.
- Cheap for a reason: 10-yr 5% growth, margins down 500 bps from peak, 3-yr PAT CAGR negative, promoter selling, real-estate detour. Cyclical trough? Partly — FY27 revenue is growing 15% and H2 is seasonally strong — but no margin recovery is visible.
- **3-yr cases (FY29):** Bull — margin back to 15%, PAT Rs 330 cr, 13x → ~Rs 950/share (~2x). Base — PAT Rs 270 cr (6% CAGR), 11x → ~Rs 655 (+43% plus ~3% yield). Bear — margins keep sliding, PAT Rs 190 cr, 8x → ~Rs 335 (-27%).

## VERDICT: HOLD-FOR-REVIEW

1. **Earnings quality, not price, is the problem:** OPM has fallen from 17% to 12% and PAT is below FY23 despite 15% revenue growth; FY26 cash conversion was 40%. Cheap P/E 9 is a fair price for a 5% long-run grower, not a mispricing.
2. **Governance is family-standard with two new smells:** ~Rs 317 cr leveraged bonus-preference payout (67% to promoters, senior to equity), a Rs 45 cr real-estate project, promoter profit-linked pay historically ~12% of PAT, small auditor. No pledge, no SEBI issues, guidance honest — so WATCH, not FAIL.
3. **What would upgrade to SELECT:** two consecutive quarters of EBITDA margin ≥15% with revenue growth ≥12%, inventory days back under 150, no further non-core projects. Review after Q3 FY27 (Jan–Feb 2027).

## Sources
- https://www.screener.in/company/SIYSIL/consolidated/
- https://nsearchives.nseindia.com/corporate/SIYSIL_27102026203902_SELetterPressRelease_Q2FY27_F.pdf (Q2 FY27 press release)
- https://nsearchives.nseindia.com/corporate/SIYSIL_27102026153025_SEIntimation_OutcomeofBM27102026.pdf
- https://www.arthneeti.com/insights/siyaram-silk-q1-fy27-earnings (Q1 FY27 call: 12% growth, 14% EBITDA, Rs 100 cr capex guidance)
- https://www.arthneeti.com/insights/siyaram-silk-q2-fy27-earnings
- https://www.freepressjournal.in/mumbai/nclt-sanctions-siyaram-silk-mills-scheme-to-issue-bonus-preference-shares-to-equity-shareholders
- https://nsearchives.nseindia.com/corporate/SIYSIL_29072026191629_SEIntimation_CertifiedTrueCopyNCLTOrder.pdf
- https://siyaram-images.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/draft-scheme-of-arrangement/copy-of-nclt-Order-dtd-09th-March-2026.pdf
- https://filingreader.com/news-wire/mumbai/2026-05-19/siyaram-silk-mills-profit-rises-as-it-pivots-to-property (Dombivli real-estate project)
- https://www.whalesbook.com/corporate-news/English/textile/Siyaram-Silk-Mills-Promoter-Sells-Nearly-Entire-Stake-via-Open-Market/6a266cf176afea9b85873c77
- https://filingreader.com/news-wire/mumbai/2026-08-10/siyaram-silk-mills-promoter-plans-block-deal-for-shares
- https://www.sebi.gov.in/sebi_data/commondocs/aug-2023/Siyaram_Silk_PA_p.pdf (2023 buyback)
- https://bseindia.com/xml-data/corpfiling/AttachHis/2ecf6fcc-e036-4316-ae52-40a1386cd171.pdf (Poddar family relationships / remuneration filings)
- https://www.business-standard.com/markets/capital-market-news/siyaram-silk-q2-pat-climbs-27-yoy-to-rs-87-cr-125110500637_1.html (Q2 FY26 base)

## Primary-source verification (2 Nov 2026)

Checked against the company's own filings (FY26 Annual Report on siyaram.com, Sep-26 shareholding XBRL on NSE, 27 Oct 2026 results filing, 25 Aug 2026 allotment filing, NCLT order). Figures in Rs cr unless stated.

**1. Promoter pledge — CONFIRMED (holding corrected 67.45% → 67.44%).**
Shareholding pattern, quarter ended 30-Sep-2026 (filed NSE 15 Oct 2026): promoter & promoter group 3,05,98,404 shares = 67.44%, 21 promoter entities; flags "encumbered under Pledge / NDU / other" all = false; no locked-in promoter shares. BSE SAST pledge register for 503811: "No Record Found". Pledge = 0%.
Source: https://nsearchives.nseindia.com/corporate/xbrl/SHP_1739027_15102026045628_WEB.xml ; https://www.bseindia.com/corporates/sastpledge?scripcd=503811

**2. Promoter-family remuneration FY26 — CONFIRMED and quantified.**
AR 2025-26, Board's Report Annexure (Sec 197(12)/Rule 5) and CG report table (Rs lakh): Ramesh D. Poddar 749.84 (commission 385), Pawan D. Poddar 722.41 (380), Shrikishan D. Poddar 722.16 (380), Gaurav P. Poddar 684.11 (380). Four Poddar WTDs = Rs 28.79 cr, of which Rs 15.25 cr is profit-linked commission. All directors Rs 30.49 cr; RPT note "Managerial Remuneration" Rs 31.47 cr (FY25 Rs 29.18 cr, +7.95%). Ratios to median employee pay (Rs 3.44 lakh): 218x / 210x / 210x / 199x.
FY26 PAT: standalone Rs 228.08 cr, consolidated Rs 230.90 cr → Poddar pay = 12.6% of standalone PAT (12.5% consolidated); all KMP/directors 13.8%. The ~12%-of-PAT figure in Gate 1 holds for FY26.
Source: https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/annual-reports/2025-2026/Annual-Report-2025-26.pdf (AR pp. 57 and 102; Note 42)

**3. Related-party transactions FY26 — CHANGED.**
AR Note 42 (standalone, Rs lakh): purchases of goods/services from "other related parties" (promoter-group enterprises) 6,917.11 plus 393.19 from The Ruby Mills (non-exec director entity) = Rs 73.10 cr; sales to related parties 13.23 cr; rent received 0.87 cr; commission paid 1.52 cr; interest received 0.06 cr; impairment of Cadini investment 3.37 cr. Non-remuneration RPTs ≈ Rs 88.8 cr = 3.5% of FY26 revenue from operations (Rs 2,569.3 cr); including managerial remuneration, sitting fees/commission and relatives' salary (Rs 32.9 cr) ≈ Rs 121.6 cr = 4.7% of revenue. BRSR: purchases from related parties = 5.01% of total purchases (FY25 4.41%); sales 0.51%.
Largest counterparties: Golden Fibres LLP purchases Rs 49.47 cr (FY25 25.55 cr — nearly doubled), Futuristic Concept Media LLP 9.68 cr, Wavelink Fabrics LLP 5.05 cr, Vibrant Clothing Co 4.95 cr; sales to DRPS Enterprises LLP 9.28 cr, Sri Radha Madhava Fashions LLP 3.11 cr. All listed as "Enterprises – KMP having significant influence / owned by major shareholders".
Correction to Gate 1: the statement "the company does not source from promoter-owned mills" is wrong — ~Rs 69 cr of FY26 purchases (2.7% of revenue) are from promoter-group entities and the amount is rising. Still modest in absolute terms, but it is a real promoter-supplier channel. Board's Report says all RPTs were arm's-length, ordinary course, no material RPTs.

**4. Auditor — CHANGED (name) / opinion CONFIRMED unmodified, with a new Emphasis of Matter.**
Statutory auditor is Jayantilal Thakkar & Co., Chartered Accountants (FRN 104133W), appointed at the 44th AGM (23 Jul 2022) for five years to the 49th AGM (2027). DSM R & Co (named in Gate 1) was replaced in 2022. FY26 standalone and consolidated audit opinions: unmodified, no Emphasis of Matter; Board's Report: report "does not contain any qualification, reservation or adverse remark".
Q2 FY27 limited review (27 Oct 2026): standalone unmodified; consolidated unmodified but with an Emphasis of Matter that subsidiary Cadini S.R.L. (Italy) "has incurred recurring losses", eroding net worth, and its continuation depends on management's plans/recapitalisation (Rs 3.37 cr impairment already taken in FY26). Not a qualification; small (investment carried at Rs 7.6 cr) but new since the AR.
Source: AR 2025-26 (Board's Report para 28, auditor's reports pp. 111 ff.); https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/SEIntimation_OutcomeofBM27102026.pdf

**5. Aug-2026 bonus preference shares — CONFIRMED in full.**
NCLT Mumbai order 21 Jul 2026 (C.P.(CAA)/13/MB/2026), scheme effective 30 Jul 2026, record date 22 Aug 2026, allotment 25 Aug 2026:
- Series I: 4 (four) 9% cumulative, non-convertible, redeemable preference shares of Rs 10 each, fully paid, for every 1 equity share of Rs 2 (ISIN INE076B04022); redeemable at par on or before 24 Aug 2029 (3 years), earlier at Board's option.
- Series II: 3 (three) 9% cumulative NCRPS of Rs 10 each per equity share (ISIN INE076B04014); redeemable at par on or before 24 Aug 2031 (5 years), earlier at Board's option.
- Issued to every equity shareholder on the register/depository records on the record date — pro-rata to ALL equity holders (incl. IEPF and unclaimed-suspense holdings; forfeited shares excluded). No lock-in.
- Source of issue: General Reserve only; Rs 317.59 cr (4,53,70,088 equity × 7 × Rs 10) debited to General Reserve. Classified as non-current borrowings; preference dividend accrued to 30 Sep 2026 (Rs 2.89 cr) booked in finance costs. Listing applications filed with NSE/BSE on 30 Sep 2026. Coupon ≈ Rs 28.6 cr p.a., of which 67.44% ≈ Rs 19.3 cr p.a. (and ≈ Rs 214 cr of redemption) accrues to the promoter group.
- RD (Western Region) and ROC raised no objection; BSE/NSE observation letters (Jul 2025) recorded no objection; NCLT left Income-tax free to examine; no objector appeared.
Sources: https://nsearchives.nseindia.com/corporate/SIYSIL_25082026172359_SEIntimation_AllotmentofPrefernceShares.pdf ; https://nsearchives.nseindia.com/corporate/SIYSIL_29072026191629_SEIntimation_CertifiedTrueCopyNCLTOrder.pdf ; Q2 FY27 investor presentation slide "Rewarding Shareholders" (https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/Investor+Presentation+Q2+FY27.pdf)

**6. Q2 FY27 (quarter ended 30 Sep 2026) — CONFIRMED; watch item MET for the quarter.**
Standalone (results filing / press release): revenue from operations Rs 813.5 cr vs 705.6 cr (+15.3%); "total income" ex non-recurring other income 827 vs 719 (+15.1%); EBITDA Rs 130.5 cr vs 120.9 cr (+8.0%); EBITDA margin 15.8% vs 16.8% (-100 bps); other income Rs 14.5 cr; finance cost Rs 12.0 cr (includes Rs 2.9 cr preference dividend accrual); PBT Rs 99.2 cr; PAT Rs 75.0 cr vs 87.0 cr (-13.8%); EPS Rs 16.5. H1 FY27: revenue 1,258.0 cr (+15.0%), EBITDA 169.8 cr (+11.3%), margin 13.1% vs 13.6%, PAT 86.0 cr (-5.9%). Mix: fabric 77% / garments 16% / yarn & others 7%. 61 stores (38 ZECODE, 23 DEVO), 70-store FY27 target reaffirmed. Rs 4 first interim dividend (record date 31 Oct 2026). Dombivli real-estate project: Rs 26.5 cr cost incurred in Q2, parked in inventories.
Watch item (EBITDA margin ≥14% and revenue growth ≥12%): Q2 15.8% / +15% — met. Caveat: H1 margin is 13.1% (Q1 was 8.4%) and Q2 margin fell 100 bps YoY, so the stricter upgrade trigger in the Verdict (two consecutive quarters ≥15%) is not met. Guidance (12% growth, ~14% margin, Rs 100 cr capex, 70 stores) confirmed from the Q1 FY27 transcript (31 Jul 2026 call).
Sources: https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/SELetterPressRelease_Q2FY27_F.pdf ; results filing above; https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/InvestorMeetTranscript05082026.pdf

**7. Announcements since 1 Oct 2026 — nothing that changes the governance picture.**
27 Oct: results, Rs 4 interim dividend, Dinesh Kumar Jaithliya elevated to Deputy CFO (1 Nov 2026), Cygnus Partners appointed IR advisor (1 Nov 2026); 28 Oct: analyst meet (audio only, no transcript yet) and newspaper publication of results; 30 Sep: NCRPS listing application. Shareholding filed 15 Oct (no pledge, no change). No auditor, director or SEBI items. Sep-26 CG report on the website is a scanned image and was not read.

**Summary:** Items 1, 2, 5, 6 CONFIRMED; item 3 CHANGED (promoter-group sourcing exists, Rs 69 cr and rising); item 4 CHANGED (auditor is Jayantilal Thakkar & Co, not DSM R; new EoM on Cadini in Q2 consolidated review); item 7 clean.

**SIYSIL: verdict stands — HOLD-FOR-REVIEW retained, no upgrade to SELECT and no downgrade to REJECT** — the latest quarter met the 14%/12% watch item, pledge is nil, pay is as modelled (12.6% of PAT) and the preference bonus is pro-rata as described; but two Gate-1 facts were wrong in the note (auditor identity; "no promoter sourcing" — in fact Rs 69 cr of FY26 purchases from promoter-group LLPs), which keeps governance at WATCH rather than improving it.
