# Monte Carlo Fashions (NSE: MONTECARLO) — Due Diligence, 2 Nov 2026

**Snapshot:** CMP Rs 510 | Mcap Rs 1,057 cr | P/E 10.1 | P/B 1.16 | Div yield 3.9% | ROCE 14% | ROE 12.7% | Promoter 73.17% | 52w 464–865 (price -27% in 1 yr)
**Note:** Q2 FY27 (Sep-26) results are due at the board meeting on **3 Nov 2026** — not yet out. Latest reported quarter is Q1 FY27.

## GATE 1 — GOVERNANCE: WATCH

- **Promoter holding / pledge:** 73.17%, unchanged every quarter since at least Dec-2023. No pledge disclosed on screener or in filings found. Good.
- **Family KMP:** All five executive directors are one family. Jawahar Lal Oswal (CMD, age 82, Nahar group patriarch), Sandeep Jain (WTD), Monica Oswal and Ruchika Oswal (WTDs, on board since 2010), Rishabh Oswal (WTD, "third generation"). A BSE director-disclosure states Rishabh Oswal "is related to Sh. Jawahar Lal Oswal, Sh. Sandeep Jain, Smt. Ruchika Oswal and Smt. Monica Oswal". Two further relatives of an executive director (Sidhant Jain, Simran Jain) draw salaries. The only non-family non-independent director (Dinesh Gogna) is a long-time Nahar group associate. The 6 independent directors are mostly retired Ludhiana/PAU academics; two (Pruthi, Singla) are also IDs at Nahar group companies. The board reads as captive, not as a check on the family. No CEO/CFO from outside the family — this is nepotism by structure, if not by any single appointment.
- **Related-party transactions (Nahar group):** H1 FY26 Reg 23(9) disclosure: total RPT value Rs 66.6 cr for the half-year. Main lines are purchases from **Oswal Woollen Mills** (approved Rs 38.5 cr), Nahar Spinning (Rs 9.2 cr purchases + rent/processing), Nahar Industrial Enterprises (Rs 2.8 cr purchases + Rs 2.8 cr rent). Roughly ~5% of annual sales, but a captive raw-material supply chain owned by the promoter family — pricing is unverifiable from outside. Moderate, not egregious.
- **Promoter remuneration:** Approved FY26 figures: J.L. Oswal Rs 3.2 cr, Sandeep Jain Rs 1.2 cr, Rishabh Oswal Rs 1.1 cr, Monica/Ruchika Rs 0.38 cr each — about Rs 6.3 cr, ~5.6% of FY26 PAT. Acceptable.
- **Auditor:** Deloitte Haskins & Sells (replaced Walker Chandiok around FY23); FY26 opinion unmodified. Positive.
- **CFO churn:** three CFO changes (2015, 2016, late-2022); current CFO Raj Kapoor Sharma since ~Nov 2022. Mild flag.
- **SEBI / exchange actions, fraud, litigation:** none found.
- **Capital allocation smell:** FY26 board approved a **Rs 150 cr, 50 MW-DC solar plant** in an SPV (75% debt) — for a Rs 1,050 cr apparel company with Rs 580 cr debt. Size crept from "35 MW / Rs 130–140 cr" (May-26 call) to "50 MW DC / Rs 150 cr" (Aug-26 call) within one quarter. Management says it may "monetise or exit" after a year. This is diversification into an unrelated asset, not core-business capex.

## GATE 2 — MANAGEMENT GUIDANCE & DELIVERY: WATCH

| Year | Guided | Delivered |
|---|---|---|
| FY24 | Started with a Rs 2,000 cr medium-term revenue target; by Nov-23 cut to "flat year" | Revenue -5% (Rs 1,062 cr), OPM 20%→14%, PAT -55% ("higher returns and discounts") |
| FY25 | "Flat to single-digit growth", focus on profitability; Rs 2,000 cr target "to be revisited" (quietly dropped) | Revenue +3.6%, OPM 17%, PAT +35% — met |
| FY26 | "Very confident of double-digit growth" | Revenue +16%, OPM 18%, PAT +38% — beat |
| FY27 | May-26: double-digit growth, ~20% EBITDA incl. other income, 40–45 EBOs, capex Rs 10–15 cr + solar. Aug-26: softened to "low double-digit", ~10% SSSG, 100 bps inflation hit, capex now Rs 30 cr + solar Rs 150 cr | Q1: revenue +7.6%, EBITDA -8.7% margin vs -4.3% LY, loss widened to Rs 23 cr. Q2 due 3 Nov |

Pattern: guidance is set low after a bad year and beaten; the one stretch target (Rs 2,000 cr) was abandoned without explanation; FY27 guidance already nudged down after one quarter and capex is drifting up. Communication is adequate (quarterly calls, IR agency appointed Oct-26) but delivery is weather-dependent.

## GATE 3 — FUNDAMENTALS: WATCH

- **Growth:** 5-yr sales CAGR 15% (flattered by FY21 Covid base; Rs 622→1,276 cr); 3-yr only 5%. PAT 5-yr CAGR 11%, 3-yr -6% — FY26 PAT Rs 112 cr is still below the FY23 peak of Rs 133 cr. TTM: sales Rs 1,286 cr, PAT Rs 105 cr.
- **Recent quarters:** Q4 FY26 sales +36% YoY, PAT Rs 5 cr vs -10 cr. Q1 FY27 sales +7.6%, loss Rs -23 cr vs -16 cr. Extreme seasonality: Dec quarter is ~48% of sales and ~100% of profit (Q3 FY26 PAT Rs 107 cr vs FY PAT Rs 112 cr). Two loss quarters a year. One warm winter (FY24) halves profit.
- **Margins:** OPM 20% (FY22–23) → 14% (FY24) → 17% → 18% (FY26). Recovered but not back to peak. Summer/cotton wear now 45% of mix, targeted 50%.
- **Returns:** ROCE 22% → 20% → 11% → 13% → 14%. ROE 12.7%, 3-yr avg 10%. Mediocre for a "brand".
- **Balance sheet:** Borrowings Rs 118 cr (FY21) → Rs 580 cr (FY26), D/E ~0.64, while the company also holds Rs 252 cr of investments and keeps paying ~50% of PAT as dividend. Solar SPV adds ~Rs 110 cr more debt. Interest not pulled; ~Rs 50 cr implied on Rs 580 cr vs Rs 229 cr EBITDA, i.e. roughly 4–5x coverage (estimate).
- **Working capital — the core problem:** Debtor days 105 → 143; inventory days 217 → 324; cash-conversion cycle 218 → 384 days (FY22→FY26). Management says it "monitors receivables" and is recalling unsold retailer stock to refurbish and resell via factory outlets/online — i.e. channel is stuffed and returns (11–12%) are structural. Debt growth is funding working capital and dividends.
- **Cash conversion:** cumulative CFO FY21–26 Rs 432 cr vs PAT Rs 566 cr = 76%; FCF ~Rs 232 cr over 6 years vs dividends of roughly Rs 250 cr → dividends are effectively debt-funded.
- **Moat:** strong regional (North India) woollen brand, 400+ EBOs, low-cost Ludhiana manufacturing + group yarn supply. But weather-dependent, geographically concentrated, and online/quick-commerce pricing pressure.

## GATE 4 — VALUATION: PASS (cheap, but partly for a reason)

- P/E 10.1 vs screener apparel-peer median ~20x (Kewal Kiran 17.7x, Lux 33x, Page 50x); own history has mostly been 10–18x since listing — currently at the low end. P/B 1.16; EV/EBITDA ≈ (1,057 + 580 – ~50 cash) / 229 ≈ 7x. Dividend yield 3.9%.
- Cheap because: 14% ROCE, 384-day cash cycle, binary winter risk, debt-funded payout, and now a solar detour. Not a structural decline (FY26 grew 16%), but a low-quality cyclical compounder.
- **3-yr cases (FY29):** Bull — PAT Rs 160 cr (12% CAGR), 13x → ~Rs 1,000/share (+95% plus ~12% dividends). Base — PAT Rs 130 cr, 10x → ~Rs 630 (+25% plus dividends). Bear — one warm winter (FY24 repeat): PAT Rs 60 cr, 10x → ~Rs 290 (-43%).

## VERDICT: HOLD-FOR-REVIEW (not a SELECT)

1. **Governance is family-captive, not fraudulent:** all 5 executive directors from one family, promoter-owned yarn suppliers, academic IDs — but Big-4 auditor, no pledge, stable 73% holding, 50% payout shared with minorities. Enough smell to refuse a SELECT, not enough for FAIL.
2. **Working capital is deteriorating every year** (CCC 218→384 days) and debt has risen 5x in five years while dividends continue — the earnings quality does not match the P/E 10 "value" optics.
3. **Capital-allocation drift:** the Rs 150 cr solar SPV (growing between calls) and the quietly dropped Rs 2,000 cr target. Re-review only after Q2 FY27 (3 Nov 2026) if debtor/inventory days fall meaningfully and solar is ring-fenced or dropped; otherwise REJECT.

## Sources
- https://www.screener.in/company/MONTECARLO/consolidated/
- https://valoremadvisors.com/assets/admin/conference_file/1787311527_Monte_Carlo_Fashions_Ltd_Q1_FY27_Earnings_Concall_Highlights.pdf
- https://valoremadvisors.com/assets/admin/earnings_presentation/1787220879_Monte_Carlo_Q1-FY27_Earnings_Presentation-Final.pdf
- https://www.arthneeti.com/stocks/monte-carlo-fas/concall/q4-fy26-earnings-call-analysis
- https://montecarlocorporate.com/Pdfs/rpt300920251763121480.pdf (Reg 23(9) RPT disclosure, H1 FY26)
- https://montecarlocorporate.com/Pdfs/breif%20profile1747909844.pdf (board profiles)
- https://www.freepressjournal.in/business/monte-carlo-fashions-reports-2342-crore-consolidated-net-loss-in-q1-fy27
- https://www.multibagg.ai/market-pulse/articles/q1fy27-update-97284
- https://alphaspread.com/security/nse/montecarlo/earnings-calls/q4-2024 ; https://alphaspread.com/security/nse/montecarlo/earnings-calls/q1-2025 (FY24/FY25 guidance)
- https://www.whalesbook.com/news/English/other/Monte-Carlo-Fashions-Q3-Profit-Jumps-11percent-Eyes-20percent-FY27-Growth/697def495fc43f26c54fed08
- https://www.montecarlocorporate.com/Pdfs/Results%20Letter1779105229.pdf (FY26 results, Deloitte unmodified opinion)
- https://www.stockopedia.com/share-prices/monte-carlo-fashions-NSI:MONTECARLO/news/ (CFO changes)
