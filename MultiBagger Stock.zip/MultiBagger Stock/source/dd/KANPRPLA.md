# Kanpur Plastipack Ltd (NSE: KANPRPLA) — Due Diligence, 2 Nov 2026

**Verdict: REJECT** | G1 Governance: FAIL | G2 Guidance & Delivery: WATCH | G3 Fundamentals: WATCH | G4 Valuation: WATCH

Price ₹242 | Mcap ₹594 cr | P/E 11.2 (TTM EPS ₹21.9) | P/B 2.0 | ROCE 17% | ROE 14.9% | Div yield 0.5% | 52w range ₹151–283 | CRISIL BBB+/Stable, A2

Note on the brief: KPL has no BOPP business. Its film diversification was a **CPP (cast polypropylene) plant**, which lost money (FY25 loss ₹12 cr incl. ₹11.6 cr impairment) and was sold in May 2025 for ₹50 cr. The "BOPP capex returns" question therefore has a clear answer: the film bet destroyed capital and was exited. Current business: FIBC (bulk bags) ~43% of Q2 revenue, PP woven fabric 12%, multifilament yarn 6%, UV masterbatch 2%, small bags/geo-fabric 2%, and polymer **trading/consignment stockist 36%**.

## Gate 1 — Governance: FAIL
- **Promoter holding** 68.03% (Sep-26), up from 66.74% (Dec-24) via two preferential warrant issues to promoter-group and select non-promoter allottees: 7.52 lakh shares at ₹116.50 (converted May-25) and 9.185 lakh at ₹130 (converted Dec-25/Mar-26) while the stock traded ₹150–283. In-the-money paper to insiders; 93,500 warrants at ₹130 still outstanding. No pledge disclosed (Screener, AR FY26).
- **Valex Ventures (UK) transaction — the key red flag.** MD Manoj Agarwal personally bought Valex shares (₹8.02 cr per RPT note), then on 1 Nov 2025 sold a 76.19% stake to KPL for 3,33,700 KPL shares at ₹202.61 (~₹6.8 cr). KPL booked **goodwill of ₹6.72 cr** — essentially the whole consideration — for an entity with total assets ₹6.1 cr, revenue ₹9 cr and a net loss. Auditors flagged it as a Key Audit Matter ("consideration exceeds book value", "post-acquisition performance varying from projections", no impairment taken). Management on the Q1 FY27 call: Valex "has not yet delivered significant tangible benefits". KPL also booked ₹17.6 cr of sales to Valex in FY26 (now a captive customer).
- **Promoter LLP fees:** Raghushree Earning Solutions LLP (entity "significantly influenced by a director", 1.45% shareholder) was paid **₹1.55 cr advisory/supervision fees** in FY26 (₹0.35 cr in FY25) on top of director salaries. Plus rent to KSM Exports (promoter, 5.84%) and KPL Packaging, design fees and shares to Manjari Agarwal (relative).
- **Remuneration:** Manoj Agarwal ₹1.93 cr (+70%), Shashank Agarwal ₹2.04 cr (+142%), at 131x/138x median employee pay; CFO Shobhit Agarwal ₹0.25 cr (+41%; also received a loan). Total KMP ₹5.16 cr + Raghushree ₹1.55 cr ≈ 18% of standalone PAT (₹36.9 cr). Usha Agarwal (13.26% holder, relative of MD) put on ₹1.5 lakh/month from Apr-26.
- **Family KMP:** Chairman-MD Manoj, Deputy MD Shashank (relative), NED Usha (relative), CFO Shobhit Agarwal (relationship not disclosed in filings I could read — treat as unverified). Four Agarwals across board and KMP; ED Sunil Mehta is the only non-family executive.
- **Auditor:** Rajiv Mehrotra & Associates, Kanpur — a small local firm for a ₹800 cr-revenue exporter; unmodified opinion, three KAMs (CPP, Valex goodwill, DFIA non-recognition), no CARO adverse remarks. Grant Thornton engaged for a process review (mildly positive).
- **Positives:** independent directors strengthened (Basant Seth, ex-Syndicate Bank CMD, Nov-25; Sanjiv Swarup, CA, Oct-26); no SEBI action or exchange clarification found; no pledge.
- **Why FAIL:** a listed company buying a loss-making foreign entity from its MD at ~100% goodwill, paying a promoter LLP "advisory" fees, issuing discounted warrants to promoters and doubling promoter pay in the same year is the governance pattern the mandate says to reject by default.

## Gate 2 — Guidance & Delivery: WATCH
- **Aug 2025 (Q1 FY26):** FY26 EBITDA margin "in line with Q1" (8.5%) / "9–10% sustainable"; debt to fall to ~₹125 cr by Mar-26; FIBC ₹425–450 cr by FY28; geotextiles ₹60 cr. **Delivered:** FY26 OPM 9–10%, net debt ₹112 cr. 
- **May 2026 (Q4 FY26):** FY27 top line +10–15%, margins "similar"; non-woven ₹20–25 cr FY27 and ₹100–125 cr FY28 at 15–16% EBITDA; Unit 3 +1,800 t in FY27; FIBC 5,000 t/quarter by Q1 FY28.
- **Aug 2026 (Q1 FY27):** FIBC output fell to ~3,000 t (vs 3,500 t in Q4 FY26) — management called it "damaged" by polymer/labour disruption and admitted expansion was "a little slow". Non-woven commissioning slipped from Sep-26 to 15 Nov 2026 (rain); second line to Mar-27. Declined to give product-mix split; said more guidance "by Q4". Ocean freight up 2.5x flagged.
- **Oct 2026 (Q2 FY27):** Q2 revenue +44%, PAT +102% — but FIBC volume only 3,475 t (flat vs Q4 FY26) and trading is 36% of revenue; growth is price (ASP +31% QoQ in Q1) and pass-through trading, not volume. Hard numeric guidance is absent; a slide shows "₹100 mn FY27 → ₹1,000 mn FY30 at 20–25% EBITDA" without saying which business it refers to.
- **US tariffs:** addressed once (Aug-25: "no orders cancelled, expect pricing pressure") and not since. North America share fell from 21% to 16–17% of revenue (US ~13–14%, Canada ~4%). FY26 AR: US exports "dropped only marginally". Europe is 65% and faces Turkish competition. Exposure is real but second-order; management's silence on it is the concern.

## Gate 3 — Fundamentals: WATCH
- **Growth:** sales 5Y CAGR 10% (₹451 → ₹718 cr), profit 5Y CAGR 3% (₹30 → ₹39 cr) — FY23–FY24 PAT was ₹4 cr and ₹1 cr. The 3Y 89% profit CAGR is a trough artefact.
- **Recent quarters (consol):** Q1 FY27 sales ₹204 cr (+13%), PAT ₹12 cr (+100%); Q2 FY27 sales ₹236 cr (+43%), PAT ₹16 cr (+100%), OPM 10–11%. TTM sales ₹812 cr, PAT ₹53 cr, OPM 9%.
- **Margins:** OPM 12% (FY21) → 4% (FY24) → 9% (FY26) → 10.8% (H1 FY27). Raw material 60–65% of cost; a commodity converter with 4-week demand visibility.
- **Returns:** ROCE 17%, ROE 15% in FY26 — but 3Y/5Y ROE averages are 8%.
- **Debt:** borrowings rose ₹112 cr (Mar-26) → ₹163 cr (Sep-26) as CWIP went ₹9 → ₹46 cr; D/E 0.55 gross; interest coverage ~6x. Capex plan ₹108 cr (FIBC Unit 3 +6,000 MTPA over 5 years, two needle-punch non-woven lines, warehouse) funded by a ₹40 cr Yes Bank term loan plus accruals. Screener flags possible interest capitalisation.
- **Cash conversion:** CFO FY22–26 ₹181 cr vs PAT ₹81 cr (2.2x, flattered by near-zero PAT years); FY26 CFO ₹51 cr vs PAT ₹39 cr. But working-capital days rose 7 (FY24) → 45 (FY26); CCC 116–155 days; debtor days 48–58, inventory 86–116. H1 FY27 debt up ₹51 cr says cash is being absorbed again.
- **Moat:** none beyond BRCGS/FSSC food-grade certification and 80–85% repeat business. ~10 large Indian FIBC peers plus Turkey; FIBC capacity (18,000 t at 85% utilisation) is the only real asset.

## Gate 4 — Valuation: WATCH
- P/E 11.2, EV/EBITDA ≈ (594 + ~150 net debt) / ~85 TTM EBITDA ≈ 9x, P/B 2.0. Own history is noise (P/E 5x–50x as earnings swung); 5-yr median roughly 12–15x. Listed FIBC peers (Jumbo Bag, Rishi Techtex, Emmbi) trade 8–15x. Not expensive, not cheap for a commodity converter whose margin is near a cyclical high on a polymer price spike.
- **3-year cases (FY29):** Bull — non-woven delivers ₹120 cr at 15%, FIBC 24,000 t, PAT ₹80 cr, 12x → ₹960 cr (+60%). Base — PAT ₹60 cr, 10x → ₹600 cr (flat). Bear — OPM reverts to 5–6% as in FY23–24, PAT ₹25 cr, 10x → ₹250 cr (-58%). Asymmetric to the downside.

## Verdict: REJECT
1. **Governance FAIL:** MD-to-company sale of loss-making Valex at ~100% goodwill (auditor KAM), ₹1.55 cr advisory fees to a promoter LLP, discounted promoter warrants, +70%/+142% promoter pay hikes at 130x+ median — all in one year.
2. **Earnings quality:** headline +44%/+102% Q2 growth is price inflation and 36% low-margin trading; FIBC volumes are flat and the last diversification (CPP film) was written off and sold.
3. **Not cheap enough to compensate:** 11x P/E on peak-cycle margins for a commodity exporter with rising debt, lengthening working capital, slipping project timelines and no US-tariff disclosure.

## Sources
- https://www.screener.in/company/KANPRPLA/consolidated/
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ba650546-d473-4b6f-90e8-243a7c7f12bc.pdf (Q2 FY27 press release, 27 Oct 2026)
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3af89e15-6862-4a29-90ec-ca9fced68360.pdf (Q2 FY27 investor presentation)
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=562ad817-75f0-452c-a5c4-a04d7ec62329.pdf (Q1 FY27 concall transcript, Aug 2026)
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=52030fc9-54f4-4046-8c3a-6871e41c3ce5.pdf (Q4 FY26 concall transcript, May 2026)
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=44b12025-f490-4c60-9108-ab42134500a0.pdf (Q1 FY26 concall transcript, Aug 2025 — US tariff commentary)
- https://www.bseindia.com/xml-data/corpfiling/AttachHis/af501730-3093-49ee-99aa-3c6f0687dbb3.pdf (Annual Report FY2026 — remuneration, RPTs, Valex, CPP discontinued ops, warrants)
- https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/KanpurPlastipackLimited_July%2001_%202026_RR_396272.html (CRISIL rationale, 1 Jul 2026)
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a196205e-a829-4ce4-b61d-56061db8505c.pdf (ID appointment, 27 Oct 2026)
- https://kanplas.com/board-of-directors
