# Sai Silks (Kalamandir) — NSE: KALAMANDIR / BSE: 543989

Due diligence as of 2 Nov 2026. Price ₹66, market cap ~₹1,010 cr, 52-wk ₹183 / ₹64 (at all-time low, -64% in 1 yr). Q2 FY27 full results due at board meeting 3 Nov 2026.

## VERDICT: REJECT

1. Sales are now shrinking (H1 FY27 turnover ₹809 cr vs ₹823 cr, -1.7%; Q1 SSSG -7.5%) while EBITDA margin fell ~100 bps — the "declining sales AND falling margins" fail condition, with no credible turnaround (FY27 guide of 12–15% growth needs ~27% H2 growth).
2. Management has missed or cut guidance three years running (FY25 PAT guide ₹150 cr vs ₹85 cr delivered; FY26 guide cut from 18–20% to 15%, delivered 13%; FY27 guide already implausible).
3. Governance smell: MD's son-in-law made CEO on a 5-year term six days after an independent director resigned without a public reason; MD skipped the Q1 FY27 call; institutions have exited (DII 20.4% → 4.3%, FII 4.6% → 0.4% since Dec 2023). Cheap valuation does not offset this.

## GATE 1 — GOVERNANCE: WATCH (borderline FAIL)
- Promoter holding flat at 60.80% → 60.97% (Dec 2023 → Sep 2026); pledge 0% in FY26–FY27 filings.
- Family KMP: Bharadwaj Rachamadugu appointed CEO effective 12 May 2026, disclosed as son-in-law of MD/promoter Nagakanaka Durga Prasad Chalavadi; required Sec 188 related-party approval. Pay ₹5 lakh/month (modest), 5-year term. No disclosed prior public-company CEO track record found. Looks like succession-by-family rather than a search.
- Independent director Sirisha Chintapalli resigned effective 6 May 2026, no reason disclosed; replaced by Sridevi Dasari on 12 May (same day as CEO appointment). Timing is a red flag.
- MD remuneration ~₹5 cr (Simply Wall St) ≈ 3.5% of FY26 PAT; board median ₹1.99 cr — high for a ₹1,000 cr company.
- RPTs: AOC-2 / Note 45 in AR FY26 — size not verifiable from secondary sources (flag: store premises historically leased from promoter entities per RHP).
- Auditor Sagar & Associates (small regional firm) proposed for another 5-year term; clean opinion. No SEBI action, no price/volume clarification found.
- Verdict: no fraud, but nepotism + ID exit + institutional flight = default REJECT territory for a small cap.

## GATE 2 — GUIDANCE & DELIVERY: FAIL
| Year | Guided | Delivered |
|---|---|---|
| FY25 | PAT ~₹150 cr; 90k sq ft; "100 stores by FY26" | PAT ₹85 cr (-15%); revenue +6.5% |
| FY26 | Rev +15–20%, raised to 18–20%, cut to 15% (Jan 2026) | Rev +13.1% (₹1,654 cr); PAT ₹141 cr (+65%, large part is interest savings from IPO debt paydown) |
| FY27 | Rev +12–15%, EBITDA margin 17.5–18%, +1 lakh sq ft, SSSG +2–3% | H1 rev -1.7%; Q1 PAT ₹25.6 cr (-15% YoY); Q1 EBITDA margin -100 bps; SSSG -7.5%; 56k sq ft added in H1 |
- Explanations are recurring one-offs: Adhik Maas, Dussehra shift, Telangana weakness, KLM Fashion Mall degrowth (closing a store), poor rainfall. Valli Silks expansion paused. ₹20 cr unutilised IPO proceeds (warehouse) deferred to Mar 2027.
- Store/sq-ft adds have been broadly delivered; revenue per sq ft has not.

## GATE 3 — FUNDAMENTALS: WATCH
- Sales (₹ cr): FY22 1,129 → FY23 1,351 → FY24 1,374 → FY25 1,462 → FY26 1,654; TTM 1,650. 3-yr CAGR 7%; 5-yr 20% only because of the FY21 COVID base (FY20→FY26 ≈ 6% p.a.).
- PAT: FY23 98 → FY24 101 → FY25 85 → FY26 141 → TTM 137. Q1 FY27 PAT ₹25.6 cr vs ₹30.1 cr. Q2 FY27 turnover ₹434 cr vs ₹444 cr (PAT not yet out).
- EBITDA margin (ex other income): 14.2% / 13.7% / 12.8% / 14.0% FY23–26 — flat; Q1 FY27 down ~100 bps. Interest fell from ₹52 cr (FY24) to ₹31 cr (FY26), flattering PAT.
- ROCE 14.4%, ROE 11.8% (3-yr avg 10.8%).
- Balance sheet clean: financial debt ~₹20 cr, lease liabilities ₹341 cr, cash + investments ₹348 cr → net cash ex-leases.
- Working capital is the weak spot: inventory ₹816 cr = 311 inventory days, cash-conversion cycle 249 days; inventory +71% FY22–26 vs sales +46%.
- Cash conversion: CFO FY22–26 = 46 / 41 / -21 / 107 / 323 = ₹496 cr vs PAT ₹483 cr (~100%), but 65% of it came in FY26; FY22–25 CFO/PAT was only ~50%. Capex ~₹50 cr/yr.
- Moat: regional ethnic-wear brand in AP/Telangana/Karnataka; value format (KLM) is bleeding; unorganised and strong regional rivals (Pothys, Chennai Silks, RmKV) cap pricing power.

## GATE 4 — VALUATION: PASS (cheap, but for a reason)
- P/E ~7.4x TTM (screener consolidated page shows 18.6x — data artefact), P/B 0.83x, EV/EBITDA ~3x ex-leases, dividend yield 2.3%. IPO (Sep 2023) priced at ₹222, ~25x.
- Peers trade at 35–50x (Vedant Fashions, Go Fashion, Arvind Fashions) — but they have growth.
- 3-yr cases: Bull — SSSG recovers, FY29 PAT ₹170 cr at 12x = ₹140 (2.1x). Base — PAT ₹130 cr at 8x = ₹70 (flat + dividends). Bear — PAT ₹90 cr at 7x = ₹43 (-35%). No visible catalyst; institutional selling continues.

## What would change the view
Two consecutive quarters of positive SSSG with margin expansion, MD back on calls, and a disclosed reason for the ID resignation. Re-check after 3 Nov results.

## Sources
- https://www.screener.in/company/KALAMANDIR/consolidated/ and https://www.screener.in/company/KALAMANDIR/
- https://stockanalysis.com/quote/nse/KALAMANDIR/financials/income-statement/ (also cash-flow-statement/, balance-sheet/)
- https://www.investing.com/news/transcripts/earnings-call-transcript-sai-silks-reports-flat-q1-2026-sales-shares-fall-3-93CH-4795511
- https://www.sahi.com/news/sai-silks-reports-q2-fy27-turnover-at-434-crore-opens-4-new-stores
- https://www.whalesbook.com/corporate-news/English/consumer-products/Sai-Silks-Q4-Profit-Soars-142percent-FY26-Net-Jumps-65percent-Amid-Governance-Concerns/6a076516e125a601ebdfef15
- https://www.whalesbook.com/corporate-news/English/consumer-products/Sai-Silks-Kalamandir-Q1-FY27-Revenue-Down-107percent-Profit-Falls-215percent/6a576b800037f07172602f78
- https://scanx.trade/stock-market-news/companies/sai-silks-clarifies-ceo-tenure-and-director-commission-caps-in-agm-corrigendum/47396084
- https://www.business-standard.com/markets/capital-market-news/sai-silks-kalamandir-standalone-net-profit-declines-14-68-in-the-june-2026-quarter-126071500997_1.html
- https://investorchandann.substack.com/p/sai-silk-kalamandir-beyond-q3
- https://www.tradingview.com/news/urn:summary_document_transcript:quartr.com:3320808:0-kalamandir-strong-fy-2026-growth-with-margin-expansion-fy-2027-targets-aggressive-expansion-and-higher-margins/
- https://quartr.com/events/sai-silks-kalamandir-limited-kalamandir-q1-24-25_FRTi5FvF
- https://ticker.finology.in/IPO/listed/sai-silks-kalamandir-ltd (pledge data)
- https://simplywall.st/stocks/in/retail/nse-kalamandir/sai-silks-kalamandir-shares/management
- https://trendlyne.com/equity/KALAMANDIR/sai-silks-kalamandir-ltd/
- https://sskl.co.in/investor-relations/
