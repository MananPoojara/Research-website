# Emami Paper Mills (NSE: EMAMIPAP) — Due Diligence, 2 Nov 2026

**Verdict: HOLD-FOR-REVIEW** | G1 Governance: WATCH | G2 Guidance & delivery: FAIL | G3 Fundamentals: WATCH | G4 Valuation: PASS (cyclical-peak caveat)

Snapshot (2 Nov 2026): price Rs 114.9, mcap ~Rs 698 cr (6.05 cr shares), EV ~Rs 1,629 cr, TTM P/E 5.6, P/B 1.4, EV/EBITDA 5.6, dividend yield 2.8% (Rs 3.20). Promoter 74.97%, pledge 0%. Capacity ~2.0 lakh TPA packaging board + 1.4 lakh TPA newsprint/W&P (Balasore, Odisha; Panipat). Rating IND A-/Stable affirmed Mar 2026.

## Gate 1 — Governance: WATCH
- Promoter holding flat at 74.97-74.98% for 12 quarters; **0% pledge** on EPML shares (FY26 "no encumbrance" declaration filed Apr 2026; Finology Jun-26 pledge 0.00%). Shareholder count fell from 21.3k (Dec-24) to 19.0k (Sep-26) — retail exiting, no institutional holding (DII 0%, FII 0.5%).
- **Group-level history is the smell**: in 2019 Emami Ltd promoters had ~48% of their Emami Ltd stake pledged to fund other group businesses and sold 10% to deleverage; the paper business was floated for divestment. Pledge on Emami Ltd is now ~7% but Diwakar Finvest / Suraj Finvest (the same vehicles that own 27.05% + 23.99% of EPML) were still creating fresh pledges with Bajaj Finance / DBS in Aug-Sep 2026. EPML itself holds Rs 50 cr of Emami Ltd shares (cross-holding) and Emami Ltd holds 13.13% of EPML.
- **Family board**: Executive Chairman Aditya V. Agarwal and Vice-Chairman/WTD Manish Goenka are promoter family; Richa Agarwal (promoter family) is a NED; Sachin Goenka (promoter group) is VP Strategy & Procurement. Promoter-director pay ~Rs 2.4-2.8 cr each; in FY25 the two promoter WTDs took ~Rs 5.6 cr against PAT of Rs 26 cr (~22%). Not nepotism-by-appointment (both are long-standing) but there is no professional CEO continuity: CEO Vivek Chawla resigned Sep 2025 (WTD Dec 2025), replaced by internal Sushil Khetan; CS resigned Dec 2025.
- RPTs with group are negligible: H1 FY26 purchases from Emami Ltd Rs 0.44 cr, sales Rs 0.08 cr, royalty Rs 0.07 cr (<0.1% of sales). No group loans/guarantees. Statutory auditor S K Agrawal & Co (unqualified, term to 2027); EY appointed internal auditor Oct 2026. Two IDs reappointed Oct 2026; no ID resignations, no SEBI/exchange action found.

## Gate 2 — Guidance & delivery: FAIL
- Company holds **no concalls and publishes no investor presentation**; the only outlook is boilerplate in the annual report.
- Nov 2015: announced Rs 2,000 cr paperboard investment over 3 years to double board capacity from 1.3 lakh TPA. Board capacity today is ~2.0 lakh TPA; capex FY22-FY26 totalled only ~Rs 130 cr. 2022: management told trade press it would be a **Rs 5,000 cr revenue company by 2025**; FY25 revenue was Rs 1,928 cr — a ~60% miss with no explanation.
- FY26 AR cites PM-2 headbox upgrade and a 7 MW solar project; no capacity plan. Management cannot be held to guidance because it gives none — that is itself a failure for a growth portfolio.

## Gate 3 — Fundamentals: WATCH
| Rs cr | FY21 | FY22 | FY23 | FY24 | FY25 | FY26 | TTM Sep-26 |
|---|---|---|---|---|---|---|---|
| Revenue | 1,216 | 1,958 | 2,381 | 1,994 | 1,928 | 1,907 | 2,142 |
| Op. margin | – | 12.6% | 7.0% | 9.3% | 4.7% | 7.4% | 11.1% |
| PAT | 51* | 110 | 64 | 79 | 21 | 61 | 127 |
*FY21 includes Rs 72 cr exceptional gain.
- 5-yr sales CAGR ~9%, **3-yr sales CAGR -7%** (FY23 peak to FY26). PAT 5-yr CAGR ~4% on a distorted base.
- Q1 FY27: sales Rs 560 cr (+22% YoY), PAT 38.6 cr (vs 6.3), OPM 14.8%. Q2 FY27: sales Rs 590 cr (+31%), op. profit Rs 93 cr (OPM 15.8% vs 8.0%), PAT Rs 44.4 cr (vs 6.6). H1 PAT Rs 83 cr already exceeds FY26. Driver appears to be industry-wide board/W&P price hikes (Jan/Apr 2026) and import protection (MIP on paperboard, ADD recommended on virgin board) rather than volume; management gives no explanation.
- ROE 24% / ROCE 20% TTM but **D/E 1.8, interest coverage 3.5x**. Total debt Rs 932 cr (Sep-26) vs Rs 606 cr (Mar-24): rose Rs 115 cr in H1 FY27 on working-capital build (receivables Rs 343 cr, inventory Rs 431 cr, both at 5-yr highs). Debt has not fallen over 5 years despite cumulative FCF ~Rs 820 cr (FY22-26) — cash use needs probing.
- Cash conversion is good: CFO FY22-26 Rs 953 cr vs PAT Rs 335 cr (D&A-heavy). Moat: thin — commodity board/newsprint with import exposure; costs 35-40% imported pulp.

## Gate 4 — Valuation: PASS (with caveat)
- P/E 5.6 vs own FY22-26 year-end P/E range 6.1-24 (median ~9); EV/EBITDA 5.6; P/B 1.4. Peers on depressed earnings: JK Paper ~22x, West Coast 12-18x, Seshasayee ~15x, Andhra ~44x. Cheap, but on **peak-cycle margins (15-16% vs 5-yr avg ~8%)**.
- 3-yr cases: Bull — OPM holds 13%+, FY27 PAT ~Rs 160 cr, 8x = Rs 1,300 cr (+85%), debt down. Bear — margins revert to 8%, PAT ~Rs 45 cr, 7x = Rs 315 cr (-55%); leverage amplifies. Base: Rs 700-900 cr, i.e. a trade, not a compounder.

## Verdict: HOLD-FOR-REVIEW
1. Governance is not a fail (0% pledge, tiny RPTs, clean audit) but the group's 2019 pledge episode, ongoing promoter-vehicle pledging and a promoter-dominated board keep it on WATCH.
2. Management has no guidance culture and missed its only two public targets by a wide margin; no growth capex — 3-yr sales CAGR is negative, so this is a margin-cycle story.
3. Optically cheap (5.6x) but earnings are at a cyclical peak with D/E 1.8. Revisit only if Q3/Q4 FY27 hold OPM >12% and gross debt falls; otherwise REJECT for a multibagger mandate.

## Sources
- https://www.screener.in/company/EMAMIPAP/consolidated/
- https://stockanalysis.com/quote/nse/EMAMIPAP/financials/ (+ /balance-sheet/, /cash-flow-statement/, /statistics/)
- https://www.jmfinancialservices.in/market-news-and-insights/1742070 ; https://univest.in/blogs/emami-paper-mills-q2-results-fy27-pat-44-crore
- https://www.multibagg.ai/market-pulse/articles/emami-paper-q1fy27-results-cmseg9rj600hf0zmw0guknebo
- https://emamipaper.com/wp-content/uploads/2025/12/EPML_RPT_30092025-1.pdf (H1 FY26 RPT disclosure)
- https://www.indiainfoline.com/company/emami-paper-mills-ltd/reports/directors-report (FY26 Directors' Report)
- https://ticker.finology.in/Company/EMAMIPAP (pledge 0%) ; https://scanx.trade/stock-market-news/companies/ (FY26 no-encumbrance declaration)
- https://www.business-standard.com/article/companies/emami-promoters-sell-10-stake-to-pare-group-debt-pledged-shares-119021801092_1.html ; https://papermart.in/emami-stake-sale-continues-includes-paper-business-for-divestment-to-reduce-debt/
- https://filingreader.com/news-wire/mumbai/2026-09-05/emami-promoters-report-pledge-and-release-of-shares
- https://www.business-standard.com/article/pti-stories/emami-paper-shares-soar-20-on-investment-plans-115113000795_1.html ; https://thepulpandpapertimes.com/news/emami-paper-intends-to-emerge-as-a-inr-5000-crore-862
- https://nsearchives.nseindia.com/corporate/GAICH_06032026144822_EPML_CREDIT_RATING_INTIMATION_06032026.pdf
- https://money9.com/news/markets/market-news/emami-paper-hits-upper-circuit-after-turnaround-q4-results-41589.html (FY21 base)
- https://www.valueresearchonline.com/stocks/42704/jk-paper-ltd/peer-comparison/ ; https://thepulpandpapertimes.com/news/paper-price-increase-2317
