# Snowman Logistics (NSE: SNOWMAN) — Due Diligence, 2 Nov 2026

**Verdict: REJECT** — G1 WATCH / G2 FAIL / G3 FAIL / G4 FAIL

Price Rs 33.5 | Mcap Rs 560 cr | 52w 30.5–53.4 | Parent: Gateway Distriparks (GDL) 50.01%
Business: 40 temperature-controlled warehouses, 21 cities, ~1.51–1.60 lakh pallets (largest organised player, ~2x the next), plus cold transport (~250 owned + ~200 leased trucks) and a low-margin 5PL trading/distribution arm ("Snowdistribute").

## GATE 1 — Governance: WATCH
- **Promoter trend**: GDL held 40.25% (FY17–FY23), bought in the market to 44.27% (Dec-23), 45.24% (Mar-24), 50.01% (Dec-24) — creeping to control at depressed prices, no pledge disclosed. Flat at 50.01% since.
- **Family on board**: Chairman Prem Kishan Dass Gupta (CMD of GDL); sons Ishaan Gupta and Samvid Gupta (both JMDs of GDL) sit as non-executive directors. Executive management is professional (CEO Padamdeep Singh Handa, CFO Raghav Garg) — no family in paid executive roles at Snowman, so no nepotism in KMP pay.
- **RPTs**: Last readable disclosure (H2 FY23) shows only sitting fees and KMP pay, total Rs 1.1 cr (<0.5% of sales); no loans/guarantees with GDL. FY26 annual report (NSE archive) could not be opened to re-verify. A third-party filing index flags a **late RPT disclosure for H1 FY26** — a compliance slip.
- **Auditor**: no change/qualification found; limited reviews unqualified.
- **Regulatory**: Income-tax penalty for FY25 (reduced to Rs 1.72 cr on rectification, 29 Oct 2026). No SEBI action found.
- **Capital allocation smell**: FY26 dividend Rs 0.50/sh (~Rs 8.4 cr, payout ~250% of PAT of ~Rs 3 cr) paid while borrowings were Rs 312 cr and ROCE 3.6% — half of it flows to the parent.
- **Independent directors**: long-tenured, no resignations found.

## GATE 2 — Guidance & delivery: FAIL
- Rs 1,000 cr revenue target was first set for FY26 (2022), moved to FY28, and on the Q4 FY26 call (May 2026) pushed to "FY29 is more realistic", blamed on the West Asia conflict. FY26 revenue: Rs 604 cr.
- Guided ~15% growth; delivered 9% (FY26), 9% (Q1 FY27), 5% (Q2 FY27).
- Capex: earlier commentary of Rs 100–150 cr/yr on owned warehouses; actual FY26 ~Rs 30 cr, FY27 guided ~Rs 50 cr, shift to asset-light built-to-suit (Pune, Patna, Hyderabad 10k pallets). Deferral dressed as strategy.
- Margin target "15% blended EBITDA at Rs 1,000 cr" — but FY26 OPM is already 15% and PAT is near zero, i.e. the target does not fix the P&L.
- Pricing: "rate hikes passed through at renewals" — Q2 FY27 EBITDA margin did recover to 15.4% (from 13.2%), so some pricing power exists at 86–87% utilisation. Dry storage (9–10%) being cut to lift yields.

## GATE 3 — Fundamentals: FAIL
| | FY21 | FY23 | FY25 | FY26 | TTM |
|---|---|---|---|---|---|
| Sales (Rs cr) | 237 | 418 | 553 | 604 | 627 |
| OPM | 27% | 21% | 16% | 15% | 16% |
| PAT | 0 | 13 | 6 | 3 | 9 |
| ROCE | 3% | 6% | 4% | 4% | – |

- 5-yr sales CAGR 21% but mostly low-margin 5PL trading (COGS-heavy); OPM halved from 27% to 15%. 5-yr profit "CAGR" is off a zero base; 3-yr profit CAGR −30%.
- Q1 FY27: Rev 177.7 (+9%), PAT 4.6 (vs 2.5). Q2 FY27: Rev 163.6 (+5%), EBITDA 25.3 (+23%), PAT 0.96 (vs −2.9). H1 PAT ~Rs 5.5 cr on Rs 341 cr revenue.
- Capital intensity: fixed assets Rs 530 cr on Rs 627 cr sales; D&A Rs 70 cr + interest Rs 27 cr ≈ entire EBITDA (~Rs 100 cr). Lease rent ~Rs 40 cr/yr sits below EBITDA (Ind AS 116), so "true" EBITDA is ~Rs 60 cr.
- Debt Rs 275 cr (Sep-26) vs equity Rs 408 cr (D/E 0.67 incl. leases); interest cover on EBIT ~1.1–1.3x (Screener flags low coverage). Cash ~Rs 14 cr.
- CFO FY22–26 = Rs 406 cr vs cumulative PAT Rs 37 cr — cash conversion fine because it is a D&A business; but FCF after capex and lease payments barely covers interest + dividend.
- Working capital: debtor days improved 86 → 51.
- Moat: scale leader in a fragmented industry (3–4% share), but cold storage is a commodity rented by the pallet; competitors (Coldman, Coldrush, Stellar, Adani) and customer-captive capacity cap pricing.

## GATE 4 — Valuation: FAIL
- P/E ~60–90x TTM; P/B 1.4x; EV ~Rs 820 cr → EV/EBITDA ~8x on reported EBITDA, ~13–14x on pre-Ind AS 116 EBITDA. Own history: P/E has been meaningless (loss or sub-Rs 15 cr PAT for a decade); stock has gone nowhere for 10 years. Logistics peers (TCI Express, GDL, Allcargo) trade 10–14x EV/EBITDA with 10–20% ROCE — Snowman is not cheap for a 3.6% ROCE.
- Cheap for a reason? No — it is expensive for a structurally low-return asset base.
- **3-yr case**: Bull — Rs 1,000 cr revenue by FY29, 15% EBITDA (Rs 150 cr), D&A ~Rs 90 cr, interest ~Rs 25 cr → PAT ~Rs 27 cr; at 25x = Rs 675 cr (+20%). Bear — Rs 750 cr revenue, 14% margin, PAT ~Rs 5 cr, stock de-rates to 1x book ≈ Rs 24 (−30%). Reward does not pay for the risk.

## Verdict: REJECT
1. A decade of capital spending has produced ROCE of 3–4% and near-zero PAT; D&A and interest eat all EBITDA. No evidence this changes at Rs 1,000 cr revenue either.
2. Guidance slipped three times (FY26 → FY28 → FY29) with vague macro excuses; capex quietly cut from 100–150 cr/yr to 30–50 cr.
3. Valuation (60x+ P/E, 1.4x book) already prices a turnaround; dividend above profit while leveraged is a parent-friendly use of cash.
Not a governance failure, but a capital-returns failure. Re-look only if PAT margin sustainably exceeds 5% or price falls below ~Rs 20 (0.8x book).

## Sources
- https://www.screener.in/company/SNOWMAN/ (financials, shareholding, announcements)
- https://nsearchives.nseindia.com/corporate/SNOWMAN8_28102026124422_Press_Release_Q_2___signed_.pdf (Q2 FY27 press release)
- https://nsearchives.nseindia.com/corporate/SNOWMAN8_14052026115148_Outcome_Transcript.pdf (Q4 FY26 call transcript)
- https://www.arthneeti.com/insights/snowman-logistic-q1-fy27-earnings (Q1 FY27 call notes)
- https://scanx.trade/stock-market-news/companies/snowman-logistics-q4-fy26-earnings-call-capacity-utilisation-capex-plans-and-cold-chain-outlook/40347657
- https://www.whalesbook.com/corporate-news/English/industrial-goodsservices/Snowman-Logistics-Pushes-indian-rupee1000-Cr-Revenue-Target-to-FY29-Due-to-Geopolitics/6a0569ca335e73ece2785b93
- https://indiaseatradenews.com/snowman-logistics-targets-revenue-of-₹1000-crore-by-fy26/ (original FY26 target)
- https://nsearchives.nseindia.com/corporate/SNOWMAN_26052023184055_DisclosureofRelatedPartyTransactions31032023SLL26052023.pdf (RPT disclosure)
- https://univest.in/blogs/snowman-logistics-q2-results-fy27-pat-0-96-crore ; https://www.sahi.com/news/snowman-logistics-reports-q2-standalone-net-profit-of-9-6m-vs-loss-of-29m (Q2 PAT)
- https://nsearchives.nseindia.com/corporate/SNOWMAN8_03092026175547_AGM_Notice_and__Annual_Report_2025-26.pdf (FY26 AR — not retrievable at time of writing)
