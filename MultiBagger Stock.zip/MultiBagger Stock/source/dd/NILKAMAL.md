# Nilkamal Ltd (NSE: NILKAMAL) — Due Diligence, 2 Nov 2026

**Verdict: HOLD-FOR-REVIEW** | G1 Governance: WATCH | G2 Guidance & Delivery: WATCH | G3 Fundamentals: WATCH | G4 Valuation: PASS (marginal)

Price ₹1,929 | Mcap ₹2,878 cr | P/E 17.1 (TTM EPS ₹106) | P/B 1.8 | ROCE 10.6% | ROE 8.2% | Div yield 1.05% | 52w range ₹1,036–2,150 | CARE AA/Stable, A1+

Note: the "@home" retail brand no longer exists as a reporting line. In FY25 Nilkamal folded @home into "Nilkamal Homes", cut the retail network from 124 to 84 stores (FOFO rationalisation) and now reports one "Retail & E-commerce" segment (108 stores at 30 Sep 2026: 31 COCO, ~77 FOFO).

## Gate 1 — Governance: WATCH
- **Promoter holding** flat at 64.54% since FY23 (64.10% in FY17). No pledge disclosed on Screener or in the FY26 annual report. FII/DII fell from ~20% to ~8% in Sep-26 while public rose to 26.5% — institutions sold into the rally.
- **Family KMP count is heavy.** Board of 8: Sharad V Parekh (Chairman, non-exec), Hiten V Parekh (MD), Manish V Parekh (JMD), Nayan S Parekh (JMD) = 4 Parekhs; 4 independents (Abhay Jadeja, Ashok Goel, Kavita Shah, Gautam Chakravarti). Mihir Parekh (next generation) is "President". CFO Paresh Mehta and CS Sagar Mehta are professionals. Only the Hiten–Manish brother link is disclosed in the AGM notice; the rest of the web of relationships is not spelled out.
- **Promoter remuneration** FY26: Hiten ₹4.25 cr, Manish ₹4.06 cr, Nayan ₹3.84 cr = ₹12.2 cr, i.e. ~11.6% of standalone PAT (₹105 cr), 72–80x median employee pay, plus 1% commission each on PAT above ₹50 cr. Hikes 4–11% vs 6% for median employee. High for a company earning 8% ROE.
- **RPTs** with KMP-influenced entities (Nilkamal Crates & Containers, M. Tech Industries, Raga Plast): purchases ₹15.9 cr, services ₹2.3 cr, rent ₹1.8 cr, sales ₹1.2 cr — ~0.5% of sales, declining YoY. Immaterial; AOC-2 not triggered.
- **Auditor** S R B C & Co LLP (EY network) since 2023, unmodified opinion FY26 and limited review Q2 FY27. No CARO adverse remarks. One ₹1.58 lakh BSE penalty (FY23 filing lapse). No SEBI action, no price/volume clarification found.
- **Negatives:** no earnings concalls at all (none listed on Screener), so investor access is press-release-only; CHRO Maya Verma resigned 28 Oct 2026; ID K. Venkataramanan exited Aug 2025 on completing two terms (not a resignation). Exceptional labour-code charge ₹15.4 cr in Q3 FY26.

## Gate 2 — Management Guidance & Delivery: WATCH
Nilkamal gives no numeric guidance and holds no concalls, so "delivery" is judged against stated intentions in press releases, the annual report and the CARE rationale:
- **Retail losses to be eliminated:** delivered. Retail EBIT -₹34.5 cr (FY25) → -₹17.6 cr (FY26) → +₹1.7 cr (Q1 FY27) → -₹4 cr (Q2 FY27, store-opening costs). Segment revenue ₹351 → ₹408 cr → H1 FY27 ₹223 cr (+10%).
- **Capex:** FY25 ₹280 cr (foam backward integration, Hosur), FY26 ₹144 cr, FY27 plan ~₹150 cr (₹100 cr debt-funded per CARE); H1 FY27 actual ₹68 cr — on track, not deferred.
- **Deleverage:** net borrowings ₹376 cr (Sep-25) → ₹254 cr (Sep-26); NCD ₹49 cr bullet due Mar-27 covered by ₹107 cr cash.
- **Stores:** said "add 20+", went 101 → 108 in six months; 23 planned for FY27.
- **Margin claims vs. reality:** OPM stuck at 9% for FY23–FY26 despite repeated "operational efficiency" language. Q2 FY27 (12%) is the first breakout; one quarter is not a trend. Q1 FY27 volumes fell 37% as the company held price through a ~50% polymer spike (Middle-East disruption) — shows pricing discipline but also demand fragility in material handling.

## Gate 3 — Fundamentals: WATCH
- **Growth:** sales 5Y CAGR 13% (₹2,092 → ₹3,778 cr), 10Y 7%. Profit 5Y CAGR 2%, 10Y 1% (₹116 cr in FY16, ₹116 cr in FY26). Fifteen years of growth with zero profit compounding until this year.
- **Recent quarters (consol):** Q1 FY27 sales ₹820 cr (-7% YoY), PAT ₹24 cr (+60%); Q2 FY27 sales ₹1,126 cr (+16%), PAT ₹68 cr (+100%), OPM 12%. TTM sales ₹3,873 cr (+8%), TTM PAT ₹159 cr (+62%).
- **Segment mix (Q2 FY27 standalone):** B2B ₹987 cr (+18%: material handling +22%, mattress/foam +39%, ready furniture +15%, plastic furniture -1%); Retail ₹119 cr (+8%).
- **Margins vs Supreme Industries:** Nilkamal OPM 9–10% (12% Q2) vs Supreme 14% (20% in FY21); ROCE 10.6% vs 21%. Nilkamal's ROCE has slid from 26% (FY16) to 11% as capital went into retail, mattresses and foam. It is a brand-led converter without Supreme's scale economics.
- **Balance sheet:** gross borrowings ₹435 cr incl. leases; D/E ex-lease 0.16; net debt/EBITDA ~0.7x; interest coverage 7x (CARE), ISCR 10.6x. Cash+investments ₹107 cr.
- **Cash conversion:** CFO FY22–26 = ₹1,062 cr vs PAT ₹562 cr (1.9x, helped by ₹140 cr/yr depreciation); FY26 CFO ₹306 cr vs PAT ₹116 cr, FCF ₹159 cr. Working-capital days improved 100 (FY21) → 64 (FY26); CCC 148 → 109; inventory days still 110.
- **Moat:** strong brand and 20,000-dealer distribution in moulded furniture and material handling; weak in retail/mattress where it fights Sleepwell, Duroflex, Pepperfry et al. Polymer price pass-through takes 1–2 quarters.

## Gate 4 — Valuation: PASS (marginal)
- P/E 17.1 on TTM; own 5-yr range roughly 10–40x (42x in late 2021 on depressed FY22 EPS, ~14x at the Feb-26 low of ₹1,036), median ~20x. EV/EBITDA ≈ (2,878 + 254 net debt + ~160 leases) / 395 ≈ 8.3x. P/B 1.8 for 8% ROE is fair, not cheap. Peer Supreme at 36x P/E.
- **Why it re-rated +50% in six months:** from a trough P/E of ~14x, FY26 PAT +9% with dividend raised to ₹20; Q1 FY27 PAT +60% on an 8% sales fall (margin proof); Q2 FY27 PAT doubled with a 12% OPM; retail turned EBIT-positive; net debt halved. This is a cyclical/execution recovery, not a structural change in return on capital.
- **3-year cases (FY29):** Bull — sales ₹5,000 cr at 11% OPM, PAT ₹250 cr, 20x → ₹5,000 cr mcap (+75%). Base — PAT ₹190 cr, 17x → ₹3,230 cr (+12%, plus 1% yield). Bear — OPM reverts to 9%, PAT ₹130 cr, 13x → ₹1,700 cr (-40%). Skewed roughly 2:1 up/down only if the 12% margin holds.

## Verdict: HOLD-FOR-REVIEW
1. **Not a multibagger profile:** 10-year profit CAGR of 1% and ROCE of 10.6% say the business has compounded capital poorly; the current run is margin mean-reversion already half priced at 17x.
2. **Governance is adequate but family-heavy:** four Parekhs on an eight-member board drawing ₹12 cr (12% of PAT) at 70–80x median pay, zero concalls, no guidance. Clean auditor (EY affiliate), no pledge, small RPTs keep it out of FAIL.
3. **Balance sheet and cash generation are genuinely good** (AA rating, CFO 1.9x PAT, net debt falling), and the retail loss has been fixed as promised.

Re-review after Q3 FY27 (Feb 2027): a SELECT needs OPM ≥ 11% for two more quarters, retail EBIT ≥ 0 and entry below ~₹1,600 (≤14x TTM). Otherwise stay out.

## Sources
- https://www.screener.in/company/NILKAMAL/consolidated/
- https://nilkamal.com/wp-content/uploads/2026/10/Press-Release-on-Quarter-2-%E2%80%93-FY-2027-Result.pdf
- https://nilkamal.com/wp-content/uploads/2026/08/Press-Release-on-Quarter-1-%E2%80%93-FY-2027-Result.pdf
- https://nilkamal.com/wp-content/uploads/2026/05/Press-Release-on-Quarter-4-%E2%80%93-FY-2026-Result.pdf
- https://www.bseindia.com/xml-data/corpfiling/AttachHis/eef47ff5-c740-4e53-8ed8-74b407598517.pdf (Annual Report FY2026)
- https://www.careratings.com/upload/CompanyFiles/PR/202607120717_Nilkamal_Limited.pdf (CARE rating rationale, 27 Jul 2026)
- https://nilkamal.com/leadership-team/
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=47d5d8d8-c4d0-4987-a362-ef24a145fad1.pdf (CHRO cessation, 28 Oct 2026)
- https://www.screener.in/company/SUPREMEIND/consolidated/ (peer margins)

## Primary-source verification (2 Nov 2026)

Sources were downloaded and parsed directly (NSE XBRL, NSE results filing PDF, FY26 annual report PDF from BSE). All ₹ figures below are from the filings; lakh → crore conversions are mine.

**1. Pledge and promoter holding — CONFIRMED.** Sep 2026 XBRL (filed 13 Oct 2026): promoter & promoter group 64.54% (`ShareholdingAsAPercentageOfTotalNumberOfShares = 0.6454`); all six encumbrance flags `false` (pledge, NDU, other) → **0% pledge**. Public 35.46%. Remark: Vamanrai V. Parekh died 2 May 2025; still shown as promoter because transmission is in process.
Source: https://nsearchives.nseindia.com/corporate/xbrl/SHP_1736873_13102026032816_WEB.xml (via https://www.nseindia.com/api/corporate-share-holdings-master?index=equities&symbol=NILKAMAL).

**2. Family remuneration FY26 — CONFIRMED (slightly higher once relatives are added).** AR Note 42 (RPT): "Remuneration to Directors" (KMP = Hiten, Manish, Nayan) ₹1,214.67 lakh = **₹12.15 cr** (FY25 ₹11.21 cr), excluding gratuity/leave provision; Director commission payable at year-end ₹2.88 cr (1% of PAT above ₹50 cr each). Annexure D Rule 5(1) ratios to median pay: Hiten 80.28x, Manish 76.69x, Nayan 72.43x, Sharad (non-exec chairman) 1.27x; hikes 11.43% / 3.91% / 10.11% vs median 6.00%; relationships: Hiten–Manish brothers, Nayan is Sharad's son. **Relatives on payroll:** Mihir H. Parekh and Eashan M. Parekh (sons of Hiten and Manish) — "Salary Paid" to relatives of KMP ₹90.03 lakh (flat YoY). Total family pay ≈ ₹12.15 + 0.90 + ~0.07 (Sharad) = **₹13.1 cr = 11.3% of FY26 consolidated PAT ₹116.07 cr** (12.5% of standalone PAT ₹105.13 cr). Below the 15% threshold. The per-person ₹4.25/4.06/3.84 cr in the note are consistent with the ratios × implied median (₹5.30 lakh) and the ₹12.15 cr total; a per-director rupee table did not parse from the PDF.
Source: FY26 AR (BSE) https://www.bseindia.com/xml-data/corpfiling/AttachHis/eef47ff5-c740-4e53-8ed8-74b407598517.pdf — Annexure D (Rule 5), Note 42, CG report s.(e).

**3. Related-party transactions FY26 — CONFIRMED (and the entity list in the note corrected).** Nilkamal Crates & Bins FZE and the two Nilkamal Eswaran companies are *subsidiaries* (eliminated on consolidation), Cambro Nilkamal is a 50% JV with Cambro (not promoter-controlled); no family trust appears as a related party and there is no royalty line. Promoter/KMP-influenced enterprises are Nilkamal Crates & Containers, M. Tech Industries and Raga Plast Pvt Ltd: purchases ₹15.88 cr, services/labour paid ₹2.27 cr, rent paid ₹1.82 cr, sales ₹1.21 cr = **₹21.2 cr = 0.56% of consolidated revenue ₹3,778.06 cr** (FY25 ₹28.2 cr). Rent deposits receivable from them ₹3.70 cr (down from ₹7.20 cr). Including the JV (sales ₹46.1 cr to Cambro Nilkamal, fees received ₹8.05 cr, dividend ₹5.25 cr) total non-subsidiary RPTs ≈ 1.6% of revenue. Board's report: all RPTs arm's length, ordinary course, no material RPT, **AOC-2: nil**. Independent of Audit Committee omnibus approvals.
Source: FY26 AR Note 42 (standalone p.136–137, consolidated p.~250) and Board's Report "Related Party Transactions".

**4. Auditor — CONFIRMED.** S R B C & CO LLP, Chartered Accountants, Mumbai, **ICAI FRN 324982E/E300003** (EY network; appointed FY24). FY26: unmodified opinion on both standalone and consolidated statements ("true and fair view"), Key Audit Matter = revenue recognition, no EoM; Board's report confirms "unmodified opinion". Q2 FY27: limited review under SRE 2410 on standalone and consolidated — "nothing has come to our attention…" (unmodified conclusion); outcome letter states "with unmodified opinion".
Source: AR p.~100 audit report; NSE filing https://nsearchives.nseindia.com/corporate/NILKAMAL_29102026133626_UFR_30092026.pdf.

**5. Q2 FY27 consolidated — CONFIRMED on P&L, CHANGED on cash/net debt.**
- Revenue from operations **₹1,125.85 cr** vs ₹967.71 cr (**+16.3%**); other income ₹3.64 cr.
- EBITDA (PBT pre-exceptional + finance cost ₹9.81 cr + D&A ₹40.50 cr) **₹138.36 cr** vs ₹88.59 cr (+56%) → **12.3% of revenue**; the filing's own "Operating Margin" (excludes other income) **11.97%** vs 9.00% in Q2 FY26 and 9.10% in Q1 FY27.
- PBT ₹91.09 cr (incl. JV share ₹3.05 cr) vs ₹45.06 cr; PAT **₹67.83 cr** vs ₹33.66 cr (**+101.5%**); EPS ₹45.41 vs ₹22.49.
- H1 FY27: revenue ₹1,945.59 cr (+5.1%), EBITDA ₹217.48 cr (operating margin 10.76% vs 7.97%), PAT **₹92.23 cr** vs ₹48.99 cr (+88.3%), EPS ₹61.70.
- Segments (consolidated): B2B revenue ₹1,007.24 cr (+17.4%), EBIT ₹106.72 cr vs ₹56.44 cr; **Retail & E-commerce revenue ₹118.61 cr (+7.9%), EBIT −₹3.51 cr vs +₹1.40 cr** (Q1 FY27 +₹1.68 cr; H1 −₹1.83 cr vs −₹8.10 cr). 108 stores.
- Balance sheet 30 Sep 2026 (consolidated): borrowings ₹153.95 cr non-current + ₹100.76 cr current = **₹254.70 cr gross**; cash ₹29.07 cr + other bank ₹4.67 cr + current investments ₹0.45 cr = ₹34.20 cr → **net debt ₹220.5 cr ex-leases** (lease liabilities ₹180.5 cr extra). D/E 0.16. The press release's "net borrowing ₹254 cr" is effectively gross standalone borrowings (standalone cash ₹4.6 cr). **CHANGED vs note:** cash+investments fell from ₹105.5 cr (Mar-26) to ₹34.2 cr as inventories (+₹102 cr) and receivables (+₹67 cr) absorbed cash; listed NCDs outstanding are ₹24.01 cr, not ₹49 cr. Gross debt flat vs Mar-26 (₹255.9 cr), down from ₹376 cr a year ago.
- Commentary (press release, no concall, no numeric guidance): RM prices stayed elevated; Q1 volumes −37% with <50% utilisation as prices were held; Q2 volumes +54% QoQ at >70% utilisation with prices maintained; mattress/foam +39%, material handling +22%, ready furniture +15%, plastic furniture −1%, Bubbleguard −1%; e-commerce +11%, stores +5%; Q2 capex ₹27 cr (vs ₹42 cr).
Source: https://nsearchives.nseindia.com/corporate/NILKAMAL_29102026133626_UFR_30092026.pdf (results + press release, 29 Oct 2026).

**6. Announcements since 1 Oct 2026 — CONFIRMED (nothing new).** NSE list: 6 Oct Reg 74(5) certificate (routine); 13 Oct Sep-26 shareholding pattern (0% pledge) and newspaper ad on special window for re-lodgement of transfer requests (routine); 28 Oct resignation of CHRO Maya Varma (senior management, not KMP/board; letter dated 28 Oct 2026); 29 Oct board outcome/results. **No** pledge, SEBI action, new RPT approval, buyback, dividend or director change.
Source: https://www.nseindia.com/api/corporate-announcements?index=equities&symbol=NILKAMAL&from_date=01-10-2026&to_date=02-11-2026; https://nsearchives.nseindia.com/corporate/NILKAMAL_ROID_102239_KMP_Doc.zip.

**7. Price and TTM P/E — CHANGED.** Price ₹1,918 (Screener, 2 Nov 2026 13:57 IST; NSE quote API blocked), 1,49,22,525 shares → mcap ₹2,862 cr. TTM consolidated PAT = FY26 ₹116.07 − H1 FY26 ₹48.99 + H1 FY27 ₹92.23 = **₹159.3 cr**; TTM EPS = 77.45 − 32.70 + 61.70 = **₹106.45** → **P/E 18.0x** (Screener's displayed 17.0 does not reconcile with its own EPS; the note's 17.1 is therefore understated).
Source: https://www.screener.in/company/NILKAMAL/consolidated/ ; EPS from the filings above.

**Summary:** 1 CONFIRMED · 2 CONFIRMED (11.3% of consol PAT incl. two next-gen relatives) · 3 CONFIRMED (0.56%; entity list corrected) · 4 CONFIRMED · 5 CONFIRMED on P&L, CHANGED on cash (₹34 cr, not ₹107 cr) and NCDs (₹24 cr) · 6 CONFIRMED · 7 CHANGED (P/E 18.0x, not 17.1x).

**NILKAMAL: SELECT — all five screen conditions are met on primary sources (0% pledge; family pay 11.3% of PAT; RPTs 0.56% of revenue; unmodified FY26 audit and Q2 review; Q2 operating margin 11.97% with PAT +101%). Caveats carried from the note: one quarter of ≥11% margin, retail EBIT turned negative again in Q2 (−₹3.5 cr), cash has dropped to ₹34 cr on working capital, and at 18x TTM the stock is above the ≤14x entry the note set.**
