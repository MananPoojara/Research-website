# Uniparts India Ltd (NSE: UNIPARTS) — Due Diligence, 5 Nov 2026

**Verdict: HOLD (watchlist)** | G1 Governance: PASS | G2 Guidance: WATCH | G3 Fundamentals: WATCH | G4 Valuation: WATCH

Noida; 3-point linkages (3PL) and precision machined parts (PMP) for ag/construction OEMs; 6 plants India + 1 US (Eldridge, Iowa); warehouses US (2), Germany, Mexico. Soni family (Gurdeep Soni CMD, Paramjit Singh Soni Vice Chairman). Listed 12 Dec 2022 at Rs 577 (100% OFS).

**Snapshot (5 Nov 2026, consolidated):** CMP Rs 754 | Mcap Rs 3,405 cr | P/E 17.2x TTM (EPS Rs 43.3) | P/B 3.6x (BV Rs 209) | Div yield 2.0% | ROCE 21.6% (FY26; co. says TTM >27%) | ROE 18.3% | Promoter 65.85% (Sep 2026), pledge nil | 52w Rs 400–916 | 1-yr +50%; since IPO +31% price (~7% CAGR over 3.9 yrs) plus ~Rs 80/sh cumulative dividends. [screener, stockanalysis]

**Latest:** Q2 FY27 (quarter to 30 Sep 2026), board approved 4 Nov 2026, call 5 Nov 2026. Revenue Rs 378.5 cr (+36.7% YoY, +9% QoQ, highest ever), operating EBITDA Rs 83.4 cr (22.0%), reported EBITDA Rs 88.6 cr (23.1%), PAT Rs 54.4 cr (+38% YoY, −4% QoQ); net US tariff refund +Rs 1.29 cr to PBT. H1 FY27: total income Rs 739 cr (+31.5%), PAT Rs 111 cr (+50%). Net cash Rs 172 cr at 30 Sep 2026. [Q2 FY27 presentation, autocarpro]

## Gate 1 — Governance: PASS

- **Holding/pledge:** Promoter + group 65.85% (Sep 2026; 65.66% at IPO, small open-market buys since). Reg 31(4) declaration signed by both Sonis, 1 Apr 2026: no encumbrance on any promoter share during FY26. Trendlyne/MarketsMojo show 0% pledge Sep 2024–Mar 2026. Promoter group = 43 entities (Soni Holdings, three "2018 CG-NG Nevada Trusts", LLPs, HUFs).
- **Family roles:** Gurdeep Soni, Chairman & MD (holds 89.95 lakh sh = 19.9%); Paramjit Singh Soni, Vice Chairman & Executive Director (also president, Uniparts USA). Angad Soni and Arjun Soni appear only as "relatives of KMP" receiving dividends (Rs 7.55 cr each in FY26) — **no executive role found; not verified** that they are employed in the group. Professional management layer since Dec 2025: Tanushree Bagrodia (ex-CFO Laxmi Organic, NRB Bearings) Whole-time Director + Group CEO from 1 Jan 2026; COO, Global S&OP and Commercial heads appointed same date, all unrelated to directors.
- **Promoter pay (FY26, AR Note 41):** Gurdeep Soni Rs 2.95 cr (paid by subsidiary Gripwel Fasteners), Paramjit Soni Rs 4.99 cr (paid by Uniparts USA), Bagrodia Rs 2.33 cr (CTC revised to Rs 3.83 cr for 2026-27 by postal ballot Jan 2026). Soni family pay Rs 7.95 cr = **5.0% of FY26 consolidated PAT Rs 158 cr** — reasonable. Optics watch: the AGM notice states Gurdeep Soni "has not drawn any remuneration from the Company" — technically true because pay is routed via subsidiaries.
- **RPTs with promoter entities (FY26):** rent to Soni Holdings Rs 0.37 cr, electricity to Avid Star LLP Rs 0.04 cr — **<0.05% of revenue**. No AOC-2 material RPT. Dividends to promoter persons/trusts Rs 112 cr in FY26 (proportional to 65.9% stake).
- **IPO (Dec 2022):** pure OFS of 1.448 cr sh at Rs 577 = Rs 835.6 cr; company got nothing. Sellers: promoter group 44 lakh sh (~Rs 254 cr, incl. 11 lakh by Karan Soni 2018 Nevada Trust), PE investors Ashoka Investment Holdings (71.8 lakh sh) and Ambadevi Mauritius — both exited fully (93.3 lakh sh, ~Rs 539 cr), individual sellers 7.5 lakh sh. Promoter 75.5% → 65.8%. Muted debut; stock fell to Rs 400 (−31% vs issue) in 2025.
- **Auditor:** S.C. Varma & Co. (FRN 000533N), appointed 28th AGM (Jul 2022) for 5 years to 33rd AGM (2027). Unmodified opinion FY26, no EoM reported; unmodified limited review Q2 FY27. Secretarial and cost audits clean. **Watch:** small Delhi firm for a Rs 1,350 cr group with ~60% revenue booked through US/German subsidiaries; auditor of foreign subs not verified.
- **Exits (24 months):** Group CFO Rohit Maheshwari (pre-IPO CFO) resigned 12 Mar 2026 "personal reasons", 10 weeks after Bagrodia became Group CEO; Sandeep Taneja appointed 16 Mar 2026. CIO resigned Mar 2025; one SMP exit Jan 2025. No independent director or CS resignation in 24 months (Sharat Mathur's term ended 31 Mar 2024; Celine George reappointed Nov 2025). Board 8: 3 executive, 1 NED (H.K. Coenen), 4 independent.
- **Regulatory:** No SEBI/exchange action found. IT demand Rs 25.8 cr (AY2024-25, 80M deduction) fully deleted on rectification. Investor grievances 11 received/11 resolved Q4 FY26.
- **Capital allocation:** dividend payout 51% FY24, 73% FY25, **108% FY26** (Rs 37.75/sh = Rs 170 cr incl. Rs 101 cr special after a near-acquisition was dropped); FY27 first interim Rs 9. Capex 2–3% of revenue (cash capex Rs 24 cr FY26). No buyback. M&A: "about a dozen targets" evaluated since IPO, two deals "fell apart"; wants a third product platform (hydraulics/PTO), ROE/ROCE-accretive. ICRA AA-(Stable)/A1+ reaffirmed 7 May 2026; downgrade trigger includes cash depletion from acquisitions or high payouts.

## Gate 2 — Guidance & Delivery: WATCH

| Date / call | Guidance | Delivered |
|---|---|---|
| Aug 2023 (Q1 FY24), Paramjit Soni | FY24 top-line cut from 15–16% to high single digit, then withdrawn ("I want to refrain… for the full year"); destocking "another quarter or quarter and a half at best"; FY25 "significantly higher" than 16% long-term pace | FY24 sales −15% to Rs 1,140 cr, PAT −39% to Rs 125 cr; destocking ran 6+ quarters. **Miss** |
| Aug 2024 (Q1 FY25), Paramjit Soni | FY25 "flat to maybe minus 2%, 3%"; EBITDA "18%… for this full year"; "quarter 4… where you will see the turnaround"; capex Rs 35–40 cr | FY25 sales −15% to Rs 964 cr, EBITDA 16.9%, PAT −30% to Rs 88 cr; Q4 FY25 was the sequential low-point exit (Rs 253 cr) but still −13% YoY. **Miss** |
| Nov 2024 (Q2 FY25) | H2 flattish vs H1, Q4 highest run rate; large ag "about a year to come back"; construction growth H2 CY25; new wins Rs 177 cr TTM | Q4 FY25 was the highest quarter (Rs 253 cr); construction turned up H2 CY25. **Met** |
| Nov 2025 (Q2 FY26) | FY26 "mid-teens" growth (new business 11–12% + base 3–4%); margins 18–20% trending to 20%; peak EPS Rs 45–50 regained by FY27/mid-FY28 | FY26 sales +21% to Rs 1,170 cr, EBITDA 22.3%, PAT +80% to Rs 158 cr; TTM EPS Rs 43.3 at Q2 FY27. **Beat** |
| May 2026 (Q4 FY26), Soni/Bagrodia | "growth in FY27 to be in line with… FY26" (~21%); "comfortably over the 20%" EBITDA; H2 > H1; capex 2.5–3.5% of revenue; "P&L neutral as far as tariffs are concerned" | H1 FY27 revenue +32%, op. EBITDA 22–24%. **Ahead** |
| Aug 2026 (Q1 FY27), Bagrodia | FY27 growth "a couple of percentage points bigger" than FY26 (~23%); Q2 "in line with Q1" | Q2 revenue +9% QoQ, +37% YoY. **Ahead** |

- **FY24–FY25 downturn explained:** US small-ag (consumer utility tractors, rate-sensitive) and aftermarket channel destocking from Q1 FY24 (~Rs 27 cr/qtr), freight-linked price cuts (Rs 8–9 cr), then large-ag down-cycle (OEM volumes −10–20%) and construction softening in FY25; Hurricane Helene cost ~2.5% of Q2 FY25 revenue. Sales fell 29% peak-to-trough (FY23 Rs 1,366 cr → FY25 Rs 964 cr), OPM 22% → 15%, PAT 205 → 88 cr.
- **TTM recovery:** construction (now ~46% of revenue) +49% YoY in Q2 FY27 on US/EU infrastructure spend; small ag +25%; large ag +10% against an industry −17% on new wins (Europe); aftermarket +50%; new-business awards Rs 177 cr (Nov 2024) → Rs 225+ cr TTM; tariffs passed through; operating leverage from mid-50s utilisation. Large ag OEMs call CY2026 the trough, recovery FY28.
- **Verdict on Gate 2:** management guided down honestly but was two years early on the recovery (FY24 and FY25 both missed by ~15 points of growth). Since Nov 2025 it has beaten every quarter. Credibility rebuilt but short; one full cycle of accurate guidance not yet shown.

## Gate 3 — Fundamentals: WATCH

- **Growth (consolidated):** sales CAGR 5y 5%, 3y −5%, TTM +33%; PAT CAGR 5y 12%, 3y −8%, TTM +71%. FY19 Rs 1,061 cr → FY26 Rs 1,170 cr = 1.4% CAGR over 7 years. This is a cyclical recovery to the FY23 peak (Rs 1,366 cr), not yet compounding.
- **Margins:** OPM 13% (FY21) → 22% (FY22–23) → 18% → 15% (FY25) → 21% (FY26) → 22–24% last four quarters. Gross margin 65–67% (warehouse/local delivery premium). Management's through-cycle target 20%.
- **Returns:** ROCE 11% FY20, 17%, 30%, 32% (FY23), 18%, 12% (FY25), 22% FY26; ROE 5-yr avg 19%. Fixed-asset turnover 1.7x.
- **Balance sheet:** borrowings Rs 162 cr (Sep 2026, incl. ~Rs 62 cr leases) vs cash + liquid investments ~Rs 334 cr → net cash Rs 172 cr; D/E 0.11; interest cover 23x (ICRA). Investments rose from 0 (FY22) to Rs 233 cr.
- **Cash conversion:** CFO FY21–FY26 Rs 1,068 cr vs PAT Rs 836 cr = **1.3x**; FCF FY22–25 Rs 150–220 cr/yr. But working capital is heavy: cash conversion cycle 326 days, inventory days 409 (FY26), WC days 107; ICRA puts WC intensity at 39–44% of revenue because the global warehouse model holds 5–6 months of stock in transit/overseas.
- **Mix (H1 FY27):** product — PMP 55%, 3PL 43%, PTO/fabrication 2%; geography — Americas 59%, Europe 21%, India 13%, Japan 5%; end-market — ag 54%, construction 46%; OEM 85.5%/aftermarket 14.5%; warehouse-delivered ~56%.
- **Concentration (rising):** top customer 28% (ICRA: "a leading global agricultural and construction equipment OEM"; broker notes name John Deere — **not verified by company**), top-5 69% (64% FY26, 61% FY25), top-10 83% (78% FY26). Customers named in DRHP/analyst notes: Deere, CNH, AGCO, Kubota, Caterpillar, Komatsu, Bobcat/Doosan — shares not disclosed. ICRA explicitly flags "moderate customer concentration risk".
- **Moat:** ~16.7% global 3PL share by value and 5.9% of PMP for construction/forestry (FY22, DRHP); engineered, OEM-validated parts with long qualification cycles; global service-delivery model (make in India, stock in US/EU/Mexico warehouses) lets OEMs buy JIT at local-delivery premium; proven tariff pass-through in FY26. Moat is in switching cost and logistics, not technology; 3PL is a mature, slow-growing category (small-ag unit volumes ~flat to +5%).
- **Capex intensity:** low — 2–3.5% of revenue guided; installed capacity 67,320 tpa, utilisation mid-to-high 50s (Nov 2024), so volume growth needs little new capital. Mexico warehouse (first dispatch Nov 2026) and Ludhiana finishing-shop rebuild (fire Q3 FY26, insured, back by Dec 2026) are the only projects.
- **US tariff exposure:** US ~45–50% of revenue (ICRA), Americas 59% H1 FY27. FY26 tariffs were passed to customers ("P&L neutral"); Q2 FY27 booked a net Rs 1.29 cr refund as US rates came down. Risk is demand destruction and price volatility (aftermarket skewing in FY26), not margin; ICRA keeps it "monitorable". No US-China style substitution risk as the US plant plus Mexico warehouse offer local delivery.

## Gate 4 — Valuation: WATCH

- **Own band since listing (stockanalysis, fiscal year-ends):** P/E 11.6x (Mar 2023) → 18.5x (Mar 2024, trough earnings) → 15.6x → 12.6x (Mar 2026) → **17.1x now**; EV/EBITDA 8.9x → 12.6x → 10.2x → 7.8x → **~10.7x now** (EV Rs 3,233 cr / TTM operating EBITDA Rs 303 cr); P/B 2.9x → 2.7x → 1.6x → 2.3x → **3.6x now**. Price is at the top of its own band on P/B and EV/EBITDA, mid-high on P/E — and on peak-cycle margins (22–24% vs 20% guided through-cycle).
- **Peers (5 Nov 2026, screener):** Happy Forgings P/E 54x, ROCE 18%, OPM 30%; Ramkrishna Forgings 69x (depressed earnings), ROCE 6%; Value Research industry median P/E 27x. Uniparts at 17x/2% yield is cheap on peers but the peers have 15–25% structural growth; Uniparts' 7-year sales CAGR is 1.4%.
- **3-year cases to FY29 (FY26 base: sales Rs 1,170 cr, PAT Rs 158 cr, 4.52 cr shares; FY27E PAT ~Rs 215 cr on H1 run-rate):**
  - **Bear (25%):** US recession / tariff re-escalation, large-ag recovery slips to FY29; FY29 sales Rs 1,300 cr, EBITDA 17%, PAT Rs 130 cr, EPS Rs 29, 13x → **Rs 375 (−50%)**.
  - **Base (50%):** FY27 +23%, FY28 +12%, FY29 +11% → sales Rs 1,800 cr, EBITDA 21%, PAT Rs 245 cr, EPS Rs 54, 16x → **Rs 870 + ~Rs 60 dividends ≈ Rs 930 (+23%, ~7% p.a. plus 2.5% yield)**.
  - **Bull (25%):** large-ag upcycle CY27–28 plus an accretive third-platform acquisition; FY29 sales Rs 2,200 cr, EBITDA 22%, PAT Rs 310 cr, EPS Rs 69, 20x → **Rs 1,380 (+83%)**.
  - Probability-weighted ≈ Rs 905 (+20% over 3 years incl. dividends in base). Upside/downside roughly 1.7:1 — fair, not a margin of safety.
- **Multibagger case (3x in 5 years = Rs 2,260, mcap ~Rs 10,200 cr by Nov 2031):** needs PAT ~Rs 500 cr at 20x, i.e. ~20% PAT CAGR from FY27E Rs 215 cr, which means ~18–20% revenue CAGR to ~Rs 3,300 cr at 15% net margin. That requires (a) a full large-ag upcycle 2027–30, (b) a successful acquisition that adds a third platform (none closed in 4 years of trying), (c) no US recession, and (d) a re-rating to 20x at the end of the cycle. The company has never delivered its own 15–16% through-cycle target (7-yr actual 1.4%). **Probability assigned: ~10–15%.**

## Verdict: HOLD (watchlist)

**Deciding fact:** 7-year sales CAGR is 1.4% and 3-year CAGR −5%; the +33% TTM is a cyclical rebound to the FY23 peak priced at the top of the stock's own EV/EBITDA and P/B band on peak margins, with top-10 customer share rising to 83%. Clean governance and a net-cash, 20%+ ROCE business justify holding on the watchlist, not selecting.

**Re-review trigger (dated):** after Q4 FY27 results, by 31 May 2027. Upgrade to SELECT if FY27 revenue ≥ Rs 1,430 cr with operating EBITDA ≥ 20% **and** a third-platform acquisition is announced at ≤ 8x EBITDA, **or** if price falls below ~Rs 600 (≈ 12.5x FY27E) with guidance intact. Downgrade to REJECT if top-customer share exceeds 30% with revenue falling, or any adverse auditor/CFO event.

## Top 3 reasons

1. **Cyclical, not compounding:** sales Rs 1,061 cr (FY19) → Rs 1,170 cr (FY26); two consecutive −15% years in FY24–25 and the 15–16% through-cycle growth target has never been met. Today's 22–24% margins sit above the 20% management itself calls sustainable.
2. **Price already discounts the recovery:** P/B 3.6x and EV/EBITDA ~10.7x are at the top of the post-listing band; stock +50% in a year and +88% from the Rs 400 low; probability-weighted 3-year return ~+20%; multibagger probability ~10–15%.
3. **What keeps it on the watchlist:** nil pledge, promoter pay 5% of PAT, RPTs <0.05% of revenue, professional Group CEO, net cash Rs 172 cr, CFO/PAT 1.3x, ICRA AA-, 108% payout, and guidance beaten four quarters running. Watch items: small statutory auditor (S.C. Varma & Co.), promoter pay routed through subsidiaries, pre-IPO CFO exit in Mar 2026, customer concentration rising.

## Sources (URLs)

- https://www.screener.in/company/UNIPARTS/consolidated/
- https://www.bseindia.com/xml-data/corpfiling/AttachHis/bea1f4b4-16e1-4e4b-bdad-01ff376e6e9e.pdf (FY2025-26 Annual Report: Board's Report, CG report, Note 41 RPTs)
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c87009b3-fb54-4800-95ef-7c511925d1ae.pdf (Q2 FY27 investor presentation, 4 Nov 2026)
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3c2083c8-ec8d-4835-9416-0d392664b3b0.pdf (Q1 FY27 call transcript, 5 Aug 2026)
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a980be58-5bbd-4fdf-9918-94f00c2690ab.pdf (Q4 FY26 call transcript, 26 May 2026)
- https://nsearchives.nseindia.com/corporate/Earth_2018_04082026194844_Q126EarningsCallPresentation.pdf (Q1 FY27 presentation)
- https://nsearchives.nseindia.com/corporate/Earth_2018_25052026212709_Q426EarningsCallPresentation.pdf (Q4 FY26 presentation)
- https://www.bseindia.com/xml-data/corpfiling/AttachHis/3c93b8ed-ea37-4bae-80c4-10a89123b7b6.pdf (Q2 FY25 call transcript, 8 Nov 2024)
- https://nsearchives.nseindia.com/corporate/UNIPARTS_15082024220239_Q1EarningsCallTranscript.pdf (Q1 FY25 call, Aug 2024)
- https://nsearchives.nseindia.com/corporate/UNIPARTS_17082023204214_EarningCallTranscript.pdf (Q1 FY24 call, Aug 2023)
- https://www.icra.in/Rating/GetRationalReportFilePdf?id=142900 (ICRA rationale, 7 May 2026)
- https://nsearchives.nseindia.com/corporate/ixbrl/INTEGRATED_FILING_GOVERNANCE_152288_23042026142842_iXBRL_WEB.html (CG report Q4 FY26)
- https://nsearchives.nseindia.com/corporate/team_bbodade_07052026162538_UNIPARTS.pdf (Reg 31(4) no-encumbrance declaration FY26)
- https://nsearchives.nseindia.com/corporate/Earth_2018_05122025185210_KMPSMsappointmentsIntimation.pdf (Group CEO/SMP appointments, 5 Dec 2025)
- https://nsearchives.nseindia.com/corporate/Earth_2018_11032026190432_IntimationCFOResignationandAppointment.pdf
- https://www.indiainfoline.com/company/uniparts-india-ltd/reports/directors-report (FY26 Board's Report text)
- https://filingreader.com/news-wire/mumbai/2025-12-27/uniparts-india-seeks-approval-for-directors-revised-remuneration
- https://www.autocarpro.in/news/uniparts-india-net-profit-rises-38-percent-to-rs-54-crore-in-q2-135734
- https://www.multibagg.ai/market-pulse/articles/uniparts-india-q2-fy27-results-cmw2h1t7r00b62mtk7d70d0jl
- https://www.arthneeti.com/stocks/uniparts-india/concall/q2-fy26-earnings-call-analysis
- https://www.arthneeti.com/stocks/uniparts-india/concall/q3-fy26-earnings-call-analysis
- https://www.arthneeti.com/stocks/uniparts-india/concall/q4-fy26-earnings-call-analysis
- https://insights.dsij.in/dsijarticledetail/ipo-analysis-uniparts-india-ltd-27511 (IPO structure, 3PL share)
- https://www.icicidirect.com/ipo/ipo-news/ipo/uniparts-india-ipo-subscribed-202-times/1385583 (OFS seller split)
- https://stockanalysis.com/quote/nse/UNIPARTS/statistics/ and https://stockanalysis.com/quote/nse/UNIPARTS/financials/ratios/
- https://www.screener.in/company/HAPPYFORGE/consolidated/ ; https://www.screener.in/company/RKFORGE/consolidated/
- https://www.nirmalbang.com/Upload/Uniparts-India-Ltd---Update.pdf (Deere ~1/3 of revenue claim; not verified)
