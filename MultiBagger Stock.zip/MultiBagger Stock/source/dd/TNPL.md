# TNPL — Tamil Nadu Newsprint & Papers Ltd (NSE: TNPL, BSE: 531426)

**Date:** 2 Nov 2026 | **Price:** ₹132 | **Mcap:** ₹917 Cr | **Verdict: REJECT**

Gates: G1 Governance **WATCH** | G2 Guidance & Delivery **FAIL** | G3 Fundamentals **FAIL** | G4 Valuation **WATCH**

Note: Q2 FY27 (Sep-2026) results not yet filed as of 2 Nov 2026 (last year's Q2 was approved 27 Oct 2025; no board-meeting intimation found). Latest quarter used is Q1 FY27 (Jun-2026).

## GATE 1 — Governance: WATCH

- **Promoter:** Government of Tamil Nadu holds 35.32%, unchanged for years; no pledge. Low holding means the state exercises control without proportionate economic stake. DII holding has fallen from 15.5% (Mar-24) to 6.6% (Sep-26) — institutions exiting.
- **Owner = customer:** GoTN accounts for ~25% of sales (CARE, Sep-2026). Debtor days rose 32 → 48 in FY26. Related-party exposure to the controlling shareholder is structural, not optional.
- **MD churn / part-time leadership:** Dr Sandeep Saxena IAS retired 30 Apr 2026; Kumar Jayant IAS took over as CMD on *additional charge* while remaining head of TIIC. The CMD of a ₹4,600 Cr company is a part-time job. Nominee-director churn is constant: V Arun Roy IAS replaced by S Vijayakumar IAS (May-26), then Arun Roy re-appointed as additional director (22 Oct 2026); T Anbalagan IAS replaced by R Kannan; Executive Director Y K Varshney resigned Jun-2026.
- **Board/auditors:** Two long-serving independent directors (audit and risk committee chairs) exited Sep-2025 on term expiry; auditor A. John Moris & Co appointed by CAG on one-year terms (normal for a state PSU, but no auditor continuity/independence signal either way). No SEBI action, no price/volume clarification found.
- **Dividend extraction:** ₹4/share recommended for FY26; dividend maintained in FY25 when PAT was ₹3.7 Cr (screener payout 195%). Small in absolute terms but shows dividends set by owner need, not cash generation.
- **Contingent liabilities:** ₹522 Cr (screener), ~23% of net worth.
- No fraud, no pledge, no nepotism (no family KMP by design) — hence WATCH rather than FAIL.

## GATE 2 — Guidance & Delivery: FAIL

TNPL holds no earnings calls; the only forward statements are via rating agencies and press.
- **Tissue plant (34,000 TPA, ~₹340–350 Cr, ₹270 Cr debt):** 2025 press said completion by Mar-2026; ICRA (Feb-2026) said Q1 FY27; CARE (Sep-2026) now says commercial operations Q3 FY27. ~Two quarters of slippage.
- **Steam/power revamp (~₹250 Cr, ₹200 Cr debt):** also pushed to Q3 FY27.
- **Board plant Phase II:** deferred to "after FY28" (ICRA). The ₹600 Cr+ growth blueprint publicised in 2025 has shrunk to maintenance-plus-tissue.
- **Revenue/margin:** No numeric guidance ever given; CARE's own positive trigger (15–17% PBILDT margin) is far above the ~10–11% being delivered.
- Delivery record: FY23 was the peak (sales ₹5,180 Cr, OPM 19%); three years later sales are 10% lower and OPM has halved.

## GATE 3 — Fundamentals: FAIL

| | FY22 | FY23 | FY24 | FY25 | FY26 | TTM |
|---|---|---|---|---|---|---|
| Sales (₹ Cr) | 4,020 | 5,180 | 4,690 | 4,491 | 4,645 | 4,649 |
| OPM | 9% | 19% | 16% | 10% | 10% | 11% |
| PAT | 14 | 388 | 208 | 4 | 248* | 261* |
| ROCE | 4% | 21% | 14% | 6% | 6% | — |

*FY26 PAT includes a ₹219 Cr deferred-tax reversal on moving to the 25.17% regime. PBT was only ₹50.6 Cr; underlying PAT ≈ ₹40 Cr.

- **CAGR:** 5-yr sales 11% (COVID base), 3-yr sales **−4%**; 3-yr profit −14%; 10-yr profit 0%.
- **Latest quarters YoY:** Q4 FY26 sales ₹1,272 Cr (−5%), PBT ₹38 Cr; Q1 FY27 sales ₹1,147 Cr (+0.4%), OPM 10.0% (vs 8.9%), PAT ₹5.7 Cr (vs −7.4). Margins stabilising at ~10%, not recovering to the 16–19% of FY23–24. Imports (China/Vietnam/Indonesia) cut realisations 13% in FY25 and a further 3% in 9M FY26.
- **Leverage:** Borrowings ₹1,613 Cr (screener) / total debt ~₹2,470 Cr incl. working-capital (CARE: TD/PBILDT 4.9x, gearing 1.07x). Interest ₹207 Cr on ₹505 Cr PBILDT; interest coverage 2.6x. Current ratio 0.69. Repayments ₹315–360 Cr p.a. in FY27–28 plus ₹360 Cr more capex — accruals (₹400–515 Cr) barely cover both.
- **Cash conversion:** CFO FY22–26 = ₹3,505 Cr vs PAT ₹862 Cr — strong, but that is ₹300 Cr/yr depreciation plus negative working-capital days (−65 to −106, i.e. funded by sugar-mill/bagasse payables and GoTN advances). Nearly all CFO goes to capex and debt service; net debt is only modestly lower than FY21.
- **Moat:** Integrated bagasse pulp, captive 104 MW power, No.1 domestic WPP brand. Real but commodity: ICRA/CARE both say Indian prices are set by global/import parity.

## GATE 4 — Valuation: WATCH

- Screen P/E 3.5x is an artefact of the tax credit. Underlying FY26 PAT ~₹40 Cr → **~22x**. P/B 0.38x (BV ₹335). EV/EBITDA ≈ 5.0x on screener debt, ~6.7x on CARE's total-debt figure. Dividend yield 3.0%.
- Peers: JK Paper ~21x P/E / 1.0x P/B; West Coast ~18x / 0.74x; Seshasayee ~18x / 0.72x. TNPL's discount to book reflects 1.1x gearing, 6% ROCE and PSU control — cheap for a reason.
- 10-yr stock CAGR −10%; 3-yr −23%. Book value has not translated into returns since 2017.
- **3-yr cases:** Bull (import MIP + wood-price fall + tissue ramp → OPM 15%, PAT ~₹200 Cr, 8x) ≈ ₹230 (+75%). Base (OPM 11%, PAT ~₹60 Cr, 0.5x book) ≈ ₹150–170 (+15–25%, mostly dividends). Bear (import pressure persists, capex slips again, coverage <2x) ≈ ₹90–100 (−30%). Asymmetry is not compelling for a multibagger mandate.

## Verdict: REJECT

1. **Declining sales and halved margins with no credible turnaround:** 3-yr sales CAGR −4%, OPM 19% → 10%, ROCE 6%; the only growth projects are a ₹350 Cr tissue plant (slipped twice) and the board Phase II is deferred past FY28.
2. **Headline cheapness is fake:** P/E 3.5x comes from a ₹219 Cr deferred-tax credit; underlying ~22x with 2.6x interest cover and ₹315–360 Cr/yr repayments.
3. **PSU governance limits upside capture:** part-time IAS CMD on additional charge, constant nominee churn, owner is 25% of sales, dividends paid regardless of profit. Nothing fraudulent, but capital allocation is not run for minority shareholders.

Revisit only if: Q2–Q3 FY27 show OPM >13% with tissue plant commissioned, and total debt/EBITDA falls below 3.5x.

## Sources
- https://www.screener.in/company/TNPL/
- https://nsearchives.nseindia.com/corporate/TNPL_22092026125053_CARELetter22092026CSDSC.pdf (CARE reaffirmation, 21 Sep 2026, with FY26 and Q1 FY27 financials)
- https://www.icra.in/Rating/GetRationalReportFilePdf?id=140940 (ICRA A+ Stable, 16 Feb 2026 — capex deferrals, import pressure)
- https://www.whalesbook.com/corporate-news/English/other/TNPL-Profit-Soars-16x-on-Tax-Reversal-Q4-Revenue-Slips/69eb8538bca97ee106b147a0
- https://tradebrains.in/tnpl-rises-5-after-q4-profit-surges-nearly-10x-to-240-cr-on-tax-reversal/
- https://papermart.in/?p=46024 (Kumar Jayant IAS appointed CMD, additional charge)
- https://nsearchives.nseindia.com/corporate/TNPL_22052026193624_323rdBMOutcome22052026CSDSC.pdf
- https://scanx.trade/stock-market-news/companies/tnpl-accepts-resignation-of-executive-director-varshney/44288074
- https://filingreader.com/news-wire/mumbai/2025-09-18/tnpl-board-exodus-auditor-change-mark-new-era
- https://filingreader.com/news-wire/mumbai/2025-09-12/tnpl-outlook-revised-to-stable-amid-profitability-challenges
- https://papermart.in/?p=43731 (₹600 Cr capex plan, 2025)
- https://www.valueresearchonline.com/stocks/42704/jk-paper-ltd/peer-comparison/ (peer multiples)
