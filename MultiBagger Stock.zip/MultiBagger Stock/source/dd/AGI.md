# AGI Greenpac Ltd (NSE: AGI) — Due Diligence, 2 Nov 2026

**Business:** India's #2 container-glass maker by capacity (17-18% share; CARE says it now out-sells HNG), 2,100 TPD glass incl. ~200 TPD specialty glass, plus PET bottles and caps/closures. FY26 mix: glass 91% of revenue, alcoholic beverages ~75% of glass, pharma ~7%. Promoter: Somany family (Sandip Somany, CMD), 60.39%.
**Price/mcap:** Rs 643 / Rs 4,157 cr. P/E 11.7, P/B ~1.6, div yield 1.1% (Rs 7 DPS, ~13% payout).

## VERDICT: HOLD-FOR-REVIEW
Gates: G1 WATCH / G2 WATCH / G3 WATCH / G4 PASS

1. Cheap (P/E 11.7 vs packaging-peer median 17.7, ROCE 19.5%, CFO > PAT), but earnings momentum has turned: TTM PAT +1%, Q2 FY27 PAT -12.5% YoY, EBITDA margin 25% -> 22% while management kept guiding 24-25%.
2. Rs 1,900-2,000 cr capex through FY28 (~half of market cap), ~Rs 900-1,000 cr of it into an unproven aluminium-can business whose land is still not released; peak debt Rs 1,000-1,200 cr and a QIP enabling resolution (dilution) if equity isn't raised.
3. Governance is family-controlled with a succession step (son Shashvat Somany to become Joint MD from 1 Oct 2026) and an opaque, still-litigated HNG saga; nothing disqualifying, but not clean enough to SELECT on autopilot.

## GATE 1 — GOVERNANCE: WATCH
- Promoter holding flat-to-up: 60.23% (Dec 2023) -> 60.39% (Sep 2026). No pledge shown on Screener; CARE rating note does not flag any.
- Family KMP: CMD Sandip Somany; wife Sumita Somany is a non-executive director (only disclosed inter-director relationship). Son Shashvat Somany drew Rs 2.9 cr salary in FY26 as "relative of KMP" and the FY26 AGM notice proposes him as Director & Joint MD from 1 Oct 2026, with Sandip re-appointed CMD from 1 Dec 2026. Mitigant: day-to-day run by a professional CEO (Rajesh Khosla, ex-AGI veteran, since May 2024) and CFO (O.P. Pandey); Group CFO Sandeep Sikka fronts calls.
- Remuneration: CMD pay = 136.7x median employee (down 49.8% YoY); CEO 151x. High but falling; not egregious vs Rs 352 cr PAT.
- RPTs small: rent + sales + fees with Hindware Ltd/Hindware Home (sister cos) ~Rs 47 cr (<2% of sales); no royalty. BRSR: RP sales 0.9% of sales, but loans to related parties rose to 10% of loans and RP investments to 10% of investments in FY26 (new AGI Retail / Sun Reach Pack FZE subsidiaries, not yet operating) — monitor.
- Auditor Lodha & Co LLP, unqualified, no change; FY26 note discloses audit-trail not enabled at database level (common but a weakness).
- SEBI: Rs 5 lakh adjudication penalty (Apr 2024, LODR breaches), under SAT appeal. Minor.
- HNG acquisition: AGI's ~Rs 2,200 cr IBC resolution plan for Hindusthan National Glass was set aside by the Supreme Court (29 Jan 2025); review petition dismissed 16 May 2025; company is still litigating in Delhi HC. Management refuses to quantify legal/advisory cost or give a timeline ("sub judice"); no write-off appears in FY26 exceptional items (only Rs 5 cr labour-code charge). Opacity, and the Rs 158 cr "claims not acknowledged as debt" is unexplained.
- Last buyback: Sept 2020 (76 lakh shares). None current.

## GATE 2 — MANAGEMENT GUIDANCE & DELIVERY: WATCH
- FY26 guided 8-10% volume growth (Oct 2025) -> trimmed to 7-9% (Jan 2026); FY26 revenue actually grew 5.4% (Rs 2,529 -> 2,665 cr). Analysts called out the shortfall on the call.
- Margin: guided 24-25% EBITDA for next 12-18 months (Jan 2026); delivered 22.0% in Q1 and 21.7% in Q2 FY27. Container-glass realisations fell Rs 1,200/t YoY as soda-ash savings were passed through — margin tailwind reversing, as CARE anticipated (normalisation to 22-24%).
- Capex delivery: debottlenecking to 1,900 TPD done early; specialty 200 TPD on time. Gwalior 500 TPD plant: Rs 700 cr, now "March 2027" (CARE had Dec 2026). Aluminium cans: Rs 850 cr phase 1 (950 mn cans, scaling to 1.6 bn by FY30), COD slipped from Oct 2027 to "Q3 FY28", land still awaited from UP government. FY27 spend guided Rs 1,100-1,200 cr.
- Debt: ECB fully prepaid, Rs 193 cr term-loan prepayment (Jul 2025) — yet gross borrowings rose from Rs 241 cr (Mar 2026) to Rs 430 cr (Sep 2026); net bank debt Rs 389 cr at Dec 2025, blamed on inventory build and "delayed deliveries".
- Q2 FY27 presentation gives no explanation for the 12.5% PAT fall and no FY27 guidance. Vague on QIP timing ("appropriate time").

## GATE 3 — FUNDAMENTALS: WATCH
- Sales: FY21 Rs 1,256 cr -> FY26 Rs 2,665 cr (~16% CAGR, flattered by post-demerger base; 10-yr CAGR only 3% because the building-products business was sold). PAT FY24 251 -> FY25 322 -> FY26 352 cr; TTM 353 (+1%).
- Recent quarters: Q1 FY27 sales 785 (+14%), PAT 99 (+11%); Q2 FY27 sales 655 (+9%), PAT 67 (-12.5%); OPM 22% vs 25% a year ago.
- ROCE 19.5%, ROE 15.7%. Interest cover 11x (9M FY26). Gearing ~0.2x; net debt/EBITDA 0.11x at Mar 2026, but heading toward ~1.5-2x at peak capex.
- Cash conversion good: CFO Rs 429 cr (FY25) and 571 cr (FY26) vs PAT 322/352. Working capital worsening: inventory days 193 -> 215, cash cycle 172 -> 188 days.
- Moat: duopoly-ish industry (HNG impaired), ~95% utilisation, pass-through with ~60% of customers, multi-fuel furnaces, specialty glass (25-26% margin) for pharma/cosmetics. Risks: 75% of glass sales to alcohol (beer volumes weather/tax sensitive; global alcohol demand -1%), gas/fuel 20-30% of cost, and the can diversification where Ball/Can-Pack are entrenched.

## GATE 4 — VALUATION: PASS
- P/E 11.7, P/B 1.6, EV/EBITDA ~7x (EV ~Rs 4,500 cr on TTM EBITDA ~Rs 620-650 cr). Peers: EPL 17x, TCPL 33x, packaging median 17.7x. Stock -22% in 1 yr, -13% CAGR over 3 yrs; 52-wk range Rs 444-851.
- Cheap for cyclical/transition reasons (margin normalisation, capex overhang, HNG noise), not structural decline — glass demand still growing mid-single digit.
- 3-yr cases: Bull — Gwalior ramps, cans break even (60-65% utilisation), FY29 PAT ~Rs 550 cr at 14x = Rs 1,200 (+85%). Base — PAT ~Rs 430 cr at 12x = Rs 800 (+25%, plus 1% yield). Bear — can project burns cash, margins 19%, dilution via QIP, PAT Rs 300 cr at 10x = Rs 450 (-30%).

## Re-review triggers
Clear evidence margins hold >=23% for two quarters; can-project land/funding finalised without dilution; disclosure of total HNG cost; promoter buying.

## Sources
- https://www.screener.in/company/AGI/consolidated/
- Q2 FY27 earnings presentation (28 Oct 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b61057cf-9e92-4c8b-b794-9478ea02c67e.pdf
- Q3 FY26 concall transcript (Jan 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f0f2ef96-83e8-4205-9e04-47a0f7df3756.pdf
- Q2 FY26 concall transcript (Oct 2025): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3ec8a959-d88c-487b-b565-b1e39ca14212.pdf
- Annual Report FY26: https://www.bseindia.com/xml-data/corpfiling/AttachHis/68c743e4-8755-4301-8b33-f69aeeea7673.pdf
- CARE Ratings press release, 8 Apr 2026: https://www.careratings.com/upload/CompanyFiles/PR/202604140428_AGI_Greenpac_Limited.pdf

## Primary-source verification (2 Nov 2026)
Sources used (all company filings): FY26 Annual Report https://www.bseindia.com/xml-data/corpfiling/AttachHis/68c743e4-8755-4301-8b33-f69aeeea7673.pdf ; Q2 FY27 results + limited review https://www.bseindia.com/xml-data/corpfiling/AttachHis/9e097964-e8c4-47aa-b233-075f9ee63cfc.pdf ; Q2 FY27 presentation https://www.bseindia.com/xml-data/corpfiling/AttachHis/b61057cf-9e92-4c8b-b794-9478ea02c67e.pdf ; Sep-2026 SHP https://www.bseindia.com/stock-share-price/agi-greenpac-ltd/agi/500187/shareholding-pattern/ ; announcements https://www.bseindia.com/stock-share-price/agi-greenpac-ltd/agi/500187/corp-announcements/ ; 12 Oct 2026 filing https://www.bseindia.com/xml-data/corpfiling/AttachHis/5b780dde-da75-4d01-9ee9-648e10dfe17e.pdf

1. **Promoter pledge — CONFIRMED.** SHP quarter ended Sep 2026: Promoter & Promoter Group 60.39% (3,90,72,819 shares, 7 holders); "shares pledged or otherwise encumbered / NDU / other encumbrance: No" (0%).
2. **Managerial remuneration — CONFIRMED.** AR Board's Report, Sec 197(12)/Rule 5(1): Sandip Somany (CMD) FY26 total Rs 6,85,77,088 (basic Rs 5.74 cr + FY25 commission Rs 47.71 lakh + PF Rs 63.84 lakh), 136.72x median, -49.79% YoY. Shashvat Somany (relative of KMP, Note 54) salary Rs 289.73 lakh (FY25 224.53). Promoter-family total Rs 9.76 cr = 2.8% of FY26 consolidated PAT Rs 352.21 cr. CEO Khosla 151.17x, CFO Pandey 47.43x. Note also carries an interest-free-type loan to the CEO (Rs 206.25 lakh receivable) — this, not promoter lending, is the "loans to related parties" item flagged earlier.
3. **RPTs — CONFIRMED (Rs 49 cr, 1.8% of revenue).** Note 54 standalone, FY26 (Rs lakh): rent received from Hindware Ltd 2,160.39; sale of goods to Hindware Ltd 2,342.63; management fees received from Hindware Ltd 122.40 / Hindware Home Innovation 183.00 / Hintastica 60.00; purchases + reimbursements <35. No royalty; the FY25 Rs 19.65 cr "payment for management services to Hindware" is nil in FY26. Transactions are net inflows to AGI. AOC-2: no non-arm's-length contracts. Other: CSR to HSIL CSR Foundation Rs 7.08 cr, HSIL Gratuity Trust Rs 2.27 cr, Rs 1.46 cr invested in Sun Reach Pack FZE. BRSR: RP sales 0.89% of sales.
4. **Auditor — CONFIRMED.** Lodha & Co LLP (FRN 301051E/E300284). FY26 standalone and consolidated opinions unmodified; no Emphasis of Matter; IFC report unmodified. Rule 11(g) remark: audit trail not enabled at database level, not enabled for relevant financial tables at application level, privileged access not restricted. Q2 FY27 limited review (28 Oct 2026): "Our conclusion on the Statement is not modified"; Other Matter only for two unreviewed subsidiaries with nil income (loss Rs 0.22 cr).
5. **Q2 FY27 — CONFIRMED.** Revenue from operations Rs 655 cr (+9.0% YoY vs 602); EBITDA excl. OI Rs 142 cr (-4.9%), margin 21.7%; PAT Rs 66.50 cr consolidated / 66.72 standalone (-12.5% vs 75.98). H1: revenue Rs 1,441 cr (+11.8%), PAT Rs 166 cr (+0.6%). Other income collapsed to Rs 1.25 cr (Q2 FY26 Rs 4.71 cr, H1 FY26 incl. Rs 20.49 cr insurance claim). No exceptional item in Q2 (FY26 had Rs 5.09 cr). **Borrowings 30 Sep 2026: Rs 426.19 cr (non-current 140.05 + current 286.14) vs Rs 238.87 cr at 31 Mar 2026; acceptances a further Rs 250.44 cr (230.37).** H1 cash flow: short-term borrowings +Rs 177 cr net. **Aluminium cans:** presentation only repeats "foray into aluminium cans / 1.6 billion cans" and "500 TPD new capacity by March 2027" — no capex, land, COD or funding update; no QIP mention in results or deck. Enabling resolution on record: special resolution by postal ballot 6 Nov 2025 to raise up to Rs 1,500 cr via QIP/public/rights/preferential issue (AR, secretarial audit report). **HNG:** AR Board's Report para 9 and secretarial audit report state the IBC resolution plan "has not been upheld" (SC 29 Jan 2025; review petition dismissed 16 May 2025); no cost quantified anywhere; Note 51(c) "claims not acknowledged as debts" Rs 157.88 cr (FY25 Rs 183.43 cr), unexplained. Nothing on HNG in Q2 filings.
6. **Announcements since 1 Oct 2026 — CONFIRMED with one addition.** 7 Oct Reg 74(5) certificate; **12 Oct: Shaili Tyagi appointed CHRO (senior management)** — no resignations; 21 Oct board-meeting intimation; 28 Oct results/deck; 29 Oct newspaper ad. No separate filing on the Joint MD appointment; the Q2 deck already shows Shashvat Somany as "Joint Managing Director" and Sandip Somany as CMD, so the 1 Oct 2026 appointment is in effect. **Terms (AGM notice in AR, not previously in note):** 5 years 1 Oct 2026–30 Sep 2031; salary Rs 2.52 cr p.a. (scale Rs 2.52–3.60 cr) plus commission so total is up to 3% of net profits; with Sandip's cap of 5%, combined promoter-executive pay exceeds the 5% aggregate limit of Reg 17(6)(e)(ii), so a special resolution (Item 6) was sought. Shashvat is also founder of "Tattva", the group's venture-capital arm — watch for RPTs. AGM voting results were not fetched (company IR page is a 2014-20 archive).

**AGI: verdict stands SELECT — no primary source contradicts the selection facts (zero pledge, promoter pay 2.8% of PAT, RPTs 1.8% and inbound, clean Lodha opinion/review); Q2 FY27 is the already-known soft quarter (PAT -12.5%, margin 21.7%) rather than a fresh miss. Watch items unchanged: borrowings doubled to Rs 426 cr in six months with no funding plan disclosed for the can project, promoter-executive pay now exceeds the 5% aggregate cap, and HNG costs remain unquantified. (The note's own grading above is HOLD-FOR-REVIEW; nothing found warrants moving it to REJECT.)**
