# NCL Industries (NSE: NCLIND) — Due Diligence, 2 Nov 2026

**Snapshot:** CMP Rs 162 | Mcap Rs 735 cr | P/E 5.9 (reported) | P/B 0.77 | Div yield 2.2% | ROCE 14.6% | ROE 11.4% | 52w 148–215 | ADTV ~Rs 0.4 cr (illiquid).
Hyderabad group (founded 1979 by late K. Ramachandra Raju): 4.0 MTPA cement (Mattapally, Kondapalli, Vizag grinding unit commissioned Nov 2025), 90k TPA cement-bonded boards (Bison Panel), RMC, two small hydel plants. Doors business discontinued FY26.

## VERDICT: REJECT

1. **Capital allocation red flag:** Board has approved a Rs 910–920 cr solar-wind hybrid project in Tuticorin, Tamil Nadu — 1.25x market cap, ~1x net worth — outside the core business, Phase-1 (50 MW, Rs 292 cr debt) by Feb 2028. CRISIL flags "project risk"; peak gearing to 0.9x. For a company with 0% five-year sales CAGR this is a value-destroying diversification risk, not a multibagger setup.
2. **Governance is "watch" not "clean":** 4 of 10 directors are one family (K. Ravi; his daughter Roopa Bhupatiraju; K. Gautam and his sister Pooja Kalidindi); K. Ravi's FY26 pay jumped 177% to Rs 4.65 cr (120x median) in a year PAT recovered from a trough; KMP pay Rs 11.3 cr = 12% of PAT; CARE has rated the Rs 65 cr public fixed deposits "Issuer Not Cooperating" continuously since 2018; promoter stake only 42.5% with pledges only recently unwound.
3. **No growth, cyclical earnings:** Sales Rs 2,046 cr (FY22) -> Rs 1,747 cr (FY26); OPM swings 7–16%; FY26 PAT of Rs 95 cr flattered by a Rs 19 cr deferred-tax credit (effective tax 6.6%). Normalised P/E is ~9–10x, not 5.9x. Cheap on assets (EV/t ~$30), but cheap for a reason.

---

## GATE 1 — GOVERNANCE: WATCH (borderline FAIL)

- **Promoter holding/pledge:** 44.5% (Dec-23) -> 40.9% (Sep-25) -> 42.5% (Sep-26). Decline was dilution-free drift plus inter-se transfers and a reported 5.42 lakh share promoter-group sale (source blocked). Small open-market buys by K. Ravi/Kakatiya Industries/NCL Holdings through 2026. Pledge fell from 20.0% of promoter holding (Dec-23) to 4.7% (Sep-26); remaining 9.06 lakh pledged shares are 99–100% of four minor promoters' holdings (Penmetsa, Datla, G.T. Sandeep). History of chronic pledging is a smell, but trend is positive.
- **Family KMP:** K. Ravi (VC & MD from Dec-25), K. Gautam (ex-MD, now non-exec), Roopa Bhupatiraju (K. Ravi's daughter, ex-ED), Pooja Kalidindi (Gautam's sister). Gautam and Roopa shifted from executive to non-executive in Dec-25 with no stated reason — possible intra-family rebalancing between the Ravi and Gautam branches; no public dispute found.
- **Remuneration:** K. Ravi Rs 465 lakh (+177%, incl. Rs 160 lakh commission), Gautam Rs 259 lakh, Prasad (ED-CFO) Rs 187 lakh (+48%), Roopa Rs 101 lakh, Goradia Rs 81 lakh. Total KMP Rs 11.26 cr vs PAT Rs 95 cr.
- **RPTs:** Modest — sales to NCL Buildtek Rs 19.5 cr and NCL Homes Rs 1.7 cr (~1.5% of sales), purchases from Kakatiya Industries Rs 2.2 cr, ICDs to NCL Holdings (Rs 9.35 cr given, Rs 18.85 cr repaid, nil at year end). Rs 4.1 cr impairment of a JV with NCL Buildtek (group company) in dissolution. Acceptable size.
- **Auditor:** M. Bhaskara Rao & Co (since 2022), unmodified opinion; audit-trail (database level) not enabled; PP&E verification discrepancies "under reconciliation".
- **Regulatory:** BSE/NSE fines Rs 3.39 lakh each for delayed committee constitution (Aug-25); NSE Rs 46k for late shareholding pattern. Three independent directors exited in FY26 (two term-end, one did not seek reappointment); new chair Renu Challu (ex-SBH) is a credible appointment.
- **Contingent liabilities:** ~Rs 160 cr disputed (Rs 91 cr Mines & Geology demand under writ in Telangana HC; Rs 46 cr indirect tax; Rs 22.5 cr income tax) — ~22% of market cap, 17% of net worth.
- **CARE non-cooperation since 2018** on public FDs (Rs 63 cr outstanding) while CRISIL rates bank lines A/Stable: selective disclosure.

## GATE 2 — GUIDANCE & DELIVERY: WATCH

- Investor communication is thin: PPTs in 2018, Jul-2024, Aug-2026; transcripts not published. No quantified FY27 guidance in the Aug-26 deck. CRISIL (relaying management): OPM "above 11%" in FY27, volume growth from Vizag unit, realisations stable.
- Delivery: Vizag 0.66 MTPA unit commissioned Nov-25 (on roughly the indicated timeline). Boards production fell 39% (82k -> 50k MT) — not flagged ahead. Doors exited. Q1 FY27 OPM 11.5% vs 13.4% FY26; PAT -20% YoY. Oct-26 monthly update: Q2 cement dispatches +22% YoY; boards mixed, RMC and energy lower.
- Hybrid power project appeared in FY26 AR/CRISIL with no prior roadmap — a strategy shift rather than a guided plan.

## GATE 3 — FUNDAMENTALS: WATCH

| | FY22 | FY23 | FY24 | FY25 | FY26 | TTM |
|---|---|---|---|---|---|---|
| Sales (cr) | 2,046 | 2,044 | 2,104 | 1,742 | 1,747 | 1,431* |
| OPM | 10% | 7% | 10% | 7% | 11% | 12% |
| PAT (cr) | 94 | 44 | 93 | 25 | 95 | 92 |
| CFO (cr) | 72 | 206 | 183 | 86 | 145 | |
*Screener TTM reflects doors reclassified as discontinued.

- 5y sales CAGR 0%, PAT CAGR -7%; 3y PAT +32% off a trough. Q1 FY27 sales +2.5%, PAT -20%.
- Segment FY26: cement Rs 1,376 cr revenue / Rs 130 cr result (up from Rs 47 cr); boards Rs 144 cr / Rs 11 cr (down); RMC Rs 112 cr / Rs 3.5 cr; energy negligible.
- Balance sheet: debt Rs 239 cr (D/E 0.25), cash ~Rs 10 cr, interest cover 11.6x (FY26). Public FDs Rs 63 cr at 8–10%. CFO 5y cumulative Rs 665 cr vs PAT Rs 351 cr — cash conversion good. FCF positive 4 of 5 years.
- Working capital: inventory days 215–327 (high, coal/clinker), CCC 148 days; debtor days 25.
- Moat: none beyond captive limestone and AP/Telangana dealer network; South India is structurally oversupplied, pricing power weak (Sept-26 South hike Rs 11/bag, no AP/TG hike confirmed in Oct-26).
- Capex: Rs 919 cr renewable project dwarfs the Rs 150 cr Vizag unit; Vishwamber Cements (322-acre limestone lease) amalgamation planned; no new cement line disclosed.

## GATE 4 — VALUATION: PASS (cheap, but value-trap profile)

- EV ~Rs 965 cr; EV/EBITDA 5.0x FY26, 5.5x TTM; P/B 0.77; EV/tonne ~$28–30 vs replacement $90–110 and listed mid-cap peers $100–150. Peer P/E median 25x vs NCL 5.9x (normalised ~9–10x).
- Own history: stock CAGR 10y 2%, 5y -7% — market has refused to re-rate through two cycles.
- 3-year scenarios: Bull (South pricing recovers, OPM 15%, EBITDA Rs 280 cr, 6x) ~Rs 330 (+100%). Base (OPM 11–12%, EBITDA ~Rs 200 cr, 5x, debt rises Rs 300 cr for power capex) ~Rs 170 (flat + 2% yield). Bear (pricing war, OPM 7%, power project overruns) ~Rs 100 (-40%). Skewed but the base case is dead money and the power capex caps re-rating.

## Key risks / what would change the view
Shelving or minority-stake-funding of the Tuticorin project; sustained AP/TG price discipline; resolution of Rs 91 cr mines demand; promoter stake rising above 45% with zero pledge; CARE rating cooperation restored.

## Sources
- Screener consolidated page: https://www.screener.in/company/NCLIND/consolidated/
- CRISIL rating rationale, 26 Jun 2026: https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/NCLIndustriesLimited_June%2026_%202026_RR_394317.html
- CARE Ratings press release (Issuer Not Cooperating), 9 Feb 2026: https://www.careratings.com/upload/CompanyFiles/PR/202602130258_NCL_Industries_Limited.pdf
- FY2025-26 Annual Report (BSE): https://www.bseindia.com/xml-data/corpfiling/AttachHis/c28987a6-27c6-447d-a0b2-6121b712bd60.pdf
- Investor presentation Aug 2026 (BSE): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7104a882-7aed-49c5-a811-f9edbd808563.pdf
- Trendlyne shareholding/pledge: https://trendlyne.com/equity/share-holding/919/NCLIND/latest/ncl-industries-ltd
- Monthly business update Oct 2026 (BSE): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=304cae55-a739-42be-8bee-4643b9abf25a.pdf
- South India cement price reports (HouseGyan, Sep 2026): https://www.housegyan.com/blog/cement-prices-rise-by-rs-7-per-bag-in-september-further-rs-5-20-hike-expected-in-october
- Not verified (source blocked): hdfcsky report of promoter-group sale of 5.42 lakh shares.
