# RSWM Ltd (NSE: RSWM, BSE: 500350) — LNJ Bhilwara group

**Date:** 2 Nov 2026 | **Price:** ₹182 | **Mcap:** ₹857 Cr | **Verdict: REJECT** (revisit after Q2 FY27 call on 3 Nov 2026)

Gates: G1 Governance **WATCH** | G2 Guidance & Delivery **WATCH** | G3 Fundamentals **FAIL** | G4 Valuation **WATCH**

Note: Board met today (2 Nov 2026) to approve Q2 FY27; numbers were not on exchanges/screener at time of writing. Concall is 3 Nov 2026, 4 pm. Latest quarter used is Q1 FY27 (Jun-2026).

## GATE 1 — Governance: WATCH

- **Promoter holding:** 55.69%, flat since FY24, up from 50.9% (FY17) via creeping purchases. **No pledge** (tijorifinance: "not pledged a significant portion"; screener shows none).
- **Family control:** Riju Jhunjhunwala (son of group patriarch Ravi Jhunjhunwala, HEG chairman) is Chairman & MD; both are named promoters. JMD Rajeev Gupta and CFO Nitin Tulyani are professionals. Classic second-generation family company; no obvious nepotism beyond the CMD seat, but succession and group priorities (HEG, Bhilwara Energy, Maral Overseas) sit above RSWM minorities.
- **Preferential warrants to promoters:** June 2026, 24.7 lakh warrants to LNJ Textiles Advisory LLP at ₹146 (₹36 Cr, 25% paid up, 18-month conversion) to fund the GreenPET subsidiary. Price was below book (₹289) and below the current ₹182; ~5% dilution going to the promoter rather than all shareholders. Also an ESOP scheme tabled May 2026. Mild smell: promoter gets cheap equity in a company that is simultaneously carrying ₹1,688 Cr debt.
- **RPTs:** Half-yearly Reg 23(9) disclosures filed; ₹44 Cr loan to WOS LNJ GreenPET (Jul-2026). Group-level RPTs (power purchase, shared services) are routine for LNJ Bhilwara but I could not quantify them vs sales from public summaries — unverified.
- **Auditor / regulator:** No auditor resignation, qualification, SEBI order or exchange clarification found. India Ratings moved outlook to Stable (IND A) in Jun-2026 after two years Negative.
- Shareholder count fell 33.5k → 25.8k (Dec-23 to Sep-26); FII 2.1% → 0.7%. Nobody institutional is accumulating.

## GATE 2 — Guidance & Delivery: WATCH

- **Q2 FY26 call:** FY26 capex ₹150–200 Cr; ₹92 Cr knitting modernisation (+20% capacity, 18–20% ROI, 5-yr payback). Delivered: machines bought FY26, commissioning H1 FY27, benefits from Q3 FY27 — on schedule.
- **Q3 FY26 call:** FY27 revenue target ~₹5,000 Cr; EBITDA margin 10–11% "within 6–8 quarters"; long-term ROCE ~13%. Against this, TTM revenue is ₹4,545 Cr and Q1 FY27 was flat YoY (₹1,161 Cr) — the ₹5,000 Cr target needs ~15% growth in the remaining three quarters and looks unachievable. Margin path is on track (6.0% → 7.4% → 8.0%).
- **Q4 FY26 call:** Revenue decline blamed on curtailing Chhata spinning (−₹250 Cr), RoDTEP removal, cotton import duty, freight. Reasonable but all externally framed.
- **GreenPET:** ₹427 Cr project (₹300 Cr project debt, rest equity/holdco loans), construction from mid-May 2026, commercial production Q1 FY28, revenue ₹475–500 Cr in 2–3 years. Capex equals 50% of market cap and ~30% of net worth, into a business (food-grade rPET) RSWM has never run. Q1 FY27 presentation gives no FY27 numeric guidance.
- Overall: execution on small capex is fine; revenue guidance is already off; the big bet is unproven.

## GATE 3 — Fundamentals: FAIL

| (consol, ₹ Cr) | FY22 | FY23 | FY24 | FY25 | FY26 | TTM |
|---|---|---|---|---|---|---|
| Sales | 3,817 | 3,789 | 4,058 | 4,826 | 4,554 | 4,545 |
| OPM | 11% | 7% | 2.3% | 4.3% | 6% | 7% |
| PAT | 246 | 123 | −21 | −40 | 52* | 63 |
| ROCE | 18% | 8% | 0% | 3% | 6% | — |
| CFO | 210 | 89 | −76 | 426 | 435 | — |

*FY26 PAT includes ₹22.7 Cr tax credit (new regime); Q4 FY26 alone had ₹16.6 Cr.

- **CAGR:** 5-yr sales 14% (off COVID base); 10-yr 5%; TTM −5%. 3-yr profit −20%. FY22 (₹246 Cr) was a one-off cotton-price windfall.
- **Latest quarters YoY:** Q4 FY26 sales ₹1,142 Cr (−9%), OPM 6%, PAT ₹34.6 Cr (tax-aided); Q1 FY27 sales ₹1,161 Cr (−0.7%), EBITDA ₹94 Cr (+16%), margin 8.0% (+118 bp), PAT ₹16.7 Cr (2.4x). Fabric segment was loss-making in Q1; yarn is 78% of sales. Margin recovery is real but from a 2% trough.
- **Leverage:** Borrowings ₹1,688 Cr vs net worth ₹1,361 Cr → D/E 1.2x. Finance cost ~₹31 Cr/qtr (~₹125 Cr/yr) against FY26 EBIT ~₹130 Cr → **interest cover ~1.0x** (screener flags "low interest coverage"). Altman Z 2.09.
- **The 34% FCF yield is not sustainable.** CFO FY25–26 (₹426 + ₹435 Cr) vs PAT (−₹40 + ₹52 Cr): the gap is ~₹160 Cr/yr depreciation plus working-capital release — inventory days 113 → 86 → 81, payable days 28 → 41 → 42, and W/C days 40 → 3 → 4. FY24 had CFO of −₹76 Cr when inventory was built and debt jumped ₹1,157 → ₹1,890 Cr; FY25–26 is the unwind. Capex FY26 ~₹183 Cr. From FY27, GreenPET (₹427 Cr) + knitting (₹92 Cr) push FCF negative and debt up again. 5-yr CFO/PAT looks great only because PAT is near zero.
- **Moat:** None. Commodity cotton/synthetic yarn and denim with 1/3 exports; margins swing with cotton spreads and policy (RoDTEP, import duty). Peer median ROCE 9.9% vs RSWM 5.6%.

## GATE 4 — Valuation: WATCH

- P/E 11.9–13.4x on TTM ₹63 Cr (which includes tax credits); P/B 0.65x (BV ₹289); dividend nil since FY25. EV ≈ ₹857 + ₹1,688 − cash ≈ ₹2,450 Cr → **EV/EBITDA ~8.1x** on TTM ₹301 Cr — not cheap for a 6% ROCE spinner; debt is 2x the market cap, so equity is an option on margin recovery.
- Own history: 10-yr stock CAGR −5%, 5-yr −9%, 3-yr 0%. The stock has traded at 0.5–1.0x book for a decade; 0.65x is mid-range, not a trough.
- Peers (screener textile set) median P/E 19.5x. Better-run spinners (e.g. Ambika Cotton) are net-cash; RSWM's discount reflects leverage.
- **3-yr cases:** Bull (margin 10–11% delivered, GreenPET ramps, EBITDA ₹550 Cr, net debt flat, 7x EV) ≈ ₹340 (+85%). Base (8% margin, EBITDA ₹380 Cr, debt +₹300 Cr for GreenPET, 7x) ≈ ₹190 (flat). Bear (cotton/export shock, GreenPET overrun, coverage <1x, 0.4x book) ≈ ₹110 (−40%). Operating leverage cuts both ways with 1.2x D/E.

## Verdict: REJECT

1. **Balance sheet, not screen, defines the equity:** D/E 1.2x, interest cover ~1x, and a ₹427 Cr debt-funded diversification into rPET starting FY27. The 34% FCF yield is a working-capital unwind plus depreciation, and reverses with the new capex.
2. **No growth, thin returns:** TTM sales −5%, 10-yr sales CAGR 5%, 10-yr profit CAGR −8%, ROE 4%, ROCE 5.6%; management's ₹5,000 Cr FY27 revenue target is already out of reach after a flat Q1.
3. **Governance is acceptable but tilted:** promoter warrants at ₹146 (below book and market) funding a promoter-championed project; family CMD; institutions and retail both exiting. Not a FAIL, but no reason to give a leveraged commodity spinner the benefit of the doubt.

Revisit if: Q2–Q3 FY27 EBITDA margin >9.5% with gross debt falling despite GreenPET spend, and GreenPET financial closure at ≤₹300 Cr project debt confirmed.

## Sources
- https://www.screener.in/company/RSWM/consolidated/
- https://nsearchives.nseindia.com/corporate/RSWM_05082026171233_InvestorPresentation05082026_sd.pdf (Q1 FY27 presentation, 5 Aug 2026)
- https://www.whalesbook.com/news/English/industrial-goodsservices/RSWM-Posts-Strong-Profit-Turnaround-Eyes-Double-Digit-Margins/699463bfcffb93b3e928301c (Q3 FY26 guidance: ₹5,000 Cr FY27 revenue, 10–11% margin, ROCE 13%)
- https://www.whalesbook.com/corporate-news/English/bankingfinance/RSWM-Ltd-Allots-Warrants-to-Promoter-Group-Signals-Capital-Commitment/6a27f7bfd7b7b190c0719097
- https://www.whalesbook.com/corporate-news/English/industrial-goodsservices/RSWM-Posts-indian-rupee52-Cr-Profit-in-FY26-Reverses-Loss-GreenPET-Project-Boosts-Outlook/6a0440129444064ed0207fe1 (Q4 FY26 call: ₹427 Cr GreenPET, ₹300 Cr project debt, Chhata curtailment)
- https://arthneeti.com/stocks/rswm-ltd/concall/q1-fy26-earnings-call-analysis (Q2 FY26 call: ₹92 Cr knitting, FY26 capex ₹150–200 Cr)
- https://scanx.trade/stock-market-news/companies/rswm-signs-loan-agreement-with-lnj-greenpet-private-ltd-for-up-to-rs-44-33-crores-to-back-bottle-to-bottle-initiative/44878375
- https://nsearchives.nseindia.com/corporate/RSWM_09062026192914_Credit_Rating_Letter_June_2026.pdf (India Ratings IND A / Stable)
- https://www.tijorifinance.com/company/rswm-limited/ (pledge, D/E, Altman Z)
- https://stockanalysis.com/quote/nse/RSWM/financials/ (operating income, CFO, capex)
- https://fashionunited.in/news/business/rswm-reports-return-to-profitability-in-turnaround-fiscal-year/2026050754362
