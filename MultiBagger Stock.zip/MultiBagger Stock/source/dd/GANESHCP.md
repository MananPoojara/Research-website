# Ganesh Consumer Products (NSE: GANESHCP) — Due-diligence note, 2 Nov 2026

Kolkata packaged staples brand "Ganesh" (atta, maida/sooji, besan, sattu — 43% East-India packaged sattu share, #3 atta in East; spices seeded FY25). Mimani family (promoters 65.85%). IPO Sept 2025 at Rs 322 (fresh issue Rs 130 cr + OFS ~86.6 lakh shares, mostly the Motilal Oswal IBEF-II PE funds exiting fully). Price Rs 171, mcap ~Rs 680 cr, -41% in 52 weeks, -47% from IPO price. Q2 FY27 results due today (board meeting 2 Nov) — not available at time of writing; latest is Q1 FY27.

## GATE 1 — Governance: FAIL
- Family-run: Manish Mimani CMD; wife Madhu Mimani non-exec director (Rs 25 lakh/yr, also director of Purnaa Real Estate which rents the corporate office to the company for Rs 1.7 cr/yr); father Purushottam Das Mimani (promoter, Rs 66 lakh "remuneration & fees" FY25 + rent); son Devansh Mimani on payroll. MD pay Rs 3.0 cr = 8.5% of FY25 PAT and 22% of total employee cost — high for a Rs 35 cr-profit company.
- Supplier conflict outside RPT net: brother Rajesh Mimani's Mimani Agro Products is the company's largest supplier of gram/besan/sattu (Rs 59.3 cr FY25); with Ganpati Tasty Foods (also his), promoter-group purchases were Rs 74.3 cr = 10.9% of FY25 purchases (11.6% FY24) and are explicitly NOT disclosed as related-party transactions under Ind AS 24. Both entities compete with the company (B2B). The IPO's capex object (a Darjeeling roasted-gram/besan unit to backward-integrate exactly this supply) has barely started. Land was also bought from Mimani Agro (Rs 1.7 cr).
- Disclosed RPTs Rs 36.9 cr = 4.3% of income FY25 (6.1% FY23), including pre-IPO loans to promoter companies (Back Bone Sales, Manoj Mercantile, New Age Import — interest income Rs 2.6 cr); Rs 37 cr inter-corporate loan to promoter group was repaid only post-IPO.
- Litigation: 8 criminal cases against the company (five FSSA complaints at Agra for "substandard/unsafe" maida/semolina/atta samples naming the MD personally, plus cheque cases), 7 criminal and 8 tax cases against promoters (Rs 34.7 cr involved), 23 tax cases against the company (Rs 11.5 cr). RHP admits untraceable statutory filings, MR-1 default on MD reappointment, and a senior manager unable to produce educational certificates.
- Positives: promoters bought ~1.8% in the open market (64.08% → 65.85%, Jun-Sep 2026); no pledge disclosed; auditor Singhi & Co; Hyderabad unit sold to a non-related buyer at 2.7x book (Rs 32.5 cr). Institutions have left: FII 8.2% → 1.8%, DII 5.6% → 3.7%, shareholders 67k → 45k in a year.

## GATE 2 — Guidance & delivery: FAIL
- Nov-2025 (first call post-IPO): FY26 revenue growth 12-14%, ~Rs 950 cr; Feb-2026: Q4 "higher single-digit volume growth". Delivered: FY26 revenue Rs 871 cr (+2.5%), Q4 -0.9%, Q1 FY27 -7.1% (B2C -4.1%, B2B -18%). Reasons given each quarter are external (monsoon hit sattu, LPG shortage, heatwave, elections).
- IPO objects: Rs 60 cr debt repaid (done); Rs 45 cr Darjeeling plant was to be deployed Rs 15 cr FY26 / Rs 30 cr FY27 — only Rs 2.5 cr spent by Jun-2026, commissioning pushed to "end of FY28" citing "global supply chain disruptions"; Rs 14.7 cr general corporate purposes 73% spent. Rs 1,000 cr revenue "milestone" quietly deferred.
- FY27 guidance (Aug-2026): volume growth 7-8%, EBITDA 9.8-10%; refused to give revenue guidance "until after Q2". Management could not recall its own prior B2B job-work remarks on the call. Margin delivery is the one bright spot (Q1 FY27 EBITDA 11.2%, record).

## GATE 3 — Fundamentals: WATCH
- Revenue FY22→FY26: Rs 455 → 871 cr (17.6% CAGR) but growth decelerated 34% → 24% → 12% → 2.5% → -7% (Q1 FY27). PAT FY22→FY26: Rs 27 → 42 cr (12% CAGR; flat FY22-FY24). FY26 PAT +20%, Q1 FY27 PAT +31% — all from margin (EBITDA 7.4% → 9.8% → 11.2%; gross margin 21% → 26%) and lower interest, not volume.
- ROE 14%, ROCE 18%; net cash Rs 17 cr (post-IPO), D/E 0.02; interest cover ~9x. Dividend Rs 5/share FY26 (3% yield) — paying out ~45% while a funded capex sits idle.
- Working capital light (cash-and-carry GT, receivable days 4-6); CCC 23 days FY26 but 43 days in Q1 FY27 on wheat stocking. CFO FY22-26 Rs 259 cr vs PAT Rs 158 cr (1.6x) — genuine cash conversion.
- Capacity utilisation 57% on 3.68 lakh TPA — no growth capex needed; the IPO capex was for integration, not volume. Moat is a regional brand in a low-margin, commoditised category (atta) exposed to wheat/gram prices and one state (West Bengal ~92% of revenue).

## GATE 4 — Valuation: WATCH
- P/E 14.4x TTM (EPS Rs 11.6), P/B 1.8x, EV/EBITDA 6.5x, EV/sales 0.65x; IPO was ~33x FY25 EPS. Listed packaged-food peers trade 30-60x; regional staples/flour peers 15-25x. Cheap vs peers, but cheap for reasons: zero/negative top-line growth, PE exit, record margin likely near peak (benign wheat, promo cuts), governance.
- 3-yr cases (FY29): Bull — growth returns to 8-10% with spices/snacks, EBITDA 11%, PAT ~Rs 65 cr, 18x → Rs 290 (+70%). Bear — flat revenue, margin mean-reverts to 8-9%, PAT ~Rs 40 cr, 11x → Rs 110 (-35%). Fair-ish risk/reward but no multibagger path without volume growth.

## VERDICT: REJECT
1. Governance fails: the crown-jewel sattu/besan supply (~11% of purchases) comes from the MD's brother's private companies and is kept outside related-party disclosure; wife, father and son on the payroll; FSSA criminal complaints naming the MD; sloppy corporate records.
2. Post-IPO delivery vs prospectus is poor: revenue guidance missed by 10 pp within two quarters of listing, IPO capex deferred two years with vague excuses, PE sponsor sold out at the top and institutions have since exited.
3. Fundamentals are "margin up, sales down" — record EBITDA margin on declining revenue and 57% utilisation is not a growth story; the 14x multiple is not cheap enough to pay for the governance and execution risk.

## Sources
- https://www.screener.in/company/GANESHCP/consolidated/ (shareholding, document links)
- https://stockanalysis.com/quote/nse/GANESHCP/financials/ , .../financials/?p=quarterly , .../cash-flow-statement/ , .../balance-sheet/ , https://stockanalysis.com/quote/nse/GANESHCP/statistics/
- Red Herring Prospectus (Sept 2025): https://admin.ganeshconsumer.com/uploads/investor_relations/1758087663877_Red_Herring_Prospectus.pdf
- Q1 FY27 transcript (5 Aug 2026): https://ganeshconsumer.s3.ap-south-1.amazonaws.com/DAMCap-GaneshConsumer-Aug05-2026+vf.pdf
- Q1 FY27 presentation: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=11b6296b-8afe-4198-ab92-883ff95dcc09.pdf
- Q4 FY26 presentation (May 2026): https://nsearchives.nseindia.com/corporate/GANESH_NSE_22052026230937_Investor_Presentation.pdf
- Q3 FY26 transcript (Feb 2026): https://admin.ganeshconsumer.com/uploads/investor_relations/1770705916418_Transcript_of_Earnings_Conference_Call_QTR3.pdf
- Q2 FY26 transcript (Nov 2025): https://admin.ganeshconsumer.com/uploads/investor_relations/1762864684631_Transcript_of_Investors_Earnings_Call_QTR_2.pdf
- Hyderabad unit sale press release (1 Oct 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cf02c534-617a-4098-9e30-7cfe85fe2286.pdf
- Board meeting intimation for Q2 FY27 (2 Nov 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f1849ecf-a8c5-4c2a-abaf-4853dd56993c.pdf
- https://trendlyne.com/equity/GANESHCP/ganesh-consumer-products-ltd/ (price)
