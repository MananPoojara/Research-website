# Credo Brands Marketing Ltd — NSE: MUFTI ("Mufti")

**Date:** 2 Nov 2026 | **CMP:** ~Rs 69.8 | **Mcap:** ~Rs 456 cr | **52w:** 116 / 62 | **IPO (Dec 2023):** Rs 280, 100% OFS → stock −75% from IPO
**Business:** Men's casualwear brand (Kamal Khushlani, Mumbai). 427 EBOs (Jun-26), ~1,300 MBOs, LFS. Q1 FY27 channel mix: EBO 61%, MBO 17%, online 12%, LFS 5%. **ADTV ~Rs 0.4 cr — illiquid.** Q2 FY27 results due 4 Nov 2026.

## VERDICT: REJECT (re-review after Q2 FY27 on 4 Nov 2026)
1. **Promoters and pre-IPO investors sold Rs 550 cr at peak earnings; PAT has since fallen 45%** (FY23 Rs 78 cr → TTM Rs 43 cr) while revenue is only +20% in three years. Textbook "sold at the top" OFS.
2. **Every margin/growth guide since listing has been missed and re-based lower:** EBITDA margin 27–30% → 26% delivered → 23–24% guided → 21.2% in Q1 FY27; "15–18% growth" headline vs −4% FY26.
3. **Receivable days 101 (FY23) → 147 (FY26)** while MBO/LFS sales shrink — working capital is absorbing the slowdown. Optically cheap (P/E ~10x, P/B 1.1, yield 2.9%) but cheap for a reason, and the float is too thin to exit.

---

## GATE 1 — GOVERNANCE: **WATCH**
- **Promoter holding:** 55.40% (Dec-23) → 54.99% (Sep-26); slow drift down of ~0.4%, partly ESOP dilution (59,600 shares allotted FY26). **No pledge disclosed.** Promoters: Kamal Khushlani (CMD, re-appointment for 5 yrs from Mar-2027 proposed), Poonam Khushlani (wife, Whole-time Director), children Andrew and Sonakshi in promoter group (both sold 1.08 lakh shares each in the IPO). Spouse as WTD is a nepotism flag; no third-generation KMP found.
- **IPO sellers (pure OFS, 19.63 mn shares, ~Rs 550 cr):** Kamal 4.14 mn, Poonam 4.27 mn, Bela Properties 5.03 mn, Concept Communications (Bennett Coleman/Times group) 2.03 mn, Jay & Sagar Mehta 1.97 mn each. Zero primary capital raised. Since listing, DII 10.4% → 3.4%, FII 3.6% → 0.5%, public 30.6% → 41.1%; shareholder count 88k → 70k. Institutions have exited; retail holds the bag.
- **Board:** 6 directors; 3 independents (Amer Jaleel re-appointed 2nd term Nov-2025; Paresh Bambolkar chairs Audit Committee; Dr Manoj Nakra). No ID resignations found. CFO Rasik Mittal, CS Sanjay Mutha — no KMP changes FY26.
- **Auditor:** M S K C & Associates LLP appointed at Aug-2024 AGM for 5 years (unmodified opinion FY26). Earlier filings reference Deloitte Haskins & Sells — a move from Big-4 to mid-tier within a year of listing; could not verify whether it was term-end rotation. **Flag, verify.**
- **Remuneration/RPT:** Annexures (ratio to median, AOC-2) not accessible from sources fetched; board states all RPTs arm's-length and ordinary course; no loans/guarantees u/s 186. **Unverified — a gap.**
- **Regulatory:** No SEBI order, penalty or litigation found; secretarial audit clean. Dividend Rs 2/share FY25 and FY26 (~28–29% payout) — a mild positive.

## GATE 2 — GUIDANCE & DELIVERY: **FAIL**
| When | Guidance | Delivered |
|---|---|---|
| IPO RHP (Dec-23) | FY23 base: Rev 498, EBITDA 164 (33%), PAT 78; growth via EBO expansion | FY24 Rev 567, PAT 59 (−24%) in the first year post-listing |
| Q1 FY26 call (Aug-25) | FY26 flat; 20 premium stores; ad spend 6–7% | FY26 Rev −4%; stock −17% on the day |
| Q2 FY26 call (Nov-25) | FY26 flat; EBITDA margin **27–30%**; growth from FY27; store count flat | FY26 EBITDA margin **26.0%**, PAT −31%; Q3 FY26 Rev −6%, EBITDA −30% ("GST pricing adjustments", "subdued festive"); Bangladesh supply disruption blamed in Q2 |
| Nov-25 (media) | "15–18% annual growth" via Tier 2–3 expansion | Q4 FY26: 7 opened, 24 closed; EBO count 446 → 429 → 427 |
| Q4 FY26 call (May-26) | FY27 mid-single-digit growth ("hope, not target"); EBITDA **23–24%**; marketing 8–10%; 20 open / 20 close; capex Rs 40–45 lakh/store | Q1 FY27: Rev +4.4%, EBITDA margin **21.2%**, PAT −64% to Rs 2.3 cr; stock −20% on results day; management declined to give 1–2 yr revenue guidance |

Pattern: each call lowers the bar and cites an external one-off. The "MUFTI 2.0" transformation (31 new-identity stores by May-26; benefits promised "from FY28") is a 2–3 year ask with no interim KPIs.

## GATE 3 — FUNDAMENTALS: **FAIL (deteriorating; turnaround unproven)**
- **Growth (Rs cr):** Rev FY21 245 → FY23 498 → FY24 567 → FY25 618 → FY26 592 → TTM (Jun-26) ~597. 3-yr CAGR ~6%; TTM −3%. PAT FY23 78 → FY24 59 → FY25 68 → FY26 47 → TTM ~43.
- **Last two quarters:** Q4 FY26 Rev 162.3 (+6%), PAT 15.3 (+11%); Q1 FY27 Rev 125.3 (+4.4%), PAT 2.3 (−64%).
- **Margins:** Gross margin improving (54% → 59–62%, premiumisation) but EBITDA margin 33% (FY23) → 29% → 26% → 21% (Q1 FY27) as marketing goes 6% → 8.5–10% of sales.
- **Returns:** ROCE 28% (FY23) → 19% (FY25) → 13.8% (FY26) → 12.9% TTM; ROE 11.2% → 10.1%.
- **Leverage:** Borrowings Rs 237 cr (FY25) mostly lease liabilities; interest Rs 25 cr; FY26 EBIT/interest ~3.4x. Net worth ~Rs 410 cr. Manageable.
- **Working capital:** Debtor days 101 (FY23) → 137 → 141 → **147 (FY26)**; working-capital days 196 (Mar-26) → 176 (Jun-26). Inventory days (company) 65; (screener COGS basis) 141. CCC ~250 days — poor for apparel; MBO channel credit is the risk.
- **Cash conversion:** CFO FY21–25 = 96+78+72+56+159 = Rs 461 cr vs PAT Rs 244 cr; FY26 CFO Rs 132 cr (post-Ind AS; lease rent ~Rs 60–70 cr sits in CFF). Real FCF after leases roughly Rs 40–70 cr/yr — supports the Rs 13 cr dividend, no accounting smell.
- **Capex:** Rs 40–45 lakh per new store, ~20 stores/yr → ~Rs 10 cr plus renovations; internally funded.
- **Moat:** 25-year brand with high gross margin, but a mid-premium men's casualwear positioning squeezed between Zudio/value and Levi's/Jack & Jones/online; EBO count shrinking. Weak and eroding.

## GATE 4 — VALUATION: **WATCH (cheap, for a reason)**
- P/E **~10.5x** TTM on my TTM PAT of ~Rs 43 cr (screener's 6.6x uses stale FY25 profit); P/B **1.1x**; dividend yield 2.9%; EV/EBITDA ~3.3x ex-lease, ~4.6x incl. lease liabilities. IPO was ~23x FY23 PAT; peer median P/E ~33x.
- **Cyclical trough or structural?** Earnings have fallen three years running under a self-inflicted "transition"; the gross-margin gain is real but is being spent on marketing with no revenue response yet. Liquidity (Rs 0.4 cr/day) means a Rs 10–20 lakh position moves the price.
- **3-yr scenarios:** Bull — MUFTI 2.0 works, PAT Rs 70 cr, 15x → Rs 1,050 cr (+130%). Base — PAT Rs 45 cr, 11x → Rs 500 cr (+10% plus dividends). Bear — PAT Rs 25 cr, 10x → Rs 250 cr (−45%). Positive skew exists but is contingent on a turnaround with no evidence yet.

## Re-review triggers (check on 4 Nov 2026 Q2 FY27 print)
EBITDA margin ≥24% with revenue growth ≥8% for two consecutive quarters; debtor days back below 120; promoter remuneration ratio and AOC-2 verified from FY26 annual report; confirm reason for 2024 auditor change. Even then, position size must respect ADTV.

## Sources
- Screener.in MUFTI consolidated — https://www.screener.in/company/MUFTI/consolidated/
- Q1 FY27 media release (NSE, 11 Aug 2026) — https://nsearchives.nseindia.com/corporate/CREDONSE_11082026192343_20260811_SE_Letter_media_release.pdf
- Q4 FY26 media release (NSE, 21 May 2026) — https://nsearchives.nseindia.com/corporate/CREDONSE_21052026201726_20260521_Letter_SE_media_release_20260331.pdf
- FY26 call summary and FY27 guidance — https://www.multibagg.ai/market-pulse/articles/mufti-fy26-94620
- Q2 FY26 analysis (27–30% margin guide, Bangladesh disruption) — https://www.multibagg.ai/market-pulse/articles/credo-mufti-q2fy26-analysis-88295
- Q3 FY26 summary — AlphaStreet; Q1 FY26 results/stock fall — Business Standard (1 Aug 2025)
- Q1 FY27 call analysis — https://www.arthneeti.com/stocks/credo-brands/concall/q1-fy27-earnings-call-analysis
- "15–18% growth" headline (7 Nov 2025) — ScanX
- FY26 Directors' Report (board, auditor, ESOP, dividend, RPT statement) — https://www.indiainfoline.com/company/credo-brands-marketing-ltd/reports/directors-report
- IPO structure and selling shareholders — Free Press Journal (SEBI nod, 2023); Wikipedia (Mufti) for history
- Independent director re-appointment (Sep 2025) — https://nsearchives.nseindia.com/corporate/CREDONSE_22092025221424_20250922_SE_Int_ID_SA_final.pdf
