# Ahluwalia Contracts (India) Ltd — NSE: AHLUCONT / BSE: 532811

**Date:** 2 Nov 2026 | **Price:** Rs 542 (52w range 515–1,078, -44% in 1 yr) | **Mcap:** Rs 3,631 cr
**Business:** Building-focused civil EPC (residential 40%, infra 30%, commercial 18%, hospitals/institutional 12%). NCR ~50% of portfolio. Private clients 61% / central govt 29% / state 10%.
**Latest results available:** Q1 FY27 (Jun-26). Q2 FY27 not yet published (expected mid-Nov).

## VERDICT: HOLD-FOR-REVIEW
Gates: G1 Governance **WATCH** | G2 Guidance **FAIL** | G3 Fundamentals **WATCH** | G4 Valuation **WATCH**

1. Guidance credibility is broken: FY25 and FY26 both missed revenue and margin guidance; FY27 guidance given in May-26 was cut within 3 months (growth 15-20% to 12-15%, double-digit margin withdrawn, order inflow Rs 8,000 cr to Rs 4,000-5,000 cr, capex Rs 300 cr to Rs 220-260 cr).
2. Q1 FY27 margin collapsed to 4.3% (PAT -78% YoY) on a Rs 29 cr AIIMS Jammu bill write-down, 35-40% NCR minimum wage hike on contracts without labour escalation, and election disruption; management could not quantify the NGT (Q3) risk. Unbilled revenue jumped to Rs 946 cr from Rs 688 cr in one quarter.
3. Not a reject: Rs 20,664 cr net order book (4.4x revenue), net cash ~Rs 920 cr, CFO/PAT >100% over 5 yrs, CARE AA-/Stable, and valuation (P/E 16, EV/EBITDA ~7) is well below its own 5-yr medians (21.6 / 11). Re-review after Q2 FY27 print: need EBITDA margin back above 8% and unbilled revenue falling.

## GATE 1 — Governance: WATCH
- **Promoter holding** 55.32%, unchanged since Mar-22 (was 59.6% in 2017; fell on QIP-era dilution, not selling). No pledge disclosed on screener/trendlyne/filings found.
- **Family concentration:** Bikramjit Ahluwalia (CMD, ~16% stake), son Vikas Ahluwalia (WTD), son-in-law Shobhit Uppal (Dy MD, ~8%, the de facto public face). All three executive roles are family; Uppal and Vikas were re-appointed for 5 yrs from 1 Apr 2026. Professional CFO (Satbeer Singh). Looks like a classic promoter-run EPC, not egregious nepotism — Uppal has run operations for 20+ years.
- **Remuneration:** ~Rs 1.5 cr + 1.9 cr + 1.2 cr = ~Rs 4.6 cr (SimplyWall.st, approx.) vs FY26 PAT Rs 266 cr = ~1.7%. Modest. Historical blemish: FY2011-12 excess remuneration required a Central Govt waiver application.
- **Directors' personal guarantees** to 13 banks for company facilities — common in Indian EPC but ties promoter and company credit.
- **Regulatory:** Exchange/SEBI warning letter (2025) for a gap in Risk Management Committee meetings — procedural, no fine found. No auditor resignation or qualification found (Amod Agrawal & Associates). No price/volume clarifications found.
- **Litigation/contingents:** Contingent liabilities Rs 3,161 cr (mostly performance BGs; 1.5x net worth). Claims filed by company Rs 610 cr vs client counter-claims Rs 285 cr (Mar-26 notes). Receivables from closed/suspended projects Rs 37 cr under arbitration. AIIMS Jammu final-bill dispute heading to arbitration. Dividend payout only ~1.5% of profits; buybacks "not part of our plan" despite Rs 920 cr cash.

## GATE 2 — Guidance & Delivery: FAIL
| Year | Guided | Delivered |
|---|---|---|
| FY25 | 15-20% growth, ~11% EBITDA margin | +6-7% growth, 8.3% margin; guidance cut to 8.5-9% after Q3 |
| FY26 | 15-20% growth, double-digit margin, >Rs 8,000 cr inflow | +11.4% growth, 9.5% margin; inflow Rs 10,257 cr (beat) |
| FY27 (May-26) | 15-20% growth, double-digit margin, Rs 8,000 cr inflow, Rs 300 cr capex | Aug-26: 12-15%, "ruling out double-digit", Rs 4,000-5,000 cr, Rs 220-260 cr; Q1 inflow only Rs 513 cr |

Three straight years of overpromising on margin. On the Q1 FY27 call an analyst asked whether management knew about the wage hike when guiding in May; the exchange was defensive and unresolved. Several data requests (share of order book with labour escalation) were deferred to email. Rs 500 cr RML L1 order unconverted; Odisha bid lapsed.

## GATE 3 — Fundamentals: WATCH
- **Growth:** Sales CAGR 5-yr 18% / 3-yr 17%; PAT CAGR 5-yr 28% (FY24 inflated by exceptional). TTM sales Rs 4,686 cr (+12%), TTM PAT Rs 225 cr (+1%).
- **Recent quarters:** Q4 FY26 sales +9% / PAT -1%; Q1 FY27 sales +12% / PAT -78%, OPM 4.2% vs 8.6%.
- **Margins:** OPM 12-13% (FY17-19) to 8-10% (FY20-26) to 4% (Q1 FY27). Structural compression from labour-intensive building work with weak escalation clauses (89% of book has escalation, but mostly material-only).
- **Returns:** ROCE 20%, ROE 14% (falling from 25%+).
- **Balance sheet:** Debt Rs 73 cr vs cash ~Rs 920 cr (net cash), but Rs 924 cr mobilisation advances (31% interest-bearing at ~8%) fund the float. Finance cost guided Rs 15-16 cr/qtr.
- **Working capital:** Debtor days 59 (improving), WC days 55; but unbilled revenue Rs 946 cr + retention Rs 401 cr + debtors Rs 632 cr = Rs 1,980 cr (~42% of revenue) tied up with clients.
- **Cash conversion:** CFO FY22-26 Rs 1,264 cr vs PAT Rs 1,192 cr (106%). FCF FY26 only Rs 16 cr as capex rose to Rs 265 cr (mechanisation push; 4-5 yr payback).
- **Moat:** Thin. Execution reputation in complex buildings (Central Vista, CSMT, AIIMS) wins repeat private orders, but bidding is competitive and margins are set by labour.

## GATE 4 — Valuation: WATCH
- P/E 16.2 (TTM) vs 5-yr median ~21.6; P/B 1.76 (was 3.0 a year ago); EV/EBITDA ~7.0 vs 5-yr median ~11. Ex-cash P/E ~12.
- Peers: Capacit'e ~9x, KNR ~8x, NCC ~13x, PSP ~70x (distressed earnings). Cheap vs own history, mid-pack vs peers.
- Cheap for a reason: earnings are falling now, and the market doubts margin recovery.
- **3-yr cases (FY29):** Bull — 12% revenue CAGR, 10% margin, PAT ~Rs 400 cr, 18x = Rs 7,200 cr (+100%). Base — 8% margin, PAT ~Rs 300 cr, 14x = Rs 4,200 cr (+15%). Bear — 6% margin / NGT disruption, PAT ~Rs 200 cr, 12x = Rs 2,400 cr (-34%).

## Sources
- https://www.screener.in/company/AHLUCONT/consolidated/
- https://www.investing.com/news/transcripts/earnings-call-transcript-ahluwalia-contracts-posts-q1-fy27-miss-as-margins-shrink-93CH-4862896
- https://www.bseindia.com/xml-data/corpfiling/AttachHis/2d435d22-de34-4710-b03a-74d8e80be5ca.pdf (Q1 FY27 concall transcript)
- https://www.sahi.com/news/ahluwalia-contracts-expects-12-15-growth-lowers-fy27-order-inflow-guidance-to-4-000-5-000-crore-2665-PE1_COR
- https://www.multibagg.ai/market-pulse/articles/ahluwalia-fy26-96005
- https://simplehai.axisdirect.in/images/2024/Ahluwalia-Contracts-India-Ltd---Q1FY26-Result-Update---19082025.pdf
- https://idbicapital.com/InstitutionReports/Uploads/AHLU_RR_13022025.pdf
- https://plindia.com/ResReport/AHLU-17-8-26-PL.pdf
- https://www.careratings.com/upload/CompanyFiles/PR/202604130433_Ahluwalia_Contracts_(India)_Limited.pdf
- https://scanx.trade/stock-market-news/companies/ahluwalia-contracts-receives-sebi-warning-for-risk-management-committee-meeting-gap-violation/37098370
- https://www.goodreturns.in/company/ahluwalia-contracts-india/notes-to-account.html
- https://www.goodreturns.in/company/ahluwalia-contracts-india/director-report.html
- https://simplywall.st/stocks/in/capital-goods/nse-ahlucont/ahluwalia-contracts-india-shares/management
- https://www.moneyworks4me.com/check-before-you-invest/ahlucont
- https://www.stockezee.com/compare/ahlucont-vs-capacite ; https://www.stockezee.com/compare/ahlucont-vs-knrcon
- https://nsearchives.nseindia.com/annual_reports/AR_31237_AHLUCONT_2025_2026_A_5525574_03092026165628.pdf
