# Talbros Automotive Components Ltd (NSE: TALBROAUTO) — Due Diligence, 5 Nov 2026

**Snapshot:** CMP Rs 388 | Mcap Rs 2,396 cr | P/E 21.4x TTM | P/B 3.2x (BV Rs 120) | Div yield 0.19% | ROCE 18.4% | ROE 14.9% | Promoter 58.43% (0% pledge) | 52w Rs 220–486 | 1-yr return +27% (screener, 5 Nov 2026)
**Latest:** Q1 FY27 (Jun-2026 quarter), reported 10 Aug 2026: revenue Rs 238 cr (+15% YoY), EBITDA Rs 43 cr (17.6%), PAT Rs 30 cr (+35%). Q2 FY27 board meeting 11 Nov 2026, call 12 Nov 2026.

Faridabad gaskets/heat shields (~50% Indian gasket share per CARE) + forgings, with 50:50 JVs Marelli Talbros Chassis Systems (MTCS, suspension arms) and Talbros Marugo Rubber (TMR, hoses/AVS), equity-accounted. Nippon Leakless Talbros JV stake was sold in FY24 (exceptional gain in Q4 FY24 other income Rs 51 cr). All figures Rs crore, consolidated (screener basis = standalone + JV profit share) unless stated.

## Gate 1 — Governance: WATCH

- **Promoter holding** 58.43%, unchanged every quarter Dec-2023 to Sep-2026; pledge 0.00%, locked 0.00% (trendlyne Sep-2026 pattern). Talbros International Pvt Ltd (promoter holdco) owns 42.89%; eight Talwar family holders 15.54%. FII 1.7%, DII 0.2%, public 39.7%; shareholder count down from 70,717 (Sep-24) to 52,857 (Sep-26).
- **Family roles (effective 1 Apr 2026, filing 11 Feb 2026, approved by postal ballot Feb–Mar 2026):** Umesh Talwar Executive Chairman (WTD); his son **Anuj Talwar MD**; Naresh Talwar (Umesh's brother) steps down to Non-Executive Director; Naresh's son **Varun Talwar Vice Chairman & MD** (no remuneration, expenses only). Two cousins as co-MDs is a textbook family-succession structure. Mitigant: **Ashish Gupta**, previously CEO of MTCS, appointed Group CEO and KMP from 1 Apr 2026 — first professional CEO. Group CFO Navin Juneja; CFO Manish Khanna (since 2016); CS Seema Narang (stable).
- **Pay:** FY25 (latest AR available) Umesh Rs 1.95 cr + Anuj Rs 1.95 cr = Rs 3.9 cr = **4.1% of FY25 consolidated PAT (Rs 94 cr)**; Naresh/Varun nil. Proposed from FY27: Rs 2.73 cr each = Rs 5.46 cr ≈ 5.2% of FY26 PAT. Modest. FY26 AR Annexure VII pay ratio: not verified (BSE PDF blocked).
- **Related-party transactions (FY25 AR Note 38):** sales to **QH Talbros Pvt Ltd** (promoter-associated; Umesh Talwar is its promoter director) Rs 73.2 cr and to **Talbros Indiparts Pvt Ltd** (promoter aftermarket arm) Rs 37.4 cr = **Rs 110.6 cr = 13.4% of FY25 revenue Rs 827 cr**; approved caps Rs 95 cr/yr (QHT, FY26–28) + Rs 60 cr/yr (Indiparts) + royalties Rs 1.5 cr + 0.4 cr; rent to Kumkum Talwar Rs 7.2 lakh. JV RPTs small: MTCS lease Rs 2.5 cr/yr, TMR management fee Rs 0.3 cr + goods up to Rs 4 cr. Company also holds shares in its own promoter holdco Talbros International (dividend received Rs 2.65 cr FY25) and in QH Talbros (Rs 0.8 cr) — cross-holdings. All declared arm's length; no material RPT flagged by auditor. Promoter-channel sales at 13% of revenue is the main governance watch item.
- **Auditor:** J C Bhalla & Co (FRN 001111N), partner Piyush Tripathi; re-appointed at the 65th AGM (25 Sep 2022) for a second 5-year term to the 70th AGM (2027). FY26 opinion unmodified, no EoM; one KAM on valuation of unquoted group-company investments; IFC unmodified.
- **Board exits (24 months):** Anil Mehra and Amit Burman (IDs) completed tenure Sep-2024; **Rajat Verma (ID) resigned 13 Mar 2026** ("other professional commitments"); **Deepak Jain (ID, chaired Risk and CSR committees, on Audit committee) resigned 2 Jun 2026** ("professional commitments, time constraints", no other material reason). Pratham Mittal appointed ID 20 May 2026. Two ID resignations in four months around a family-succession reshuffle is a yellow flag; no CFO/CS exits.
- **SEBI/exchange actions:** none found for TACL (a Rs 2 lakh SEBI consent settlement exists for sister-listed Talbros Engineering, a separate company).
- **Capital allocation:** **No 2023 QIP found** — equity capital Rs 12.35 cr flat since FY15, no equity raise since the 2005 FPO, FY24 CFF −Rs 18 cr; the only 2023 corporate action was the 10:2 split (27 Oct 2023). Capex: FY26 Rs 51 cr, FY27 plan Rs 103 cr (gasket/heat shield 16, forging 60, MTCS 20, TMR 7), internally funded + Rs 25–30 cr debt. Dividend Rs 0.75/share FY26 (interim 0.20 + final 0.55), payout 4–5% — thin for a net-cash company. JV investments: new **Lohum Talbros JV** (recovered carbon black/devulcanised rubber) capex ~Rs 70 cr over 2 years (40% equity, 60% debt), target Rs 500–600 cr revenue in 5 years — a diversification outside core competence to watch. Management said (Aug-2026) a 50%→100% stake increase in MTCS "tied to court proceedings" would be clarified by 30 Sep 2026; no filing found — not verified.
- CARE A+/Stable (LT) and A1+ (ST) reaffirmed 5 Dec 2025.

## Gate 2 — Guidance & Delivery: WATCH

| Date / call | Guided | Delivered |
|---|---|---|
| 24 May 2024 (Q4 FY24) | Exports 25% → 35% "in the next three years" (i.e. by FY27); FY24 order wins Rs 980 cr; MTCS Rs 1,000 cr Stellantis order (19 Apr 2024, 8 yrs from Q4 FY25) | FY25 revenue +6%, exports 27%; FY26 exports 25%; Q1 FY27 25% — **flat, target now pushed to "35% by FY28"** |
| May 2025 (Q4 FY25) | "consolidated sales growth of minimum 15% next year"; EBITDA 16.75–17%; exports 30% by FY26, 33–34% by FY27; MTCS +35–40%; FY25 order wins Rs 1,475 cr | **FY26 revenue +5% (Rs 870 cr) — miss**; EBITDA 17.5% — beat; exports ~25% — miss; MTCS +21% — miss |
| 14 Nov 2025 (Q2 FY26) | Juneja: H2 to bring year to "about 10%"; margin ~16.5%; FY27 capex Marelli ~60 cr; Q3/Q4 "much, much, much better" (Anuj Talwar); Q2 hit by JLR cyberattack (Rs 10 cr) | FY26 +5%; Q4 FY26 +15%, margin 18.7% record — H2 did recover |
| Feb 2026 (Q3 FY26) | FY27 capex ~Rs 155–165 cr, done by Dec-2026; Gujarat plant by FY27-28; "Rs 1,100 cr gasket+forging by FY27", "Rs 2,000 cr at company level"; new Rs 1,000 cr+ orders FY27–31 (Rs 700 cr export, Rs 100 cr EV) | May 2026: **capex cut to Rs 103 cr**, Gujarat plant pushed to FY28 |
| 21 May 2026 (Q4 FY26) | FY27 revenue +15–20%, "targeting for crossing INR1,000 crores this year"; EBITDA 17–18%; ~70% of order book commercialised by FY27-end; Stellantis chassis ~Rs 100 cr in FY27, forging Rs 500 cr order from Oct-2026 (20% in FY27) | Q1 FY27 +15%, 17.6% margin — on track at the low end |
| 11 Aug 2026 (Q1 FY27) | Anuj Talwar: "target group revenue target of about 18% to 20%"; margin "17-odd percent, maybe 17.5%"; capex "about INR103 crores"; exports "35% by FY28"; FY30: gasket Rs 850–900 cr, forging Rs 600–700 cr; EV share 3.3% → ~5% in 2–3 yrs | Q2 FY27 due 11 Nov 2026 — first test |

- Order-book disclosures total roughly Rs 3,500 cr announced since FY24 (980 + 1,475 + 1,000 standalone/JV, plus MTCS's Rs 1,000 cr) against FY25/FY26 revenue growth of 6% and 5%. Conversion has lagged two years running (JLR cyberattack, European EV launch delays, Ford recall, Meritor tariff loss Rs 30–40 cr). Management is specific and does not hide misses, but revenue guidance has been missed in both of the last two years while margin guidance was beaten.

## Gate 3 — Fundamentals: PASS (with EV caveat)

- **Growth (screener, consolidated):** Sales CAGR 10y 8%, 5y 14%, 3y 10%, TTM +9%; PAT CAGR 10y 25%, 5y 33%, 3y 23% (FY24 base includes ~Rs 50 cr NLT stake gain; ex-one-off FY24 PAT ~Rs 60 cr → 3y PAT CAGR ~20%). FY26: sales Rs 870 cr, PAT Rs 104 cr (first >Rs 100 cr); TTM sales Rs 902 cr, PAT Rs 112 cr, EPS Rs 18.1.
- **JV share of profit** (equity method, FY25 AR): FY24 Rs 16.2 cr, FY25 Rs 17.7 cr = 19% of FY25 PAT; FY26 not verified but MTCS EBITDA +35% (Rs 62 cr) and TMR +14% (Rs 19 cr) imply ~Rs 22–25 cr. One-fifth of earnings is non-cash JV share — dividends from MTCS were only Rs 1.2 cr/yr.
- **Margin trend:** OPM 10% (FY15–20) → 13% (FY21–23) → 15–16% (FY24–26); company-defined EBITDA 17.5% FY26, 17.6% Q1 FY27, 18.7% Q4 FY26. Gasket EBITDA Rs 105 cr FY26 (+9%); forging EBITDA flat.
- **ROCE:** 9% (FY20) → 18% (FY22) → 21% (FY24) → 19% (FY25) → 18% (FY26). ROE 15–16%.
- **Balance sheet:** borrowings Rs 84 cr (Mar-26), cash Rs 58 cr Mar-25 + Rs 21 cr net inflow FY26 ≈ Rs 80 cr (not verified) → roughly net-cash-neutral; D/E 0.11; adjusted gearing 0.22x, interest cover 9.7x, TD/GCA 0.74x (CARE). Investments Rs 247 cr (JV carrying value Rs 64 cr + group cross-holdings + treasury).
- **Cash conversion:** CFO FY22–26 Rs 341 cr vs PAT Rs 409 cr = **83%** (≈95% ex the FY24 one-off and JV non-cash share). FCF positive every year since FY20; FY26 FCF Rs 46 cr. Capex intensity ~5–6% of sales (FY27 plan 10%).
- **Working capital:** worsening — WC days 32 (FY22) → 71 (FY26); debtor days 118, inventory 118, payables 161; CCC 75 days. CARE: 90–120 day credit to OEMs, ~30% of raw material imported, ~55% WC utilisation.
- **Segment mix FY26 (proportionate):** gaskets & heat shields ~Rs 595 cr (+7%), forgings Rs 295 cr (+2%), MTCS 50% share Rs 173 cr (+21%), TMR 50% share Rs 74 cr (+13%). Q1 FY27: gaskets +21%, forgings +4%, MTCS +43%, TMR +31%. Vehicle mix: PV 34%, CV 24%, 2/3W 15%, agri/off-highway 13%.
- **Exports:** 27% FY25 (Rs 250 cr), ~25% FY26, 25% Q1 FY27; forging 57% export, gaskets 13%; UK 54% of exports (JLR), Europe ex-UK 26%, US 14% → concentrated JLR/Europe exposure; tariffs touched Meritor (US) business.
- **Customer concentration:** one customer >10% of revenue (FY25 AR); top 3 = 32% FY25 (vs 26% FY24, CARE); Cummins single-source data-centre engine gaskets (Rs 25 cr/qtr).
- **Moat:** ~50% domestic gasket share, 70-year OEM relationships, JV technology (Marelli, Marugo), heat-shield adjacency, raw-material tie-up with Interface Performance Materials. Pricing power limited (forging margin squeezed by delayed pass-through).
- **EV exposure:** EV revenue only 3.3%; gaskets (~55% of proportionate revenue) are engine-linked, forgings largely ICE/driveline. Chassis (MTCS), rubber (TMR) and heat shields are powertrain-agnostic. Roughly half the business shrinks structurally if India's PV/2W EV mix accelerates — the main long-term risk.

## Gate 4 — Valuation: WATCH

- P/E 21.4x TTM vs own 5-yr median ~16.5x (MoneyWorks4Me); EV/EBITDA ~15–16x (EV ≈ Rs 2,400 cr on TTM OP Rs 145 cr) vs 5-yr median ~12.5x; P/B 3.2x. Value Research peer median P/E 28.7x (Gabriel 80x, Sansera, Asahi) — but a 2 Nov 2026 peer set from this project (Precision Camshafts 22x, Federal-Mogul Goetze 13–14x, Menon Pistons 11x, Rico 40x+) gives a mid-cap forging/engine-parts median ~17x. Talbros sits above its history and above ICE-component peers, below chassis/suspension names.
- Shares 6.17 cr. FY29 cases (3 years):
  - **Bear:** 8% CAGR → sales ~Rs 1,100 cr, OPM 15%, PAT ~Rs 125 cr (EPS 20) at 14x = **Rs 280 (−28%)**.
  - **Base:** 15% CAGR → ~Rs 1,320 cr, 17%, PAT ~Rs 175 cr (EPS 28) at 18x = **Rs 510 (+31%, ~10% CAGR)**.
  - **Bull:** 20% CAGR with order-book conversion and exports 35% → ~Rs 1,500 cr, 18%, PAT ~Rs 215 cr (EPS 35) at 24x = **Rs 840 (+115%)**.
- Risk/reward roughly 1:1.6 at Rs 388; not cheap enough for the guidance-miss history.

**Multibagger case (3x in 5 years = Rs ~1,165, mcap ~Rs 7,200 cr by FY31):** needs PAT ~Rs 300 cr at 24x — a 22% PAT CAGR from TTM Rs 112 cr. That requires management's FY30 divisional targets (gasket Rs 850–900 cr + forging Rs 600–700 cr + MTCS ~Rs 500 cr + TMR ~Rs 200 cr ≈ Rs 2,000 cr group, ~Rs 1,900 cr proportionate) to land on time at 17–18% margin, exports to reach 35%, and the P/E to hold or expand above 20x despite ICE-gasket exposure. Two consecutive years of 5–6% growth against Rs 3,500 cr of announced orders say timing slips. **Probability assigned: ~20%.**

## Verdict: HOLD

Deciding fact: revenue guidance was missed in FY25 (exports) and FY26 ("minimum 15%" → 5%) while the stock already trades at 21x vs a 16.5x own-history median; governance is clean on pledge, pay and auditor but carries 13% promoter-channel RPT sales, a two-cousin co-MD succession and two independent-director resignations in Mar–Jun 2026. Not a reject — net cash, 18% ROCE, 83% cash conversion, A+ rating, professional CEO — but not a select until delivery is proven.

**Re-review trigger:** Q2 FY27 results (11 Nov 2026) and H1 FY27 commentary: SELECT candidate if H1 FY27 revenue growth ≥15% YoY with EBITDA ≥17% and exports ≥27%, and FY27 tracks ≥Rs 1,000 cr; else re-review at Q4 FY27 (May 2027). Also watch: any MTCS stake-purchase filing (price and funding), Lohum JV cash calls, and further ID exits.

## Top 3 reasons

1. **Delivery gap:** FY26 revenue +5% vs "minimum 15%" guided; exports stuck at 25% vs 35% promised for FY27; Rs 3,500 cr of orders announced since FY24 with conversion repeatedly deferred.
2. **Price already discounts the recovery:** 21x TTM and ~15x EV/EBITDA vs 16.5x/12.5x own 5-yr medians; base case ~10% annual return, bear −28%.
3. **Structural and governance watch items:** ~55% of revenue ICE-linked gaskets with EV share 3%; promoter-entity sales 13% of revenue; cousin co-MDs; two ID resignations in 2026; Lohum JV diversification (~Rs 70 cr) outside core.

Not verified: FY26 annual report pay ratio/AOC-2 amounts (BSE PDF blocked; FY25 AR used), FY26 cash balance and JV profit share, MTCS stake-purchase status, the "2023 QIP" (no evidence it occurred), Q4 FY24 call FY25 growth guidance (only the exports target was found).

## Sources (URLs)

- https://www.screener.in/company/TALBROAUTO/consolidated/
- https://nsearchives.nseindia.com/corporate/TALBROAUTO_10082026142247_PressReleasesigned.pdf (Q1 FY27 press release, via r.jina.ai)
- https://nsearchives.nseindia.com/corporate/TALBROAUTO_14082026145017_transcriptmergedsigned.pdf (Q1 FY27 transcript, 11 Aug 2026)
- https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=885ff0ef-a9f6-4ccb-bfbc-3077a94d93fa.pdf (Q4 FY26 transcript, 21 May 2026)
- https://nsearchives.nseindia.com/corporate/TALBROAUTO_17112025164529_ECTranscriptmergedsigned.pdf (Q2 FY26 transcript, 14 Nov 2025)
- https://nsearchives.nseindia.com/annual_reports/AR_27960_TALBROAUTO_2024_2025_A_6220844_30082025172226.pdf (FY25 annual report: pay, RPT Note 38, JV profit share, exports Note 44)
- https://www.bseindia.com/xml-data/corpfiling/AttachHis/e50702df-e11e-4b4c-9c41-71f5f1129c66.pdf (FY26 annual report — blocked, not read)
- https://www.indiainfoline.com/company/talbros-automotive-components-ltd/reports/directors-report (FY26 Directors' Report text)
- https://www.indiainfoline.com/company/talbros-automotive-components-ltd/reports/auditors-report (FY26 auditor's report)
- https://www.careratings.com/upload/CompanyFiles/PR/202512131256_Talbros_Automotive_Components_Limited.pdf (CARE A+/Stable, 5 Dec 2025)
- https://nsearchives.nseindia.com/corporate/TALBROAUTO_11022026171304_ChangeinManagementsigned.pdf (management reshuffle, 11 Feb 2026)
- https://nsearchives.nseindia.com/corporate/TALBROAUTO_13032026151003_Resignationmergedsigned.pdf (Rajat Verma resignation)
- https://filingreader.com/news-wire/mumbai/2026-06-02/deepak-jain-resigns-from-talbros-automotive-components-board
- https://trendlyne.com/equity/share-holding/1347/TALBROAUTO/latest/talbros-automotive-components-ltd/ (Sep-2026 shareholding, pledge)
- https://www.whalesbook.com/news/English/industrial-goodsservices/Talbros-Automotive-Leadership-Succession-Approved-Key-Execs-to-Earn-indian-rupee227-Cr-Annually/69a1787efa7d0695d1aba089
- https://www.arthneeti.com/stocks/talbros-auto/concall/q1-fy27-earnings-call-analysis
- https://www.arthneeti.com/stocks/talbros-auto/concall/q3-fy26-earnings-call-analysis
- https://www.arthneeti.com/insights/talbros-auto-q4-fy25-earnings
- https://www.sahi.com/news/talbros-automotive-targets-18-to-20-fy27-revenue-growth-and-plans-103-crore-capex-279-PE1_CORP
- https://www.multibagg.ai/market-pulse/articles/talbros-q1-97647
- https://autocarpro.in/news-international/marelli-talbros-chassis-systems-wins-rs-1000-crore-business-from-european-oem-120155 (19 Apr 2024)
- https://sgp.gurufocus.com/news/2523500/q4-2024-talbros-automotive-components-ltd-earnings-call-transcript (May 2024 exports target, via search snippet)
- https://www.moneyworks4me.com/check-before-you-invest/talbroauto (5-yr P/E, EV/EBITDA medians)
- https://www.valueresearchonline.com/stocks/44789/talbros-automotive-components-ltd/ (peer median P/E)
- Project peer set: source/dd/RICOAUTO.md, source/dd/FMGOETZE.md (2 Nov 2026)
