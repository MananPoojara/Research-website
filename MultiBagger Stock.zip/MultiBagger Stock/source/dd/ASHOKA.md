# Ashoka Buildcon (NSE: ASHOKA) — Due Diligence, 2 Nov 2026

**Snapshot:** CMP Rs 100, mcap Rs 2,811 cr, headline P/E 4.2 (meaningless — see Gate 4), P/B 0.41, no dividend. 52-wk range Rs 95–214 (−53% in 1 yr). Nashik-based road EPC + residual BOT/HAM holder (Katariya & Parakh families, 54.47%). Order book Rs 15,251 cr (Jun-26). Q2 FY27 results due 5 Nov 2026; same board meeting will consider a fresh NCD issue.

## What was sold (the −37% asset shrink)
Total assets fell Rs 20,573 cr → Rs 12,884 cr (Mar-25 → Mar-26) because BOT/HAM SPVs carrying ~Rs 5,000 cr project debt were deconsolidated:
- **5 HAM SPVs → Edelweiss (EAAA) Sep 2025:** consideration Rs 1,146 cr, cost Rs 599 cr, gain Rs 547 cr.
- **5 BOT toll SPVs (Bhandara, Durg, Belgaum-Dharwad, Sambalpur-Baragarh, Dhankuni-Kharagpur) → Maple Infrastructure Trust, Nov 2025:** ~Rs 1,814 cr (ICRA). May-2025 call had indicated ~Rs 2,500 cr net equity consideration (Rs 700 cr contingent on traffic-linked extensions) — realised value is ~27% below that indication. Gain booked as Rs 2,416 cr other income in Q3 FY26.
- **Use of proceeds (~Rs 2,960 cr):** buy-out of SBI Macquarie's 34% in Ashoka Concessions + Jaora stake (~Rs 1,526 cr + Rs 150 cr), Rs 300 cr NCD repayment, working capital.
- **Pending:** remaining 6 HAM SPVs → Epic Concesiones 2 (EAAA) ~Rs 1,150 cr; ~Rs 750 cr guided for FY27 (slipped from Q1 to Sep/Oct), ~Rs 400 cr FY28; Rs 30–40 cr holdbacks possible. Residual assets: Jaora-Nayagaon (74%, Rs 418 cr invested, Rs 75 cr quarterly toll), Chennai ORR (~Rs 300 cr), 6 newer HAMs (Rs 608 cr equity) plus Bowaichandi (Rs 226 cr to invest).

## GATE 1 — GOVERNANCE: WATCH
- Promoters 54.47% flat; pledge not verifiable today. FIIs fell 8.5% → 4.2% and DIIs 15.5% → 12.8% over 7 quarters — institutions are leaving.
- **Family KMP:** JMD Ashish Kataria is Chairman Ashok Katariya's son (AR FY25). COO Aditya Parakh is MD Satish Parakh's son. Shobha Parakh (MD's wife) holds 13.55%, the single largest holder. Two families, two sons in senior operating roles — nepotism risk is real though both have long tenure. CFO Paresh Mehta, CS Manoj Kulkarni are professionals.
- Remuneration: Katariya and Parakh Rs 5.13 cr each FY25 (Londhe/Ashish not captured) vs standalone PAT Rs 197 cr — ~5%+ for two; acceptable.
- **Capital allocation smell:** Rs 2,576 cr FY26 PAT and ~Rs 2,960 cr cash proceeds, yet zero dividend, no buyback, standalone debt still Rs 1,173 cr (NCDs Rs 1,110 cr) and the board is now considering *more* NCDs. ICRA notes interest cover must be "adjusted for loans from ABL Group entities" — intra-group loans to the parent.
- Positives: auditor is S R B C & Co (EY affiliate), no qualifications found; independent directors are credible (ex-Mahindra chief internal auditor, Khaitan & Co partner, NetApp audit head). No SEBI penalties found.
- Opacity: unexplained dilution of "Purestudy" stake 59% → 39%, SPV-level questions deferred offline, "strategic focus" declined.

## GATE 2 — GUIDANCE & DELIVERY: FAIL
| Guided | Actual |
|---|---|
| FY26 revenue +15% (Feb-25) → cut to +10% (May-25) | Standalone operating income −17.7% (Rs 5,812 cr) |
| FY26 EBITDA margin 10–10.5% | 8.5–8.8% |
| FY26 inflow Rs 10–12k cr | Order book ~flat (14.9k → 15.3k cr) |
| BOT sale close "by 30 Jun 2025", ~Rs 2,500 cr | Closed Nov 2025, ~Rs 1,814 cr |
| HAM remaining sales "by Dec 2025/FY27" | 6 SPVs still pending, now Sep-26 → Dec-26/FY28 |
| Post-sale standalone debt Rs 200–300 cr | Rs 1,173 cr at Jun-26; FY27 guide now Rs 500–700 cr |
| FY27 revenue +20% (May-26) | Cut to +10–15% after Q1 (−2%); margin cut to 9–9.5% |
Three straight guidance cuts, every monetisation milestone slipped, and the same "H1 slow, H2 ramp" line as last year.

## GATE 3 — FUNDAMENTALS: FAIL
- Consolidated sales: FY25 10,037 → FY26 7,520 → TTM 7,132 (−25%); 3-yr sales CAGR −2%; 5-yr +9%. Last two quarters: Mar-26 sales −27% YoY, PAT −67%; Jun-26 sales −21%, PAT −44%. Standalone EPC Q1: revenue −2%, EBITDA −17%, margin 11.3% → 9.5%.
- Margins: consolidated OPM 33% → 19% as toll income left; standalone 7.7–8.8% vs 11–15% in FY18–22.
- Working capital: WC days 3 → 142, debtor days 44 → 78 (Power T&D collections stuck; Rs 250 cr infused). Cash conversion ex-monetisation is weak: standalone debt/EBITDA 4.3x, interest coverage 1.6x (ICRA) — that is thin for an EPC company that just sold Rs 3,000 cr of assets.
- CFO FY22–26: Rs 353/492/749/1,673/655 cr — historically driven by toll SPVs that are now sold; not representative going forward.
- Positives: order book 2.9x standalone revenue, 21 states + 15% overseas, HAM equity commitments modest (Rs 179/72/72 cr). Capex Rs 125 cr. No moat — commoditised road EPC with "intense competition" (ICRA).
- Declining sales **and** falling margins with no demonstrated turnaround → FAIL under the brief's rule.

## GATE 4 — VALUATION: WATCH (cheap for a reason)
- Reported P/E 4.2 is driven by Rs 2,312 cr one-off gains. Core PAT (standalone ~Rs 320 cr FY26 incl. Rs 112 cr Kandi gain → ~Rs 210 cr core, plus residual toll/HAM) ~Rs 250–300 cr → normalised P/E ~9–11x; EV/EBITDA ~4x on ~Rs 1,170 cr annualised consolidated EBITDA (EV ~Rs 4,640 cr incl. ~Rs 1,830 cr net debt).
- Sum-of-parts: EPC 8x core PAT ~Rs 1,750 cr + pending HAM sale ~Rs 1,100 cr + Jaora Rs 418 cr + Chennai ORR Rs 300 cr + HAM equity Rs 608 cr − standalone net debt ~Rs 900 cr ≈ Rs 3,300 cr → ~+17% vs mcap. P/B 0.41 looks cheap but book is inflated by gains sitting in cash/receivables that management keeps redeploying into debt service and new HAM equity rather than returning.
- **3-yr case:** Bull — HAM sales close, standalone debt < Rs 300 cr, EPC margin 10.5%, revenue Rs 8,000 cr, PAT Rs 400 cr at 9x → Rs 3,600 cr (+28%) plus residual asset value → +40–50%. Bear — another guidance miss, NCD refinancing, holdbacks → PAT Rs 200 cr at 7x → Rs 1,400 cr (−50%). Not asymmetric enough.

## VERDICT: REJECT
1. Management has missed revenue, margin, debt and monetisation-timing guidance for two straight years; the FY27 20% growth guide lasted one quarter.
2. Core EPC is shrinking with falling margins (standalone −18% FY26, Q1 FY27 −2%, 9.5% margin), working-capital days exploded 3 → 142 and interest cover is 1.6x — fundamentals FAIL.
3. Rs 2,960 cr of asset proceeds produced no dividend/buyback; debt is being re-raised, FIIs have halved their stake, and two promoter sons occupy JMD/COO seats. The "cheap" P/E is an accounting artefact of one-off gains.

## Sources
- https://www.screener.in/company/ASHOKA/consolidated/
- Q1 FY27 concall transcript (12 Aug 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f530bfde-0bc8-4c92-bbff-6ab6373a0e04.pdf
- Q1 FY27 investor presentation: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6ec06272-1f16-4f4a-9d45-c0aa4c8060ec.pdf
- Q4 FY25 concall transcript (May 2025, FY26 guidance & monetisation plan): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6c840a1f-3a49-479f-a0c2-ca0f01623b5e.pdf
- ICRA rationale 30 Oct 2026: https://www.icra.in/Rationale/ShowRationaleReport/?Id=146710
- Annual Report FY25 (board relationships, remuneration): https://www.bseindia.com/xml-data/corpfiling/AttachHis/7ea14a7a-2a21-4fbd-9c83-91de83d26408.pdf
- Board meeting notice 1 Nov 2026 (NCD fund-raise): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2f5a9533-b9dd-4f91-9d9a-fa2fd94677d0.pdf
- Board page: https://www.ashokabuildcon.com/board-of-directors.php
- Governance page: https://www.ashokabuildcon.com/corporate-governance.php

*Limitations: web-search budget exhausted this session; FY26 annual report could not be parsed (RPT totals, contingent liabilities, pledge unverified). Q2 FY27 results due 5 Nov 2026 were not available.*
