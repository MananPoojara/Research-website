# Jay Bharat Maruti (NSE: JAYBARMARU) — Due diligence, 2 Nov 2026

**Business:** Sheet-metal BIW parts, exhausts, fuel necks, axles for Maruti Suzuki (MSIL) and Suzuki Motor Gujarat (SMG). Plants at Gurgaon, Manesar, Kharkhoda (J7, new) and SMG supplier park Gujarat. Promoters: Arya family / JBM group (~30%) plus MSIL 29.28% as co-promoter; promoter group 59.35%, unchanged since 2019.
**Snapshot (screener consolidated, 2 Nov 2026):** Price Rs 122, mcap Rs 1,320 cr, 52-wk 74–207, headline P/E 9.6, P/B 1.9 (BV 64), ROCE 16.6%, ROE 22.3%. Board meets today (2 Nov) for Q2 FY27 — results not available at time of writing.

## Gate 1 — Governance: FAIL
- Captive on both sides. FY25 standalone: sales to MSIL Rs 1,292 cr + SMG Rs 668 cr = Rs 1,961 cr = 86% of revenue. Purchases from Neel Metal Products Ltd (NMPL, Arya-controlled, unlisted) Rs 924 cr = 40% of revenue, plus Rs 11.6 cr capital goods and Rs 4.3 cr other expenses; payable to NMPL Rs 171 cr at year end. Shareholder-approved RPT caps for FY26: MSIL Rs 2,185 cr, SMG Rs 1,220 cr, NMPL Rs 1,920 cr (= 84% of sales). JBML is effectively a conversion shop between Maruti and a promoter-owned steel processor; the economics of where margin lands are set by the promoter.
- Promoter pay vs profit: S.K. Arya, non-executive Chairman, received Rs 5.67 cr in FY25 and Rs 9.43 cr in FY24 — 17% and 29% of PAT respectively, for a non-executive role. Son Nishant Arya is a non-executive director. Dividend payout cut to 5% in FY26 while promoter commission continues.
- Group complexity: 49% JV (JBM Ogihara Die Tech) with sister listed JBM Auto; group gratuity trust; royalty Rs 3.3 cr; JBM Auto itself sought Rs 19,450 cr of RPT approvals in 2026 — the group runs on intra-group trade.
- Positives: MSIL as 29% co-promoter and board nominee is a real check; auditor GSA & Associates LLP (since 2022, unqualified); no pledge disclosed by Arya entities; ex-IAS independent director added Jul 2026; no SEBI action found. Exchange volume clarifications Jan and Oct 2026 — routine replies.
- Net: no fraud, but structural value leakage (40% of COGS from a promoter entity plus 17–29% of PAT paid to a non-executive promoter) is exactly the governance smell the mandate says to reject.

## Gate 2 — Guidance & delivery: WATCH
No earnings calls from Jan 2022 until May 2026; transcripts of the May/Aug 2026 calls are not publicly retrievable, so there is no verifiable guidance track record. Stated plans: Rs 350 cr capex for Kharkhoda J7 + Gujarat assembly plant (approved 2023), J7 phase II Rs 170 cr (Feb 2026), enabling QIP resolution Rs 750 cr. Delivery: J7 began partial Brezza supply FY25; CWIP fell 308 -> 110 cr in FY26 as fixed assets rose to Rs 1,173 cr, so plants were commissioned. But Q1 FY27 shows the ramp is not yet earning: revenue +13% while EBITDA -4% and PAT -9%, blamed on commodity lag and employee cost. MSIL itself guides 10%+ volume growth in FY27, which is the real driver.

## Gate 3 — Fundamentals: WATCH
- Sales CAGR: 5-yr 11%, 3-yr 3% (FY23 2,344 -> FY25 2,290 flat, FY26 2,551 +11%). TTM 2,621 cr.
- Profit: FY26 PAT Rs 140 cr vs 33 cr, but Q4 FY26 (PAT 80 cr) included a Rs 36.8 cr deferred-tax remeasurement (115BAA switch) and a Rs 35.5 cr GST incentive for J5. Adjusted FY26 PAT ~Rs 75–80 cr; adjusted TTM ~Rs 75 cr.
- Recent quarters: Q4 FY26 sales 766 cr (+25%), OPM 12% (incl. incentive); Q1 FY27 sales 627 cr (+13%), OPM 10% vs 12%, PAT 22 cr (-9%). Direction: volume up, margin down.
- OPM 9% (FY19–21) -> 7% (FY22–25) -> 11% FY26; sustainable run-rate looks ~10%.
- Leverage: borrowings Rs 531 cr vs equity Rs 696 cr (D/E 0.76; was 0.97 FY25). Interest coverage ~4x FY26 (2.3x FY25). Interest Rs 44 cr/yr.
- Working capital negative (-13 days) thanks to Maruti payment terms and NMPL payables; debtor days 17.
- Cash conversion strong: cumulative CFO FY22–26 Rs 844 cr vs PAT Rs 271 cr (depreciation ~Rs 90 cr/yr); FCF positive in 4 of 5 years but capex cycle (Rs 265 cr FY25) absorbs it.
- Moat: none independent of Maruti. Single-customer risk 86%; pricing is cost-plus with lagged commodity pass-through, so margins are set by MSIL.

## Gate 4 — Valuation: WATCH
Headline P/E 9.6x is optical. On adjusted TTM PAT ~75 cr the P/E is ~17–18x; P/B 1.9x for a 10–12% normalised ROE; EV/EBITDA ~7.5x on adjusted EBITDA ~245 cr. Own 5-yr P/E range roughly 10–30x; peers (Value Research, Oct 2026): ZF Commercial 10x, TVS Holdings 12x, Gabriel/Sansera 70x+. Not cheap for a 3-yr sales CAGR of 3% and 11% 5-yr. Stock doubled in a year on the FY26 one-off profit.
3-yr cases: Bull — Kharkhoda/Gujarat ramp, sales 15% CAGR to ~3,900 cr, OPM 11.5%, PAT ~150 cr, 14x = Rs 2,100 cr (+60%). Base — 10% growth with MSIL, OPM 10%, PAT ~100 cr, 12x = Rs 1,200 cr (-9%). Bear — MSIL volume slowdown or commodity squeeze, PAT ~55 cr, 10x = Rs 550 cr (-58%).

## Verdict: REJECT
1. Governance FAIL: 40% of cost of goods bought from the promoter's unlisted Neel Metal Products (Rs 924 cr/yr, cap Rs 1,920 cr) and a non-executive Chairman paid 17–29% of PAT. Minority shareholders cannot see where the group's margin is booked.
2. 86% revenue from one customer who is also co-promoter; JBML is a cost-plus captive with 3-yr sales CAGR of 3% and OPM that MSIL effectively sets. No multibagger lever the company controls.
3. The "9.6x P/E" is built on Rs 72 cr of Q4 FY26 one-offs; adjusted ~17–18x for 10% ROE is not cheap, and Q1 FY27 already shows margins reversing. Revisit only if Q2 FY27 (due today) shows OPM >11% ex-incentives and NMPL purchases falling as a share of sales.

## Sources
- https://www.screener.in/company/JAYBARMARU/consolidated/ (financials, shareholding, announcements)
- https://www.jbmgroup.com/wp-content/uploads/annual-reports/JBML-AR-2024-25_combined.pdf (AGM notice RPT caps; Note 48 related-party disclosures; single-customer note; remuneration; auditor; Kharkhoda status)
- https://www.arthneeti.com/insights/jay-bharat-maruti-ltd-q1-fy27-earnings (Q1 FY27 presentation figures)
- https://www.sahi.com/news/jay-bharat-maruti-reports-q1-revenue-of-6-3b-rupees-standalone-net-profit-at-212m-rupees-515-PE1_CORP (Q1 FY27, AGM, new ID)
- https://www.multibagg.ai/market-pulse/articles/q4-fy26-results-94350 (Q4 FY26 deferred tax Rs 36.79 cr and GST incentive Rs 35.50 cr)
- https://bsmedia.business-standard.com/_media/bs/data/announcements/bse/06022026/702cdc7b-f769-44e9-bed3-3a481216f8fa.pdf (J7 phase II capex Rs 170 cr)
- https://scanx.trade/stock-market-news/stocks/jay-bharat-maruti-limited-clarifies-significant-trading-volume-increase-to-bse/29147505 (volume clarification)
- https://www.whalesbook.com/corporate-news/English/industrial-goodsservices/JBM-Auto-seeks-shareholder-nod-for-Rs-19450-Cr-RPTs-Rs-5000-Cr-borrowing-limit/6a201ed67f2bd0fbfa56aa2b (group RPT scale)
- https://www.valueresearchonline.com/stocks/42758/jay-bharat-maruti-ltd/peer-comparison/ (peer P/E)
- https://www.business-standard.com/companies/quarterly-results/maruti-q2fy27-results-net-profit-declines-26-36-to-2-466-1-crore-126102700965_1.html (MSIL Q2 FY27 demand/margin context)
