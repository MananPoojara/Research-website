# iValue Infosolutions (NSE: IVALUE) — Due Diligence, 2 Nov 2026

**Price ~Rs 200 | Mcap Rs 1,093 cr | IPO Sept 2025 at Rs 299 (stock -33% vs IPO, -31% 1-yr) | 52w 340/189**
Bengaluru value-added distributor of cybersecurity / data-centre / ILM / cloud products (115 OEMs, 866 SIs, 474 enterprise customers). Reports revenue net (agent basis) since FY23; management talks in gross sales (FY26 Rs 2,914 cr).

Latest reported quarter: Q1 FY27 (Jun-2026). Q2 FY27 (Sep-2026) not yet published (expected mid-Nov 2026).

## GATE 1 — GOVERNANCE: WATCH
- **IPO was 100% OFS, Rs 560 cr, zero fresh money.** Sellers: Sundara (Mauritius) Ltd (Creador vehicle) sold its entire 11.0 mn shares (Rs 329 cr, full exit); the three promoters sold Rs 85 cr; promoter-group member Hilda Sunil Pillai sold Rs 30 cr; CFO, COO and six other senior managers sold ~Rs 115 cr. Promoter + group fell 39.0% → 32.0% (now 32.09%, Sep-26). No pledge. Token promoter buy of 35,661 shares in Q2 FY27.
- **Leadership churn within a year of listing:** co-founder/promoter Srinivasan Sriram resigned from senior management (Mar-2026); CEO Shrikant Shitole resigned "for personal reasons" (Jul-2026) — CMD Sunil Pillai and ED Krishna Raj Sharma now jointly cover the CEO role, no succession timeline. An analyst cited three senior exits on the Q1 FY27 call; management did not address it. Three new C-level hires (CBO, CRO, CTO) announced the same quarter.
- Kabir Thakur (Creador nominee) remains a non-independent NED after Creador's full exit — board composition looks stale.
- No family members in management found (Hilda Pillai is a shareholder only). Promoter pay modest: MD 5.2x median, ED 4.5x, nil increase FY26. RPTs only with subsidiaries (Asia iValue Pte, Quantanxt), immaterial.
- Auditor Price Waterhouse & Co (since Sept-2022), unqualified; secretarial audit clean; no fraud reported; no SEBI/exchange action on promoters in last 5 years. Contingent liabilities Rs 6.3 cr (customs/GST), 10 tax proceedings, 1 criminal case against company (prospectus).
- Net: no RPT/pledge/auditor smell, but a PE-exit IPO at Rs 299 followed by CEO + co-founder exits and a 33% drawdown is a pattern that needs explaining.

## GATE 2 — GUIDANCE & DELIVERY: WATCH
- Nov-2025 (first call post-IPO): refused numeric guidance; said H2 would be ~60% of gross sales. FY26 delivered gross sales +19.5% (Rs 2,914 cr), PAT +20% pre-Labour-Code (reported Rs 98 cr, +15.5%). CFO > PAT for the first time (Rs 108 cr). Reasonable delivery.
- May-2026: FY27 guide 18-20% gross-sales growth, 20-22% PAT growth; gross margin ~10% of gross sales.
- Jul-2026 (Q1 FY27): gross sales only +5.7%; net revenue -21%; ILM segment -60% (Hitachi slowdown), DCI +183% (Arista). PAT +52% on a weak Q1 FY26 base. **20% guidance reaffirmed** with "H2 is seasonally stronger" and a Rs 6,150 cr "qualified pipeline" (not order book, 30-35% win rate). Analysts pushed on sequential slowdown, cyber growing slower than peers, hardware -28%; answers were deflective ("don't look at it on a quarter basis", "will come back to the community"). Appraisal costs to pressure margins from Q2.
- Acquisition / dividend / buyback: "evaluating", no specifics for 3 calls running. No dividend ever paid.

## GATE 3 — FUNDAMENTALS: WATCH
- 5-yr CAGR (FY21-26): net sales 2.4% (distorted by gross→net accounting change in FY23; gross-sales 10-yr CAGR claimed 23%); PAT 24% (34 → 98 cr). 3-yr PAT CAGR 19%.
- TTM: net sales Rs 1,007 cr (+6%), PAT Rs 104 cr (+24%). Last two quarters YoY: Q4 FY26 sales +4.6%, PAT +13%; Q1 FY27 sales -21%, PAT +52%.
- OPM 13-14% (net basis); gross margin on gross sales slipped 9.9% → 9.1% in FY26, 8.1% in Q1 FY27 (vs 6.8%); volatile, FX-sensitive, rebate-dependent in Q4.
- ROCE 25%, ROE 20%. Borrowings Rs 69 cr vs equity Rs 568 cr (D/E 0.12), interest cover ~10x; net cash Rs 212 cr (Mar-26), Rs 121 cr (Jun-26, seasonal).
- **Working capital is the core weakness:** trade receivables Rs 1,102 cr (Jun-26, +19% YoY) = ~92% of net revenue / ~135 days of gross sales; screener debtor days 336. Offset by payables (341 days), so NWC days 30-52. 90% of receivables credit-insured. Receivables growing faster than sales (Tijori flag).
- Cash conversion FY22-26: cumulative CFO Rs 230 cr vs PAT Rs 358 cr = 64%. FY26 was the first year CFO > PAT. Capex negligible.
- Moat: thin. Multi-OEM distributor with top-10 OEMs 63% of gross sales (FY25; top OEM 17%), vulnerable to OEM direct/platform bundling, FX and vendor-rebate swings.

## GATE 4 — VALUATION: PASS (cheap, partly for a reason)
- P/E 10.2x TTM, P/B 1.9x, EV/EBITDA ~6.4x (EV ~Rs 880 cr / EBITDA 138 cr). IPO was priced at ~15-17x. No 5-yr listed history. Peers: Redington 15x, Rashi Peripherals 16x.
- Cheap because of post-IPO overhang (PE/insider exit), CEO exit, and Q1 miss — not (yet) structural decline.
- 3-yr cases (FY29 PAT / multiple): Bull 18% CAGR → ~Rs 165 cr at 14x = Rs 2,300 cr (+110%); Base 10% → ~Rs 135 cr at 10x = Rs 1,350 cr (+25%); Bear growth stalls, receivable provision, 8x on Rs 110 cr = Rs 880 cr (-20%).

## VERDICT: HOLD-FOR-REVIEW
1. Governance smell without hard evidence: pure-OFS PE/insider exit at Rs 299, then CEO and co-founder departures inside 12 months; need a named CEO and a clean Q2.
2. Guidance credibility: Q1 FY27 grew 5.7% against a reaffirmed 20% FY27 target; Q2 FY27 (mid-Nov 2026) must show >15% gross-sales growth or the guide is broken.
3. Valuation (10x, 6x EV/EBITDA, net cash) is attractive for 20% earnings growth, but a distributor with Rs 1,100 cr receivables and 64% five-year cash conversion does not deserve a re-rating until cash conversion holds >80% for two years.
Re-review after Q2 FY27 results; REJECT if growth <10% or any further KMP exit.

## Sources
- https://www.screener.in/company/IVALUE/consolidated/
- https://www.tijorifinance.com/company/ivalue-infosolutions-ltd/
- Q1 FY27 transcript (Jul-29-2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8a8a8fc0-f448-463b-af34-0413aa7f8a68.pdf
- Q1 FY27 presentation: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=200978bf-8a01-4d7c-ad93-74c3b0a1c788.pdf
- Q4 FY26 transcript (May-27-2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b2590e34-5554-4803-aec9-f5c143b6a8aa.pdf
- Q2 FY26 transcript (Nov-2025): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4da67a7f-ce07-42a2-8556-d43d18bb9dca.pdf
- IPO Prospectus: https://ivaluegroup.com/en-in/wp-content/uploads/sites/2/2026/03/Prospectus.pdf
- Annual Report FY26: https://ivaluegroup.com/en-in/wp-content/uploads/sites/2/2026/07/Annual-Report.pdf
- Leadership: https://ivaluegroup.com/en-in/corporate/ivalue-leadership-team/ ; Governance: https://ivaluegroup.com/en-in/investor-relations/governance/
- Promoter purchase disclosure (Oct-6-2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3849acb0-2315-4975-96a4-90c198b1858a.pdf
