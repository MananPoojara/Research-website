# Rico Auto Industries Ltd (NSE: RICOAUTO) — Due Diligence, 2 Nov 2026

**Verdict: REJECT** | G1 Governance: WATCH | G2 Guidance: FAIL | G3 Fundamentals: FAIL | G4 Valuation: FAIL

Gurugram aluminium/ferrous castings and machined assemblies for 2W/PV OEMs (Kapur family, est. 1983; 16 plants). Price Rs 106, mcap Rs 1,428 cr, P/E ~40–47x TTM, P/B 1.7, EV/EBITDA 10, ROCE 9%, ROE 7.7%. Q2 FY27 results due 6 Nov 2026 (board meeting + call scheduled).

## Gate 1 — Governance: WATCH

- **Promoter holding** 50.33%, flat since Mar-2023; **no pledge/encumbrance** (FY26 declaration signed by Arvind Kapur, Apr-2026).
- **Family concentration**: Arvind Kapur is Chairman + CEO + MD (all three). Samarth Kapur is Whole-time Director; Shikha Kapur was added as non-executive non-independent director Apr-2024; Arun Kapur moved from Joint MD to WTD (2022) and runs subsidiary Rico Jinfei Wheels; Rakesh Kapur (director, died 2020). Two of five "independent" directors are also surnamed Kapur (Sarita Kapur, Yogesh Kapur) — relationship undisclosed in sources, but independence optics are poor. Five Kapurs on an 11-person board.
- **Promoter pay**: Arvind Kapur Rs 9.3–9.8 cr/yr (FY24–FY25) — about **46% of FY25 consolidated PAT** (Rs 21 cr) and 19% of FY26 PAT (Rs 52 cr); Simply Wall St peer-median CEO pay for the size bracket ~Rs 1.2 cr.
- **Disclosure credibility**: on the Aug-2023 call Arvind Kapur apologised for not telling investors about a year-long Hero MotoCorp pricing dispute that cost ~Rs 100 cr of sales. Three CFO changes in 10 years (2017, 2023, 2026).
- **JV history**: Continental brakes JV sold 2012, FCC clutch JV sold 2014 (Rs 495 cr), Magna oil-pump JV bought out 2019, Jinfei (China) wheels JV now 96% owned. All ended by sale/buyout, not litigation — pattern of partners leaving rather than fraud.
- Auditor B S R & Co, unmodified reports. No SEBI/exchange action found. CRISIL A/Stable reaffirmed Dec-2025 (screener lists a further CRISIL update 30-Oct-2026, text not found). RPTs: no material numbers surfaced; group entity Popular Mega Motors is separately rated.

## Gate 2 — Guidance & delivery: FAIL

- 2018: "Rs 2,000 cr turnover in FY2020" — reached FY23, three years late.
- Aug-2023 (FY24): revenue Rs 2,700 cr cut to Rs 2,600 cr incl. Rs 80–100 cr defence; EBITDA margin >11%, 12%+ in FY25 → actual FY24 Rs 2,160 cr, 10% margin; FY25 Rs 2,212 cr, 9% margin, PAT Rs 21 cr. Defence still only Rs 20–30 cr in FY26.
- CRISIL expected FY25 net cash accrual Rs 180–200 cr; actual Rs 115 cr. ROCE target 11–13% lowered to >9.5%.
- Hosur greenfield: benefits "from FY26" (CRISIL 2025) → commercial production Sep/Oct-2026.
- FY27 (Aug-2026 call): revenue guide *raised* Rs 3,000 → 3,250 cr while Q1 margin collapsed to 4.6% and PAT went negative; margin recovery pushed to Q3; capex "being curtailed", FY27–28 capex numbers deferred; Rs 13 cr air-freight and Rs 10 cr raw-material lag blamed. Consistent over-promising on margins and timelines.

## Gate 3 — Fundamentals: FAIL

- Sales CAGR 5y 11%, 3y 2%; PAT CAGR 3y 6% (5y "50%" is off a FY21 loss base). FY26 sales Rs 2,478 cr (+12%), PAT Rs 52 cr. TTM sales Rs 2,689 cr, TTM PAT Rs 32 cr (falling).
- Last two quarters: Q4 FY26 sales +24% YoY, PAT Rs 6.9 cr (-7%), OPM 7.1%; Q1 FY27 sales Rs 755 cr (+39%), **net loss Rs -3.4 cr** vs +16.7 cr, OPM 4.6% vs 9.9%. Revenue growth without profit.
- OPM trend 11% (FY17–18) → 10% → 9% → 4.6%; ROCE 8–9%, ROE 6–8% for a decade — below cost of capital.
- Debt Rs 728 cr, net debt ~Rs 710 cr, D/E 0.93, interest cover ~1.9x (EBIT basis), current ratio 0.84; CRISIL flags "moderate cushion" between accruals and repayments and expects promoter unsecured loans if needed.
- Cash conversion looks fine on paper (CFO FY22–26 Rs 1,142 cr vs PAT Rs 187 cr) but investing outflow was Rs 943 cr, so 5-yr FCF is only ~Rs 200 cr and debt has not fallen. Working capital negative (-25 days) because payables are stretched to 111 days.
- Customer concentration: Hero MotoCorp ~28–30% of revenue (2023 disclosure), top 3–5 OEMs an estimated 60–70%; exports ~15%, hit by 9-week ocean transit and freight in Q1 FY27. No pricing power (raw-material pass-through lags a quarter; still converting 25% of customers to monthly settlement).

## Gate 4 — Valuation: FAIL

- P/E 40–47x TTM (28x even on FY26 peak EPS Rs 3.73), P/B 1.7, EV/EBITDA 10, EV/Sales 0.8. Auto-ancillary peers (Talbros 19x, Precision Camshafts 22x, Menon Pistons 11x, Federal-Mogul 14x) median ~17x. Tijori: trading at a premium to its own 3-yr history.
- Not cheap for a 9% ROCE business with 2% three-year sales CAGR; market is already paying for the Hosur/EV/railways/defence story.
- 3-yr case: bull — Rs 3,500 cr revenue at 10% EBITDA, PAT ~Rs 110 cr, EPS ~Rs 8 at 15x = Rs 120 (+13%); bear — margins stuck at 7%, PAT ~Rs 30 cr, 20x = Rs 45 (-57%). Asymmetric to the downside.

## Verdict: REJECT

1. A decade of ROE 6–8% and ROCE 8–9% with Rs 728 cr debt and ~1.9x interest cover; latest quarter is a loss despite +39% sales — no credible margin turnaround yet, only promises.
2. Management has missed revenue, margin, defence and plant-timing guidance repeatedly since 2018 and once withheld a material customer dispute; promoter pay was ~46% of FY25 PAT and five Kapurs sit on the board.
3. At 40x+ trailing earnings and ~17x peer median, the price already discounts a recovery; downside is 2–4x the upside.

## Sources

- https://www.screener.in/company/RICOAUTO/consolidated/
- https://nsearchives.nseindia.com/corporate/RICOAUTO_19082026123257_Earnings_call_Transcript.pdf
- https://nsearchives.nseindia.com/corporate/RICOAUTO_22082023151634_ConCallTranscript.pdf
- https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/RicoAutoIndustriesLimited_December%2002_%202025_RR_384710.html
- https://www.multibagg.ai/market-pulse/articles/rico-fy26-95557
- https://www.multibagg.ai/market-pulse/articles/rico-auto-q1fy27-loss-cmsr96vrh01zz0zntutcta50e
- https://stockanalysis.com/quote/nse/RICOAUTO/statistics/
- https://www.tijorifinance.com/company/rico-auto-industries-limited/
- https://choiceindia.com/stocks/rico-auto-industries-ltd-board-of-directors
- https://scanx.trade/stock-market-news/companies/rico-auto-industries-confirms-no-encumbrance-of-promoter-shares-in-fy26/41473169
- https://simplywall.st/stocks/in/automobiles/nse-ricoauto/rico-auto-industries-shares/management
- https://www.icicidirect.com/mailimages/IDirect_RicoAuto_MgmtNote_Jan23.pdf
- https://autocarpro.in/news-national/rico-auto-targets-rs-2-000-crore-turnover-in-fy2020-lines-up-rs-167-crore-capex-43279
- https://autocarpro.in/news-national/rico-auto-sells-percent-stake-japanese-partner-rs-495-crore-6382
- https://www.autocarpro.in/news-national/continental-buys-rico-auto-hydraulics-jv-2285
- https://ca.marketscreener.com/quote/stock/RICO-AUTO-INDUSTRIES-LIMI-6496620/news/Rico-Auto-Industries-Limited-Announces-Management-Changes-Effective-1st-April-2024-46310724
