# HPL Electric & Power (NSE: HPL) — Due Diligence, 2 Nov 2026

**Price ₹242 | Mcap ₹1,557 cr | 52-wk ₹224–481 | P/E 16.3x | P/B 1.55x | Div yield 0.4%**
Latest results: Q1 FY27 (Jun-26). Q2 FY27 board meeting is 5 Nov 2026 — not yet released.

## Verdict: REJECT (G1 WATCH / G2 FAIL / G3 WATCH / G4 WATCH)

1. Balance sheet cannot absorb a margin squeeze: gross debt ~₹900 cr vs mcap ₹1,557 cr, net leverage 3.1x (India Ratings, Oct-26), interest coverage 3.0x, finance cost ₹94 cr ≈ FY26 PAT ₹91 cr; FCF negative in FY26 and FY27 capex (₹100–120 cr MV/HV cables, debt-funded) appeared after management said FY27 capex would be "mainly maintenance".
2. Guidance credibility: Feb-26 call said FY27 margins should return to 16–17% and 25% growth is "achievable"; Q1 FY27 delivered +35% revenue but EBITDA margin 12.3% (vs 15.1%), gross margin ~38% → ~30%, metering margins "halved", PAT +1%. Smart-meter tenders are open-priced with realisations trending down.
3. Governance is family-run with no counterweight: Chairman, MD and Joint-MD-cum-CFO are all Seths (CFO is a promoter), auditor is a small Delhi firm (Sakshi & Associates, fee ₹31 lakh), promoter 72.66% unchanged for a decade, institutions hold <1%, and management declines to disclose new orders on exchanges "for confidentiality". Receivables include ₹29 cr aged >3 years with only ₹8.4 cr provided (standalone).

## Gate 1 — Governance: WATCH (borderline)
- Promoter 72.66%, flat since 2017; one promoter entity pledged ~2.42% (raised by analyst on Jun-26 call; management "expects it to fall"). Promoter group entities: HPL India Ltd, HPL Power Corp, HPL Electronics, Jesons Impex, Amerex, HPL Holdings, Seth Inder Narain Trust.
- Family KMP: Lalit Seth (Chairman & WTD), Rishi Seth (MD), Gautam Seth (Joint MD & **CFO**). Three related executives, no independent CFO — nepotism risk structural. FY26 remuneration: Lalit ₹3.74 cr, Rishi ₹1.56 cr, Gautam ₹1.56 cr = ₹6.86 cr ≈ 7.5% of PAT. CS Vivek Kumar is professional.
- Independent directors: Rashmi Vij, Dhruv Goyal, Ajit Sood (joined Apr-25 replacing Hargovind Sachdev after full second term). No early resignations. Board 7, 3 independent (43%) with executive promoter chairman — LODR requires 50% independent when chairman is an executive promoter; verify compliance.
- RPTs: sales ₹114.6 cr and asset purchases ₹86.4 cr with Himachal Energy (97% sub, now 100% after 29 Oct 2026 buyback — eliminates on consolidation). Services from HPL India Ltd ₹3.6 cr; ₹21 cr preference shares held by Seth family redeemed in FY26. Small vs ₹1,858 cr sales; BRSR: RP purchases 3.6%, sales 6.2%.
- Auditor: Sakshi & Associates (unmodified; KAM "significant tax litigations"). Contingent liabilities ~₹4.7 cr. No SEBI/exchange penalties in 3 years; no investor complaints.
- Shareholder base: FII 0.5%, DII 0.1%, public 26.7% — no institutional scrutiny; shareholder count falling (1.48 lakh → 1.19 lakh).

## Gate 2 — Guidance & delivery: FAIL
- FY26: analyst noted ~₹500 cr Q4 commitment was met (Q4 ₹520 cr); FY26 revenue ₹1,811 cr (+6.5%), OPM 16% — fine.
- FY27: Feb-26 "25% growth achievable", C&I ~₹1,000 cr, margins to 16–17%. Jun-26: debt to "stay at current levels", capex "mainly maintenance". Aug-26: Q1 margin 12.3%, metering EBIT margin 14.2% (17.7%), C&I EBIT 8.4% (11.3%); no numeric FY27 guidance; blamed West-Asia-conflict raw-material inflation; "hope" to recover by Q3. Oct-26 India Ratings: FY27 capex ₹100–120 cr debt-funded for cable expansion.
- Order book ₹3,200 cr (96–97% metering), "1.5–2 years" execution — flat since Feb-26 (₹3,177 cr), i.e. no net new wins disclosed. India Ratings' own report is inconsistent on smart-meter share (97% vs ₹360 cr).
- Pattern: vague qualitative outlook, margin targets missed, capex scope creep.

## Gate 3 — Fundamentals: WATCH
- Sales CAGR: 10-yr 5%, 5-yr 16%, 3-yr 13%. Profit CAGR 5-yr 57% / 3-yr 47% off a ₹8 cr FY22 base; TTM PAT ₹91 cr, flat YoY. Q1 FY27: sales +35%, PAT +1%; Q4 FY26: sales +5.5%, PAT −16%.
- OPM: 13% (FY24) → 15% (FY25) → 16% (FY26) → 12% (Q1 FY27). Mix shifting to low-margin wires & cables (+79%).
- ROCE 13.5%, ROE 10% (3-yr 9%). D/E ~0.75x (borrowings ₹755 cr on screener; India Ratings gross debt ₹900 cr incl. acceptances). Interest coverage 3.0x. Fund-based limit utilisation 82–86%.
- Working capital: debtor days 154 (Ind-Ra: 180–200), inventory 236, WC days 75, GCA ~320 days. Receivables >6 months ₹67.5 cr incl. ₹29 cr >3 years; ECL ₹8.4–13.9 cr.
- Cash conversion: CFO FY22–26 ₹669 cr vs PAT ₹267 cr (250% — depreciation and interest heavy); FCF FY22–26 ~₹198 cr cumulative but FY26 −₹48 cr per Ind-Ra. Capex FY26 ₹220 cr.
- Moat: ~20% domestic meter share, 11m meters/yr capacity, 900 dealers / 85,000 retailers. But smart-meter tenders are L1 open-priced, AMISPs squeeze OEMs, and Genus, Polycab, Havells and Chinese-sourced competitors have deeper pockets. Water meter (Neeram) is pre-revenue.

## Gate 4 — Valuation: WATCH
- P/E 16.3x TTM; P/B 1.55x; EV/EBITDA ~8.4x (EV ~₹2,430 cr / TTM EBITDA ~₹290 cr). 5-yr median P/E roughly 20–25x (stock ran 27% CAGR on 57% profit CAGR). Peers: Genus Power trades at >2x this multiple; screener electrical-equipment median P/E 32x.
- Optically cheap, but leverage-adjusted it is not: EV is 1.6x mcap. Cheap because margins are compressing in a price-war segment, not a clean cyclical trough.
- 3-yr cases: Bear — margin stays 12%, PAT ₹70 cr, 12x = ₹130 (−45%). Base — PAT ₹130 cr, 15x = ₹300 (+25%). Bull — margins recover to 16%, smart-meter phase-2 awards, PAT ₹200 cr, 20x = ₹620 (+155%). Skew is not attractive enough given G1/G2.

## What would change the view
Q2 FY27 (5 Nov) EBITDA margin back above 15% with debtor days <140; net debt/EBITDA <2x; a professional CFO; a Big-6 auditor; order wins disclosed on exchanges.

## Sources
- https://www.screener.in/company/HPL/consolidated/
- FY26 annual report: https://www.bseindia.com/xml-data/corpfiling/AttachHis/2b6033c7-f91a-4010-a499-26315697ba8a.pdf
- Q1 FY27 transcript (Aug-26): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c7849cdd-26a9-4a3b-9d49-51c0d3c96b8c.pdf
- Q1 FY27 presentation: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=eb1c54ee-8cbd-4b26-9c13-c5bf90103271.pdf
- Q4 FY26 transcript (Jun-26): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=874d7e38-4651-4449-a72c-caf9082a5ba2.pdf
- Q3 FY26 transcript (Feb-26): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dd7938ad-5890-45de-ae73-a304f5cf1ba3.pdf
- India Ratings affirmation 26 Oct 2026: https://www.indiaratings.co.in/pressrelease/83944
- CRISIL upgrade 9 Apr 2026: https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/HPLElectricandPowerLimited_April%2009_%202026_RR_393099.html
