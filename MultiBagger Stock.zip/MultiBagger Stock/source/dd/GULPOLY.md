# Gulshan Polyols Ltd (NSE: GULPOLY) — Due Diligence, 2 Nov 2026

**Business:** Grain-based ethanol (810 KLPD: Chhindwara MP 500 + MP-1 60 + Goalpara Assam 250; ~26 cr litres/yr) = 70% of FY26 revenue and ~85% of segment EBIT; grain processing (starch, sorbitol; 1.92 lakh MTPA) 26%; precipitated/ground calcium carbonate (~98,000 MTPA) 4%. Mcap Rs 918 cr at Rs 147 (52-wk 228/122; -24% in 6 months). FY26 revenue Rs 2,312 cr, PAT Rs 107 cr.

Note: screener's consolidated tab is stale (ends Sep-2025); standalone tab and BSE filings carry FY26 and Q1 FY27 and are used here. **Q2 FY27 (Sep-2026) results are not yet released** (due by 14 Nov 2026).

**VERDICT: HOLD-FOR-REVIEW — re-check after Q2 FY27 results and ESY 2026-27 allocation; needs an answer on the 2024 auditor resignation before any SELECT.**

## Gate 1 — Governance: WATCH
- **Promoter holding rising** 64.86% (FY22) → 66.80% (Sep 2026); **pledge 0.00%** every quarter Sep-2025 to Sep-2026 (Finology). Promoter director gives personal guarantee on term loans (routine).
- **Family KMP: three daughters of CMD Dr Chandra Kumar Jain on the board** — Arushi Jain and Aditi Pasari (Joint MDs), Anubha Gupta (non-exec, non-independent). CEO Ashwani Kumar Vats (WTD) and CFO Rajiv Gupta are non-family; Aditi Pasari fronts concalls competently. Rent of Rs 1.08 cr/yr paid to CMD and Rs 9.6 lakh to his wife Mridula Jain.
- **Promoter pay jump:** JMD remuneration rose from Rs 104 lakh each (FY24/FY25) to Rs 254 lakh each in FY26 (Rs 1.5 cr commission each); managerial pay +48% vs 12% for other staff. Family pay Rs 8.1 cr = 7.6% of FY26 PAT (was 20% of FY25's Rs 25 cr PAT). Acceptable in a turnaround year, but watch.
- **Auditor red flag:** Rajeev Singal & Co. (appointed Sep 2022 for five years) **resigned on 13 Aug 2024, two years into its term, no reason disclosed**; replaced via casual vacancy by Shahid & Associates, Muzaffarnagar (a small local firm for a Rs 2,300 cr company). Reports since are unqualified, no KAMs, no fraud reported.
- **Company Secretary churn:** Tyagi (Jan 2024-Feb 2025) → Singhal (May 2025-Apr 2026) → Pant (May 2026). Three CS in 2.5 years.
- Independent directors: five, with orderly rotations (two ceased Mar 2024, one Sep 2024, one added Oct 2025); no abrupt resignations found. Exchange fine Rs 11,800 (FY24, one-day delay) only. Disputed GST Rs 3.95 cr; no SEBI action found. Related-party loans nil; UAE subsidiary wound down.
- Accounting: interest-subvention recognition switched to cash basis after a reversal (Q3 FY26); PLI (~Rs 30 cr/yr) and state subsidies are inside reported margins — earnings quality is partly policy-dependent.

## Gate 2 — Guidance & Delivery: WATCH
- **FY24-FY25 (capex ramp):** OPM collapsed 14% → 4%, PAT Rs 85 cr → 18 cr; maize at Rs 26-27/kg and starch dumping blamed. Rs 500 cr distillery capex funded by debt (borrowings Rs 117 cr → 392 cr) while FCF was negative four straight years.
- **FY26 guidance (Feb/May 2025):** ethanol 20-22 cr litres, ~Rs 1,500 cr ethanol revenue, EBIT margin 8-10% → **delivered** Rs 1,609 cr ethanol revenue, 10% OPM, PAT Rs 107 cr. Volume target missed (order book 18 cr L vs 23 applied), revenue/margin met.
- **FY27 guidance (May 2026, reiterated Aug 2026):** revenue Rs 2,600-2,800 cr, EBITDA 10-12%, PAT 5-6%, ethanol 21-22 cr L (order book 19 cr L). Q1 FY27: revenue Rs 646 cr (+8%), EBITDA 14.2%, PAT Rs 54 cr — ahead of guide; management itself called Q1 "exceptional" and warned Q2 is seasonally weak.
- **Inconsistency to probe:** concalls say "no major capex until FY28", but CRISIL (Jul 2026) cites Rs 200-220 cr debt-funded capex over the next two years; a ~Rs 500 cr Narsinghpur project with "fundraising under evaluation" (dilution risk) is pencilled for FY28-29.

## Gate 3 — Fundamentals: WATCH (improving sharply)
- CAGR: sales 10-yr 18%, 5-yr 25%, 3-yr 25%; PAT 5-yr 12%, 3-yr 36%. TTM PAT ~Rs 149 cr (Sep-25 16 + Dec-25 41 + Mar-26 38 + Jun-26 54) vs Rs 25 cr in FY25.
- Last two reported quarters: Mar-26 sales +7% / PAT Rs 38 cr vs 7 cr; Jun-26 sales +8% / PAT Rs 54 cr vs 13 cr. OPM 12-14% in last three quarters vs 4-6% a year earlier.
- ROCE 19% (FY26) vs 3% (FY24); ROE 17%. D/E 0.43 (0.64 FY25); interest coverage 5.6x; borrowings Rs 392 cr → 318 cr; bank limits <80% used; CRISIL A outlook Negative → Stable (Jul 2026).
- **Cash conversion fixed in FY26:** CFO Rs 207 cr vs PAT 107 cr; FY21-26 CFO Rs 498 cr vs PAT ~Rs 380 cr. WC days 57 → 11, CCC 80 → 48.
- **Structural exposures:** ethanol price is set by government; maize ~50% / FCI rice ~40% of feedstock; management says breakeven maize ~Rs 24/kg (Q1 cost Rs 23-25). **ESY 2026-27 tender (16 Oct 2026): ~11 bn litres, sugar-based ethanol excluded (positive for grain volumes) but maize-ethanol price cut Rs 71.86 → 68.86/L** (incentive 5.79 → 2.79). On ~10 cr maize litres that is ~Rs 30 cr off EBITDA (~12% of FY27E) unless maize softens. This, plus E20 backlash and Q2 seasonality, explains the 6-month drawdown. Grain-processing segment loss-making (EBIT -Rs 4 cr FY26). No moat beyond location/PLI; CRISIL flags fragmented industry with overcapacity.

## Gate 4 — Valuation: PASS (cheap, partly for a reason)
- P/E ~6.2x TTM (screener consolidated 21.5x is stale), P/B 1.2x, EV/EBITDA ~4.2x; yield 1%. Own history: traded 15-25x in FY22-FY24 on depressed/peak earnings; current multiple is near a 5-yr low (estimate). Peers: TruAlt Bioenergy 13.9x, Gujarat Ambuja Exports 12.9x, sector median 13.5x.
- Discount reflects regulated single-product earnings and the auditor question, not a structural decline — volumes, cash flow and leverage are all moving the right way.
- 3-yr cases (FY29): Bear — price cuts/maize spike, PAT Rs 50 cr x 10x = Rs 500 cr (-45%). Base — ethanol margin normalises to 11%, grain 5%, PAT Rs 150 cr x 9x = Rs 1,350 cr (+47%). Bull — E27/E30 plus new capex at 15% margin, PAT Rs 220 cr x 12x = Rs 2,640 cr (2.9x), diluted if equity is raised.

## Top 3 reasons
1. **Genuine, cash-backed turnaround at 6x earnings:** FY26 PAT 4x, CFO Rs 207 cr, debt down, ROCE 19%, 0% pledge, promoters buying.
2. **Governance not clean enough to SELECT yet:** mid-term auditor resignation (Aug 2024) with no stated reason and a small successor firm, three daughters on the board, 144% JMD pay rise, CS churn.
3. **Earnings are policy-set:** Oct-2026 Rs 3/L maize-ethanol price cut and E20 politics make FY27 margin guidance (10-12%) the key test — wait for Q2 FY27 and the ESY-27 allocation (target >=20 cr litres) before committing.

## Sources
- https://www.screener.in/company/GULPOLY/ (standalone, current) and https://www.screener.in/company/GULPOLY/consolidated/ (stale)
- Q1 FY27 concall transcript (Aug 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d7221fa2-9fba-400c-94ec-b427866da390.pdf ; PPT: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3ce219bf-59b8-4796-a60e-d7bab5c6d2c2.pdf
- Q4 FY26 transcript (May 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1775beb2-2867-4e41-a23d-179c8e37b71d.pdf
- Q3 FY26 transcript (Feb 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c5acc2be-ea9d-40a3-826b-67a697ef7bee.pdf
- Q4 FY25 transcript (May 2025): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b39158d6-5ffe-453e-b85d-23e0457f3658.pdf ; Nuvama call (Feb 2025): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=09da81cc-1a91-4ead-9f23-7172112b0e01.pdf
- Annual Report FY2025-26: https://www.bseindia.com/xml-data/corpfiling/AttachHis/6c239e7f-c703-424c-b64a-c8c310904a22.pdf ; FY2024-25: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c9c093c4-2be3-4004-9cc4-2fe0b100088b.pdf ; FY2023-24: https://www.bseindia.com/xml-data/corpfiling/AttachHis/47aabe41-6161-4782-a960-814d52ad531b.pdf
- CRISIL rationale 23 Jul 2026: https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/GulshanPolyolsLimited_July%2023_%202026_RR_393385.html
- Ethanol tender ESY 2026-27 (Business Standard, 18 Oct 2026): https://www.business-standard.com/industry/news/omcs-bar-sugar-based-ethanol-in-2026-27-tender-cuts-maize-incentive-126101800305_1.html ; https://www.business-standard.com/topic/ethanol
- https://ticker.finology.in/company/GULPOLY ; https://www.bseindia.com/stock-share-price/gulshan-polyols-ltd/gulpoly/532457/

## Primary-source verification (2 Nov 2026)

**Correction to Gate 1:** the auditor resignation was NOT "with no reason disclosed". The Reg 30 filing (GPL\SEC\34\2024-25, dated 13 Aug 2024, signed 14 Aug 2024) with the resignation letter and SEBI Annexure A is on the company website; the BSE API/PDF mirrors blocked automated access, so the company-hosted copy is the source used.

**Stated reason, verbatim (Rajeev Singal & Co. letter, 13 Aug 2024, CA Sunil Kumar, M.No. 408730):**
> "We had completed our Statutory Audit for the financial year ended on March 31, 2024 and issued our audit reports on May 21, 2024. In view of the above and as discussed and agreed with the management, we express to discontinue as the Statutory Auditors of the Company due to our personal reasons. Further, we have issued our Limited Review Report for quarter ended June 30, 2024 in compliance with Para 6(A)(i) of SEBI circular No. CIR/CFD/CMD1/114/2019 dated October 18, 2019. In view of the above and as discussed and agreed with the management and in order to enable the Company to make the desired changes, we tender our resignation as the Statutory Auditors of the Company. Our resignation does not result from an inability to obtain sufficient appropriate audit evidence. There are no other circumstances connected with our resignation which we consider should be brought to the notice of the Board. ... It is clarified that our firm neither have any sort of dispute nor have any concern relating to suppression of information by the management of the Company for the purpose of carrying out audit procedures."

- Company's Reg 30 table, item 4: "Resignation as Statutory Auditor vide Letter dated 13th August, 2024 due to personal reasons".
- Annexure A: item 4 (detailed reasons) and 5 (concerns/efforts) both "Refer attached resignation letter"; item 6 (information not provided) "Not Applicable"; item 7 (other facts) "None"; declaration "no other material reason". Last report before resigning: Q1 FY25 limited review (satisfies the circular's 6(A)(i) condition).
- Audit Committee view (same filing): "there were no such concerns raised/reported by the Statutory Auditors with respect to its resignation and the grounds stated by the statutory auditors for resignation were convincing." Board: "no other reasons other than mentioned in the resignation letter."
- Successor: Shahid & Associates (FRN 002140C), est. 1983, CA Mohammad Shahid, Muzaffarnagar; casual vacancy from 13 Aug 2024, then 5-year term approved at 24th AGM, 20 Sep 2024 (to 29th AGM, 2029). FY25 Board's Report (p. "19. Auditors") repeats this and confirms a valid peer-review certificate. Both outgoing and incoming firms are small Muzaffarnagar practices (the registered office is in Muzaffarnagar).

**Classification: benign on the record, with one soft caveat.** No disagreement, no unresolved audit matters, no non-cooperation, no scope limitation; the FY24 audit opinion (21 May 2024) was unmodified. The caveat is the phrasing "as discussed and agreed with the management and in order to enable the Company to make the desired changes" — i.e. a management-driven auditor switch labelled "personal reasons", not an auditor walking away. That is a mild governance smell (an auditor was changed mid-term to another small local firm with no stated rationale from the company) but not an audit-quality red flag.

**Audit reports by Shahid & Associates:**
- FY25 (AR 2024-25): standalone and consolidated opinions unmodified ("true and fair view"), "no key audit matters to communicate", IFC opinion unmodified. CARO 2020: no loan defaults (ix), no material fraud and no whistle-blower complaints (xi), no cash losses (xvii), clause xviii only states "There has been resignation of the previous statutory auditors M/s Rajeev Singal & Co" (terse — does not add the usual "we have taken into consideration the issues, objections or concerns raised by the outgoing auditors"), xxi "no Qualification or Adverse remarks" in subsidiaries' CARO. Corporate governance report: "no qualification or modified opinion".
- FY26 (AR 2025-26): opinion unmodified, no KAMs, IFC unmodified; CARO: no defaults, not a wilful defaulter, no material fraud, no whistle-blower complaints, "no resignation of the statutory auditor during the year". No CARO qualifications in either year.

**Q2 FY27 (Sep 2026 quarter):** NOT filed as of 2 Nov 2026. Company website financial-results page lists only Q1 FY27; IIFL/BSE board-meeting list (page dated 2 Nov 2026) shows the last meeting as 6 Aug 2026 (Q1), with no intimation yet for the Sep-2026 quarter. Prior pattern: Q2 FY26 results 6 Nov 2025 (notice 31 Oct), Q2 FY25 results 13 Nov 2024. Expect notice any day; deadline 14 Nov 2026. PAT / EBITDA margin / debt for Q2 FY27 therefore not available; latest remain Q1 FY27 (revenue Rs 640 cr, OPM 13%, PAT Rs 54 cr; borrowings Rs 318 cr at Mar-26).

**Shareholding pattern, quarter ended 30 Sep 2026 (company filing):** promoter & promoter group 66.80% (4,16,63,867 of 6,23,70,586 shares); pledged / NDU / other encumbrance: 0 shares, 0% — declaration "Whether any shares held by promoters are encumbered under 'Pledged'?" answered "No". Public 32.9%. Confirms the note's 0% pledge.

**Verdict line:** GULPOLY: stays HOLD — the auditor-resignation question is resolved as benign (personal reasons, no disputes, no scope limitation, unmodified FY24-FY26 opinions, clean CARO, 0% pledge), so the governance blocker to SELECT is lifted, but the note's other preconditions (Q2 FY27 results and ESY 2026-27 allocation after the Rs 3/L maize-ethanol price cut) are still pending; re-assess for SELECT once Q2 FY27 is filed (expected 6-14 Nov 2026).

Sources:
- Resignation filing + letter + Annexure A: https://www.gulshanindia.com/pdf/2024-25/Resignation-of-Statutory-Auditor-of-the-Company.pdf
- FY25 Annual Report (Board's Report sec. 19, auditor's report, CARO): https://www.bseindia.com/xml-data/corpfiling/AttachHis/c9c093c4-2be3-4004-9cc4-2fe0b100088b.pdf (mirror: https://www.gulshanindia.com/pdf/2025-26/Annual-Report-FY-2024-25-agm25.pdf)
- FY26 Annual Report: https://www.bseindia.com/xml-data/corpfiling/AttachHis/6c239e7f-c703-424c-b64a-c8c310904a22.pdf
- Shareholding pattern Sep 2026: https://www.gulshanindia.com/pdf/2026-27/SEP-Q2-FY-2026-27.html ; index https://www.gulshanindia.com/shareholding-pattern.html
- Financial results index: https://www.gulshanindia.com/financial-results.html ; board meetings: https://www.indiainfoline.com/company/gulshan-polyols-ltd/corporate-action/board-meeting
- BSE announcement API (api.bseindia.com AnnSubCategoryGetData, scrip 532457, 10-25 Aug 2024) returned 403 to non-browser clients; not independently re-fetched.
