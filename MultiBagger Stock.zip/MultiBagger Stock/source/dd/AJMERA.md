# Ajmera Realty & Infra India (NSE: AJMERA) — Due Diligence, 2 Nov 2026

Price Rs 132 | Mcap Rs 2,604 cr | 52w 98–221 (−38% 1Y) | Promoter 68.56% | CRISIL A-/Stable

**VERDICT: REJECT (watchlist; re-review after Q3 FY27 call)** — G1 WATCH / G2 WATCH→FAIL / G3 WATCH / G4 WATCH

## Gate 1 — Governance: WATCH
- **Holding/pledge:** 74.2% → 68.23% (Nov-2024 QIP, Rs 225 cr) → 68.56% (open-market buy of 6.41 lakh shares, Jun-2026 at ~Rs 110). Pledge cut from 7.41% (Jun-24) to 0.02%. Positive.
- **Family control:** All 3 executive directors are Ajmeras (Rajnikant S., Manoj I., Sanjay C. — cousins; report says "not related inter se" under s.2(77), legally true but a family board). Four more Ajmeras (Bandish, Dhaval, Ashwin, Nimish) run strategy/affairs/BD/projects as non-board "Directors". **Nepotism flag:** Dhaval Ajmera (CMD's son) appointed Director–Corporate Affairs from 1 Oct 2026 at Rs 2.0–2.5 cr p.a. — more than the CMD's FY26 pay (Rs 2.39 cr). Promoter pay total ~Rs 4.5 cr = 2.9% of PAT; ~4.5% after Dhaval.
- **RPTs:** Standalone loans outstanding to group entities ~Rs 601 cr (Ajmera Estate Karnataka 171, Jolly Brothers 146, Ajmera Mayfair Global Bahrain 53 — legacy stuck asset, Ultratech Property 47, Laudable 41, Ajmera Luxe 37, VM Procon 19); corporate guarantees Rs 445 cr incl. Rs 125 cr to Ajmera Bora Associates (67% via Laudable LLP). Most are consolidated subs/JVs, so leakage to promoter-private entities is small (rent to Pramukh Development Rs 1.14 cr, up 2.6x; relatives' pay Rs 0.32 cr). FY25 BRSR: 42% of investments and 41% of loans are to related parties. Opaque LLP/partnership web; MahaRERA/litigation search found nothing material (only Rs 0.8 cr tax dispute).
- **Auditor/regulatory:** V. Parekh & Associates (small firm, since FY23), unmodified, one KAM (Ind AS 115). BSE/NSE penalty Rs 62k each for late CS appointment; CHG-1 filing delay. No ID resignations; 3 IDs, 50% board. Minor.

## Gate 2 — Guidance vs delivery: WATCH (FAIL if FY27 guidance not cut)
| FY | Pre-sales guide | Actual | Debt/eq guide vs actual |
|---|---|---|---|
| FY25 | Rs 1,350 cr | Rs 1,080 cr (80%, miss) | — |
| FY26 | Rs 1,600 cr | Rs 1,701 cr (beat) | 0.85x vs 0.53x |
| FY27 | Rs 2,200 cr; BD adds Rs 1,800 cr; D/E to 1.0x | H1: Rs 370 cr (17%); Q2 Rs 224 cr, −69% YoY; H1 collections Rs 363 cr, −20% | D/E 0.47x Jun-26 |

Slippage in Q1 FY27 call: Pune launch Q1→Q4, Borivali Q3→Q4, Bengaluru SV Concrete dropped (replaced by Whitefield Rs 389 cr BD vs Rs 1,800 cr guide), Vann Versova 3% sold with "subdued sales this year", 33Fifteen Bandra 19% sold, asset monetisation Rs 89 cr of Rs 330 cr. Pipeline cited as Rs 3,000 cr (Dhaval) and Rs 6,500 cr (CFO) in the same call — unreconciled. FY27 now hinges on one Q3 launch: Wadala Boutique Office Phase 1, Rs 3,600 cr GDV (doubled from Rs 1,800 cr), 8–8.5 lakh sq ft of office — a big, untested product for them. Guidance has not been cut despite H1 at 17%. Q2 FY27 financials/concall not yet out (expected mid-Nov).

## Gate 3 — Fundamentals: WATCH
- Sales CAGR 5y 26% / 3y 36%; PAT CAGR 5y 38%. FY26 sales Rs 1,090 cr (+46%), PAT 157 cr (+24%). TTM sales 1,149 / PAT 163 cr.
- Q4 FY26: sales 431 cr (+185% YoY), PAT 59 (+141%); Q1 FY27: 317 cr (+23%), PAT 45 (+14%). Recognition lumpy (Solis OC/milestone).
- OPM 31% → 27% → 29% (Q1); PAT margin 17% → 14%. ROCE 14.3%, ROE 11.5% (3y 12%) — mediocre for 36% growth.
- Debt Rs 737 cr → 680 cr (Jun-26), D/E 0.47x, cost of debt 12.2% → 11.0%, interest cover 4.2x (CRISIL). But guided to 1.0x D/E and CRISIL sees Rs 1,465 cr incremental project debt. Finance cost spiked to Rs 30 cr in Q1 from high-cost PE-linked project debt.
- Cash: FY22–26 CFO sum Rs 368 cr vs PAT Rs 505 cr (73%); company's own FY26 net OCF −Rs 30 cr. Debtor days 142. Dilutive QIP.
- Visibility: committed sales Rs 1,661 cr + unsold Rs 2,185 cr; Wadala land bank GDV ~Rs 18,600 cr (post-FSI) and Kanjurmarg 55 acres (FY28) are the real option value — but monetisation depends on approvals and funding partners.

## Gate 4 — Valuation: WATCH (cheap for a reason)
P/E 16.9, P/B 1.86, EV/EBITDA ~10x (EV ~Rs 3,230 cr). Peers: Sunteck P/E 18.8 / P/B 1.1 / ROCE 7.5%; Keystone 36x / ROCE 4.7%; Arkade 12.7x (TTM loss) / ROCE 19%; sector median 23x. 5y price CAGR 16% vs PAT CAGR 38% — de-rated as pre-sales rolled over. Looks cheap on trailing earnings, but FY26-27 revenue reflects FY24-25 sales; H1 FY27 pre-sales at Rs 370 cr implies FY28-29 earnings air pocket unless the Wadala office sells.
- Bull (3y): Wadala office launch sells, pre-sales ~Rs 2,000 cr/yr, PAT Rs 250 cr, 18x → Rs 4,500 cr (+70%).
- Bear: launches slip, PAT ~Rs 150 cr, D/E 1x, 12x → Rs 1,800 cr (−30%).
- Base: ~+15–25%. Not multibagger asymmetry.

## Why REJECT
1. Delivery risk: H1 FY27 pre-sales 17% of unrevised Rs 2,200 cr guidance, Q2 −69% YoY, three launches slipped; FY25 also missed by 20%. Everything rides on one Q3 office launch.
2. Family-run with a nepotism signal (son at Rs 2–2.5 cr ≥ CMD pay, 7 Ajmeras in management) and Rs 600 cr loans / Rs 445 cr guarantees across an opaque LLP/partnership web.
3. Mediocre ROE (11–12%), lumpy recognition, CFO < PAT, leverage guided to double — valuation is fair, not cheap, for this quality.

**Re-rate trigger:** Q3 FY27 call (Feb-2027) with honest guidance cut, Wadala office launched with >30% sold, D/E held <0.7x.

## Sources
- https://www.screener.in/company/AJMERA/consolidated/
- https://www.screener.in/company/SUNTECK/consolidated/ ; /RUSTOMJEE/ ; /ARKADE/
- https://trendlyne.com/equity/share-holding/50/AJMERA/latest/ajmera-realty-infra-india-ltd/
- https://ajmera.com/wp-content/uploads/2026/08/39th-Annual-Report.pdf
- https://alphastreet.com/india/ajmera-realty-infra-india-limited-ajmera-q1-2027-earnings-call-transcript/
- https://www.multibagg.ai/market-pulse/articles/ajmera-fy26-94858
- https://www.freepressjournal.in/amp/business/ajmera-realty-reports-h1fy27-sales-value-of-370-crore-collections-of-363-crore
- https://www.equitybulls.com/category.php?id=376692
- https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AjmeraRealtyAndInfraIndiaLimited_August%2004_%202026_RR_401606.html
- https://www.arthneeti.com/stocks/ajmera-realty/concall/q1-fy25-earnings-call-analysis
- https://www.newsdrum.in/business/ajmera-realty-q4-sale-bookings-down-13-pc-to-rs-250-cr-fy25-sales-at-rs-1080-cr-8950962
- https://scanx.trade/stock-market-news/corporate-actions/ajmera-realty-approves-rs-125-crore-corporate-guarantee-for-associate-firm/32875122
- https://www.whalesbook.com/corporate-news/English/real-estate/Ajmera-Realty-Promoters-Boost-Stake-by-033percent-via-Open-Market-Purchase/6a2294d3c75ed156cfa1759c
- https://ajmera.com/wp-content/uploads/2025/07/Business-Responsibility-Sustainability-Report.pdf
- https://www.freepressjournal.in/business/ajmera-realty-infra-india-reports-4498-crore-consolidated-profit-for-q1-fy27-up-14-yoy
