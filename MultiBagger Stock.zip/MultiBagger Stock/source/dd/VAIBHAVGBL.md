# Vaibhav Global (NSE: VAIBHAVGBL) — Due Diligence, 2 Nov 2026

**Price ₹156 | Mcap ₹2,616 cr | 52-wk ₹155–284 | P/E 9.4x | P/B 1.6x | Div yield 3.8%**
Latest results: Q2 FY27 (Sep-26) released 29 Oct 2026.

## Verdict: HOLD-FOR-REVIEW (G1 WATCH / G2 WATCH / G3 WATCH / G4 PASS)

1. Second FY27 guidance cut in a row of soft years: revenue growth 9–11% → 7–9%, margin expansion (+50–100 bps) → "flat vs FY26", caused by a self-inflicted Shopify re-platforming that cost ~$2.8m revenue and ~100 bps margin in Q2.
2. Underlying growth is weak: Q1 FY27 was flat in constant currency (reported +12.7% only via INR depreciation and a ₹25.6 cr US tariff refund booked in revenue); Q2 PAT fell 12% YoY. TTM EPS ₹16.7 is flattered by the refund and a negative tax quarter (Mar-26, tax rate -43%).
3. But: net cash ₹186 cr, 5-yr CFO/PAT ~109%, 3.8% yield, A+/A1+ ratings, and a 9x P/E vs ~30x+ historically. Cheap enough to re-review after Q3 FY27 (holiday quarter) proves the digital channel has recovered.

## Gate 1 — Governance: WATCH
- Promoter holding 57.2% (Sep-26) vs 57.3% (Mar-25): stable; no pledge disclosed in ICRA/CARE rationales or filings.
- Family on board: Sunil Agrawal (MD) is the only promoter executive. Mother Sheela Agarwal ceased as director 5 Aug 2025; Sanjeev Agrawal (non-exec, non-independent, family) resigned 15 Sep 2026 and was replaced on the audit committee by Harsh Bahadur (non-independent chair). Board is now 7: 3 independent (Parwal, Spong, Goldberg), Pulak Prasad (Nalanda, large shareholder), Bahadur, Agrawal. Independent share 43% — legal, but thin.
- KMP: Group CFO Nitin Panwad and CS Yashasvi Pareek are professionals, not family. No nepotism in KMP.
- RPTs: all 12 consolidated entities are wholly owned; no promoter-entity RPTs surfaced in rating reports. I could not open the FY26 annual report (BSE PDF blocked), so MD remuneration vs profit and RPT totals are unverified.
- Regulatory: no penalties, strictures or investor complaints (Q2 FY27 CG report). Open transfer-pricing dispute with Jaipur IT dept (AY 2022-23) remanded by ITAT. Analysts on the Aug-26 call criticised management for not separately disclosing the ₹25 cr tariff refund's profit impact; management conceded.
- Auditor: no change/qualification found. Ratings: ICRA A+ Stable reaffirmed (Oct-26); CARE upgraded ST to A1+ (Sep-26).
- Capital returns: ₹686 cr dividends since FY20 (~51% payout), quarterly for 15–20 quarters; ₹100 cr in FY26. No buyback despite repeated analyst pressure (Aug and Oct 2026 calls) — management wants a $50–100m acquisition war chest. Mindful Souls (bought ₹105 cr, 2023) took a ~₹25 cr impairment in FY26.

## Gate 2 — Guidance & delivery: WATCH
| Year | Guided | Delivered |
|---|---|---|
| FY25 | mid-teens at start, cut mid-year (recollection, not re-verified) | +11.1% |
| FY26 | 7–9% (reiterated Feb-26) | +9.2%, EBITDA margin 10.8% (+140 bps) — delivered |
| FY27 | May-26: 9–11% rev, +50–100 bps margin; Feb-26 had said EBITDA 10.5–11% | Oct-26: cut to 7–9%, margin flat; H1 rev +9.7%, Q2 +7.0%, Q2 EBITDA margin 8.1% vs 10.0% |
- Germany: guided to "contribute to profitability from FY27". H1 FY27 Europe EBITDA −€0.1m (Q2 −€0.2m); H1 loss ₹0.7 cr vs ₹6.6 cr — narrowing but still not positive. TV household reach in Germany shrank on regulatory changes.
- Capex: ICRA says FY27 ₹80–90 cr (Shopify + UK warehouse consolidation ₹36 cr), then ₹50–60 cr p.a.; analyst cited ₹63 cr in H1.
- Targets: digital 50% of B2C by Q4 FY27 (42% in Q2, down 3 pts QoQ); FY30 revenue ₹5,000–5,500 cr (~8–10% CAGR, i.e. mostly INR depreciation). Management admits mid-term 12–15% guidance relies on ~3% annual currency tailwind.

## Gate 3 — Fundamentals: WATCH
- Sales CAGR: 10-yr 11%, 5-yr 8%, 3-yr 11%. Profit CAGR: 5-yr 0% (FY21 Covid peak ₹272 cr), 3-yr 37% (off FY23 trough).
- TTM: sales ₹3,856 cr (+10%), PAT ₹279 cr (+52%, inflated by refund/tax). Q1 FY27: sales +12.7%, PAT +50%. Q2 FY27: sales +7.0%, PAT −12%, OPM 7% vs 9%.
- Margins: OPM 15% (FY21) → 7% (FY23) → 10% (FY26); gross margin 65.5% rising via own brands (57% of B2C) and lab-grown diamonds (13%). EBITDA leverage repeatedly lost to digital marketing/freight.
- ROCE 16%, ROE 18% (3-yr ROE 14%). Interest coverage 24x. Borrowings ₹416 cr are mostly leases + packing credit; net cash ₹186 cr (down from ₹296 cr at Mar-26 on inventory + capex).
- Working capital: inventory days 232 (219), WC days 68 (60) — rising. Budget-Pay EMI = 36–38% of B2C sales; bad-debt write-offs ₹46 cr FY26 vs ₹31 cr FY25 — watch.
- Cash conversion: CFO FY22–26 = ₹967 cr vs PAT ₹888 cr (109%). FCF FY26 ₹290 cr.
- Moat: vertically integrated low-ticket jewellery, 127m TV households, 687k customers with 38% retention; but TV is structurally flat (+2.7% Q2), unique customers down from 710k (FY25). US 58% / UK 29% / Germany 13% — tariff risk partly mitigated by US casting line (duty on value-add only) and advance shipments.

## Gate 4 — Valuation: PASS
- P/E 9.4x TTM (≈11x on normalised EPS ~₹14 ex-refund/tax). P/B 1.6x. EV/EBITDA ~6–7x (EV ₹2,430 cr ex-cash; ~₹2,690 cr incl. leases). 5-yr median P/E was ~30–40x (stock -23% CAGR over 5 yrs while sales grew 8%). Dividend yield 3.8%.
- Cheap for a reason: constant-currency growth ~0–4%, TV shopping in secular decline, execution misses. Not a structural collapse — cash generative, debt free.
- 3-yr cases: Bear — EPS ₹12, 9x = ₹108 (−30%). Base — EPS ₹18, 13x = ₹234 + ~₹18 dividends (+60%). Bull — EPS ₹22, 18x = ₹396 (+150%) if digital reaches 50% and Germany turns.

## Re-review triggers
Q3 FY27 (Feb 2027): digital growth back to double digits in constant currency; Germany EBITDA positive for H2; no further guidance cut; buyback announced.

## Sources
- https://www.screener.in/company/VAIBHAVGBL/consolidated/
- Q2 FY27 investor presentation: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=566e8d2d-2d02-410b-877e-6ded22ab66d7.pdf
- Q2 FY27 call summary (guidance cut): https://in.investing.com/news/stock-market-news/earnings-call-transcript-vaibhav-global-cuts-fy-2027-outlook-in-q2-2026-93CH-5664312
- Q1 FY27 transcript: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b0a0ce97-79de-42b1-8780-596e50737413.pdf
- Q4 FY26 transcript: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9b8fd910-eb5d-415d-95fa-ec794ad1412a.pdf
- Q3 FY26 transcript: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=53f24651-121d-4e52-b607-76d8a6fd1d23.pdf
- ICRA rationale 7 Oct 2026: https://www.icra.in/Rationale/ShowRationaleReport/?Id=146172
- CARE rationale 8 Sep 2026: https://www.careratings.com/upload/CompanyFiles/PR/202609120929_Vaibhav_Global_Limited.pdf
- Quarterly CG report Jul–Sep 2026: https://www.vaibhavglobal.com/admin_assets/images/ESG/1879212345702460.pdf
- https://www.freepressjournal.in/business/vaibhav-global-reports-7-revenue-growth-to-9384-crore-in-q2-fy27-b2b-segment-surges-324

## Primary-source verification (2 Nov 2026)

Checked against the company's own documents on vaibhavglobal.com and NSE (FY26 Integrated Annual Report, Sep-26 shareholding pattern, 28 Oct 2026 results + limited review, 29 Oct press release, Q2 presentation, Q1 FY27 transcript). Figures in Rs cr unless stated.

**1. Promoter pledge — CONFIRMED.**
Shareholding pattern, quarter ended 30-Sep-2026: promoter & promoter group 9,59,47,563 shares = 57.19% (6 holders; Brett Enterprises Pvt Ltd is the main vehicle; Sunil Agrawal 1,40,700 shares = 0.08%). "Whether any shares held by promoters are encumbered under Pledge / NDU / other" = No / No / No. Share count unchanged from Jun-26 (57.33%); the dip is ESOP dilution. Pledge = 0%.
Source: https://www.vaibhavglobal.com/admin_assets/Investor/Shareholder_Pattern/1879212553287504.pdf (Jun-26: .../1871301161160100.pdf)

**2. Promoter-family remuneration FY26 — now VERIFIED (was unverified in Gate 1).**
AR 2025-26 CG report: "Mr. Sunil Agrawal does not receive any remuneration from the Company. During the financial year, he received remuneration from Shop LC Global Inc., USA, a step-down subsidiary ... aggregating to USD 650.91K, comprising fixed pay of USD 125.00K, bonus of USD 434.40K and profit-related commission of USD 91.51K" ≈ Rs 5.6 cr. Family non-exec Sanjeev Agrawal: Rs 5.4 lakh sitting fees. All non-executive directors (fees + commission) Rs 1.36 cr. Non-family KMP (Group CFO, CS etc.) Rs 2.94 cr; Group CFO pay +25%.
FY26 consolidated PAT Rs 266.1 cr → promoter-family remuneration ≈ 2.1% of PAT (all directors + KMP ≈ 3.6%). Low. One flag: AR Note 48 states the Company's borrowings "are secured by the personal guarantee of Mr. Sunil Agrawal".
Source: https://www.vaibhavglobal.com/admin_assets/Investor/Annual_Reports/1870602021379036.pdf (CG report NRC section; Note 48)

**3. Related-party transactions FY26 — now VERIFIED; immaterial.**
Standalone Note 48: all operating RPTs (sales Rs 326 cr, purchases Rs 66 cr, management fees, loans) are with wholly-owned subsidiaries and eliminate on consolidation. Transactions with promoter entity Brett Enterprises: dividend paid Rs 55.82 cr and rent paid Rs 0.39 cr. KMP remuneration Rs 2.94 cr, sitting fees Rs 0.21 cr, dividends to KMP relatives Rs 1.29 cr. Non-dividend third-party RPTs ≈ Rs 3.5 cr = 0.1% of consolidated revenue (Rs 3,691.8 cr). AOC-2: all RPTs ordinary course and arm's length; Board's Report: no material RPTs. Consistent with Gate 1.

**4. Auditor — CONFIRMED unmodified.**
B S R & Co. LLP (ICAI FRN 101248W/W-100022), second five-year term 1 Apr 2022 – 31 Mar 2027 (to the 38th AGM). FY26 standalone and consolidated opinions: unmodified, no Emphasis of Matter; CG report certifies an "unmodified audit opinion". Q2 FY27 limited review dated 28 Oct 2026 (partner Gaurav Mahajan, Chandigarh): "nothing has come to our attention ..."; four subsidiaries reviewed by other auditors; "Our conclusion is not modified in respect of this matter." No auditor change.
Source: AR 2025-26 Board's Report "Statutory Auditors"; https://vaibhavglobal.com/admin_assets/Investor/Shareholder_Communication/1880322056519040.pdf (review reports on pp. 10–14, scanned)

**5. Revised FY27 guidance and net cash — PARTLY CONFIRMED.**
- Press release (29 Oct 2026) contains no guidance and no net-cash figure. Q2 presentation: "22% ROCE and ₹186 Cr net cash position". Computed from the 30 Sep 2026 consolidated balance sheet: cash Rs 242.7 cr + other bank balances 38.1 + investments 19.2 − borrowings 129.6 = Rs 170 cr before leases (lease liabilities Rs 296 cr); the company's Rs 186 cr presumably nets differently. Mar-26 comparator in the FY26 presentation was Rs 296 cr. Net cash ≈ Rs 170–186 cr — CONFIRMED.
- Guidance cut (revenue growth 9–11% → 7–9%; margin +50–100 bps → "broadly in line with FY26", i.e. ~10.8%) was given only orally on the 29 Oct call. The company has posted the audio but no transcript as of 2 Nov 2026, so the only written record is a third-party call summary (investing.com). The prior 9–11% / +50–100 bps guidance is confirmed verbatim in the company's Q1 FY27 transcript (5 Aug 2026 call: "we reiterate our FY '27 guidance of 9% to 11% revenue growth with EBITDA margin expansion of 50 to 100 basis points over FY '26"). Treat the cut as reliably reported but not yet in a filed document; re-check when the transcript is filed.
Sources: https://nsearchives.nseindia.com/corporate/VAIBHAVGBL_29102026013439_Press_Release_Final.pdf ; https://www.vaibhavglobal.com/admin_assets/Investor/Investor_Presentation/1880324334484567.pdf ; https://www.vaibhavglobal.com/admin_assets/Investor/Investor_Presentation/1873211962764972.pdf ; call audio https://www.vaibhavglobal.com/admin_assets/Investor/Investor_Presentation/1880393708745777.mp3

**6. Q2 FY27 (quarter ended 30 Sep 2026) — CONFIRMED; watch item NOT met.**
Consolidated: revenue from operations Rs 938.4 cr, +7.0% reported, **−1.7% constant currency**; EBITDA Rs 76.2 cr, −13.5%; EBITDA margin 8.1% vs 10.0% (−191 bps); PAT Rs 41.7 cr, −12.3% (helped by a Rs 4.34 cr foreign tax credit); gross margin 65.5% (+196 bps). H1: revenue Rs 1,855.4 cr +9.7% (cc −0.3%, includes Rs 25.6 cr Q1 tariff refund), EBITDA 178.3 cr +9.6% (9.6% margin), PAT 98.1 cr +15.2%.
Geography (press release, local currency): US −4.1% (EBITDA Rs 28.7 cr, −15.1% cc, 5.7% margin), UK −7.0% (EBITDA Rs 7.3 cr, −69.9% cc), Europe ex-UK +8.0% (revenue Rs 110 cr, EBITDA **−Rs 2.2 cr**, −2.0% margin; H1 −Rs 0.75 cr vs larger loss LY); B2B +32.4% (EBITDA Rs 42.4 cr). Digital 42.4% of B2C (Q1 45.1%). Germany is not disclosed separately — "Europe ex-UK" is the proxy; presentation still says Germany is "expected to contribute towards profitability from FY27" (H1 revenue €12.7m).
Watch item (constant-currency growth; Germany EBITDA): cc growth is negative at group level and in both core markets, and Europe EBITDA is still a loss — not met. Mitigant: management attributes the miss to the Shopify migration and Q3 is the holiday quarter.
Second interim dividend Rs 1.50 (record date 4 Nov 2026); Rs 3.00 declared YTD.

**7. Announcements since 1 Oct 2026 — nothing that changes the governance picture.**
19 Oct: concall notice; 28 Oct: Q2 results + Rs 1.50 interim dividend; 29 Oct: press release, presentation, call. No auditor, director, RPT or regulatory filings. Last board change was before the window: Sanjeev Agrawal (family NED) resigned w.e.f. 15 Sep 2026 citing "enhanced professional commitments", with the standard confirmation of no other material reasons (filed 16 Sep 2026: https://vaibhavglobal.com/admin_assets/Investor/Shareholder_Communication/1876498842808191.pdf).

**Summary:** Items 1, 4, 6 CONFIRMED (6 confirms the watch item failed); items 2 and 3 verified for the first time and are clean (family pay ≈ 2.1% of PAT, paid by the US subsidiary; RPTs ≈ 0.1% of revenue); item 5 partly confirmed (net cash yes; guidance cut only on call audio, transcript pending); item 7 clean. One new governance detail: company borrowings carry Sunil Agrawal's personal guarantee.

**VAIBHAVGBL: verdict stands — HOLD-FOR-REVIEW retained, no upgrade to SELECT and no downgrade to REJECT** — no primary source contradicts the governance facts (pledge nil, pay and RPTs immaterial, auditor unmodified), but Q2 missed the watch item: constant-currency revenue −1.7%, EBITDA −13.5%, Europe EBITDA still negative, and FY27 guidance cut (per call). Re-review after Q3 FY27 as planned; confirm the guidance cut from the filed transcript.
