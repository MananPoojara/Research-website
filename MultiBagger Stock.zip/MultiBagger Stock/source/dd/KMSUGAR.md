# KM Sugar Mills (NSE: KMSUGAR, BSE 532673) — Due Diligence, 2 Nov 2026

**Verdict: REJECT** — G1 FAIL / G2 WATCH / G3 WATCH / G4 WATCH

Price Rs 32.2 | Mcap Rs 296 cr | 52w 18.6–34.3 | P/E 6.1 (TTM, pre-demerger) | P/B 0.73 | ADTV ~Rs 0.7 cr
Business: single 9,500 TCD sugar mill at Motinagar, Ayodhya (UP) with 25 MW bagasse cogen. The 50 KLPD distillery (ethanol, ENA, country liquor; Rs 91 cr / 13% of FY25 turnover) was **demerged into KM Spirits & Allied Industries** — effective 1 Oct 2026, record date 2 Oct, 1 KM Spirits share per 5 KMSUGAR shares, 1.84 cr shares allotted 12 Oct, listing application pending. The listed entity is now a pure-play UP sugar + power company. Q2 FY27 results due 5 Nov 2026 (not yet out).

## GATE 1 — Governance: FAIL
- **Promoter holding**: 56.51%, zero pledge (Finology/Trendlyne, every quarter to Mar-26). Fell from 64.6% to 56.5% in FY23 — coincides with the Feb-2022 reclassification of several family members from "promoter group" to "public", so effective family control is understated. Marvel Business Pvt Ltd holds 13.1%.
- **Family KMP / nepotism**: Chairman L.K. Jhunjhunwala died 14 Mar 2026. His **widow Naina Devi Jhunjhunwala, age 80–81, was made Whole-Time Director** from 1 Aug 2026 (3-yr term) at Rs 10–15 lakh/month plus commission up to Rs 5 cr/yr, two chauffeur-driven cars, furnished house. Sons Aditya (MD, Rs 17.5–30 lakh/month + up to Rs 5 cr commission) and Sanjay (JMD, Rs 15–20 lakh/month + up to Rs 5 cr) re-appointed to 2030. Grandson Vatsal Jhunjhunwala (VP) had his pay cap raised 4x to Rs 10 lakh/month via an RPT resolution. Actual FY25 pay: Aditya ~Rs 3.0–3.6 cr, Sanjay ~Rs 2.0 cr (SimplyWallSt/Stoculator) — total family pay already ~10–12% of PAT and the authorised ceiling (~Rs 20 cr) exceeds post-demerger PAT.
- **Group-company exposure (the big one)**: Infomerics (Jul 2025) — KMSML has given Sonar Casting Ltd (a Jhunjhunwala group company with "no operational linkages") corporate guarantees Rs 68.66 cr, loans Rs 11.24 cr, 12.5% preference shares Rs 49.60 cr and holds 19.82% of its equity. Total ~Rs 130 cr ≈ 40% of reported net worth; the rating agency haircuts net worth from ~Rs 290 cr to Rs 210 cr for it. This is shareholder capital funding a private family venture; AGM 2025 carried a Sec-185 loans/guarantees resolution.
- **Auditor**: Mehrotra & Mehrotra (appointed 2022, unqualified). Screener flags "may be capitalising interest costs".
- **No dividend in years** despite consistent profit ("deployment for growth") while funds go to a group casting company.
- **SEBI/exchange**: nothing adverse found; MarketsMojo cut the stock to Sell (Mar 2026) on quality.
- **Investor communication**: no concalls, no investor presentations — ever.

## GATE 2 — Guidance & delivery: WATCH
No quantitative guidance is issued. The one stated project — the distillery demerger (board approved 7 Aug 2025) — was executed on schedule (NCLT 19 Aug 2026, effective 1 Oct 2026). Rationale ("independent valuation, separate capital raising") is plausible but also moves the higher-margin, policy-cushioned business out of the listed sugar company. No capacity-expansion plan disclosed; capex has been maintenance-level (CWIP Rs 14 cr).

## GATE 3 — Fundamentals: WATCH
| | FY21 | FY23 | FY25 | FY26 | TTM |
|---|---|---|---|---|---|
| Sales (Rs cr) | 503 | 576 | 659 | 658 | 640 |
| OPM | 11% | 9% | 13% | 13% | 12% |
| PAT | 26 | 23 | 36 | 53 | 48 |
| ROCE | 12% | 9% | 11% | 13% | – |

- 5-yr sales CAGR 6%, PAT CAGR 14%; flat topline, profit driven by sugar realisation and lower finance cost (Rs 18 cr → 11.7 cr).
- **Latest 2 quarters**: Q4 FY26 sales 106 (−31% YoY), PAT 9.2 (−16%); Q1 FY27 sales 190 (−9%), OP 15.8 (−39%), PAT 7.8 (−40%). TTM sales −8%. Recovery slipped 11.01% → 10.90%, crushing days 121 (vs 144) — cane availability is the constraint.
- Debt Rs 250 cr (mostly cash credit against sugar inventory); D/E 0.64; ICR 4.5x (FY25), ~9x FY26. Inventory ~300 days — structural for UP sugar.
- CFO FY22–26 = Rs 227 cr vs PAT Rs 181 cr (1.25x), but lumpy (Rs 5 cr in FY22, Rs 89 cr in FY26). FCF FY26 Rs 40 cr.
- **Policy**: SY2026-27 — government set sugar diversion to ethanol at **zero** and excluded cane-juice/B-heavy ethanol from the 11 bn-litre tender; sugar exports prohibited; MSP unchanged at Rs 31/kg since 2019 (industry lobbying for a hike); UP SAP revisions pending. Rising domestic sugar prices help near-term, but the ethanol cushion is gone and now sits in an unlisted entity anyway.
- Moat: none — regulated commodity, cane command-area dependent, single location.

## GATE 4 — Valuation: WATCH
- P/E 6.1x and P/B 0.73x look cheap, but TTM numbers still include the distillery; remaining-co P/E is likely 8–10x once Q2 FY27 restates. Peers: Balrampur ~15–18x, Dwarikesh ~12x, Dhampur ~10x, Dalmia Bharat Sugar ~8–9x — KMSUGAR's discount reflects size, governance and illiquidity, not mispricing. 5-yr own median P/E ~7–9x, so it is mid-range, not at a trough.
- Cheap for a reason: cyclical trough-ish on recovery/cane, but also structurally discounted.
- **3-yr case**: Bull — firm sugar prices, recovery back to 11%+, PAT Rs 45 cr remaining-co, 8x → Rs 360 cr (+20%) plus KM Spirits listing worth perhaps Rs 10–15/KMSUGAR share equivalent → total +40–50%. Bear — SAP hike without MSP hike, recovery <10.5%, PAT Rs 15–20 cr, 6x → Rs 110 cr (−60%); ADTV Rs 0.7 cr means you cannot exit in a bear case.

## Verdict: REJECT
1. **Governance FAIL**: ~Rs 130 cr of guarantees, loans and preference capital to a non-operating family company (Sonar Casting) — ~40% of net worth — plus an 80-year-old widow installed as paid Whole-Time Director and a grandson's pay quadrupled. Minority capital is not the priority.
2. Shrinking business: TTM sales −8%, Q1 FY27 PAT −40%, recovery falling, and the ethanol hedge both removed by policy (zero diversion) and demerged out of the listed company.
3. Liquidity: Rs 0.7 cr ADTV on a Rs 296 cr mcap makes any position un-exitable; the 6x P/E is a fair price for that risk, not a bargain.
Only revisit if Sonar Casting exposure is fully unwound and the company starts paying dividends.

## Sources
- https://www.screener.in/company/KMSUGAR/consolidated/
- https://infomerics.com/admin/uploads/pr-KM-SugarMills-11july25.pdf (rating rationale: Sonar Casting exposure, debt, capacity)
- https://nsearchives.nseindia.com/corporate/KMSUGAR_04072026195741_KMSML_Notice_2026.pdf (53rd AGM notice: Naina Devi WTD, family remuneration, Vatsal RPT)
- https://www.indiainfoline.com/company/km-sugar-mills-ltd/reports/directors-report (FY26 directors' report)
- https://nsearchives.nseindia.com/corporate/KMSUGAR_07082025180451_OUTCOMEDEMERGER30062025.pdf (demerger scheme)
- https://nsearchives.nseindia.com/corporate/KMSUGAR_12102026210814_REG30_SUBSIDIARY_CESSATION__1_.pdf (allotment, record date)
- https://nsearchives.nseindia.com/corporate/KMSUGAR_12022022203910_outcomereclassification12022022.pdf (promoter reclassification)
- https://scanx.trade/stock-market-news/companies/km-sugar-mills-approves-naina-devi-jhunjhunwala-as-wtd-at-53rd-agm/46805832
- https://ticker.finology.in/company/KMSUGAR ; https://trendlyne.com/equity/share-holding/751/KMSUGAR/latest/km-sugar-mills-ltd (pledge, holders)
- https://www.kotakneo.com/financial-results/km-sugar-mills-share-price-q1fy2026-27-results/
- https://businesstoday.in/india/story/2026-27-supply-season-government-sets-sugar-diversion-for-ethanol-to-zero-heres-why-562257-2026-10-17 ; https://www.business-standard.com/india-news/india-sugar-export-ban-september-stock-concerns-dgft-order-126051401291_1.html (policy)
- https://simplywall.st/stocks/in/food-beverage-tobacco/nse-kmsugar/km-sugar-mills-shares/management (executive pay)
