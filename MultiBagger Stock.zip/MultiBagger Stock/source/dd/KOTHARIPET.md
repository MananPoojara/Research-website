# Kothari Petrochemicals (NSE: KOTHARIPET) — Due Diligence, 2 Nov 2026

**Snapshot:** CMP Rs 110 | Mcap Rs 649 cr | 5.88 cr shares (FV 10) | 52w 94.8–155 | TTM EPS 12.22 | P/E ~9.0 | P/B ~1.7 | Div yield 0.9%
India's largest polyisobutylene (PIB) maker; single plant at Manali, Chennai (48,000 MTPA, raised from 36,000 in 2023). Feedstock = refinery C4 streams (CPCL next door, plus Reliance). H.C. Kothari group. Q2 FY27 results due 3 Nov 2026 (not out at time of writing).

## VERDICT: REJECT (re-review only if public shareholders vote down the Kothari Sugars merger on 13 Nov 2026)

1. **Minority-unfriendly group merger.** Loss-making promoter company Kothari Sugars & Chemicals (KSCL: FY26 OPM -6%, TTM -9%, sales collapsed Rs 609 cr FY23 -> Rs 247 cr FY26) is being merged into cash-rich KPL at 1:5. ~1.66 cr new KPL shares = ~22% dilution for KPL holders; pro-forma FY26 EPS falls from Rs 12.3 to ~Rs 9.6 with no earnings contributed. Stated rationale ("eliminate duplication, economies of scale") between a sugar mill and a PIB plant is thin. ICRA has KPL on rating watch with negative implications. Promoter stake stays ~72.5%.
2. **Growth has stalled.** Volumes flat for 3 years (FY24 40,782 MT; FY25 37,995; FY26 39,163 vs 48,000 capacity). 3-yr sales CAGR 7%, TTM -3%, Q1 FY27 sales -9% YoY. Feedstock supply constrained (refinery shutdowns, LPG prioritisation). Rs 79 cr spent on Andhra Pradesh land with "timeline not finalized".
3. **Family extraction on top.** MD Arjun Kothari paid Rs 6.6 cr in FY26 (76x median employee, incl. commission 5% of PAT) = 9% of PAT; his mother Nina Kothari (non-exec chairperson) gets 1% of PAT commission. Combined ~10% of profit to two family members.

## GATE 1 — GOVERNANCE: FAIL
- Promoter holding 70.98% -> 72.22% (Sep 2025); zero pledge/encumbrance declared for FY26.
- Board: Nina B. Kothari (chairperson, non-exec) is mother of MD Arjun B. Kothari. One professional WTD (M. Rajavel). Four independent directors; no resignations found. ID Brij Mohan Bansal breached trading-window closure (2,000 shares) — minor, self-reported.
- RPTs (ex-merger) small vs Rs 591 cr sales: dividends to BHK Trading LLP, CSR Rs ~1.5 cr to family trusts (Shyam Kothari Foundation, HCK Trust), minor rent/manpower with group cos. No loans to/from related parties. Not material by size.
- The merger is the RPT that matters: KSCL (promoters 73.5%) valued by KPMG/Saffron at ~Rs 183 cr in KPL stock (vs KSCL mcap Rs 189 cr, book ~Rs 296 cr) for a business with negative EBITDA and shrinking cane supply. KPL minorities get sugar-cycle losses and dilution; KSCL promoters get liquid, dividend-paying PIB stock. Requires majority-of-minority approval on 13 Nov 2026 — key event.
- Auditor P. Chandrasekar LLP (second term to FY27), unmodified opinion, no fraud reported; KAM on raw-material quantity (tanker weighing). Small disputed GST (~Rs 46 lakh).
- No SEBI/exchange penalties found. Promoter remuneration vs profit: ~10% of PAT to family — high for a Rs 72 cr PAT company.

## GATE 2 — GUIDANCE & DELIVERY: WATCH
- No concalls; disclosure via annual report only. FY24 guidance was capacity to 48,000 MTPA — delivered (2023). Utilisation then fell from 100% (FY24) to 82-88%; management blames feedstock, not demand.
- Nov 2024: Rs 74 cr AP land for "long-term growth"; FY26 AR: "working with engineering consultants", "capacity augmentation and PIB derivatives under evaluation", no capex number, no timeline. Two years, no committed project = capex deferral.
- Exports grew Rs 144 cr -> Rs 166 cr (28% of sales) — the one positive delivery.
- Merger announced May 2026 with no quantified synergy; rationale vague.

## GATE 3 — FUNDAMENTALS: WATCH
- 5-yr CAGR (FY21-26): sales 21% (227 -> 591), PAT 26% (23 -> 72). 3-yr: 7% / 24%. TTM: -3% / +13%.
- Quarters: Q4 FY26 sales 153 (flat YoY), PAT 18 (+3%); Q1 FY27 sales 146 (-9%), PAT 17 (-5%). OPM 15-19% last 4 qtrs (FY26 16.4%, up from 13.9%) — margin fine, volumes not.
- ROCE 29% (FY26; 42% in FY24), ROE 21%. Debt Rs 2 cr; interest cover 131x. Investments Rs 104 cr + cash ~Rs 10 cr. WC days 25 (debtor 38, inventory 27).
- Cash conversion FY22-26: CFO Rs 257 cr vs PAT Rs 274 cr = 94%. FCF FY26 Rs 62 cr. Capex FY25 Rs 86 cr (mostly land), FY26 Rs 19 cr.
- Moat: near-monopoly domestic PIB (~90% of conventional PIB), import substitution, refinery-adjacent logistics. Weaknesses: single plant, single product, non-exclusive feedstock from 1-2 refineries, Korean/Japanese/Chinese import competition, EV-linked lube demand risk, CBAM for EU exports.

## GATE 4 — VALUATION: PASS (cheap, but for a reason)
- P/E ~9x TTM vs sector median 12.2x (Supreme Petro 24x, Bhansali 12x, Manali 10x). Stock de-rated from ~Rs 218 (Nov 2024) to Rs 110 while EPS rose — own 2024 P/E was ~18-20x. P/B ~1.7x on 21% ROE. EV ~Rs 535 cr / TTM EBITDA Rs 96 cr = ~5.6x.
- Cheap because: volume stagnation, feedstock risk, and a 22% dilutive merger with a loss-making sugar mill. Not a cyclical trough in PIB; it is a governance/capital-allocation discount.
- 3-yr cases: Bull (scheme voted down, volumes to 45k MT, PAT Rs 85 cr, 14x) ~Rs 200 (+80%). Base (scheme passes, pro-forma EPS ~9.5, sugar drag, 10x) ~Rs 95-110 (flat to -10%). Bear (feedstock cuts + sugar losses, EPS 8, 8x) ~Rs 65 (-40%).

## Sources
- https://www.screener.in/company/KOTHARIPET/ (standalone financials, quarterly, shareholding, peers)
- https://www.screener.in/company/KOTHARIPET/consolidated/
- https://www.screener.in/company/KOTARISUG/ (Kothari Sugars financials)
- https://nsearchives.nseindia.com/annual_reports/AR_29863_KOTHARIPET_2025_2026_A_1783049_17072026180604.pdf (FY26 annual report: remuneration, RPTs, MD&A, AP land, auditor)
- https://www.icra.in/Rating/GetRationalReportFilePdf?id=143320 (ICRA, 28 May 2026, watch negative)
- https://nsearchives.nseindia.com/corporate/KOTARISUG_19082026184337_KSCLIntimationunderReg30.pdf (NSE no-objection to scheme)
- https://nsearchives.nseindia.com/corporate/KOTHARIPET_05102026192310_IntimationofreceiptofNCLTOrder.pdf
- https://www.arthneeti.com/announcements/kothari-petrochemicals-ltd-shareholders-meeting-12-oct-2026
- https://scanx.trade/stock-market-news/companies/kothari-sugars-approves-merger-with-kothari-petrochemicals/40776699
- https://www.indiainfoline.com/company/kothari-petrochemicals-ltd/management-discussions (FY25 MD&A)
- https://machinist.in/2024/11/kothari-petrochemicals-to-invest-%E2%82%B974-crore-in-andhra-pradesh-land-acquisition-for-expansion/
- https://univest.in/blogs/kothari-petro-q1-fy27-results-pat-17-crore
- https://www.business-standard.com/markets/capital-market-news/kothari-petrochemicals-standalone-net-profit-rises-12-80-in-the-september-2025-quarter-125111300477_1.html
