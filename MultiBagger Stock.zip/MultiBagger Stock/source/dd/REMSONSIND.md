# Remsons Industries (NSE: REMSONSIND, BSE 530919) — Due Diligence, 2 Nov 2026

**Snapshot:** CMP Rs 91.9 | Mcap Rs 320 cr | 3.49 cr shares (FV 2, split 5:1 Jul 2024) | 52w 75.2–152 (1-yr -41%) | TTM EPS 4.96 | P/E ~18 | P/B ~2.2 | Div yield 0.3%
Control cables, gear shifters, parking brakes, pedal boxes, spare-wheel winches; 8 plants (India + UK). UK arm = Magal Cables (bought from administrators Oct 2020, now Remsons Automotive UK). Kejriwal family (promoter group also "Harlalka family"). Q2 FY27 not yet reported.

## VERDICT: REJECT (revisit as HOLD-FOR-REVIEW if Q2 FY27 shows EBITDA margin back above 11% and promoter selling has stopped)

1. **Family board and nepotistic succession.** CMD Krishna Kejriwal, wife Chand (WTD), son Rahul (WTD, died 6 Oct 2026). Ten days later the board appointed Rahul's widow Shivani Kejriwal (45) as Whole-time Director for 5 years; her CV is sales roles at Koohsports/IMG Reliance, an internship at the Gurgaon plant, running tiny Remsons Uni Autonics, and yoga teaching. Professional CEO Amit Srivastava resigned (effective Sep 2026) after ~2 years; Rahul Kejriwal had earlier been WTD-cum-CFO. Promoters sold ~Rs 13 cr of stock in Mar-Jun 2026 at Rs 83-111 while telling investors they are "firmly on track" for Rs 900-1,000 cr revenue by FY30; promoter holding 75% (Mar 2023) -> 62.8% (Sep 2026).
2. **Profit falling on rising sales.** Q4 FY26: sales +23%, PAT -32%; Q1 FY27: sales +20%, PAT -33% (net -19%). EBITDA margin 11.9% (Q3 FY26) -> 8.4% -> 8.7%, against a guided 13-14%. Interest cover only ~3.5-4x, D/E 0.66, goodwill ~Rs 34-37 cr (~22% of net worth).
3. **Erratic capital allocation.** Bought 51% of EV three-wheeler start-up Astro Motors (Apr 2025, Rs 14.2 cr, partly via preferential shares whose valuation report NSE made the company revise), cancelled part of it, dodged questions on two concalls, sold the remaining 35.9% for Rs 10 cr in Mar 2026. Exited Aircom JV for Rs 5.2 lakh. Now wants "one more meaningful acquisition" with Rs 50-70 cr set aside, funded by equity + debt, plus a new ESOS 2026.

## GATE 1 — GOVERNANCE: FAIL
- Promoter trend: 75.0% -> 65.3% (Mar 2024, preferential issue of 10.4 lakh shares to non-promoters at ~Rs 470-480 pre-split plus 2.7 lakh warrants to promoters) -> 66.2% (small buys Mar 2025 at Rs 112-121) -> 62.8% (Sep 2026) after Goodluck Electronics sold 2.5 lakh shares at ~Rs 110 (Mar 2026), Chand Kejriwal ~5.5 lakh at ~Rs 92 (29 May-2 Jun 2026) and Krishna Kejriwal ~2.2 lakh in June 2026. No pledge disclosed.
- KMP relationships: CMD, wife, son and now daughter-in-law all executive directors. Three IDs (Anil Agrawal, Visalakshi Sridhar, Shishir Dalal) plus Suresh Ramarao; no ID resignations found.
- RPTs: 49% of Remsons Edge Technologies bought from promoters at par (Rs 7.35 lakh) — small; Astro Motors sale buyer "not promoter group". FY26 AR RPT note not machine-readable; remuneration ratios not verified.
- Regulatory: NSE queried the Astro preferential-issue valuation weights (Aug 2025; fair value revised Rs 124.5 -> 131.5); secretarial auditor flagged delayed RoC e-form filings. No SEBI penalties found. Auditor Kanu Doshi Associates LLP, no change or qualification found.

## GATE 2 — GUIDANCE & DELIVERY: WATCH
- Delivered on top line: "20%+ CAGR" guidance met (FY25 +21%, FY26 +24%, Q1 FY27 +20%). Stellantis Rs 300 cr/7-yr, Rs 60 cr CV gear-shifter, Rs 160 cr pedal-box (from CY2028), Ford Otosan Rs 80 cr wins are real.
- Missed on margin: 13-14% EBITDA target repeated since at least FY25 as "2-3 years out"; actual 10% FY25, 11% FY26, 9% Q1 FY27. Management now says margins will rise "steadily, won't jump" — no FY27 number.
- FY27 revenue guide Rs 520-570 cr needs Rs 400+ cr in the remaining 3 quarters (Q1 was Rs 120 cr); achievable only if Stellantis ramps on time, and its start date was stated inconsistently on the Feb 2026 call.
- Vague/deferred: order pipeline quoted as both Rs 500 cr and Rs 800-900 cr on one call; Astro questions deferred twice; Brazil licence numbers "in three months"; UK business "stable, no growth" with no subsidiary P&L disclosed.

## GATE 3 — FUNDAMENTALS: WATCH
- 5-yr CAGR (FY21-26): sales 16% (226 -> 469), PAT 47% (4 -> 21, low base). 3-yr: 14% / 30%. TTM sales 489 (+22%), PAT 19 (+12%).
- OPM: 4.5% (FY21) -> 8% -> 10% -> 11% (FY26) -> 8.7% (Q1 FY27). Raw material 54% of sales; steel +11%, aluminium +27%, copper +28% recently; pass-through lags 1-2 quarters and covers only 40-60%.
- ROCE 15%, ROE 13.5%. Borrowings Rs 98 cr vs equity Rs 149 cr (0.66x; net D/E 0.57x). Interest Rs 8-9 cr on EBIT ~Rs 32 cr.
- Working capital: inventory 114 days, debtors 59, CCC 77 (52 in FY23). Cash conversion FY22-26: CFO Rs 139 cr vs PAT Rs 64 cr (depreciation-heavy, Rs 18 cr/yr); cumulative FCF Rs 45 cr; FY26 FCF Rs 28 cr.
- Capex plan Rs 100 cr over 3 years vs FY26 CFO Rs 60 cr — will need debt/equity. Moat: 50-year OEM relationships, Tier-1 status with Stellantis/Ford/JLR, but control cables are commoditised and customer concentration is high (top-5 ~80% per ICRA).

## GATE 4 — VALUATION: WATCH
- P/E ~18x TTM vs auto-ancillary median 27.8x and peers 37-85x; own P/E was 30-40x at the 2024-25 peak, so below its 5-yr median. P/B 2.2x on 13.5% ROE. EV ~Rs 394 cr / TTM EBITDA Rs 49 cr = ~8x.
- Cheap vs peers but not vs its own trajectory: PAT down 30%+ for two quarters; on a normalised Rs 15-17 cr PAT the multiple is ~20x. Cyclical input-cost squeeze, not structural decline — but the equity is thin (free float ~Rs 118 cr; ~1-1.6 lakh shares/day ≈ Rs 1-1.5 cr/day), so exit liquidity is poor.
- 3-yr cases: Bull (FY29 rev Rs 750 cr, 13% margin, PAT ~Rs 45 cr, 20x) ~Rs 258 (+180%). Base (rev Rs 650 cr, 10.5%, PAT Rs 28 cr, 15x) ~Rs 120 (+30%). Bear (margin stuck at 9%, PAT Rs 15 cr, 12x) ~Rs 52 (-43%).

## Sources
- https://www.screener.in/company/REMSONSIND/consolidated/ (financials, shareholding, peers, announcements incl. 6 Oct 2026 demise filing)
- https://nsearchives.nseindia.com/corporate/REMSONSIND_14082026163604_PRSE.pdf (Q1 FY27 press release)
- https://nsearchives.nseindia.com/corporate/REMSONSIND_14082026163719_IPSE.pdf (Q1 FY27 investor presentation)
- https://files.tijorifinance.com/insight/india/3453/Conference%20Call/CC-Feb26.pdf (Q3 FY26 concall transcript, 13 Feb 2026)
- https://nsearchives.nseindia.com/corporate/REMSONSIND_16102026121429_OUTCOME16102026.pdf (Shivani Kejriwal appointment)
- https://nsearchives.nseindia.com/corporate/REMSONSIND_23032026125136_OUTCOME.pdf (Astro Motors sale, Remsons Edge RPT)
- https://nsearchives.nseindia.com/corporate/REMSONSIND_04082025100034_NSEREPLYVR.pdf (NSE query on valuation report)
- https://nsearchives.nseindia.com/annual_reports/AR_32049_REMSONSIND_2025_2026_A_9325537_18092026114718.pdf (FY26 annual report; partly unreadable)
- https://www.insiderscreener.com/en/company/remsons-industries-ltd (promoter trades 2025-26)
- https://www.icra.in/Rating/ShowRationalReportFilePdf/110922 (ICRA BBB-, Mar 2022: leverage, customer concentration)
- https://insights.dsij.in/dsijarticledetail/4400-per-cent-multibagger-returns-promoters-decrease-stake-board-announces-51-stock-split-check-record-date-for-eligibility-38879
- https://www.autocarpro.in/news/remsons-industries-acquires-51-stake-in-electric-three-wheeler-maker-astro-motors-125823
- https://www.autocarpro.in/news/remsons-industries-posts-26-percent-profit-growth-in-fy26-revenue-jumps-24-percent-132753
- https://www.marklines.com/en/news/245703 (Magal Cables acquisition, 2020)
