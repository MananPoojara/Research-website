# Cords Cable Industries (NSE: CORDSCABLE) — Due diligence, 2 Nov 2026

**Business:** Control, instrumentation and LT power cables (up to 3.3 kV) from two plants at Bhiwadi, Rajasthan. Customers: IOCL/HPCL/BPCL, L&T, Tata Projects, solar EPCs. FY25 mix: power 46%, instrumentation 33%, control 21%. Promoter/CMD Naveen Sawhney (47.2% personally; promoter group 52.45%).
**Snapshot (screener, 2 Nov 2026):** Price Rs 285, mcap Rs 369 cr, 52-wk 126–407, P/E 15.0 (TTM EPS 19.0), P/B 1.8 (BV 156), ROCE 17.6%, ROE 10.8%, div yield 0.4%. Q2 FY27 results due 6 Nov 2026 (not yet out).

## Gate 1 — Governance: WATCH
- Promoter holding stable/creeping up: 51.4% (2017) -> 52.45% (Sep 2026). No pledge shown on screener or in CARE/annual-report disclosures.
- Family in management: MD's two sons Varun (VP Marketing/HR/IT) and Gaurav (VP Finance & Banking) each paid ~Rs 29 lakh in FY25, raised to Rs 2.97 lakh/month via AGM resolutions; wife Adarsh Sawhney receives Rs 3.15 lakh rent. Amounts are modest, but the finance function sits with a promoter's son and the Board is chaired by the executive MD.
- RPT with promoter-relative entity: Stem Factory Solutions Pvt Ltd ("entity owned/controlled by relative of MD") — Rs 20.9 cr of goods/services in FY25 (2.6% of sales), shareholder cap Rs 50 cr/yr. Nature of business not explained in the AR. Smell, not a fail.
- MD remuneration Rs 1.81 cr FY25 = 12% of PAT, 41x median employee, +17.7% YoY.
- Statutory auditor rotated Sept 2026 (Alok Misra & Co -> G V K N & Associates) at end of second term — routine. Audit reports unqualified.
- Tax/penalty history: Nov 2025 GST demand incl. personal penalty on the MD and ex-WTD; Rs 1.77 cr paid under protest; a Rs 45.9 lakh demand was set aside on appeal Oct 2026. Exchange sought price-movement clarification 2 Sep 2026 (stock went 126 -> 407 in a year).
- Independent directors: four, none resigned early; P.K. Vohra retired on tenure March 2026, Praveen Verma appointed. Board is small and long-tenured.
- No investor concall or presentation since Feb 2023 for a Rs 950 cr revenue company — low transparency.

## Gate 2 — Guidance & delivery: WATCH
No management guidance exists publicly (no concalls since FY23). Only proxy: CARE (Oct 2025) relayed management's expectation of higher FY26 turnover on an order book of ~Rs 260 cr and "no significant capex besides maintenance". Delivery: FY26 revenue +20% to Rs 954 cr, PAT +41% to Rs 20.6 cr — delivered. CARE upgraded to BBB+/A3+ (Oct 2026). Negative: no capacity expansion announced despite 22% CAGR, which caps the growth runway; management deliberately keeps order book to 3–4 months to hedge copper.

## Gate 3 — Fundamentals: WATCH
- Sales CAGR: 5-yr 24%, 3-yr 22%, 10-yr 13%. Profit CAGR 5-yr 37%. FY22->FY26 sales 438 -> 954 cr; PAT 6 -> 21 cr.
- Recent quarters: Q4 FY26 sales 267 cr (+14% YoY), PAT 8.3 cr (+84%); Q1 FY27 sales 247 cr (+9.5%), PAT 7.8 cr (+101%). TTM sales 975 cr, PAT 25 cr.
- Margins: OPM slid 10% (FY20) -> 6.0–6.2% (FY25–FY27) as low-margin power cables rose to ~half of sales; PAT growth is coming from operating leverage on flat interest cost, not margin expansion. Raw material ~90% of cost; limited pricing power with PSU/EPC buyers.
- Returns: ROCE 18%, ROE only 10.8% (equity-heavy, thin margin). 
- Leverage: borrowings Rs 111 cr vs equity Rs 202 cr (D/E 0.55; CARE gearing 1.23x incl. all debt FY25). Interest coverage ~2x (CARE 1.96x FY25) — weak; Rs 26 cr interest on Rs 60 cr EBITDA. WC limit utilisation 75–80%.
- Working capital: debtor days improved 123 (FY21) -> 84 (FY26); CCC 134 -> 70 days; still WC-intensive (90–120 day credit to PSUs). Contingent liabilities Rs 156–171 cr are mostly BG/LCs (non-fund limit Rs 167 cr) — normal for tender business.
- Cash conversion good: cumulative CFO FY22–26 Rs 152 cr vs PAT Rs 59 cr; FCF positive every year except FY25.
- Moat: approvals/BIS/NABL and PSU vendor status give repeat orders, but industry is fragmented and Cords is a price-taker vs KEI/Polycab/RR Kabel.

## Gate 4 — Valuation: PASS (relative), WATCH (absolute)
P/E 15x, P/B 1.8x, EV/EBITDA ~7.9x (EV ~475 cr / EBITDA 60 cr). Peers: KEI/Polycab/RR Kabel 42–47x, Finolex 28x, Dynamic Cables ~18–21x. Cheap versus peers and versus its own 37% profit CAGR (PEG ~0.4), but the discount is partly deserved: 6% OPM, 11% ROE, 2x interest coverage, no capacity capex. Stock already up 47% in 12 months and 2.3x from the low; 5-yr price CAGR 39% roughly tracked profit CAGR, so re-rating has not yet happened.
3-yr cases: Bull — sales 15% CAGR, OPM to 7%, PAT ~Rs 50 cr, 18x = Rs 900 cr mcap (+145%). Base — 12% growth, OPM flat, PAT ~35 cr, 14x = Rs 490 cr (+33%). Bear — copper spike/power-cable price war, OPM 5%, PAT ~18 cr, 10x = Rs 180 cr (-50%).

## Verdict: HOLD-FOR-REVIEW
1. Cheapest listed cable play (15x) with a 20%+ growth record, improving receivables and real cash conversion — but ROE 11% and 2x interest coverage mean it is a thin-margin converter, not a compounder, unless margins turn.
2. Governance is "family firm" grade: sons run marketing and finance, Rs 21 cr/yr business with a relative-owned entity, personal GST penalty on the MD, no investor communication since 2023. Not disqualifying, but it caps position size.
3. No capacity expansion disclosed; growth from here depends on order flow and copper, which management cannot control. Review after Q2 FY27 (6 Nov 2026) for order book, OPM >6.5%, and any capex/concall resumption; reject if margins slip or the relative-entity RPT grows.

## Sources
- https://www.screener.in/company/CORDSCABLE/ (financials, shareholding, announcements)
- https://www.careratings.com/upload/CompanyFiles/PR/202510141026_Cords_Cable_Industries_Limited.pdf (CARE rationale Oct 2025: order book, gearing, coverage, WC)
- https://cordscable.com/wp-content/uploads/2025/10/Annual-Report-24-25-modified.pdf (RPTs, remuneration, board, contingent liabilities)
- https://cordscable.com/wp-content/uploads/2025/12/Notice-of-AGM-24-25.pdf (Varun/Gaurav Sawhney remuneration resolutions)
- https://nsearchives.nseindia.com/corporate/CORDSCABLE_30092026165645_Appointment_of_SA.pdf (auditor change)
- https://nsearchives.nseindia.com/corporate/CORDSCABLE_12112025180015_DemandOrder.pdf and https://nsearchives.nseindia.com/corporate/CORDSCABLE_02012026154547_SGST_ORDER31dec_2025.pdf (GST demands)
- https://univest.in/blogs/cords-cable-q1-fy27-results-pat-7-crore (Q1 FY27)
- https://www.whalesbook.com/corporate-news/English/industrial-goodsservices/Cords-Cable-FY26-Revenue-Jumps-20percent-To-indian-rupee954-Cr-Profit-Soars-41percent/6a180a790c0232fe81a8f408 (FY26)
- https://www.valueresearchonline.com/stocks/42919/kei-industries-ltd/peer-comparison/ (peer P/E)
