# Kamat Hotels (India) (NSE: KAMATHOTEL) — Due Diligence, 2 Nov 2026

**Snapshot:** CMP Rs 219 | Mcap Rs 646 cr | P/E 15.4 (TTM) | P/B 2.0 | No dividend | ROCE 15.8% | ROE 11.6% | 52w 140–298 | ADTV ~Rs 0.5 cr (illiquid). Q2 FY27 results due 3 Nov 2026.
Mumbai-based Kamat family (Dr Vithal Kamat CMD; son Vishal Kamat ED; daughter Vidita NED). 24 hotels / ~1,950 keys: Orchid (1,309 keys, 2 owned, 4 leased, 2 revenue-share, 2 managed), IRA by Orchid (464 keys, all leased/rev-share/managed), Lotus, Fort JadhavGadh, Toyam. Orchid Mumbai (372 keys) + Orchid Pune (386) are ~70–75% of revenue.

## VERDICT: REJECT

1. **Flagship asset sits on promoter-owned land:** The Orchid Mumbai is operated on leasehold land of Plaza Hotels Pvt Ltd (PHPL, 16% promoter shareholder). KHIL pays PHPL Rs 6.0 cr/yr royalty (cap Rs 10 cr), has parked Rs 80 cr interest-free deposits with PHPL, carries a Rs 13 cr advance to PHPL whose interest is accruing (receivable Rs 2.3 cr) rather than being paid, and shareholders have pre-approved RPTs with PHPL of up to Rs 90 cr p.a. for 30 years. The listed company bears the debt (Axis Finance loan secured on the Orchid Mumbai structure) while the promoter entity owns the land. This is a structural minority-shareholder disadvantage, not a one-off.
2. **Chronic over-promising:** FY25 guided ~Rs 400 cr revenue / Rs 140 cr EBITDA and ">300 keys" -> delivered Rs 357 cr / Rs 105 cr / ~220 keys. FY26 targets (ARR Rs 7,500, revenue Rs 400 cr) -> Orchid ARR ~Rs 6,000–6,300, revenue Rs 386 cr, EBITDA margin down to 25% from 29%. Dehradun has slipped from Dec-24 to Dec-26; Gwalior Dec-25 to Nov-26; Mandvi Dec-25 to Dec-27. Management now declines to give FY27 numbers.
3. **Deteriorating quality of earnings behind the "cheap" multiple:** OPM 37% (FY23) -> 30% -> 29% -> 25% (FY26); PAT -17% in FY26; lost the 197-key IRA Mumbai lease (~Rs 50 cr revenue) to the landlord in Mar-26 — the asset-light model's fragility. Pune subsidiary (OHPPL) carries a going-concern "material uncertainty" and a Rs 21.9 cr disputed rent liability. Debt default/ARC/OTS history (FY15–FY23) and 81–98% promoter pledging as recently as 2024.

---

## GATE 1 — GOVERNANCE: FAIL (structural RPT + history), despite recent clean-up

- **Promoter holding/pledge:** 60.9% (FY17–22) -> 64.2% (Jun-24, warrant conversion at Rs 97 when CMP ~Rs 280) -> 57.78% (Sep-24 onward, diluted by Alpha Alternatives' warrant conversion; its Kaushal Biyani sits on the board as NED). Pledge was 88–98% of promoter holding in 2023, 81%/40% in 2024, 0% since Dec-24 — a genuine improvement, but the history matters.
- **Family KMP:** Father (CMD), son (ED), daughter (NED): 3 of 10 directors; 6 independents. Remuneration is restrained: Vithal Rs 1.10 cr, Vishal Rs 1.06 cr (36x median), proposed cap Rs 1.15 cr. Personal guarantees by both on the Axis Finance loan; PHPL, Savarwadi Rubber Agro (promoter entities) are corporate guarantors — promoter entities and listco are financially intertwined both ways.
- **RPTs vs sales:** PHPL royalty Rs 6.0 cr (1.6% of sales) looks small, but the Rs 80 cr interest-free deposit (12% of market cap) and Rs 13 cr advance are the real leakage; Rs 90 cr/yr omnibus approval. Intra-group: Rs 175 cr advance to OHPPL (Pune) with Rs 14.6 cr accrued unpaid interest and investment 46% impaired. Promoter-entity merger (Savarwadi/Treeo, share-swap) was withdrawn Nov-25 after exchange review — positive; replaced by Rs 2 lakh/month land rent + Rs 1 cr deposit to Savarwadi.
- **Auditor:** N.A. Shah Associates LLP, unmodified; EoMs on ED matter, Konark lease expiry (extended only to Sep-26), OHPPL rent arbitration; going-concern uncertainty for OHPPL and MPPL; CARO exceptions on statutory dues and one title deed. No auditor change found.
- **Regulatory/legal:** ED (PMLA) froze KHIL bank accounts in 2023 over Rs 3 cr forfeited earnest money from Micro Leasing & Funding (2013); KHIL deposited Rs 15.67 cr with the court, got it back Apr-25 and paid Rs 5 cr to ED (Jun-25); still "pending final adjudication". Exchange fines Rs 60k x2 (FY25); secretarial lapse on statutory advertisements (FY26). Disputed direct tax Rs 23 cr.
- **Past defaults:** Bank loans taken over by ARCs (FY15–16), default to ARCs, OTS with ~Rs 143 cr haircut (FY23), refinanced via 14% NCDs (Rs 297.5 cr, Acuite C -> BB), fully redeemed Jul-24 with Axis Finance Rs 194 cr facility at 10.75% (now ~9.75%). Clearwater Capital converted debt to 32% equity (2012) and exited at a loss.
- **Positives:** CFO Smita Nanda resigned May-26, replaced by Milind Wadekar (ex-Chalet, Leela) Aug-26; no ESOS granted; promoter stake stable; pledge nil.

## GATE 2 — GUIDANCE & DELIVERY: FAIL

See verdict point 2. Pattern: numeric targets issued early, walked back mid-year ("premature to commit"), misses attributed to owners' delays, elections, Rajkot fire, wage code, LPG shortages. Latest (Aug-26): no FY27 revenue/EBITDA guidance; "~400 keys in 12–15 months" (pipeline deck says 620 keys, but Mandvi Dec-27 and Puri Dec-29); EBITDA margin "30% in 2–3 years"; Q1 FY27 occupancy 66% vs 55%. Q1 FY27 delivery was good (revenue +10%, same-store +17%, EBITDA +36%), but Q1 FY26 was a depressed base (EBITDA margin 22%).

## GATE 3 — FUNDAMENTALS: WATCH

| Rs cr | FY22 | FY23 | FY24 | FY25 | FY26 | TTM |
|---|---|---|---|---|---|---|
| Sales | 144 | 295 | 304 | 357 | 386 | 394 |
| OPM | 25% | 37% | 30% | 29% | 25% | 26% |
| PAT | -23 | 313* | 45 | 47 | 39 | 44 |
| CFO | 31 | 116 | 72 | 66 | 98 | |
*FY23 includes Rs 238 cr exceptional gain on debt settlement.

- Growth: 3y sales CAGR 9%, FY26 +8%, TTM +8%; 3y PAT CAGR -24%. Q4 FY26 sales +19%/PAT +59%; Q1 FY27 sales +10%/PAT +126% (low base).
- Returns: ROCE 16% (26% FY23), ROE 12%. Debt Rs 105 cr, cash Rs 66 cr, net debt Rs 38 cr (0.12x equity); lease liabilities jumped to Rs 57 cr (Ind AS 116 flatters EBITDA as leased keys grow). Interest cover ~2.9x (incl. lease interest).
- Cash conversion strong: FY24–26 CFO Rs 236 cr vs PAT Rs 131 cr. Working capital negative (hotel model). FY26 CFO Rs 98 cr vs capex ~Rs 28 cr.
- Operating KPIs Q1 FY27: Orchid ARR Rs 6,020 (-5%), occupancy 70% (vs 56%), RevPAR +18%; IRA ARR -25%/RevPAR -37% (Mumbai exit), ex-Mumbai flat; JadhavGadh occupancy 32%.
- Capex: minimal (leases); Rs 40 cr Pune renovation flagged Apr-25, now "guidance next quarter". Management says it can borrow up to Rs 300 cr for owned assets — watch for a return to leverage.
- Moat: Orchid Mumbai's airport-adjacent location is genuinely scarce (91% occupancy); the rest of the portfolio is leased/managed mid-market with landlord risk and sub-scale brands.

## GATE 4 — VALUATION: PASS on optics, WATCH on substance

- EV ~Rs 685 cr (Rs 740 cr incl. leases); EV/EBITDA 6.6x TTM (7.2x lease-adjusted); P/E 15.4; P/B 2.0. Peers: Lemon Tree 35x P/E, Chalet 34x, EIH 26x, sector EV/EBITDA 15–25x. Own history: traded 7–8x EBITDA in 2024 too — the discount is persistent, reflecting promoter-land structure, default history, size and illiquidity, not a cyclical trough.
- 3-year scenarios: Bull (FY29 rev Rs 520 cr, 30% margin, 10x) ~Rs 500 (+130%). Base (rev Rs 450 cr, 27%, 7x) ~Rs 290 (+30%, ~9% CAGR). Bear (margin 22%, IRA-type lease losses recur, 5.5x) ~Rs 160 (-27%). Upside exists but requires a re-rating that the governance structure has blocked for a decade.

## What would change the view
PHPL land brought into the listed company (or deposits returned); two consecutive years of guidance met; Orchid-brand ARR back above Rs 7,000 with margin >28%; OHPPL rent dispute resolved; FY27 Q2/Q3 confirming same-store growth without new lease losses.

## Sources
- Screener consolidated page: https://www.screener.in/company/KAMATHOTEL/consolidated/
- FY2025-26 Annual Report (khil.com): https://www.khil.com/uploads/annual-reports/2025-2026/Annual%20Report_KHIL_2025-26.pdf
- FY2024-25 Annual Report (BSE): https://www.bseindia.com/xml-data/corpfiling/AttachHis/7257f1ad-26eb-4849-9c3c-22a7c2d04517.pdf
- Q1 FY27 concall transcript, 12 Aug 2026 (BSE): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=91619422-6ab6-4aff-8451-202d07b13b12.pdf
- Q1 FY27 investor presentation (BSE): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=80721a83-6503-4268-a953-e30fce138a04.pdf
- Q4 FY26 concall transcript, 13 May 2026 (BSE): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2305be40-f4c8-4f29-a9ad-d490ee45b1a0.pdf
- Q4 FY25 concall transcript, 28 Apr 2025 (BSE): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a21e32a8-f8e4-44d6-8725-5a2382406e37.pdf
- Q1 FY25 concall transcript, 13 Aug 2024 (BSE): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=da0ecea5-7a62-4183-a035-05ab7bd815e9.pdf
- Acuite rating rationale (NCD upgrade C -> BB), 23 Jan 2024: https://www.acuite.in/documents/ratings/revised/29060-RR-20240123.pdf ; withdrawal Nov 2024: https://www.acuite.in/documents/ratings/revised/29060-RR-20241106.pdf
- ED court-order intimation, 19 Jun 2025 (NSE): https://nsearchives.nseindia.com/corporate/KAMATHOTEL_19062025195308_IntimationaboutEDCourtOrder.pdf
- Valorem fact sheet Q1 FY27: https://valoremadvisors.com/assets/admin/fact_file/1787228157_Fact_sheet_of_Kamat_hotels_Q1FY27.pdf
- Trendlyne shareholding/pledge: https://trendlyne.com/equity/share-holding/714/KAMATHOTEL/latest/kamat-hotels-india-ltd
- ValuePickr thread (default/OTS/pledge history, member observations): https://forum.valuepickr.com/t/kamat-hotels-india-ltd-a-possible-turnaround-story/11839?page=3
- Outlook Business on Clearwater exit: https://www.outlookbusiness.com/markets/trend/inhospitable-foray-2946
