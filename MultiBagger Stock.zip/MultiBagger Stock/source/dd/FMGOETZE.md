# Federal-Mogul Goetze (India) Ltd (NSE: FMGOETZE) — Due Diligence, 2 Nov 2026

**Business:** Pistons, piston rings, pins, valve seats/guides for ICE engines; #2 in India (~25-30% share). Plants at Patiala, Bengaluru, Bhiwadi; 51% sub Federal-Mogul TPR (steel rings, with Teikoku). FY25 mix: CV/off-highway ~35%, PV 31%, aftermarket/OES 26%, 2W ~10%; exports ~8%. Promoter: Federal-Mogul/Tenneco group (owned by Apollo Global funds since Nov 2022), 74.98%.
**Price/mcap:** Rs 427 / Rs 2,374 cr. P/E 13.1, P/B ~1.65. Screener shows 1.76% yield but the company has paid NO dividend in any year 2010-2026 (treat the yield figure as wrong).

## VERDICT: REJECT
Gates: G1 FAIL / G2 WATCH / G3 PASS / G4 PASS

1. Minority treatment: the open offer triggered by Apollo's Nov 2022 takeover of Tenneco is still not completed four years later — acquirer fought SEBI on terms, SAT ruled for the acquirer (20 Dec 2024), SEBI has appealed to the Supreme Court. Minorities have been denied a regulated exit; the earlier 2019-20 Tenneco open offer mopped up 21.8% (promoter 96.8%) and was then unwound by OFS in 2021 to meet MPS — the parent has twice shown it treats the listing as a nuisance.
2. Cash extraction skewed to the parent: royalty + trademark Rs 44 cr and "management support charges" Rs 34 cr in FY26 (~Rs 78 cr, 4% of sales, ~44% of PAT, both rising) while Rs 700+ cr cash (30% of mcap) earns FD interest and zero dividend has been paid in 15+ years "for operational needs".
3. Pure ICE exposure with no concall/guidance since Aug 2022, an MD who is also the CFO, 10+ board exits/entries in two years, and an ED (FEMA) summons on 2018-25 import/export transactions. Cheap, but cheap for reasons that are unlikely to resolve in minorities' favour.

## GATE 1 — GOVERNANCE: FAIL
- Promoter 74.98% unchanged since Mar 2022 (96.82% Mar 2020 -> 94.91% Mar 2021 -> 74.98% after OFS of 19.9% by IEH FMGI Holdings LLC on 23 Apr 2021). No pledge.
- Open offer saga: DPS 23 Nov 2022 -> draft letter of offer only filed 1 Dec 2023 -> SEBI dispute -> SAT order for acquirer 20 Dec 2024 -> SEBI appeal pending in SC (per FY26 AR). Company line: "does not foresee a financial or other impact on itself." Offer price not located in the pages read.
- RPT (FY26, Rs lakh): royalty/trademark 4,434 (FY25 4,101); management support paid to Federal-Mogul Powertrain LLC 3,374 (3,026); plus group purchases/sales not totalled. Royalty + fees ~4% of sales, ~44% of consolidated PAT 178 cr. Classified "not material", so no shareholder vote.
- No dividend 2010-2026 despite Rs 599 cr free liquidity + Rs 114 cr lien-marked FDs (Feb 2026) and nil debt. Dividend Distribution Policy dates to 2016. Rs 335 cr capex (Oct 2026) is the first real use of cash.
- KMP: Amit Mittal is Managing Director AND CFO since 11 Aug 2025 (no independent finance check). Khalid Iqbal Khan is WTD-Legal and Company Secretary. Director churn FY24-FY26: Hans, Kannan, Chadha, Merry, Vaccari (5 months), Pillai, Sinha, Subramaniam, Khairari (4 months), Johnson out; Mittal, Verma, Dua, Duggal, Jain, Venkataramaiah in. Only 3 of 8 directors independent (one, Nalini Jolly, since 2019).
- Remuneration modest (MD Rs 1.9 cr, WTD Rs 2.2 cr); KMP total Rs 8.7 cr. Auditor Deloitte Haskins & Sells LLP, unmodified; audit-trail/backup-server exceptions in CARO.
- Regulatory: ED summons under FEMA s.37 (7 Mar 2025) seeking 2018-25 export/import details — plausibly transfer-pricing/related-party related; still open. No SEBI fine found.

## GATE 2 — GUIDANCE & DELIVERY: WATCH
- No investor calls or presentations since Aug 2022; FY26 AR outlook: FY27 "a year of consolidation", industry single-digit growth. No quantitative guidance to test.
- Delivered: sales CAGR 12% (FY21-26), OPM 12% -> 16%, PAT Rs 5 cr -> 178 cr, debt-free — a real operational turnaround under the new owner.
- New: Rs 335 cr capex over 18 months at Bahadurgarh, Patiala, Yelahanka, Bhiwadi incl. a valve plant (LOIs from customers) — first growth capex in years; execution unproven. CARE flags margin pressure in near term (RM lag 3-4 months).
- Q2 FY27 (Sep 2026) results not published as of 2 Nov 2026.

## GATE 3 — FUNDAMENTALS: PASS (with ICE caveat)
- 5-yr: sales Rs 1,107 cr (FY21) -> 1,958 cr (FY26), 12% CAGR; PAT 5 -> 178 cr (from a depressed base; 3-yr PAT CAGR 22%). TTM sales 2,001 cr (+9%), PAT 178 (+7%).
- Latest quarters: Q4 FY26 sales 489 (+7%), PAT 51 (-17%); Q1 FY27 sales 526 (+9%), PAT 45 (flat), OPM 13% vs 15%. Margin drifting down from the 21% Q4 FY25 peak.
- ROCE 18.6%, ROE 13.5% (depressed by idle cash). Debt nil (gearing 0.04x), interest cover ~44x.
- Working capital excellent: WC days 13 (from 65 in FY19), debtor days 50, inventory 112. CFO 5-yr sum Rs 1,023 cr vs PAT ~650 cr — strong conversion; FCF FY26 Rs 207 cr.
- Moat: 70-yr OEM relationships (M&M, Bajaj, Maruti, Tata, Hero, AL), top-10 = 55% of sales, Tenneco tech. Structural risk: 100% ICE content; 2W (10%) electrifying first; CV/PV ICE longevity gives 10+ yrs runway, but terminal value is the question.

## GATE 4 — VALUATION: PASS (cheap for a reason)
- P/E 13.1, P/B 1.65; EV ~Rs 1,670 cr after ~Rs 700 cr cash -> EV/EBITDA ~5.5x on TTM EBITDA ~Rs 300 cr; EV/sales 0.8x. Auto-ancillary peer median P/E 28x; Bosch 60x, Schaeffler 41x. 10-yr stock CAGR 0%.
- The discount reflects ICE terminal risk, zero payout, parent-fee leakage, and the unresolved open offer rather than a cyclical trough; cash is unlikely to reach minorities.
- 3-yr cases: Bull — CV upcycle + valves, PAT Rs 260 cr, 15x = Rs 700 (+65%); Base — PAT Rs 210 cr, 12x = Rs 450 (+5%); Bear — margin 12%, PAT 150 cr, 9x = Rs 240 (-45%). Wildcard: a completed open offer / delisting at a court-set price could be the only real catalyst, and it is outside minority control.

## Sources
- https://www.screener.in/company/FMGOETZE/consolidated/ and https://www.screener.in/company/FMGOETZE/
- Annual Report FY26: https://www.bseindia.com/xml-data/corpfiling/AttachHis/55bbd01c-4055-4cc9-86e3-38c323e45eca.pdf
- Annual Report FY25: https://www.bseindia.com/xml-data/corpfiling/AttachHis/12a5227a-c37f-4ef4-a8d5-607b7270b3ff.pdf
- Annual Report FY24: https://www.bseindia.com/xml-data/corpfiling/AttachHis/2497bf62-46e7-4574-835b-f7950b1caf6e.pdf
- Annual Report FY21 (OFS/MPS): https://www.bseindia.com/bseplus/AnnualReport/505744/70779505744_28_09_21.pdf
- Annual Report FY20 (2019-20 open offer): https://www.bseindia.com/bseplus/AnnualReport/505744/65194505744_23_09_20.pdf
- CARE Ratings press release, 2 Apr 2026: https://www.careratings.com/upload/CompanyFiles/PR/202604140442_Federal_Mogul_Goetze_India_Limited.pdf
- Capacity-addition intimation, 9 Oct 2026 (Rs 3,351 mn): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=918611a8-4752-4ba9-8a7e-a10a2f1f9e75.pdf
