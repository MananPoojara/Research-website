# Expleo Solutions (NSE: EXPLEOSOL) — Due Diligence, 2 Nov 2026

**Price ~Rs 813 | Mcap Rs 1,262 cr | 52w 1,179/640 | Promoter (Expleo Group, France) 71.05%, no pledge | FII 0.2%, DII 0.4%**
Chennai-based QA/testing and digital/engineering services, BFSI-heavy (Europe 57%, Asia 33%, N. America 10%). Ex-SQS India BFSI; in 2022 absorbed four unlisted Expleo Indian entities.

Latest reported quarter: Q1 FY27 (Jun-2026). Q2 FY27 (Sep-2026) not yet published (expected ~mid-Nov 2026).

## GATE 1 — GOVERNANCE: WATCH (leaning FAIL)
- **Parent dependence and RPT scale:** 35% of FY26 revenue (~Rs 388 cr) is from Expleo Group entities (30% in Nov-2025, rising). AOC-2 caps approved: up to Rs 450 cr/yr sales to group, Rs 130 cr/yr purchases from group. Management fee to Expleo France Rs 24 cr in FY26 (~14% of PBT), "to continue at similar level". Everything is declared arm's-length; no transfer-pricing dispute was found in the sections read, but the mix means minority economics are set by the parent.
- **Listed-company cash lent to the leveraged parent group:** subsidiaries had Rs 97.5 cr of loans outstanding to Expleo Services SASU (France) and others at Mar-26 (USD 5.5 mn, GBP 2.5 mn, SGD 2 mn) at "9.5-10%"; a Sept-2026 postal ballot sought a standing Rs 280 cr/yr cap for unsecured one-year loans from WOS to Expleo entities in Germany, Austria, Spain, Romania and Switzerland (interested director: Chairman Ralph Gillessen). Parent is ~EUR 1.4 bn revenue at ~10% EBITDA margin — the Indian entity is its cheapest funding source. Classic minority red flag.
- **2022 merger:** four group entities merged for new shares (equity Rs 10 cr → 16 cr); parent holding ~56% → ~71%. Post-merger OPM fell from 20-23% (FY20-21) to 15-16%, ROCE from ~39% to 20-24%; the engineering/auto piece "has shrunk quite a bit" (analyst, May-2026). Minorities were diluted into lower-margin, parent-sourced work. Valuation fairness opinions not reviewed (FY22 AR excerpt did not reach scheme terms).
- **Auditor change:** Kalyaniwalla & Mistry was recommended in FY22 for reappointment to the 29th AGM, yet Deloitte Haskins & Sells was appointed at the 26th AGM (2024) — a mid-term switch, reason not disclosed in material read. Reports since are unqualified.
- Resignations: NED Rajesh Krishnamurthy (Jan-2026, personal reasons); KMP Saket Newaskar (Jul-2026). Four independent directors of good standing (IIM-B, IIIT-B, ex-PE). MD pay Rs 2.4 cr, 20x median — fine.
- Minority-positive: Rs 110/share FY26 final dividend (Rs 171 cr, ~138% payout, paid Sept-2026) after Rs 50 in FY25; 71% of it goes to the parent, which is the point.

## GATE 2 — GUIDANCE & DELIVERY: WATCH
- FY25 AGM: "high single-digit" FY26 growth → delivered +8.1% reported, **-0.4% constant currency**; met only via INR depreciation (Rs 37 cr FX/other income).
- Nov-2025: "healthy double-digit" FY27. May-2026: "sustainable double-digit, EBITDA 15-16%"; Aug-2026 AGM: refused numbers, "double-digit for next few years", Q1 FY27 to be slower (Middle East conflict). Q1 FY27: revenue +12.3% reported (CC not disclosed), EBITDA margin 14.5% (below 15-16% band), PAT +67% on other income.
- M&A: "2 assets in diligence, decide by Q1 CY26" (Nov-25) → "close in upcoming quarter" (May-26) → "within about a quarter" (Aug-26). Slipping for 12 months while cash is lent to the parent.
- CEO is candid on AI deflation: same work now delivered in 40-50% of effort, "bulk of productivity gains passed to customers", ticket sizes shrinking — i.e. management itself describes structural price deflation in the core business.

## GATE 3 — FUNDAMENTALS: WATCH
- 5-yr CAGR (FY21-26): sales 30% (merger-inflated), PAT 20%. **3-yr: sales 7%, PAT 0%** (FY23 Rs 134 cr → FY26 Rs 124 cr). 10-yr stock CAGR 1%, 5-yr -5%.
- TTM: sales Rs 1,140 cr (+10%), PAT Rs 138 cr (+47%, other-income and FX driven). Last two quarters YoY: Q4 FY26 sales +12% (CC +0.7%), PAT +74%; Q1 FY27 sales +12%, PAT +67%.
- OPM 15-16% (vs 22% FY23); wage inflation 8-10% absorbed only by bench <6% and cost cuts. ROCE 24%, ROE 19%.
- Debt-free; cash Rs 376 cr (Mar-26), ~Rs 190 cr after the Rs 171 cr dividend. Debtor days 76, stable. Cash conversion FY22-26: cumulative CFO Rs 416 cr vs PAT Rs 519 cr = 80% (FY25-26 strong). Capex low (new Bengaluru aero/defence lab).
- Headcount flat (3,683 delivery); top-10 clients 51%; active clients 108. Moat: 20-year BFSI test-domain relationships and captive group flow — real but commoditising.

## GATE 4 — VALUATION: PASS (cheap, for a reason)
- P/E 8.6x TTM, P/B 1.6x, EV/EBITDA ~6x (EV ~Rs 1,070 cr post-dividend / EBITDA Rs 178 cr); pre-dividend ~5x. Historic range for SQS-BFSI/Expleo was ~14-20x; listed mid-cap IT services peers 18-30x.
- Cheap because constant-currency growth is ~zero for two years, margins structurally reset lower post-merger, AI deflation acknowledged, and a 71% parent treats the company as a funding and delivery arm. Cyclical trough argument (Europe offshoring, aero/defence, payments 2028) is plausible but unquantified.
- 3-yr cases (FY29 PAT / multiple): Bull 10% CAGR → Rs 165 cr at 12x = Rs 2,000 cr + dividends (+65%); Base 5% → Rs 143 cr at 9x = Rs 1,290 cr + ~Rs 100/share dividends (+15%); Bear CC decline, FX reverses, 7x on Rs 110 cr = Rs 770 cr (-40%).

## VERDICT: REJECT
1. Governance: 35% of revenue, Rs 24 cr fees and now Rs 100-280 cr of loans flow to/from a leveraged foreign parent holding 71%; the 2022 merger diluted minorities into lower-margin group work and an unexplained auditor switch followed. Not a FAIL on evidence, but too much smell for a small-cap "multibagger" sleeve.
2. No organic growth: FY26 -0.4% CC, FY23-26 PAT CAGR 0%; the CEO himself describes AI deflating ticket sizes 40-50% with gains handed to customers.
3. Cheap but not mispriced: 8.6x earnings with a 13% trailing yield is the market pricing a parent-controlled annuity, not a compounder. Re-look only if (a) CC growth >8% for two quarters, (b) group loans are repaid rather than expanded, and (c) group revenue share stops rising.

## Sources
- https://www.screener.in/company/EXPLEOSOL/consolidated/
- Q4 FY26 transcript (May-14-2026): https://investors.expleo.com/wp-content/documents/Earnings%20Call%20Transcript%20Q4%202025-26.pdf
- Q2 FY26 transcript (Nov-14-2025): https://investors.expleo.com/wp-content/documents/Earnings%20Call%20Transcript%20Q2%202025-26.pdf
- 28th AGM transcript (Aug-26-2026): https://investors.expleo.com/wp-content/documents/28th%20AGM%20Transcript.pdf
- AGM Notice FY26: https://investors.expleo.com/wp-content/documents/AGM-Notice-2025-26.pdf
- Q1 FY27 results: https://investors.expleo.com/wp-content/documents/Unaudited%20Consolidated%20Financial%20Statements%20Q1%202026-27.pdf
- Q1 FY27 presentation: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4bded4e4-934b-4d50-8a32-7428e22ab9dc.pdf
- Annual Report FY26: https://www.bseindia.com/xml-data/corpfiling/AttachHis/396c38f0-c005-47c7-b805-89c4df6f68a7.pdf
- Annual Report FY22 (merger, auditor): https://www.bseindia.com/bseplus/AnnualReport/533121/73823533121.pdf
- Postal ballot notice Sept-2026 (Rs 280 cr loans to group): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1fb387be-45ca-4777-8697-8c850fde39c3.pdf
- Board: https://investors.expleo.com/board-of-directors/ ; Financials: https://investors.expleo.com/financial/
