# Aries Agro Ltd (NSE: ARIES) — Due Diligence, 2 Nov 2026

**Verdict: HOLD-FOR-REVIEW** | G1 Governance: WATCH | G2 Guidance: PASS | G3 Fundamentals: PASS | G4 Valuation: WATCH

Mumbai chelated-micronutrient fertiliser maker (Mirchandani family, est. 1969). Price Rs 430, mcap Rs 559 cr, P/E 11.7, P/B 1.7, EV/EBITDA 7.0, ROCE 21%, ROE 13%. Q2 FY27 (Sep-26) results not yet out (statutory deadline 14 Nov 2026).

## Gate 1 — Governance: WATCH

- **Promoter holding** 52.66%, unchanged every quarter; **no pledge** (Tijori/MarketsMojo). Jimmy Mirchandani (ex-MD, brother of CMD, ~21.6%) **died May 2025**; transmission of ~58 lakh shares to Dr Rahul Mirchandani (now 28.67%) was still in process per Dec-2025 filings. Older history: Jimmy sold small lots 2018–2023 (90k shares Sep-2023); no warrants/preferential issues found.
- **Family KMP**: Rahul Mirchandani is Chairman *and* MD (combined role since Apr-2017). Mrs Nitya Mirchandani (same surname, relationship not disclosed on company site, but RPT filings show lease rent and sitting fees to her) is a non-executive non-independent director since 2014. Akshay Mirchandani (son of a director) receives rent. Six-member board with only 3 independents. Looks like a family board, though the executive layer is thin rather than stuffed with relatives.
- **RPTs**: rent/leases/remuneration to family in lakhs — immaterial vs Rs 970 cr sales. CMD remuneration ~Rs 2.7 cr/yr, ~6% of FY26 PAT (was ~15% of PAT in FY23).
- **The real smell — UAE capital**: Rs ~75 cr of loans to associate Amarak Chemicals FZC got stuck in FY18; 26% was divested to Odyssey Global in FY20 and CRISIL had fully written off the investment by 2022; recoveries are only Rs 10–15 cr/yr. Loans to subsidiary Golden Harvest Middle East (88%) still Rs 72 cr at Mar-26 (declining). Roughly Rs 150 cr of shareholder capital (vs Rs 338 cr net worth) spent a decade parked offshore.
- **Receivables** (historic red flag) genuinely fixed: debtor days 172 (FY15) → 46 (FY26); CRISIL: fund-based limits nil-utilised all FY26.
- No SEBI order found. NSE price-movement clarification Feb-2024 (routine). Maharashtra GST demand Rs 1.7 cr tax + Rs 4 cr interest/penalty, unprovided, under appeal. Auditor: no qualifications found. CRISIL upgraded to A-/Stable (Aug-2026).

## Gate 2 — Guidance & delivery: PASS

- FY26 guidance (Q1 FY26 call): gross revenue Rs 950 cr on Rs 830 cr dealer bookings → delivered Rs 957 cr gross / Rs 970 cr operating income (+20%), PAT +26.5%. FY25 delivered +17%.
- Working-capital reduction promised and delivered (cycle 89 → 64 days by company measure; 115–120 → 30 days per CRISIL).
- FY27 guidance: gross revenue ~Rs 1,010 cr (only ~+5.5%) against Rs 1,084 cr bookings — conservative, but signals growth decelerating to single digits. CRISIL models 8–10% growth, 9–10% margin, capex ≤ Rs 20 cr.
- Soft spots: Lucknow plant has no commissioning date; Jebel Ali sulphur-bentonite contract mentioned once with no figures. No guidance cuts found.

## Gate 3 — Fundamentals: PASS

- Sales CAGR 5y 14%, 3y 16%; PAT CAGR 5y 17%, 3y 32%. FY26 sales Rs 740 cr (+19%), PAT Rs 42 cr (+27%). TTM Rs 779 cr / Rs 47 cr.
- Last two quarters: Q4 FY26 sales Rs 185 cr (+45% YoY) but loss Rs -5 cr (seasonal; Q4 is always loss-making); Q1 FY27 sales Rs 188 cr (+16%), PAT Rs 15 cr (+49%), OPM 14% vs 14%.
- OPM flat 10–12% for five years; no operating leverage despite 2x revenue. ROE only 13% (3y 11%) — adequate, not multibagger-grade.
- Balance sheet: debt Rs 56 cr, gearing 0.17x, cash Rs 49 cr, interest cover 4–5x.
- Cash conversion strong: CFO FY22–26 cumulative Rs 390 cr vs PAT Rs 121 cr (3.2x), helped by receivable release; FCF FY26 Rs 38 cr after Rs 78 cr investing outflow.
- Moat: brand/distribution (1,700+ dealers, 134 brands, market leader in chelates) in a market CRISIL says is ~60% unorganised with low entry barriers. Monsoon-sensitive.

## Gate 4 — Valuation: WATCH

- P/E 11.7, P/B 1.7, EV/EBITDA 7.0. Own history: roughly 10x five years ago, ~13x three years ago; Tijori flags "premium to 3-yr history". Commodity-fertiliser peers trade 7–12x (median ~7x), but Aries has better ROCE and no debt.
- Cheap-ish, but growth is guided to slow and ROE is only 13%, so a re-rating case is weak.
- 3-yr case: bull — EPS Rs 37 → Rs 50 at 12–13x = Rs 600–650 (+40–50%); base — EPS Rs 45 at 11x = Rs 495 (+15%); bear — bad monsoon, EPS Rs 30 at 8x = Rs 240 (-45%).

## Verdict: HOLD-FOR-REVIEW

1. Governance is clean enough on the checklist items (no pledge, no SEBI action, RPTs trivial, receivables fixed, rating upgrade) but ~Rs 150 cr of capital stuck/written off in UAE entities and a family-controlled 6-member board stop it from being a PASS.
2. Fundamentals and cash conversion are genuinely good and the stock is at 11.7x, but management's own FY27 guide (~+5%) and flat 10–12% margins cap the upside; this is a fair-value compounder, not a mispriced multibagger.
3. Review triggers: Q2 FY27 results (by 14 Nov), FY26 annual report RPT/remuneration note, GHME loan repayment progress, Lucknow plant timeline.

## Sources

- https://www.screener.in/company/ARIES/consolidated/
- https://www.crisilratings.com/mnt/winshare/Ratings/RatingList/RatingDocs/AriesAgroLimited_August%2007_%202026_RR_402222.html
- https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AriesAgroLimited_January%2011,%202022_RR_285222.html
- https://www.tijorifinance.com/company/aries-agro-limited/
- https://stockanalysis.com/quote/nse/ARIES/statistics/
- https://ariesagro.com/board-of-directors/
- https://www.arthneeti.com/stocks/aries-agro/concall/q1-fy26-earnings-call-analysis
- https://themachinemaker.com/news/aries-agro-reports-strong-q1-fy27-performance-pat-rises-49/
- https://www.whalesbook.com/corporate-news/English/agriculture/Aries-Agro-FY26-Revenue-Jumps-19percent-To-indian-rupee957-Crore-PAT-Up-265percent/6a196b4f6ec823f1f29183ab
- https://univest.in/blogs/aries-agro-q2-results-fy27-preview-date-expectations
- https://nsearchives.nseindia.com/corporate/ARIES_23052023235959_LettertoNSERPT31032023.pdf
- https://nsearchives.nseindia.com/corporate/ARIES_18112022160530_LettertoNSERPT30.09.2022.pdf
- https://nsearchives.nseindia.com/corporate/ARIES_25022025174525_LettertoNSEGSTOrder25022025.pdf
- https://scanx.trade/stock-market-news/stocks/dr-rahul-mirchandani-increases-shareholding-in-aries-agro-to-28-67/27936047
- https://trendlyne.com/equity/insider-trading-sast/all/ARIES/99/aries-agro-ltd
- https://www.careratings.com/upload/CompanyFiles/PR/Aries%20Agro%20Limited-03-12-2020.pdf

## Primary-source verification (2 Nov 2026)

Sources used: FY2025-26 Annual Report (company site, https://ariesagro.com/wp-content/uploads/2026/09/Annual-Report-2025-26-As-Published.pdf — Rs in lakhs unless stated); Sep-26 shareholding XBRL filed 7 Oct 2026 (https://nsearchives.nseindia.com/corporate/xbrl/SHP_1733730_07102026021440_WEB.xml); Q1 FY27 results filing 11 Aug 2026 (https://nsearchives.nseindia.com/corporate/ARIES_11082026190728_LettertoBSENSEOutComeBM11082026.pdf); AGM Chairman's speech 29 Sep 2026 (https://nsearchives.nseindia.com/corporate/ARIES_29092026154138_ChairmanSpeechPPTFinal.pdf); CRISIL rationale 7 Aug 2026 (link in Sources); NSE announcement list 1 Aug–2 Nov 2026 (api, symbol ARIES).

1. **Promoter pledge — CONFIRMED.** Sep-26 SHP XBRL: promoter & promoter group 52.66%; `WhetherAnySharesHeldByPromotersAreEncumberedUnderPledged = false` (also false for NDU / other encumbrance). Pledge 0%.
2. **Managerial remuneration — CONFIRMED (figures corrected).** Board's Report Sec 197/Rule 5(1): Dr Rahul Mirchandani (CMD) Rs 254.51 lakh = Rs 2.55 cr, **82.1x median** employee pay, +3.19% YoY. Standalone PAT Rs 3,837.15 lakh → **6.6% of PAT** (5.9% of consolidated PAT Rs 4,285 lakh). Other family payments (RPT note 40): rent to Rahul Rs 10.80 L, rent + sitting fees to Nitya Rs 14.40 L, salary to **Armaan** Mirchandani (son) Rs 9.94 L — total promoter-family ≈ Rs 2.9 cr (7.5% of standalone PAT). Correction to Gate 1: the AR discloses Nitya Mirchandani as **spouse** of the CMD and Armaan as son (the note said relationship undisclosed and named "Akshay"). NEW at the Sep-2026 AGM: (a) Rahul re-appointed MD for 5 years from the 11 Aug 2026 board, salary cap Rs 25 lakh/month plus perquisites and commission; (b) **commission to Nitya Mirchandani (promoter, non-executive) up to 1% of net profits from FY27** — a new promoter-family payout line.
3. **RPTs — CHANGED (larger than "trivial"; UAE exposure restated).** Standalone RPT note (FY26): purchases from subsidiaries Rs 5,123.19 L (Mirabelle 4,124.97; Aries Agro Equipments 601.51; GHME 396.70), purchases from associate Amarak Rs 1,216.45 L, sales to subsidiaries/associate Rs 177 L, interest income on GHME loan Rs 264.27 L, resource-sharing Rs 74 L, KMP/relative pay and rent Rs 377 L. Total ≈ Rs 72.7 cr = **10.4% of standalone net revenue (Rs 701.83 cr)**, 7.9% of gross. On a consolidated basis the intra-group purchases eliminate; the non-eliminated RPTs (Amarak Rs 12.5 cr + family pay Rs 3.8 cr) are ≈ Rs 16.3 cr = **2.2% of consolidated net revenue Rs 740.06 cr**. AOC-2: all at arm's length, none non-arm's-length. **Governance observation:** Secretarial Audit Report FY26 records that RPTs with GHME "exceeded the Audit Committee approved limit by Rs 1.79 crore during the quarter ended 31 Dec 2025 due to business exigencies", ratified by the Audit Committee on 13 Feb 2026 (Board's Report, CG report and RPT note all repeat this).
   **UAE balances at 31 Mar 2026 (none provided, all "unsecured, considered good"):**
   - Aries → GHME loan principal Rs 3,925.17 L (Rs 44.39 cr → **Rs 39.25 cr**; refund received FY26 Rs 5.14 cr vs Rs 8.34 cr in FY25), plus interest accrued Rs 35.12 cr (up from 32.47 — interest is accrued, not collected) plus FX translation on the loan Rs 33.99 cr (up from 24.35). Total loan-related receivable from GHME **Rs 108.4 cr, up from Rs 101.2 cr**; plus equity in GHME Rs 20.25 cr.
   - Consolidated: GHME's loans & advances to associate Amarak **Rs 7,195.61 L = Rs 72.0 cr (up from Rs 64.8 cr)** — this, not the Aries→GHME loan, is the "Rs 72 cr"; plus share application money in Amarak Rs 64.79 cr for shares still **not allotted** (GHME auditor note 10), plus Amarak trade receivable Rs 1.55 cr. Consolidated unprovided UAE exposure ≈ **Rs 138 cr vs consolidated net worth ~Rs 340 cr**. GHME's own FY26 accounts wrote off AED 375k of a third-party advance and record "no expense ... for bad or doubtful debts" on the Amarak balance (AED 28.15 mn). So: the Rs 72 cr is **outstanding, unprovided and growing in INR terms**; only the Rs 39 cr principal leg is being repaid (~Rs 5 cr/yr). CRISIL's "Rs 10–15 cr/yr recovery" is not visible in FY26 cash flows.
4. **Auditor — CONFIRMED.** Kirti D. Shah & Associates, Mumbai, FRN 115133W (appointed 2022 for 5 years; a small firm — the sole signing partner also signs the review reports). FY26 standalone and consolidated opinions **unmodified**; consolidated report carries an "Other Matters" paragraph (two subsidiaries and the foreign subsidiary audited by other auditors, Amarak share of loss AED nil) — "our opinion is not modified". Board's Report: "no qualification, reservation or adverse remark"; "no qualifications ... for the last 16 years". Q1 FY27 limited review (11 Aug 2026): clean — "nothing has come to our attention".
5. **Latest quarter & FY27 guidance — CONFIRMED (guidance base clarified).** Q1 FY27 consolidated (filed 11 Aug 2026): gross revenue Rs 237.06 cr, net income from operations **Rs 187.58 cr (+16.4% YoY)**, PBT Rs 19.62 cr (+35%), **PAT Rs 14.85 cr (+49.5%** vs Rs 9.93 cr). Q2 FY27: **no board-meeting intimation filed as of 2 Nov 2026** (NSE list); last year Q2 came on 13 Nov. FY27 guidance (Chairman's AGM speech, 29 Sep 2026): bookings Rs 1,084.40 cr from 1,788 dealers → "estimated FY 2026–27 gross revenue of approximately Rs 1,010 crore"; FY27 "expected to remain challenging" (El Niño risk, 94% monsoon forecast, China fertiliser export curbs, soft farm-gate prices). Bookings and the Rs 1,010 cr guide are **standalone** (AR p.4: FY26 standalone gross Rs 917.64 cr; consolidated gross Rs 956.88 cr), so the guide implies **~+10% standalone**, not the +5.5% the note computed against consolidated. Historic booking→sales conversion 95–99%. CRISIL rationale dated **7 Aug 2026**: A-/Stable (from BBB+/Positive), A2+; text: "Large investments in overseas subsidiary, GHME, and associate company, Amarak ... Operations in Amarak ... were disrupted in fiscal 2018 ... Loans and advances of Rs 75 crore were stuck ... loans and advances extended to group company, GHME, stood at Rs 72 crore as on March 31, 2026 ... reducing gradually, with further repayments expected during fiscal 2027"; "expected to recover Rs 10-15 crore per annum". Medium-term: revenue +8–10%, OPM 9–10%.
6. **Announcements since 1 Oct 2026:** 5 Oct Reg 74(5) certificate; 7 Oct re-lodgement report; 9 Oct AGM minutes (all resolutions passed, incl. Rahul re-appointment and Nitya commission). Nothing else. Also relevant from Sep: 4 Sep 2026 GST Appellate Authority **confirmed** the FY2018-19 ITC demand of **Rs 3.96 cr incl. interest and penalty**; company to appeal to GSTAT (still unprovided). Governance picture unchanged in kind, slightly worse in degree (RPT limit breach, new promoter commission, UAE receivables growing not shrinking).

**Status per item:** 1 CONFIRMED | 2 CONFIRMED (family relationships corrected, new commission) | 3 CHANGED | 4 CONFIRMED | 5 CONFIRMED (guidance base corrected) | 6 CONFIRMED (GST now Rs 3.96 cr confirmed on appeal) | 7 no governance-changing event.

**ARIES: verdict stands HOLD-FOR-REVIEW (not SELECT; no downgrade to REJECT)** — primary sources show the UAE exposure is ~Rs 138 cr consolidated, unprovided and growing in INR, with only ~Rs 5 cr/yr of principal coming back, plus an RPT-limit breach and a new 1%-of-profit commission to the promoter's spouse; that keeps Gate 1 at WATCH and argues against promotion to SELECT, but auditor opinion, pledge, cash conversion and Q1 FY27 delivery are all clean, so it does not fall to REJECT. Re-check on Q2 FY27 (due by 14 Nov).
