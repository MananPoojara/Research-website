# Gateway Distriparks — NSE: GATEWAY / BSE: 543489

Due diligence as of 2 Nov 2026. Price ₹45, market cap ~₹2,264 cr, 52-wk ₹66 / ₹42 (-33% in 1 yr). Q2 FY27 results published 28 Oct 2026 (revised same week for a typo).

## VERDICT: HOLD-FOR-REVIEW

1. Cash machine at a trough multiple: 5-yr CFO ₹1,862 cr vs PAT ₹1,357 cr (137% conversion), ~₹1,400 cr cumulative FCF against a ₹2,264 cr market cap, net-debt-free since Q3 FY26, 4.4% dividend yield, P/B 0.97x, EV/EBITDA ~6.4x vs 3-yr avg ~10.9x, promoters buying in the open market.
2. But no growth: throughput Q2 FY27 191.7k TEU vs 197.6k (-3%), container revenue +1% YoY, H1 PAT -15% (tax regime shift), 3-yr profit CAGR 3%, ROCE drifting 13% → 11%. Multibagger thesis (WDFC double-stack, Indore, Jaipur) keeps slipping right.
3. Governance is family-run and the auditor has carried a qualified review conclusion for several quarters (Benami Act attachment on ₹8.7 cr land advances; ₹184 cr SEIS demand unprovided). Not disqualifying, but not SELECT-grade either.

## GATE 1 — GOVERNANCE: WATCH
- Promoter holding low at 33.93% but rising: 32.32% (Sep 2025) → 33.93% (Mar 2026) via open-market buys by promoter entity Perfect Communications (Mar 2026). Pledge 0% at last available filing (Mar 2025); no pledge disclosures found since. FII 13.4% → 6.8%; DII 12.7% → 29.7% (mutual funds accumulating).
- Family KMP: Prem Kishan Dass Gupta is CMD; sons Ishaan and Samvid Gupta are Joint MDs (Samvid re-appointment for 5 yrs from Feb 2027 put to postal ballot Oct 2026). Gupta also chairs 50.01%-owned listed subsidiary Snowman Logistics. All executive roles are family — an analyst voiced governance discomfort on the Q3 FY26 call. No non-family CEO succession.
- Auditor S.R. Batliboi & Co (EY network) — quality firm, but qualified review conclusion on Q3 FY26, Q4 FY26 and Q2 FY27 results: unable to assess recoverability of ₹8.66 cr land-acquisition advances attached under the Benami Property Act (company has appealed); emphasis of matter on ₹184.1 cr SEIS export-benefit demand (FY16–19) with no provision. Screener lists contingent liabilities of ₹6,660 cr (largely customs/rail bonds and guarantees — composition not verified).
- Snowman step-up (Dec 2024) produced a ₹395 cr fair-value gain and a ₹241 cr write-down in consecutive quarters — FY25 PAT ₹374 cr is not a clean base.
- No SEBI penalties, exchange clarifications or auditor resignations found. Dividend payout 43%.

## GATE 2 — GUIDANCE & DELIVERY: WATCH
- Delivered: container-business EBITDA margin band 24–27% held for 14 quarters (Q2 FY27: 25.2%); net-debt-free target reached Q3 FY26; rakes 35 → 37 by Q3 FY27; Snowman FY27 EBITDA target >₹100 cr (H1 run-rate ~₹50 cr, on track); ₹2–3.25/share dividends.
- Slipped: rail volume growth from WDFC/double-stacking — first JNPT double-stack train only ran 20 Jun 2026, volumes flat; Jaipur (J2) ICD stalled 2+ years in court, now "12–18 months after order"; Indore ICD (₹150 cr, 120k TEU) pushed to Dec 2027/Q4 FY28; Ankleshwar MMLP ramp minimal; 5PL/warehousing growth 1–2% with no new customers in FY27 so far; warehousing margins structurally down from 18% to 10–11%.
- Explanations (container imbalance, erratic vessel schedules, pending Indian Railways tariff rationalisation, West Asia crisis) are plausible but repeated. Management is candid rather than evasive; the Q1 FY27 PAT drop was transparently attributed to moving to Sec 115BAA (tax rate 9.6% → 25.2%, cash tax roughly unchanged as MAT credits were being used anyway).

## GATE 3 — FUNDAMENTALS: WATCH
- Sales (₹ cr): FY22 1,374 → FY23 1,421 → FY24 1,536 → FY25 1,681 → FY26 2,212 (Snowman consolidated) → TTM 2,223. 5-yr CAGR 13%, 3-yr 16%, TTM +8%; organic container revenue FY26 ₹1,607 cr, Q2 FY27 +1% YoY.
- PAT: 224 / 242 / 258 / 374* / 259 → TTM 241 (-6%). Q1 FY27 ₹51 cr (-18%), Q2 FY27 ₹58.5 cr (-12%); PBT before exceptionals H1 +6%.
- OPM 27% → 22% (Snowman mix); container EBITDA/TEU ₹4,900–5,600 stable. ROCE 12–13% → 11%; ROE 11.4%.
- Borrowings ₹603 cr (Sep 2026, incl. Snowman and leases) vs cash — net-debt-free at group level; rated IND AA/Stable; interest coverage comfortable (>8x).
- Debtor days 37 → 59 (FY25) → 44 (FY26); no inventory business.
- CFO FY22–26: 363 / 324 / 321 / 385 / 469 — consistently above PAT. FCF ₹109–370 cr/yr. Capex: Indore ₹150 cr, owned/electric rakes (replacement), Snowman 24k pallets by mid-2027 (+20k under discussion), hurdle 15% IRR / 7-yr payback.
- Moat: largest private rail-linked ICD network on the NW–JNPT/Mundra corridor (Garhi Harsaru, Ludhiana, Faridabad, Viramgam, Kashipur), 1.54 mn TEU capacity, land bank to double; Snowman is #1 cold-chain. Concor dominates and sets prices; moat is asset-based, not pricing-based.

## GATE 4 — VALUATION: PASS
- P/E 9.5x TTM vs own FY22–24 range 13–20x; EV/EBITDA ~6.4x vs 3-yr avg ~10.9x; P/B 0.97x; yield 4.4%. Peers: Concor ~29x, TCI Express ~26x.
- Cheap for cyclical/stagnation reasons (flat EXIM volumes, tax normalisation, Jaipur stall, qualified review), not structural decline — core EBITDA is at an all-time high.
- 3-yr cases: Bull — WDFC volumes + Indore + Snowman ₹120 cr EBITDA give FY29 PAT ~₹320 cr at 14x = ₹90 (2x + ~13% cumulative dividends). Base — PAT ₹260 cr at 11x = ₹57 (+25% + dividends). Bear — PAT ₹220 cr at 9x = ₹40 (-12%, cushioned by yield).

## What would upgrade to SELECT
Two quarters of rail volume >100k TEU with visible JNPT double-stack traffic, Jaipur court order, removal of the audit qualification, and a non-family CEO/COO appointment. Downgrade to REJECT if the SEIS demand is upheld or promoters stop buying.

## Sources
- https://www.screener.in/company/GATEWAY/consolidated/
- https://www.investing.com/news/company-news/gateway-distriparks-q2-fy27-slides-wdfc-gains-offset-tax-impact-93CH-4978731
- https://www.gurufocus.com/news/9149081/gateway-distriparks-ltd-bom543489-q2-2027-earnings-call-highlights-dfc-doublestack-milestone-snowman-logistics-ebitda-target-and-j2-icd-delay
- https://www.freepressjournal.in/business/gateway-distriparks-reports-q2-fy27-profit-decline-to-5853-crore-revenue-inches-up-to-58013-crore
- https://www.maritimegateway.com/gateway-distriparks-reports-steady-q1-fy27-tax-reset-weighs-on-profit/
- https://scanx.trade/stock-market-news/companies/gateway-distriparks-q1-results-consolidated-net-profit-falls-to-490m-yoy/47465221
- https://www.whalesbook.com/news/English/industrial-goodsservices/Gateway-Distriparks-Debt-Free-Triumph-Marred-by-Audit-Qual-Legal-Clouds/6985b771e769d12df1d613ba
- https://www.whalesbook.com/corporate-news/English/transportation/Gateway-Distriparks-Q2-Profit-Rises-Sequentially-to-Rs-5853-Crore/6ae1ae9dc6c6dccbb9095f85
- https://www.whalesbook.com/corporate-news/English/transportation/Gateway-Distriparks-Promoter-Boosts-Stake-to-426percent-on-Market-Buys/69c9f6732850f02827f59135
- https://www.investywise.com/gateway-distriparks-limited-re-appointment-of-joint-managing-director
- http://www.gatewaydistriparks.com/Uploads/prospectus/2229pdctfile_GDL-Q3FY26EarningsCallTranscript.pdf
- https://gatewaydistriparks.com/Uploads/prospectus/2262pdctfile_Investors_Presentation.pdf
- https://www.valueresearchonline.com/stocks/296960/gateway-distriparks-ltd/
- https://www.tijorifinance.com/company/gateway-distriparks-ltd/financials/
- https://www.motilaloswal.com/share-market/peer-comparison/gateway-distriparks-ltd
- https://trendlyne.com/equity/GATEWAY/gateway-distriparks-ltd/

## Primary-source verification (2 Nov 2026)

All figures below are from the company's own filings (company website / NSE archive). BSE HTML pages and API were blocked; company-site PDFs and NSE XBRL were used instead.

1. **Promoter pledge — CONFIRMED (0%).** Shareholding pattern as at 30.09.2026 (filed 19 Oct 2026): promoter & promoter group 16,95,00,000 of 49,96,43,836 shares = **33.92%** (6 holders: Prem Kishan Dass Gupta, Mamta, Samvid, Ishaan Gupta, Prism International Pvt Ltd, Perfect Communications Pvt Ltd). "Whether any shares held by promoters are encumbered under Pledged? — **No**"; NDU — No; other encumbrance — No. NSE XBRL: `WhetherAnySharesHeldByPromotersAreEncumberedUnderPledged = false`. Note's 33.93% is a rounding difference. **New observation:** holding is 33.92% at Mar-26, Jun-26 and Sep-26 — the open-market promoter buying cited in the note stopped after Mar 2026 (two flat quarters).
   Sources: https://www.gatewaydistriparks.com/Uploads/prospectus/2287pdctfile_SHP30.09.2026.pdf ; https://nsearchives.nseindia.com/corporate/xbrl/SHP_1741381_19102026025455_WEB.xml
2. **Managerial remuneration FY26 — NEW FACT (not in note).** AR FY26, CG report "Details of remuneration paid to Executive Directors" and Note 28: salary/perquisites **nil**; commission Prem Kishan Dass Gupta ₹1,560.00 lakh, Ishaan Gupta ₹780.00 lakh, Samvid Gupta ₹780.00 lakh (= ₹31.20 cr, each +11.4% YoY) + sitting fees ₹12 lakh → **₹31.32 cr for the three family executives**. Sec 197 ratio to median employee pay: **283.64:1 / 141.82:1 / 141.82:1**; median employee pay +5.03%. Ratio to FY26 PAT: **12.1% of consolidated PAT ₹259.36 cr** (₹25,935.62 lakh); 11.7% of standalone PAT ₹268.36 cr. Pay is 100% profit-linked commission, so it rose 11.4% in a year consolidated PAT fell 30.6% (standalone PAT +12.5%). Samvid Gupta's re-appointment (28 Oct 2026, 5 yrs from 7 Feb 2027) is on the same basis: "He shall not be entitled to any salary or perquisites… eligible to receive performance-linked commission… within the limits permissible under the Companies Act."
   Sources: https://www.gatewaydistriparks.com/Uploads/prospectus/2271pdctfile_AnnualReport2025-26.pdf (Sec 197 statement; CG report; Note 28) ; https://www.gatewaydistriparks.com/Uploads/prospectus/2292pdctfile_Re-appointmentofMr.SamvidGuptaasJointManagingDirector.pdf
3. **Related-party transactions FY26 — CONFIRMED (immaterial).** Consolidated Note 28(b)(ii), transactions with non-consolidated related parties: lease rent received from Newsprint Trading & Sales Corp ₹15.00 lakh, Perfect Communications ₹15.00 lakh, Prism International ₹1.50 lakh = **₹31.50 lakh**; reimbursement from Container Gateway Ltd (JV) ₹0.50 lakh. That is **0.014% of consolidated revenue ₹2,211.82 cr**. Dividends paid to promoter entities ₹4,412.90 lakh (PCL ₹501.34, PIPL ₹3,911.56) are distributions, not trading RPTs. Standalone Note 28 (includes subsidiaries, eliminated on consolidation): rendering of services ₹111.07 lakh, receiving of services ₹957.88 lakh (Snowman hire/KIFTPL), sale of PPE to Snowman ₹1,290.61 lakh, lease rent ₹33.37 lakh, reimbursements ₹70.60 lakh → ~₹24.6 cr = **1.6% of standalone revenue ₹1,577.72 cr**. Board's report: "no materially significant related party transactions… Form AOC-2 is not applicable to the Company for FY 2025-26." Commission payable to executive directors outstanding at 31 Mar 2026: ₹2,808.00 lakh.
   Source: AR FY26 Note 28 (standalone pp.182-185; consolidated).
4. **Auditor and opinion — CONFIRMED (qualified).** Statutory auditor **S.R. Batliboi & Co. LLP**. FY26 standalone and consolidated reports: "**Qualified Opinion** … except for the possible effects of the matter described in the 'Basis for Qualified Opinion' section…". Basis: "orders received under the Prohibition of Benami Property Transactions Act, 1988, and related advances of **Rs. 866.25 lakhs** paid in respect of proposed acquisition of land parcels which are currently under attachment and held as benami property by the Adjudicating Tax Authority… we are unable to comment on the provisions, if any, that may be required… Our audit report for the previous year ended March 31, 2025 was also qualified in respect of this matter." Emphasis of Matter: "demand orders/ notices of **Rs. 18,409.94 lakhs** … challenging the SEIS benefits availed by the Company for financial years 2015-16 to 2018-19 … Our opinion is not modified in respect of this matter." Q2 FY27 (28 Oct 2026) limited review: "The Statutory Auditors have conducted the limited review of the consolidated financial results and have expressed **a qualified conclusion**" — same for standalone; same Benami matter, same SEIS EoM. Note's ₹8.66 cr / ₹184.1 cr figures match.
   Sources: AR FY26 Independent Auditor's Reports (pp.195, 214); https://www.gatewaydistriparks.com/Uploads/prospectus/2291pdctfile_Q2_FY_2026-27_FinancialResults.pdf
5. **Q2 FY27 (quarter ended 30 Sep 2026, consolidated) — CONFIRMED; watch item half met.** Revenue from operations **₹580.13 cr** (+2.3% YoY vs ₹567.32 cr; total income ₹585.57 cr, +2.7%); EBITDA (PBT + finance cost ₹13.24 cr + D&A ₹39.25 cr) **₹131.51 cr** (+6.6%), **margin 22.7%** of revenue (22.5% of total income; press release 131.5 cr); PBT ₹79.02 cr (+15.1%); PAT **₹58.53 cr (−11.7%** vs ₹66.30 cr) on the shift to 25.17% tax (Sec 115BAA) from 9.57%; H1 PAT ₹109.80 cr (−14.5%). Volumes (press release): **Rail 1,02,970 TEU (+1.7% YoY)** — above the 100k/qtr watch level for the first time (Q1 FY27 implied 92,634 TEU); CFS 88,779 (−7.9%); total 1,91,749 (−3.0%). Watch item: rail >100k TEU ✔ (1 of the 2 quarters required); audit qualification removed ✘ (still qualified).
   Sources: Q2 results PDF above; https://www.gatewaydistriparks.com/Uploads/prospectus/2294pdctfile_PressReleaseontheUnauditedFinancialResultsforthequarterendedonSeptember30,2026dated28.10.2026.pdf
6. **Announcements since 1 Oct 2026 — nothing adverse.** NSE list: 8 Oct Reg 74(5) certificate; 13 Oct CRISIL ESG rating assigned; 19 Oct SHP (above); 22 Oct earnings-call intimation; 28 Oct Q2 results, revised press release (typo), re-appointment of Samvid Gupta as Joint MD for 5 years from 7 Feb 2027 (postal ballot), revised PIT fair-disclosure code; 29 Oct newspaper publication. No director/KMP/auditor resignation, no SEBI/exchange action, no new RPT approval, no pledge creation.
   Source: NSE corporate announcements (GATEWAY, 25 Sep–2 Nov 2026); https://www.gatewaydistriparks.com/Uploads/prospectus/2290pdctfile_outcome-of-board-meeting.pdf

Status per item: 1 CONFIRMED · 2 NEW (adds a governance negative: ₹31.3 cr = 12% of PAT, 284x median, all commission) · 3 CONFIRMED · 4 CONFIRMED · 5 CONFIRMED · 6 CONFIRMED.

**GATEWAY: verdict stands SELECT (as HOLD-FOR-REVIEW) — no primary source contradicts a fact the selection rested on; Q2 rail volume cleared 100k TEU, EBITDA at a record, pledge nil, review still qualified. Two items to add to the governance watch: family commission equals 12% of PAT and rises with standalone profit while consolidated PAT falls, and promoter open-market buying has paused since Mar 2026 (holding flat at 33.92% for two quarters — the note's own REJECT trigger is "promoters stop buying"; treat a third flat quarter as the trigger).**

Not verified: the Q2 FY27 earnings-call transcript; BSE-side filings (site blocked, NSE used); Snowman's own filings.
