# Alldigi Tech Ltd (NSE: ALLDIGI, BSE: 532633) — Due Diligence, 3 Nov 2026

**Business:** Chennai-based outsourcer (formerly Allsec Technologies), 73.39% owned by Digitide Solutions (the Quess Corp demerged entity, Fairfax-backed). Two segments: BPM (customer experience, collections, healthcare revenue cycle; 73% of revenue, 83% of it international, US/Philippines delivery) and Tech & Digital/HRO (payroll and HRMS; 27% of revenue, 44% segment margin, 51 lakh employee records a quarter). Mcap Rs 1,267 cr at Rs 832; FY26 revenue Rs 599 cr, PAT Rs 82 cr; TTM revenue Rs 611 cr, PAT Rs 94 cr.

**VERDICT: HOLD (not selected). Re-review at the Q4 FY27 print (May 2027): FY27 revenue growth >=10% with H2 >=8% YoY, no further group-driven KMP exits, no merger/delisting proposal from Digitide. Downgrade to REJECT if FY27 growth <8% or a Digitide scheme appears on unfavourable terms.**

Was in the Oct-31 stage-1 screen (failed the screen's G3 growth filter) and never got a full gate review; reviewed now at the user's request.

## Gate 1 — Governance: WATCH
- **Promoter:** single entity, Digitide Solutions Ltd, 73.39% (1,11,82,912 shares), unchanged for 8+ quarters. **Pledge 0%** (Mar-26 SHP, "Whether any shares held by promoters are pledged or otherwise encumbered? No"); Sep-26 holding identical. Chairman Ajit Isaac (Quess founder).
- **Auditor:** Deloitte Haskins & Sells (FRN 008072S), reappointed Aug 2025 through FY30; FY26 standalone and consolidated opinions **unmodified**; secretarial audit clean; no auditor resignation.
- **Related parties small:** FY26 income from Digitide Rs 2.5 cr, expenses to Digitide Rs 1.2 cr, Bluspring Rs 2.7 cr, Terrier Security Rs 2.0 cr; fellow-subsidiary MFXchange US Rs 14.1 cr income vs Rs 13.6 cr expense (pass-through). Ex-dividend RPTs ~Rs 35 cr on Rs 599 cr revenue, ~1% excluding MFXchange. Board states no material RPTs under Reg 23. Dividend paid to parent FY26 Rs 67.1 cr.
- **Smell 1 — parent-driven management churn since the Mar-2025 demerger:** two Quess nominees off the board 14 May 2025; CEO Naozer Dalal (ran the firm for the whole growth phase) "superannuated" 31 Dec 2025, **seat vacant 2.5 months**, filled 18 Mar 2026 by Digitide's COO Natarajan Laxsmanan; CFO Avinash Jain moved to the holding company 21 Jun 2026 (Manish Agarwal in); non-exec director Gurmeet Chahal out 31 May 2026, Digitide's own CEO Sameer Ahluwalia in 1 Jun 2026. Both Ahluwalias (Sameer, Ruchi, Digitide's group CPO) are "employees of the Holding Company"; the AR does not state whether they are related to each other.
- **Smell 2 — audit committee:** 5 members, 4 independent plus **Ruchi Ahluwalia (Digitide employee)**. Legal, but the parent sits on the committee that polices parent dealings.
- **Smell 3 — cash upstreaming:** FY26 dividend Rs 91.4 cr = 111% of PAT (Rs 60/share, two interims); FY24 107%, FY22 257%. Now a Rs 48 cr tender buyback at Rs 1,000 (4.8 lakh shares, 3.15%) in which the promoter "intends to participate", so ~Rs 35 cr of it goes to Digitide. Alldigi is being run as the cash engine of a newly listed parent. Q4 FY26 also carried a "one-time leave policy alignment with our holding company".
- Independent directors: 4 of 7 (Bhumralkar, Anandaram, Chalisgaonkar, Lakshmi Sarada), stable; ID pay modest (ratio to median 5-6x). CEO pay Rs 3.0 cr (3.7% of PAT). Disputed: GST demand Rs 18.5 cr (order Jan 2026, appeal Apr 2026, unprovided), income tax Rs 2.7 cr. No SEBI action found.
- **Net:** no family, no pledge, Big-4 auditor, tiny RPTs = passes the Sai Silks test. But a 73% parent that has replaced CEO, CFO and a director in 12 months and extracts >100% of profits is a control risk, and any future Digitide merger/delisting would be decided by the parent. WATCH, not FAIL.

## Gate 2 — Guidance & Delivery: FAIL (revenue) / beat (margin)
- **FY26:** May 2025 "we will continue to grow in mid to high teens"; Oct 2025 "I don't see a challenge in growing in the high teens... I have not been changing our position." **Delivered +9.6%, of which 3.3 pts was rupee depreciation: 6.3% constant currency.** CEO left two months later.
- **FY27:** May 2026 new CEO: "we're looking at the mid-teens again, so we should see the mid-teen growth for this year." **H1 FY27 delivered +4.2%, Q2 +4.0%** (BPM +1.0%, domestic BPM -33% as low-margin work is exited; T&D +12.9%). Second consecutive year at a third of guidance.
- **Margin guidance kept:** "1% to 1.5% margin growth year-on-year" promised; delivered 23.7% (FY25) to 27.1% (FY26) to 28.9% (H1 FY27), 30.2% in Q2. PAT H1 +37.5%, but Q2 PAT includes a Rs 2.6 cr foreign-tax-credit provision reversal (Digitide Q2 disclosure); ex that, Q2 PAT +36%, not +51%.
- Leading indicator the bulls lean on: new ACV Rs 37.2 cr in Q2 (+86%), Rs 82.6 cr in H1 (+107%); "two large wins"; Europe consumer-goods contract "final signing in progress". None of it is in revenue yet. Capex guidance (Rs 20-25 cr/yr plus Rs 20 cr Chennai office) is on track.

## Gate 3 — Fundamentals: WATCH
- Growth: 5-yr sales CAGR 17%, PAT 18%; 3-yr 15%/20%; **TTM 6%/40%** (profit via mix and tax, not volume). BPM FTE down 14% YoY (4,979 to 4,272); T&D FTE flat at ~700 while records processed +7%.
- Quality: ROCE 27.9%, ROE 31.5%; OPM 30.2% latest quarter, highest ever. **CFO FY22-26 Rs 488 cr vs PAT Rs 314 cr (155%)**; FY26 CFO Rs 144 cr, FCF Rs 116 cr; H1 FY27 OCF Rs 70 cr (80% of EBITDA). DSO 74 days (improving).
- Balance sheet: **no financial debt**; the Rs 153-171 cr "borrowings" are Ind AS 116 lease liabilities (Chennai, Bengaluru, Manila leases). Cash and liquid funds Rs 127 cr (Sep-26) after dividends.
- Tax: FY26 consolidated tax Rs 14.2 cr on PBT Rs 96.4 cr = **14.7%**, flattered by Rs 10.3 cr FTC provision reversal and Section 80M relief on Manila dividends; Philippines subsidiary enjoys a concessional regime. Normalised PAT is ~Rs 10 cr lower than reported in FY26. Screener's "tax rate seems low" flag is real.
- Mix: international 69.8% of revenue (63.1% a year ago); BFSI 43%, healthcare 18%. Client concentration is not disclosed in the deck or AR summary (gap).
- Moat: 25-year HRO franchise with 99.9% payroll accuracy and sticky payroll clients; BPM is commoditised and AI-exposed (management itself is repricing to "outcomes, not seats"). The T&D product roadmap (Alldigi 360, Buzzily 2.0) is real but tiny so far.

## Gate 4 — Valuation: PASS
- P/E 13.4x TTM (12.5x on FY27E ~Rs 100 cr); EV/EBITDA 6.4x (EV Rs 1,140 cr ex cash / TTM EBITDA Rs 177 cr); P/B 5.0x on a 31% ROE; FCF yield ~9%; **dividend yield 7.2%** (Rs 60 FY26). Peers: Firstsource 24x, eClerx 20x.
- 5-yr price CAGR 7% vs PAT CAGR 18%: the stock has de-rated steadily; 52-wk range Rs 680-1,000, -8% in a year. Buyback at Rs 1,000 is a 20% premium.
- 3-yr cases (FY29): Bear PAT Rs 85 cr x 11x = Rs 935 cr (-26%, ~-6% with dividends). Base 8% revenue CAGR, PAT Rs 115 cr x 14x = Rs 1,610 cr (+27% plus ~22% cumulative dividends, ~14% CAGR). Bull mid-teens delivered, PAT Rs 150 cr x 18x = Rs 2,700 cr (2.1x). A good income/value holding; a multibagger only if the revenue guidance that has been missed twice is finally met.

## Top 3 reasons
1. **Revenue guidance missed two years running** (mid/high-teens promised, 9.6% then 4.2% delivered) while the CEO, CFO and a director were all replaced by the parent's people within 12 months.
2. **Parent control and cash extraction:** 73% holder, >100% dividend payout plus a buyback it will tender into, a holding-company employee on the audit committee. Governance is clean on paper but minority interests ride on Digitide's decisions.
3. **Cheap and cash-rich** (13x, 7% yield, net cash, 155% cash conversion, record 30% margin) with Rs 83 cr of new ACV booked in H1. That is why it is a HOLD rather than a REJECT: if H2 FY27 shows the ACV converting, this re-rates.

## Sources
- https://www.screener.in/company/ALLDIGI/consolidated/
- Q2 FY27 investor presentation (29 Oct 2026): https://www.alldigitech.com/wp-content/uploads/2026/10/InvestorPPT_29102026.pdf
- Q4 FY26 concall transcript (8 May 2026): https://www.alldigitech.com/wp-content/uploads/2026/05/SEFiling_Transcript_08052026-1.pdf
- Q2 FY26 concall transcript (31 Oct 2025): https://www.alldigitech.com/wp-content/uploads/2025/11/Alldigi_transcript_upload.pdf
- Q4 FY25 concall transcript (May 2025): https://www.alldigitech.com/wp-content/uploads/2025/07/SignedSEFilingInvestorCallTranscript.pdf
- Annual Report FY2025-26 (RPT note 27, tax note 25.1, contingent liabilities note 29, directors report): https://www.alldigitech.com/wp-content/uploads/2026/07/Alldigi-Tech_Annual-Report_All-Pages-Updated-Final-3.pdf
- Shareholding pattern 31 Mar 2026 (pledge nil): https://www.alldigitech.com/wp-content/uploads/2026/04/SHP_31032026_Website.pdf
- Committee composition 1 Jun 2026: https://www.alldigitech.com/wp-content/uploads/2026/06/Composition-of-Various-Committees-of-Directors_01062026-1.pdf
- CFO change intimation (May 2026): https://www.alldigitech.com/wp-content/uploads/2026/05/Alldigi_SEIntimationforappointmentCFO.pdf
- Buyback terms (secondary): https://specialsituationsindia.substack.com/p/alldigi-tech-tender-buyback-at-20 ; Q2 FTC reversal (Digitide Q2 results, secondary): https://www.whalesbook.com/corporate-news/English/technology/Digitide-Solutions-Q2-Profit-Rises-to-Rs-891-Million-ESOPs-Approved/6ae8ba25c6c6dccbb90fa8de
- Not obtained: Q2 FY27 concall transcript (only audio published), Sep-26 XBRL shareholding (BSE blocked; Mar-26 used, promoter count unchanged), client concentration data.
