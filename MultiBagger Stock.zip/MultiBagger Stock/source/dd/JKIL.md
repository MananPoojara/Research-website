# J Kumar Infraprojects (NSE: JKIL) — Due Diligence, 2 Nov 2026

**Snapshot:** CMP Rs 420, mcap Rs 3,181 cr, P/E 8.2, P/B 0.94, ROCE 18.4%, ROE 12.4%, div yield 1.0%. 52-wk range Rs 400–672 (stock −38% in 1 yr). Mumbai-centric urban-infra EPC (elevated corridors/flyovers 48% of book, roads/tunnels 20%, metro 9%). Order book Rs 22,246 cr at 30 Jun 2026 (3.9x FY26 revenue). Q2 FY27 (Sep-26) results not yet published.

## GATE 1 — GOVERNANCE: WATCH
- **Promoters:** Gupta family 46.64%, unchanged for 8 quarters. No pledge shown on Screener (not independently verified). FIIs 11.8%, DIIs 15.3% (stable).
- **Family KMP:** Executive Chairman Jagdishkumar Gupta; both MDs (Kamal, Nalin) are his sons (AR FY26 CG report). Wife Kusum Gupta was a director till ~FY18. CFO Vasant Savla and CS are non-family. Family controls all three top executive seats — classic promoter-run EPC; not nepotism beyond the norm for the sector, but no professional CEO layer.
- **Remuneration:** FY26 Rs 8.0 cr + 7.5 cr + 7.5 cr = Rs 23 cr for the three (5.9% of PAT; 237–253x median employee pay). Up from ~Rs 6.25 cr in FY19 while PAT only ~2.2x in the period. High but shareholder-approved.
- **Regulatory history (the key smell):** Aug 2017 SEBI placed JKIL in its 331 "suspected shell company" list (GSM Stage VI); SAT stayed it within 4 days. Sept 2018 SEBI interim order directed a forensic audit (alleged misrepresentation of financials/misuse of funds via KMP/promoter-linked transactions). Oct 2019 SEBI final order found "no adequate circumstances" and **revoked all directions**. A separate SCN alleging promoters' warrant subscription was funded with company money was quashed; no penalty. An FY16-17 income-tax search is widely reported but I could not verify it from primary sources today. Net: serious allegations, formally closed in the company's favour; still a historical blot.
- **RPTs:** AOC-2 shows Rs 934.8 cr (JKNPL TBM work) and Rs 1,750 cr (J.Kumar-NCC GMLR JV) — these are JV counterparties with NCC, not promoter entities. No non-arm's-length RPTs reported.
- **Auditor:** Todi Tulsyan & Co rotated out after 10 years (Sep 2026); replaced by SPML & Associates — both small regional firms, not a Big-6 affiliate. No qualifications.
- **Other:** 21.4% of institutional votes against re-appointment of ED Pravin Ghag (Sep 2026). RGM (Projects) resigned Oct 2026 "personal reasons" — minor. No exchange penalties in last 3 yrs (AR FY26).

## GATE 2 — GUIDANCE & DELIVERY: WATCH
- **FY26:** Aug-2025 call guided ~15% revenue growth; actual FY26 revenue Rs 5,723 cr, +0.5%. Blamed land acquisition, tree-cutting, GAD approvals. Order inflow only Rs 515 cr in 9M FY26 (ICRA).
- **FY27 (Aug-2026 call):** 15% growth (~Rs 6,500 cr), EBITDA 14–15%; earlier Rs 7,500 cr FY27 target pushed to FY28 (one-year slip). Q1 FY27 revenue +2% — needs H2 hockey-stick. Analyst explicitly flagged the repeat of last year's pattern.
- **Delivered:** margins (14.3–14.7% for 11+ quarters), balance sheet (net cash), working-capital days (103 vs 120 target). Order inflow FY27 YTD ~Rs 5,500 cr + Rs 1,500 cr DMRC L1 vs Rs 8,000–10,000 cr guidance — on track.
- **Execution slippage:** GMLR tunnel (contract Nov-2028, now Jun–Dec 2029), Chennai NHAI packages (Dec-2028), Chennai 20% done. 72% of book still in early billing stage (ICRA).

## GATE 3 — FUNDAMENTALS: WATCH
| | FY23 | FY24 | FY25 | FY26 | TTM |
|---|---|---|---|---|---|
| Sales (Rs cr) | 4,203 | 4,879 | 5,693 | 5,723 | 5,750 |
| OPM | 14% | 14% | 15% | 14% | 14% |
| PAT | 274 | 331 | 391 | 387 | 381 |
| CFO | 220 | 339 | 376 | 1,128 | |
- CAGR: 10-yr sales 14%/PAT 15%; 3-yr 11%/13%; TTM −2%/−5%. Last two quarters: Mar-26 sales −3% YoY, PAT −4%; Jun-26 sales +2%, PAT −6%.
- Cash conversion: CFO/PAT FY23–26 = 2,063/1,383 = 149% (FY26 flattered by advances; FY23–25 ~85%). Debtor days ~95 (steady), WC cycle 44–99 days depending on definition.
- Leverage: gross debt Rs 840 cr (Jun-26, TBM term loan), net cash ~Rs 45 cr, D/E 0.24, interest cover 5.3x (ICRA A+/Positive). Contingent liabilities Rs 4,383 cr = bank guarantees (normal for EPC).
- Capex: Rs 500 cr FY26 (TBMs), Rs 150–200 cr/yr FY27–28.
- Concentration: Maharashtra ~62% of book, top-3 clients ~65% (MMRDA/MMRC/NHAI). Moat: owned TBM fleet and underground-metro track record; real but narrow.

## GATE 4 — VALUATION: PASS
- P/E 8.2 vs peers 15–30x and Screener industry median 14.6; P/B 0.94; EV/EBITDA ~3.9x (EV ~Rs 3,140 cr on ~Rs 805 cr EBITDA). My estimate of its own 5-yr median P/E is ~12–14x (not verified). Cheap because growth has stalled two years running and the 2017–19 SEBI history caps the multiple — cyclical/execution trough, not structural decline (book 3.9x revenue).
- **3-yr case:** Base — revenue Rs 7,500 cr by FY29, PAT ~Rs 500 cr, 10–12x → Rs 5,000–6,000 cr (+60–90%). Bear — revenue flat, PAT ~Rs 370 cr, 7x → Rs 2,600 cr (−18%). Asymmetric.

## VERDICT: HOLD-FOR-REVIEW
1. Governance is a WATCH not a FAIL: the SEBI shell/forensic episode ended with directions revoked and no penalty, promoter holding steady, no pledge; but three family members in all top seats earning Rs 23 cr and a small-firm auditor keep it from PASS.
2. Two consecutive years of ~15% growth guidance delivering ~0% is the main concern; Rs 22,246 cr order book and strong FY27 inflows mean the growth story is credible only if Q2/Q3 FY27 show ≥10% YoY revenue growth. Review after Q2 FY27 results (Nov 2026) and DMRC LoA.
3. Valuation (8x, below book, net cash) is cheap enough that a growth re-acceleration would re-rate it; downside is limited by the balance sheet.

## Sources
- https://www.screener.in/company/JKIL/consolidated/
- Q1 FY27 concall transcript (7 Aug 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=50ee0f3f-64b1-48ee-b6c5-2ee95ad3e22b.pdf
- ICRA rationale 27 Feb 2026: https://www.icra.in/Rationale/ShowRationaleReport/?Id=141316
- Annual Report FY26: https://www.bseindia.com/xml-data/corpfiling/AttachHis/5dfddb1b-e1f2-4ab8-9b87-21f34221ba0a.pdf
- Annual Report FY18 (SEBI GSM/SAT): https://www.bseindia.com/bseplus/AnnualReport/532940/5329400318.pdf
- Annual Report FY19 (SEBI interim order): https://www.bseindia.com/bseplus/AnnualReport/532940/5329400319.pdf
- Annual Report FY20 (SEBI final order revoked, warrants SCN quashed): https://www.bseindia.com/bseplus/AnnualReport/532940/66861532940.pdf
- AGM voting results 24 Sep 2026: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=23c198d9-4a20-41f4-9e76-f65360ec3e04.pdf
- Auditor appointment: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f1d67bd9-9467-401d-869d-fd958ed4ab86.pdf
- SMP resignation 9 Oct 2026: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cb17d77d-d564-4be1-ba07-5648f465f8c7.pdf
- Leadership page: https://www.jkumar.com/our-leadership

*Limitations: web-search budget was exhausted this session; research relied on direct filings. Q2 FY27 results not yet out; promoter pledge and the FY16-17 income-tax search were not verified from primary documents.*

## Primary-source verification (2 Nov 2026)

All figures from the company's own filings (FY26 Annual Report PDF on BSE, NSE XBRL shareholding patterns, NSE announcement archive). BSE HTML/API pages were blocked; BSE PDF downloads and NSE worked. jkumar.com investor pages list no documents.

1. **Promoter pledge — CHANGED (note said "no pledge").** SHP as at 30.09.2026 (NSE XBRL, filed 7 Oct 2026): promoter & promoter group **3,52,94,867 of 7,56,65,506 shares = 46.65%**; `WhetherAnySharesHeldByPromotersAreEncumberedUnderPledged = true`; **80,00,000 shares pledged = 22.67% of promoter holding = 10.57% of total equity.** By holder: Jagdishkumar M. Gupta 40,00,000 of 1,09,71,947 (36.46% of his holding); Kamal J. Gupta 20,00,000 of 30,20,000 (66.2%); Nalin J. Gupta 20,00,000 of 29,86,225 (67.0%). The same 80 lakh shares appear in the Sep-25, Dec-25, Mar-26 and Jun-26 patterns — longstanding, not new. AR FY26 borrowings note lists, among security for the consortium bank facilities: "Pledge of 80 Lakhs company's equity shares (Face Value ₹5/- per share) owned by promoter" alongside "Personal guarantee of Mr. Jagdishkumar M. Gupta, Mr. Kamal J. Gupta, Dr. Nalin J. Gupta, Mrs Kusum J. Gupta and J. Kumar and Co." So the pledge secures the company's own debt (less alarming than personal leverage), but the note's "no pledge" was wrong and Screener's nil figure is unreliable.
   Sources: https://nsearchives.nseindia.com/corporate/xbrl/SHP_1733785_07102026032917_WEB.xml ; Jun-26: https://nsearchives.nseindia.com/corporate/xbrl/SHP_1712290_12082026094512_WEB.xml ; AR FY26 standalone borrowings note.
2. **Managerial remuneration FY26 — CONFIRMED.** Note 34(b) "Payment of salaries, commission and perquisites": Jagdishkumar M. Gupta **₹800.00 lakh**, Kamal J. Gupta **₹750.00 lakh**, Nalin J. Gupta **₹750.00 lakh** = **₹23.00 cr** (FY25 ₹22.12 cr); plus third-generation employees Rachit K. Gupta ₹51.16 lakh and Disha N. Gupta ₹51.16 lakh → family total ₹24.02 cr. Sec 197 ratio to median employee: **252.83x / 237.03x / 237.03x**; median pay +6.69%. Ratio to PAT: **5.9% of consolidated PAT ₹386.89 cr** (6.2% incl. grandchildren); standalone PAT ₹383.55 cr (₹38,355.12 lakh). CFO Vasant Savla ₹88.10 lakh; CS Poornima Reddy ₹58.28 lakh.
   Source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/5dfddb1b-e1f2-4ab8-9b87-21f34221ba0a.pdf — Sec 197 statement (Board's report annexure), CG report remuneration table, Note 34 (standalone p.207).
3. **Related-party transactions FY26 — CHANGED (material new item).** Note 34(b), identical in standalone and consolidated (₹ lakh, FY26 vs FY25):
   - **Rent paid: Key Managerial Personnel 3,548.12 (FY25: nil); Relatives of KMP 4,252.34 (548.09); total 7,800.46 (602.09)** — i.e. **₹78.0 cr of rent to the promoter family in FY26 vs ₹6.0 cr in FY25, a 13x jump, with no footnote explaining the asset or lease term.** This is 3.4x their disclosed remuneration and **20% of PAT**. Related-party list includes J. Kumar & Co., Goldline Advertiser and Goldline Business Center (all proprietorships of Jagdishkumar Gupta) and Mrs Kusum Gupta, whose Andheri (W) property is also mortgaged to the company's lenders.
   - Subcontract given by enterprises owned/influenced by KMP (J Kumar NCC Pvt Ltd, the TBM JV with NCC; AOC-2 contract value ₹934.80 cr approved 6 Aug 2024): **45,828.65 (13,515.00)** = ₹458.3 cr.
   - Unsecured loan given to such enterprise **3,430.00 (nil)** = ₹34.3 cr; interest earned 154.12.
   - Dividends to promoter group 1,411.79; salaries 2,573.61; sitting fees 49.15.
   - Total trading RPTs (rent + subcontract) **₹536.3 cr = 9.4% of FY26 revenue ₹5,723.03 cr**; promoter-family rent alone 1.4% of revenue. AOC-2: "transactions not at arm's length basis — NIL"; material contracts listed are only JKNPL and J.Kumar-NCC (GMLR) JV. The ₹78 cr rent sits below the SEBI materiality threshold (10% of turnover), so it never needed shareholder approval and does not appear in AOC-2. The note's statement that RPTs are "JV counterparties, not promoter entities" is therefore wrong.
   Source: AR FY26 Note 34 (standalone pp.206-207; consolidated p.~270); Form AOC-2 in Board's report.
4. **Auditor and opinion — CONFIRMED (unmodified).** FY26 statutory auditor **Todi Tulsyan & Co.** (FRN 002180C). Standalone: "In our opinion… the aforesaid Financial Statements give the information required by the Companies Act, 2013… and give a true and fair view…" — no qualification, **no Emphasis of Matter**; an "Other Matters" paragraph covers component auditors of 28 joint operations. Consolidated opinion identical in form. Board's report: "an Independent Statutory Auditor has issued an unmodified opinion on the Company's Financial Statements (Standalone & Consolidated)." KAM: revenue recognition on construction contracts. **S P M L & Associates** appointed statutory auditor at the 27th AGM (22 Sep 2026) in place of Todi Tulsyan & Co. Q1 FY27 limited-review conclusion could not be read — the 6 Aug 2026 results PDF is a scanned image.
   Sources: AR FY26 Independent Auditor's Reports; https://nsearchives.nseindia.com/corporate/JKInfra_24092026120329_FINALJKILSELETTER.pdf (AGM proceedings)
5. **Latest quarter = Q1 FY27 (Q2 FY27 not yet filed; NSE shows no board-meeting intimation as of 2 Nov; due by 14 Nov) — CONFIRMED; watch item fails on growth.** Company press release 6 Aug 2026, consolidated: revenue **₹1,511 cr (+2% YoY** vs ₹1,484 cr); EBITDA **₹215 cr (−1%)**, **margin 14.2%** (14.6% Q1 FY26); PBT ₹138 cr (−4%); PAT **₹97 cr (−6%** vs ₹103 cr); cash PAT ₹149 cr; net debt −₹45 cr; working-capital days 103 (99 at FY26); order book ₹22,246 cr. Watch item (≥10% growth with ≥14% margin): margin ✔, growth ✘ (+2%). Decision still hinges on Q2 FY27.
   Sources: https://nsearchives.nseindia.com/corporate/JKInfra_06082026170524_JKIL_Press_Release.pdf ; https://nsearchives.nseindia.com/corporate/JKInfra_06082026144629_Outcome_BM.pdf (scanned)
6. **Announcements since 1 Oct 2026 — minor only.** 9 Oct: resignation of Raj Bahadur Singh, Regional General Manager–Projects (designated SMP), "personal reasons", effective same day (XBRL filed 12 Oct). 12 Oct: Reg 74(5) certificate. No SEBI/exchange action, no director/KMP/auditor change, no new RPT approval, no pledge creation/release, no Q2 board-meeting intimation.
   Sources: https://nsearchives.nseindia.com/corporate/JKInfra_09102026172614_JKIL_SE_intimation.pdf ; https://nsearchives.nseindia.com/corporate/JKIL_ROID_100221_KMP_Doc.zip

Status per item: 1 CHANGED · 2 CONFIRMED · 3 CHANGED · 4 CONFIRMED · 5 CONFIRMED (Q2 pending) · 6 CONFIRMED.

**JKIL: downgrade to HOLD (do not add to the portfolio) — two facts the governance WATCH rested on are contradicted by the company's own filings: 22.7% of the promoter holding (10.6% of equity) is pledged, and FY26 rent paid to the promoter family jumped 13x to ₹78.0 cr (20% of PAT, 3.4x their salaries) with no explanation in the AR or AOC-2 — the same promoter-linked-transaction pattern SEBI investigated in 2017-19. Revisit only after (a) management explains the rent (asset, lease term, valuation) on the Q2 FY27 call and (b) Q2 shows ≥10% revenue growth at ≥14% margin; move to REJECT if the rent is not explained or runs at a similar rate in FY27.**

Not verified: Q1 FY27 auditor review conclusion (scanned PDF, no OCR available); the Q2 FY27 date; what the ₹78 cr rent is for; the 16 Sep 2026 "Appointment of Mr. Milind Gopalrao Wani" filing (role not checked).
