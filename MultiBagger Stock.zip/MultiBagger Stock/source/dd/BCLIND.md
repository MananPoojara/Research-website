# BCL Industries (NSE: BCLIND, BSE 524332) — Due diligence, 2 Nov 2026

**Snapshot:** CMP ₹29.1 | Mcap ₹858 cr | P/E 7.4 | P/B 0.92 | ROCE 13.9% / ROE 13.4% | Div yield 1.2% | 52-wk 25.5–40.1 | Promoter 58.23%
Grain-ethanol/ENA/IMIL distiller (900 KLPD: Bathinda 550 + Svaksha Kharagpur 350, 100% owned since 30 Jun 2026); packaged edible oil exited FY26, soft-oil refinery + oil trading retained. Q2 FY27 results due today (board meeting 2 Nov) — not yet published at time of writing.

## GATE 1 — GOVERNANCE: **FAIL**
- **SEBI action:** Company and MD Rajinder Mittal paid ₹42.9 lakh (Feb 2025) to settle SEBI adjudication for non-disclosure of promoter-group entity Manoj Finvest under LODR 31(4) read with PIT Regulations. Separate exchange fines for LODR 13(3) (₹23,600, paid Jun 2025); FY26 annual report admits 20-day and 1-day delays in Reg 23(9) RPT disclosures. BSE sought a volume clarification on 9 Jun 2026. Pattern of repeated compliance lapses.
- **Cash related-party deal:** Jun 2025 board approved paying ₹30.8 cr cash to Sunita Mittal (wife), Kushal Mittal (son) and promoter-owned Kissan Fats for 69.7 lakh shares (15.2%) of unlisted Pioneer Industries Pvt Ltd, lifting BCL's stake to 19.57% — a minority stake in a promoter-linked private distillery, priced on a CA "fair value" certificate; no shareholder vote reported. This is ~30% of FY25 PAT flowing to the family.
- **Other RPTs:** FY26 Ind AS-24 list includes R.K. Exports (MD's proprietorship), Mittal Enterprises and Kushal Impex (relatives' firms), VKM Township; amounts are in image tables and could not be extracted — unverified.
- **Family KMP:** MD Rajinder Mittal; Joint MD Kushal Mittal (son); Sunita Mittal (wife) is largest holder (16.6%) without a board seat. CEO Varun Gupta (non-family, appointed FY26). Board of 7 with only 3 independents (Bal, Pannu, Neerja Jain); FY26 report lists WTD Sat Narain Goyal and CFO Gulab Singh as "non-executive directors" — internally inconsistent disclosure. R.C. Nayyar retired after 10 years (Aug 2024); no ID resignations found.
- **Pledge:** 75.4 lakh shares (2.55% of equity, 4.38% of promoter holding; Sunita and Kushal 37.7 lakh each) pledged at Jun 2026; management said in Aug 2026 banks agreed to release. Promoter holding rising (56.9% Dec-23 → 58.23%) via open-market buys — positive.
- Auditor AMRG & Associates (FRN 004453N), unqualified FY26; no resignation. MD pay ~₹60 lakh (low vs profit). Infomerics IVR A+/Stable (Oct 2025).

## GATE 2 — GUIDANCE & DELIVERY: **WATCH**
- Feb 2025 guidance: 850 KLPD by FY26 (delivered 900 — met); distillery EBITDA 10–11% (delivered 11–12.4% — met); 150 KLPD Bathinda "within 12 months" (commissioned Jul 2026, ~5 months late); 75 KLPD biodiesel "3–4 months, ~₹250 cr revenue" (built, idle — "prices not remunerative"); Fatehabad 250 KLPD "18 months" — put **on hold** Nov 2025, called "on track, work started, 1.5–2 yrs" in May 2026, **on hold again** Aug 2026. Flip-flopping on the only growth project.
- FY26 structural miss: OMC ethanol allocation came well below expectation; ethanol volume 1.89 lakh KL (flat YoY), output diverted to ENA/SDS where realisations fell to ~₹58/l from ₹70 (oversupply). Q1 FY27 ethanol volume 37.8k KL vs 55.5k KL YoY.
- Latest (May/Aug 2026): +₹300 cr revenue from new 150 KLPD at full utilisation (75% from Q2 FY27), "maintain or improve" 11.8% distillery margin, debt-free in 5 years, ~₹30 cr land sale, no new capex. No formal FY27 revenue/EBITDA numbers — vague on allocation.

## GATE 3 — FUNDAMENTALS: **WATCH**
- 5Y CAGR: sales 14%, PAT 22%; TTM sales −13% (oil exit), PAT +13%. Q4 FY26 sales −19% / PAT −7% YoY; Q1 FY27 sales −24% / PAT +6% YoY; EBITDA margin 10.5% (from 6.8%).
- OPM improving 6–7% (FY17–23) → 9% FY26 → 10.5% Q1 FY27 as low-margin oil exits; distillery EBITDA ₹223 cr FY26 (4-yr CAGR 29%).
- Balance sheet: borrowings ₹569 cr vs equity ₹910 cr (gross D/E 0.63, net 0.43); cash ₹157 cr; interest cover 7.6x. Working-capital days 28 (from 47); receivables 10 days.
- Cash conversion weak until FY26: CFO FY22–25 ₹226 cr vs PAT ₹348 cr (65%); FY26 CFO ₹325 cr vs PAT ₹126 cr flattered by ₹170 cr inventory liquidation. Cumulative capex FY22–26 ≈ ₹850 cr, debt tripled (₹183 → ₹569 cr). Screener flags "possibly capitalising interest".
- Moat: dual ENA/ethanol licence (hard to get), paddy-straw boilers (100% steam/power), maize backward integration — real but policy-dependent; ethanol price fixed by Govt (maize ₹71.86/l unchanged since Jan 2024), FCI-rice ethanol ~at cost.

## GATE 4 — VALUATION: **PASS (cheap, partly for a reason)**
- P/E 7.4 (own 5-yr median roughly 12–15x; stock −24% 1Y, −15% 3Y CAGR), P/B 0.92, EV/EBITDA ≈ 5x (EV ≈ ₹1,270 cr / EBITDA ₹250 cr). Peer Globus Spirits P/E 22.6, ROE 8.8%.
- Cheap because: OMC allocation uncertainty, ENA glut, declining headline revenue, governance discount. Cyclical-policy trough rather than structural decline, but the turn depends on E20+/E30 policy, not the company.
- 3-yr cases: Bull (allocation recovers, Fatehabad built, FY29 PAT ₹180 cr × 12x) ≈ ₹73 (+150%); Base (PAT ₹140 cr × 8x) ≈ ₹38 (+30%); Bear (ENA glut persists, allocation cut, PAT ₹90 cr × 6x) ≈ ₹18 (−37%).

## VERDICT: **REJECT**
1. Governance fails the screen: SEBI settlement for promoter-entity non-disclosure, ₹30.8 cr cash to the family for an illiquid Pioneer stake, relatives' firms as counterparties, pledged promoter shares, and recurring filing lapses.
2. Growth engine is hostage to policy: OMC allocation shortfall forced diversion to ENA at 17% lower realisations; the 250 KLPD Fatehabad project has been "on hold / on track / on hold" within nine months.
3. Optically cheap (P/E 7, P/B 0.9) but with 65% historical cash conversion and ₹569 cr debt; re-examine only if Q2 FY27 shows allocation recovery, the pledge is released and the Pioneer stake is explained or unwound.

## Sources
- https://www.screener.in/company/BCLIND/consolidated/
- https://www.bcl.ind.in/investors-pdf/785/Investor%20Presentation%20Q1%20FY27 (Aug 2026 presentation)
- https://www.bcl.ind.in/investors-pdf/758/Concall%20Transcript%20Q4%20FY26 (27 May 2026 call)
- https://www.bcl.ind.in/investors-pdf/772/50th%20Annual%20Report%202025-26
- https://www.bcl.ind.in/investors-pdf/783/Shareholding%20Pattern%20for%20the%20Quarter%20ended%2030th%20June%202026
- https://www.multibagg.ai/market-pulse/articles/bcl-q1fy27-98073
- https://filingreader.com/news-wire/mumbai/2025-11-18/bcl-industries-shifts-focus-amid-ethanol-allocation-challenges
- https://www.arthneeti.com/stocks/bcl-industries/concall/q3-fy25-earnings-call-analysis
- https://www.infomerics.com/admin/uploads/PR-BCLIndustries-28Oct25.pdf
- https://moneylife.in/article/bcl-industries-md-pay-rs4290-lakh-to-settle-nondisclosure-insider-trading-violation-case/76581.html
- https://www.angelone.in/news/share-market/bcl-industries-to-acquire-additional-stake-in-pioneer-industries
- https://www.whalesbook.com/corporate-news/English/industrial-goodsservices/BCL-Industries-Files-Annual-Compliance-Report-SEBI-Fine-Resolved/6a0343b68b07706dac6ef951
- https://www.screener.in/company/GLOBUSSPR/consolidated/
