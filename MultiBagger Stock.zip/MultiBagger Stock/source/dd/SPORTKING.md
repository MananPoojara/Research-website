# Sportking India (NSE: SPORTKING) — Due-diligence note, 2 Nov 2026

Ludhiana/Bathinda compact cotton & blended yarn spinner (3.79 lakh spindles, 96%+ utilisation), Avasthi family (promoters 74.36%). Price Rs 191, mcap ~Rs 2,405 cr, +88% in 52 weeks. Yarn >90% of revenue; exports 52% (Bangladesh largest, China re-emerging; direct US exposure small, tariff hit was indirect via sentiment and ended Mar-2026 per MD).

## GATE 1 — Governance: WATCH (leaning negative)
- Promoter holding flat at 74.36% since Mar-2024 (69.2% pre-FY21). No pledge disclosed in AR FY26. FII/DII ~1%.
- Family KMP: Munish Avasthi is CMD; wife Anjali Avasthi (non-exec since 2022, 15 yrs in the family garment business) was elevated to Whole-time Director in 2026 — timed with the group's garment business being folded into the listed company. Board: 3 executive/promoter, 3 independent (bare minimum). No ID resignations; auditor SCV & Co LLP (reappointed to 2027), unmodified opinion; BRSR penalties nil.
- Related-party acquisition (the main smell): Board approved (May-2026) buying a majority stake in Marvel Dyers & Processors and the manufacturing facilities of Sobhagia Sales (garments) via slump sale, with land/building leased from Sobhagia. Both are "enterprises in which KMP exercise significant influence"; Sobhagia Sales itself holds 12.74% of Sportking. Consideration "predominantly preferential shares" with only ~Rs 25-30 cr cash — i.e. promoters receive listed stock for their private downstream businesses (~Rs 200-250 cr revenue, no profit disclosed). Valuation not yet disclosed; closing has slipped by a quarter. Watch the Reg 23 minority vote and the valuation report.
- RPT size is small (sales to RPs 0.41%, purchases 0.15% of totals) but receivable from Sobhagia Sales jumped to Rs 8.2 cr from Rs 2.5 cr on Rs 10 cr annual sales, and Rs 2.3 cr of CSR garments were bought from Sobhagia.
- MD pay Rs 2.22 cr (137x median, ~1.9% of PAT, no increase) — reasonable. No SEBI actions found in filings reviewed.

## GATE 2 — Guidance & delivery: PASS
- Nov-2025 (trough): guided H2 FY26 revenue ≈ H1 with similar margins; Odisha ground-breaking in 30-40 days; solar 40 MW from 1 Mar 2026. Delivered: H2 revenue Rs 1,283 cr vs H1 Rs 1,213 cr; solar slipped ~3 months (commissioned Q1 FY27); Odisha first phase still "Q3 FY27" (originally Sep-Oct 2026).
- May-2026: "top line +7-10% next 3 quarters, margins expanding 15-20% QoQ, FY27 revenue Rs 2,700-2,800 cr". Delivered better: Q1 FY27 revenue +20% / EBITDA margin 15.4%; Q2 FY27 revenue +24.5% to Rs 781 cr, EBITDA Rs 155 cr (19.8%), PAT Rs 96.4 cr (+241%). H1 FY27 Rs 1,485 cr — on track.
- Long-term guidance: 15% EBITDA margin through-cycle once Odisha is up; FY22's 28% called an aberration. Capex Rs ~1,000 cr for 1.5 lakh spindles funded Rs 300-350 cr internal accruals + term debt; CRISIL expects debt to peak Rs 1,050-1,150 cr (FY27-28).

## GATE 3 — Fundamentals: WATCH (cyclical, not compounding)
- Revenue FY22→FY26: Rs 2,154 → 2,496 cr (3.8% CAGR; ~14% from FY21). PAT: Rs 409 cr (FY22 peak) → 70 cr (FY24) → 119 cr (FY26); operating margin 25.7% → 5.8% → 8.0%. Textbook cotton-spread cycle.
- TTM PAT ~Rs 229 cr; last two quarters Q1/Q2 FY27 revenue +20%/+25% YoY, PAT +116%/+241% on spreads at 3-yr highs (Rs 133/kg vs 107). Volumes flat (21.2k MT/qtr, plant full) — growth is price/spread.
- ROE 19.7%, ROIC ~15% TTM (FY24-26 ROE was 8-12%). Debt Rs 472 cr Mar-26 (D/E 0.43, cover 13x); borrowings rising to ~Rs 545 cr at Sep-26 and headed to ~Rs 1,100 cr for Odisha. CRISIL A+/Positive (Sep-2026).
- Working capital heavy: receivables ~74 days, inventory ~57 days; CCC ~120 days. Cash conversion is fine cumulatively: CFO FY22-26 Rs 1,086 cr vs PAT Rs 843 cr (1.3x), though FY24 CFO was -Rs 236 cr on cotton stocking.
- Buyback history: FY21 (promoter stake rose 69→74%) and FY24 Rs 67.8 cr; bonus 3:1 FY22; split 10:1 FY26. Dividend Re 1 (0.5% yield).
- Moat: scale, 96% utilisation, Rieter compact yarn, 4-Star Export House, captive solar — cost leadership, not pricing power. Odisha adds 40% capacity in a cotton belt (+4-5% EBITDA margin claimed).

## GATE 4 — Valuation: WATCH
- P/E 10.5x TTM, P/B 1.9x, EV/EBITDA 6.7x — optically cheap but on peak spreads (Q2 EBITDA margin 19.8% vs 10-yr range 10-28%). On a mid-cycle 13-14% margin the stock is ~15-17x. Spinner peers (Vardhman, Nitin, Ambika) trade ~10-18x; Sportking's 5-yr median P/E is single-digit-to-low-teens (not verified from a database).
- 3-yr cases (FY29): Bull — spreads hold, Odisha + acquisitions take revenue to ~Rs 3,800 cr at 15% EBITDA, PAT ~Rs 330-380 cr, EPS ~Rs 25-28 (post preferential dilution), 11-12x → Rs 280-330 (+45-75%). Bear — spreads normalise to FY25-26 level, 11% EBITDA on bigger, more leveraged base, PAT ~Rs 150 cr, EPS ~Rs 11, 9x → Rs 100 (-45%). Asymmetric only if you believe this cycle is structural (China/Bangladesh demand, FTAs, capacity exits).

## VERDICT: HOLD-FOR-REVIEW
1. Governance watch item: promoter-group downstream businesses (Sobhagia Sales, Marvel Dyers) being merged in for preferential shares, with the promoter's wife made WTD — await valuation and minority approval before trusting capital allocation.
2. Earnings are at a cyclical high; "cheap" P/E is on peak spreads, and debt is about to double for Odisha — a spread reversal in FY28 would hit a leveraged balance sheet.
3. Execution record is good (guidance beaten in FY27, Odisha broadly on schedule, CRISIL Positive), so revisit after Q3 FY27 commissioning, the acquisition terms, and evidence that margins hold above 15%.

## Sources
- https://www.screener.in/company/SPORTKING/consolidated/ (shareholding, document links)
- https://stockanalysis.com/quote/nse/SPORTKING/financials/ , .../financials/?p=quarterly , .../cash-flow-statement/ , .../balance-sheet/ , https://stockanalysis.com/quote/nse/SPORTKING/statistics/
- Q2 FY27 press release: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5b567de9-18f5-4640-9950-65e2276332b9.pdf
- Q2 FY27 investor presentation: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fc15aaec-931a-42b1-b538-f30944343dc8.pdf
- Q2 FY27 results: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dfd3e61b-2362-47e7-9a6b-197d9b899686.pdf
- Q1 FY27 transcript (Aug 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fb1984af-8018-4c82-97e0-813a0f40ff9d.pdf
- Q4 FY26 transcript (May 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1f899bf6-5424-4f0a-ba06-0347d04b9297.pdf
- Q2 FY26 transcript (Nov 2025): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5122e281-b333-46b8-b032-97d342b0b0d4.pdf
- Annual Report FY2025-26: https://www.bseindia.com/xml-data/corpfiling/AttachHis/2716b5ba-3087-463e-be1c-6af2b928333e.pdf
- CRISIL rating rationale 8 Sep 2026: https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/SportkingIndiaLimited_September%2008_%202026_RR_404203.html
- https://trendlyne.com/equity/SPORTKING/sportking-india-ltd/ (price), https://sportking.co.in/
