# Confidence Petroleum India (NSE: CONFIPET) — Due Diligence, 2 Nov 2026

**Snapshot (screener.in, 2 Nov 2026):** Price Rs 60.9 | Mcap Rs 2,024 cr | P/E 15.0 | P/B 1.43 (BV Rs 42.7) | ROCE 9.1% | ROE 6.9% | 52w 27–93 | Promoter 60.26%.
Business: LPG cylinder manufacturing, LPG bottling for OMCs, auto-LPG/CNG retail, LPG import/trading. Nitin Khara (CMD/CEO), brother Elesh Khara (director), Nagpur.

## VERDICT: REJECT

1. **Governance smell is thick, not faint.** Income-tax search on 7 Oct 2025 (75+ officers, promoters' and CAs' residences); FY26 audit *qualified* (Rs 12.88 cr GST-ITC gap unreconciled); promoter entity Gaspoint Petroleum pledged 2.61 cr shares (7.86% of company) in Jun 2026 "for working capital"; FY27 RPT ceilings of Rs 3,000 cr (Sneha Petroleum) + Rs 1,000 cr (Gaspoint) = ~85% of FY26 sales; company named in SEBI's 2009 GDR interim-order matter; exchange price-movement queries Mar/Apr 2026.
2. **Growth is low-quality.** Revenue CAGR 40% (5y) but OPM fell 14% to 7%, ROCE 24% (FY19) to 9%, PAT 3y CAGR 5%. Q1 FY27 revenue doubled to Rs 2,409 cr (+117% YoY) at 6% OPM with no public explanation — consistent with low-margin LPG trading routed via the same related parties.
3. **Shareholders funded it.** Borrowings Rs 88 cr (FY21) to Rs 761 cr; equity capital 28 to 33 cr shares via warrants/preferential to promoters (Dec 2022 warrants at Rs 63.5, 1.1 cr to promoter-entity Essenn LPG). Cumulative 5y FCF ≈ Rs –570 cr.

## GATE 1 — GOVERNANCE: FAIL
- **Promoter holding/pledge:** 61.63% (Dec 23) → 55.89% (Mar 24, dilution) → 60.26% (Sep 26). The +4.4 pt rise in Jun–Sep 2026 coincides with strategic partner BW LPG dumping its entire 8.5% off-market (3 Jun 2026; buyer not disclosed in sources seen; strategic agreements terminated). Pledge: Gaspoint Petroleum (promoter) pledged 2.61 cr shares Jun 2026; aggregators put ~41% of promoter holding pledged (unverified against BSE pattern). Retail holder count fell from 1.17 lakh to 96.7k over 2 years.
- **Family KMP:** Nitin Khara (CMD+CEO, combined roles), Elesh Khara (brother, director), Neela Khara (3.2% via transmission), Hiral Yatin Khara (warrant allottee). Closed family board; non-exec director Ketki Save resigned 4 Jun 2026 (same day as BW exit).
- **RPTs:** AGM 2026 sought FY27 RPT limits of Rs 3,000 cr with Sneha Petroleum and Rs 1,000 cr with Gaspoint (five group entities in total). Against FY26 revenue of Rs 4,705 cr this is extraordinary and makes reported revenue/margins hard to trust.
- **Auditor:** FY26 opinion qualified on GST-ITC Rs 12.88 cr; management says reconciliation "in process". Auditor name not verified.
- **Regulatory:** SEBI interim order 4 Jun 2009 (GDR-proceeds matter) named Confidence Petroleum alongside Cals Refineries, Bang Overseas, Temptation Foods; the Oct 2011 order revoked directions only against two trading entities — final outcome vs company not verified. IT raid Oct 2025 with no disclosed outcome. NSE/BSE price-volume clarifications Mar–Apr 2026.
- **Remuneration:** Nitin Khara ~Rs 1.8 cr (FY24, Simply Wall St) — modest vs PAT; not the issue here.

## GATE 2 — GUIDANCE & DELIVERY: FAIL
- Company has historically publicised large CNG/auto-LPG rollout ambitions (GAIL Gas tie-up, 50 CNG stations Bengaluru; 3,150 LPG dealer network), but the Aug 2026 corporate presentation gives **no station count, no capex, no revenue/EBITDA target**. No concall transcripts located for FY26/FY27. Delivery cannot be audited because nothing measurable is promised — a red flag on its own.
- Only "explanation" offered for FY26 was "Middle East conflict affected Auto LPG"; no explanation for 2.2x Q1 FY27 revenue.

## GATE 3 — FUNDAMENTALS: WATCH (deteriorating quality)
| | FY21 | FY24 | FY25 | FY26 | TTM |
|---|---|---|---|---|---|
| Sales (Rs cr) | 863 | 2,698 | 3,146 | 4,705 | 6,001 |
| OPM | 14% | 13% | 10% | 7% | 7% |
| PAT | 49 | 105 | 91 | 97 | 139 |
| Interest | 9 | 74 | 79 | 84 | 84 |
| Borrowings | 88 | 633 | 765 | 761 | |
| ROCE | 12% | 13% | 9% | 9% | |
| CFO | 98 | 263 | 5 | 400 | |
- 5y CAGR: sales 40%, PAT 14%; 3y PAT CAGR 5%. Last 2 qtrs: Mar-26 sales +31%/PAT +26%; Jun-26 sales +117%/PAT +215% (OPM 6%).
- D/E 0.54; EBITDA/interest ~4x, EBIT/interest est. ~2.5–3x. Debtor days 17, CCC 26 — OMC receivables not a problem.
- CFO 5y (FY22–26) Rs 646 cr vs PAT Rs 467 cr — fine in aggregate but wildly lumpy (–125, +263, +5, +400), typical of working-capital timing/trading. CFI –Rs 1,216 cr; FCF negative every year since FY22.
- Rating: Acuite A/Stable (Feb 2026, Rs 324 cr facilities) — adequate credit but rationale not retrievable.
- Moat: thin. Cylinder manufacturing is OMC-tender commodity; bottling margins fixed; retail CNG faces CGD incumbents.

## GATE 4 — VALUATION: WATCH
- P/E 15 (TTM EPS 4.04 inflated by one unexplained quarter), P/B 1.4 on ROE 7% (below cost of equity), EV/EBITDA ≈ 6.6x (EV ~Rs 2,700 cr / TTM EBITDA Rs 407 cr). Optically cheap vs LPG peers (Aegis 30x+), but appropriate for 7% OPM, 9% ROCE, qualified accounts.
- 5y price CAGR –7%, 3y –10%. Stock +43% in 1y, driven by the Q1 FY27 print.
- 3-yr range: bull (growth sticks, OPM back to 10%, PAT Rs 250 cr, 15x) ≈ Rs 110 (+80%); bear (RPT/tax issues crystallise, margin 5%, de-rating to 8x on PAT Rs 120 cr) ≈ Rs 29 (–52%). Skew not attractive given unknowable accounting.

## Sources
- screener.in/company/CONFIPET/consolidated/ (financials, shareholding, announcements)
- The Hitavada, 8 Oct 2025 — IT raid on Nitin Khara-led Confidence Petroleum
- Whalesbook summaries of FY26 audited results (qualified opinion Rs 12.88 cr GST ITC; secured borrowing Rs 173 cr) and Neela Khara transmission (Apr 2026)
- FilingReader 4 Jun 2026 — BW LPG Shipping FZCO exits 8.5% (2.82 cr shares), agreements terminated
- ScanX 3 Jun 2026 — Gaspoint Petroleum pledges 2.61 cr shares (title/snippet only)
- NSE filings 29 Dec 2022, 21 Nov 2023, 2 May 2024 — 2 cr warrants at Rs 63.5 incl. 1.1 cr to Essenn LPG; promoter conversions
- Arthneeti summary of FY26 Annual Report/AGM notice (8 Sep 2026) — RPT ceilings Sneha Petroleum Rs 3,000 cr, Gaspoint Rs 1,000 cr
- Kalkine 21 Aug 2026 — corporate presentation summary (no targets; Q1 FY27 revenue Rs 2,412 cr)
- SEBI PR 142/2011 (watchoutinvestors) — order in GDR matter naming Confidence Petroleum; Acuite rating 6 Feb 2026 (title only); Marketscreener — director resignation 4 Jun 2026
- Not retrieved: full annual report (remuneration, auditor name), Acuite rationale text, concall transcripts, BSE pledge table.
