# Banswara Syntex Ltd — NSE: BANSWRAS / BSE: 503722

**Date:** 2 Nov 2026 | **Price:** Rs 99 (52w range 93–144, -17% in 1 yr) | **Mcap:** Rs 340 cr
**Business:** Vertically integrated Rajasthan textile maker — yarn (33% of FY26 revenue), fabric (42%), garments (24%). Exports to 65+ countries; Toshniwal/Mehra family; incorporated 1976.
**Latest results available:** Q1 FY27 (Jun-26). Board met today (2 Nov) for Q2 FY27; figures not yet on exchange feeds at time of writing. Concall 3 Nov.

## VERDICT: REJECT
Gates: G1 Governance **FAIL** | G2 Guidance **WATCH** | G3 Fundamentals **WATCH** | G4 Valuation **WATCH**

1. Governance churn in the last 7 months is too dense for a Rs 340 cr company: two independent directors gone (Sept-26 resignation of the audit committee chair citing age; Oct-26 cessation with no stated reason), company secretary resigned (May-26) and the replacement withdrew consent (Aug-26), HR chief left (Apr-26), garment business head resigned (30 Oct-26), plus two factory fires in four days (27 and 30 Oct-26). India Ratings has carried a Negative outlook since Jan-25 and re-affirmed it in Jan-26.
2. Three family whole-time directors (Chairman Rakesh Mehra, Vice Chairman R.K. Toshniwal, MD Shaleen Toshniwal) draw roughly Rs 8-10 cr in pay against FY26 PAT of Rs 31 cr and a total dividend of Rs 3.4 cr — the family is paid ~3x what all shareholders receive.
3. Structural, not just cyclical: 10-yr sales CAGR 1%, ROE 6.5% (below cost of capital every year except FY23), borrowings up from Rs 227 cr (FY21) to Rs 475 cr (FY26) while cumulative 5-yr FCF is negative. P/B 0.59 is cheap for a reason.

## GATE 1 — Governance: FAIL
- **Promoter holding** 54.13%, drifting down from 59.1% (2016) and 54.37% (Dec-23); small quarterly declines. **No pledge** — promoters filed a nil-encumbrance declaration for FY26.
- **Family KMP:** Rakesh Mehra (Exec Chairman, WTD, brother-in-law of R.K. Toshniwal), Ravindra Kumar Toshniwal (Vice Chairman, WTD), Shaleen Toshniwal (MD, son; largest individual holder 12.5%), Kavita Soni (WTD). Three of four executive directors are related promoters; remuneration historically split equally with a 1% of net profit cap each, revised again in a 2024-25 filing. Aggregator data: Mehra ~Rs 4.0 cr, R.K. Toshniwal ~Rs 2.5 cr; Shaleen not disclosed in sources found. Executive pay exceeds dividend income — a third-party analysis flagged the same.
- **Board/KMP turnover:** CFO Pankaj Gharat lasted 9 months (May-22 to Feb-23); Kavita Gandhi CFO since May-23. CS churn in 2024 and 2026. Independent directors Ambwani (8 Sept-26, audit committee chair; letter dated Jan-26) and J.M. Mehta (26 Oct-26, reason not found). Audit committee chair vacancy acknowledged on company website.
- **Related parties:** Directors' report says no materially significant RPTs with directors/KMP/relatives (Note 47 not reviewed). JV with TESCA France for automotive fabrics.
- **Credit:** India Ratings IND A / Negative since Jan-25 ("credit metrics to remain stretched"). CRISIL/ICRA withdrew in 2021-22, one citing "issuer not cooperating".
- **SEBI/exchange:** No penalties or price/volume clarifications found. No auditor qualifications found.
- **Operational:** Two fires (BTM dye house spreading to BFL TFO section on 27 Oct; Thermopac at BTM on 30 Oct). Insured; damage "under assessment". Timing right before results and alongside the garment head's exit is uncomfortable.

## GATE 2 — Guidance & Delivery: WATCH
- Q3 FY26 call (Feb-26): "15-20% revenue growth across all divisions in FY27". Q4 FY26 call (May-26): Rs 1,450-1,500 cr (i.e., +6-10%) and 10.5-11% margin. Growth aspiration halved in three months.
- FY26 delivered: total income Rs 1,370 cr (+4.8%), EBITDA margin 10.5% (from 9.0%), PAT Rs 28.4 cr (+33%). Garment utilisation 46% to 72% — the one clear delivery.
- Q1 FY27: income Rs 322 cr (+4%), EBITDA margin 9.1%, PAT Rs 4.4 cr vs loss. Yarn -12% (labour shortage), fabric +25%, garments -8% (export logistics). Annualised run-rate ~Rs 1,290 cr vs Rs 1,450-1,500 cr guide — needs 55% H2 skew as management itself says.
- Capex: FY27 Rs 135-140 cr guided (zero-liquid-discharge, 132 KV line, solar) — on a Rs 340 cr mcap company with Rs 475 cr debt. Management warned near-term margins may dip as raw-material pass-through lags 2-4 quarters.
- Third-party analysts note a "persistent disconnect between aspiration (20%+) and delivery".

## GATE 3 — Fundamentals: WATCH
- **Growth:** Sales CAGR 10-yr 1%, 5-yr 12% (COVID base), 3-yr -3%. PAT CAGR 3-yr -30% (FY23 peak Rs 113 cr to FY26 Rs 31 cr). TTM sales Rs 1,366 cr (+3%), TTM PAT Rs 37 cr.
- **Recent quarters:** Q4 FY26 sales +7.5% / PAT +96% (Rs 11.5 cr); Q1 FY27 sales +3% / PAT Rs 4.6 cr vs -1.4 cr. OPM 7.0% in Q1 after 11.8% in Q4.
- **Margins:** OPM oscillates 8-13% with the textile cycle; no structural uptrend over a decade.
- **Returns:** ROCE 9%, ROE 6.5% (3-yr avg 5.7%). 10-yr avg ROE 9%.
- **Leverage:** Borrowings Rs 475 cr (D/E 0.8x); finance cost Rs 42.6 cr FY26; EBIT/interest roughly 2x. Net debt Rs 472 cr at Jun-26, flat.
- **Working capital:** Inventory days 208, cash conversion cycle 218 days (up from 127 in FY20); debtor days 66 (rising).
- **Cash conversion:** CFO FY22-26 Rs 411 cr vs PAT Rs 248 cr (166%, aided by depreciation ~Rs 55 cr/yr), but capex Rs 470 cr over the same period: cumulative FCF ~ -Rs 66 cr. Capex is funded by debt, not earnings.
- **Moat:** Niche in poly-viscose/wool-blend suiting and bi-stretch fabrics; customers include Uniqlo, Next, Mango, Walmart. Commodity yarn drags; garments are the growth leg but only 24% of mix.

## GATE 4 — Valuation: WATCH
- P/E 8.1, P/B 0.59, EV/EBITDA ~5.7 (EV ~Rs 800 cr / TTM EBITDA ~Rs 140 cr). Own history: P/E typically 5-14 over 5 yrs; P/B 0.6-0.8 range for most of the decade — current is at the low end but not an outlier.
- Peers: Nitin Spinners P/E 17 / P/B 2.0; Sangam India 24 / 2.9; RSWM 12.7 / 0.67. Banswara is cheapest but has the lowest ROE.
- Cheap for a reason: sub-cost-of-capital ROE, rising debt, zero decade growth. A 0.6x P/B on a 6.5% ROE is fair, not a bargain.
- **3-yr cases (FY29):** Bull — revenue Rs 1,600 cr, 11.5% margin, PAT ~Rs 60 cr, 10x = Rs 600 cr (+75%). Base — PAT ~Rs 35 cr, 8x = Rs 280 cr (-18%). Bear — textile downcycle / fire disruption, PAT ~Rs 10 cr, 0.4x book = Rs 150 cr (-55%). Skew does not compensate for governance risk.

## Sources
- https://www.screener.in/company/BANSWRAS/consolidated/
- https://www.bseindia.com/xml-data/corpfiling/AttachHis/ba480090-9ef7-4d60-bf00-b452ec3807cf.pdf (Investor presentation Aug-26)
- https://www.bseindia.com/stock-share-price/banswara-syntex-ltd/banswras/503722/corp-announcements/
- https://www.multibagg.ai/market-pulse/articles/banswara-fy26-94340
- https://www.multibagg.ai/market-pulse/articles/banswara-syntex-dye-house-fire-cmvv2lcqb00a42klzgf4fq2cj
- https://apparelresources.com/business-news/manufacturing/banswara-syntex-posts-strong-fy-26-earnings-growth-sets-higher-revenue-target-fy-27/
- https://www.arthneeti.com/insights/banswara-syntex-q3-fy26-earnings
- https://scanx.trade/stock-market-news/companies/banswara-syntex-promoters-declare-no-encumbrance-on-shares-for-fy26-under-sebi-takeover-regulations/40722817
- https://scanx.trade/stock-market-news/companies/banswara-syntex-q1-results-net-profit-rises-to-4-4-cr-revenue-up-3/47113428
- https://bsmedia.business-standard.com/_media/bs/data/announcements/bse/08012026/ee10fcd1-c12a-43cc-abed-6a3c5d24ad2d.pdf (India Ratings Jan-26)
- https://trendlyne.com/credit-ratings/164/BANSWRAS/banswara-syntex-ltd
- https://www.banswarasyntex.com/cg/
- https://www.indiainfoline.com/company/banswara-syntex-ltd/reports/directors-report
- https://finance.yahoo.com/quote/BANSWRAS.NS/profile/
- https://www.marketscreener.com/quote/stock/BANSWARA-SYNTEX-LIMITED-46728746/news/Banswara-Syntex-Limited-Announces-Resignation-of-Pankaj-Prakash-Gharat-as-Chief-Financial-Officer-42980471/
- https://www.business-standard.com/amp/markets/capital-market-news/banswara-syntex-reports-consolidated-net-profit-of-rs-4-61-crore-in-the-june-2026-quarter-126073100844_1.html
- https://www.stockezee.com/compare/banswras-vs-nitinspin ; https://lemonn.co.in/stocks/banswras/peer-comparison
