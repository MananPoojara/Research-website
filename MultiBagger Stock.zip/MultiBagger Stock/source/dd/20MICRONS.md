# 20 Microns Ltd (NSE: 20MICRONS) — Due Diligence, 2 Nov 2026

**Business:** Vadodara-based micronised industrial minerals (calcium carbonate ~50%, kaolin, talc, barytes) and functional additives/speciality chemicals (precipitated silica, construction chemicals via Sievert JV). Paints 46-48% of revenue, polymers 25%, rubber 9-10%; exports ~14%. Top-5 customers (Asian Paints, Berger, Akzo, Grasim) ~ half of sales. Mcap Rs 582 cr at Rs 165; FY26 revenue Rs 954 cr, PAT Rs 67 cr.

**VERDICT: REJECT (re-review trigger: two consecutive quarters of >10% revenue growth with EBITDA margin back above 13%, plus capex programme >75% deployed).**

## Gate 1 — Governance: WATCH (borderline)
- **Promoter holding flat at 45.04%** for 8+ quarters (Ionix Advanced Materials 24.56%, Ilaben Parikh 9.02%, Rajesh and Atil Parikh 5.73% each). No pledge found on screener/Finology; BSE pledge page could not be fetched, so pledge = "not confirmed zero".
- **Family on payroll: four.** Rajesh C. Parikh (Chairman & MD) and brother Atil C. Parikh (CEO & MD) run the firm; Rajesh's wife Sejal R. Parikh is a Whole-Time Director (salary cap Rs 44.8 lakh), and Atil's wife Purvi A. Parikh is "Senior Executive, Accounts" under a Section 188 related-party resolution (Rs 43.6 lakh). Three of nine directors are family. Positives: Group CFO (Nihad Baluch) and CS (Komal Pandey) are non-family; CFO leads concalls.
- **Promoter pay:** approved salary ceilings Rs 2.86 cr (Rajesh) and Rs 2.33 cr (Atil) plus perquisites; family pay roughly Rs 6-7 cr = ~9-10% of FY26 PAT. High for a Rs 67 cr PAT company.
- **Smell:** May-2026 AGM enabling resolution to extend corporate guarantees up to **Rs 50 cr for borrowings of director-owned entities** (actual exposure stated as Rs 2.5 cr for a JV partner). Analyst question on whether these entities compete with 20 Microns was not clearly answered.
- RPTs: Board states no material RPTs; Eriez Industries Pvt Ltd (Parikh family company) appears only in directorships. Auditor Manubhai & Shah LLP, no change/qualification seen (FY24 report; FY26 report could not be parsed). Disputed dues modest: Rs 4.19 cr mining royalty (Gujarat) + Rs 0.28 cr income tax. No SEBI action found. Independent directors appear stable (one added 2024, one 2025).

## Gate 2 — Guidance & Delivery: FAIL
- **FY25:** guided 10-15% growth (May 2024) → delivered +17.4%. Good.
- **FY26:** guided 15-18% growth, stable margins (May 2025) → cut to 13% (Nov 2025) → **delivered +4.5%** (Rs 954 cr vs 913 cr). Margin 12.9% vs 12.8%. Clear miss.
- **FY27:** management declined formal guidance ("not suitable to give any kind of broader picture"); only "aspirational" 3-yr 18% CAGR, +200-250 bps margin, 18-20% ROCE. **H1 FY27: revenue +1.0%, EBITDA -5.5%, PAT -8.3%; Q2 FY27 revenue +3.2%, EBITDA margin 11.6% (-216 bps), PAT -21%.** Deck gives no specific cause beyond "energy and freight costs".
- **Capex:** Rs 100 cr programme announced May 2025 for "15-18 months, internal accruals" → "slightly deferred" Nov 2025 → only Rs 30 cr (30%) deployed by Sep 2026; Malaysia (40% of plan) now "early FY28"; most projects "by FY30". Vague, slipping.

## Gate 3 — Fundamentals: WATCH
- 5-yr CAGR: sales 15%, PAT 23%; 3-yr: 11%/17%; **TTM: 4%/2%**. Growth has stalled in FY26-27.
- OPM 12-14% band for a decade; latest quarter 11.6%, lowest in 3 years. ROCE 17.3%, ROE 14.5% (ROCE 22% in FY24 → 17% now).
- Balance sheet sound: borrowings Rs 154 cr, gearing 0.3x, net D/E 0.16x, interest coverage ~7.4x, Rs 83 cr cash (Mar-26). CRISIL A/Stable reaffirmed Oct 2026.
- **Working capital deteriorating:** WC days 24 (FY21) → 46 (FY26); cash conversion cycle 78 → 126 days; receivables 68 days; bank limit utilisation averaged **97%** (CRISIL, Aug 2026). CRISIL: "continued support from payables is critical".
- Cash conversion acceptable but lumpy: CFO FY22-26 = Rs 288 cr vs PAT Rs 262 cr (110%); FY25 CFO only Rs 32 cr vs PAT 62 cr, FY26 Rs 104 cr vs 67 cr.
- Mining: 13.5 mn t reserves across six sites in four states; ~30% of raw material captive, 70% bought (36% imported). Two small captive mines bought Q2 FY27 (Rs 7 cr). Regulatory risk (mining bans, royalty) flagged by CRISIL; one Rs 4.19 cr royalty dispute pending.
- Speciality/functional additives ~25% of revenue; new products only 4-5% of sales; 20 Microns Nano Minerals revenue Rs 104 cr (FY25, +18%). Moat: approvals with large paint companies, but customer concentration cuts the other way.

## Gate 4 — Valuation: WATCH
- P/E 9.0x TTM, P/B 1.15x, EV/EBITDA ~5.5x (EV ~Rs 650 cr / EBITDA Rs 119 cr). Dividend yield 0.75%.
- Vs own history: 5-yr price CAGR 23% = profit CAGR 23%, so P/E roughly at its 5-yr median (~9-10x), down from ~14x peak in 2024 (estimate; no direct median series available). Peers: Ashapura Minechem 9.7x, sector median 14.9x.
- Cheap optically, but earnings are flat-to-down and the capex that justifies the 18% CAGR narrative is 30% deployed: **cheap for a reason (growth stall), not a cyclical trough with visible recovery.**
- 3-yr cases (FY29): Bear PAT Rs 55 cr x 8x = Rs 440 cr (-24%). Base PAT Rs 80 cr x 10x = Rs 800 cr (+37%, ~11% CAGR). Bull (18% CAGR delivered, +200 bps) PAT Rs 120 cr x 14x = Rs 1,680 cr (2.9x). Probability-weighted return is not multibagger-grade given delivery record.

## Top 3 reasons
1. **Guidance credibility broken:** FY26 15-18% guide delivered 4.5%; FY27 no guide; H1 FY27 PAT -8%, Q2 -21%; capex 30% deployed after 17 months.
2. **Governance smells for a family firm:** two promoter spouses on payroll, Rs 50 cr guarantee enabler for director-owned entities, promoter pay ~10% of PAT, 97% bank-limit utilisation with lengthening cash cycle.
3. **Valuation not cheap enough for zero growth:** 9x P/E is at its own median with stalling earnings and no near-term catalyst; solar capex (Rs 8 cr EBITDA from Q4 FY27) is the only visible lever.

## Sources
- https://www.screener.in/company/20MICRONS/consolidated/
- Q2 FY27 earnings presentation (30 Oct 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=11fa2614-763b-434d-a5f9-70fd53093ba2.pdf
- Q1 FY27 presentation (Aug 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3b507040-6cc8-4615-bac9-08fb08c1cb2b.pdf
- Q4 FY26 concall transcript (May 2026): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9766489b-d1a3-47cd-91af-8ebc23010595.pdf
- Q2 FY26 transcript (Nov 2025): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d9705dce-b6d9-4501-b79a-4ee4bfd490da.pdf
- Q4 FY25 transcript (May 2025): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=44abedb9-b343-43ce-95e2-ab108cbd6be9.pdf ; PPT: https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=efe1993c-b21f-45f7-bbd5-0c7e4a50913f.pdf
- Q4 FY24 transcript (May 2024): https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7451b273-0401-47f6-9d7d-b7a60280d7f0.pdf
- Annual Report FY2023-24: https://www.bseindia.com/xml-data/corpfiling/AttachHis/58d248ae-100b-4e72-abc9-f034160222ab.pdf (FY26 report at https://www.bseindia.com/xml-data/corpfiling/AttachHis/4be8a863-82ec-4642-82c2-b0bd10618a7a.pdf could not be parsed)
- CRISIL rationale 29 Oct 2026: https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/20MicronsLimited_October%2029_%202026_RR_409308.html ; 13 Oct 2025: https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/20MicronsLimited_October%2013_%202025_RR_380349.html
- https://ticker.finology.in/company/20MICRONS ; https://in.investing.com/equities/20-microns-ltd-company-profile ; https://www.bseindia.com/stock-share-price/20-microns-ltd/20microns/533022/
