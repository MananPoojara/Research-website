# Go Fashion (India) Ltd — NSE: GOCOLORS ("Go Colors")

**Date:** 2 Nov 2026 | **CMP:** ~Rs 254 | **Mcap:** ~Rs 1,335 cr | **52w:** 650 / 233 | **1-yr return:** −62%
**Business:** Women's bottom-wear EBO retailer (Chennai, Saraogi family). ~737 EBOs (est. Sep-26) + ~2,500 LFS counters. Channel mix H1 FY27: EBO 71%, LFS 23%, online 4%, MBO 2%.

## VERDICT: REJECT
1. **Three consecutive guidance misses with shifting explanations** (store adds → closures; "margin recovery from Q2 FY27" → Q2 EBITDA margin fell 460 bps; gross-margin band 62.5–63.5% → 60.8%).
2. **Fundamentals deteriorating, no visible turnaround:** sales −4% TTM, PAT −54% TTM, ROCE 23% (FY18) → 11% (FY26), inventory days (COGS basis) at 387, the worst since FY22.
3. **Not cheap for a shrinking business:** 33x TTM P/E on EPS that has halved; an Income-Tax search in Oct 2025 adds governance noise.

---

## GATE 1 — GOVERNANCE: **WATCH**
- **Promoter holding:** 52.78% (flat Mar-22 to Dec-25) → 54.20% (Mar-26, post Rs 65 cr buyback in which promoters did not participate) → **55.45%** (Jun/Sep-26), implying ~6.6 lakh shares bought in the market (not verified via SAST filings). Held via PKS Family Trust and VKS Family Trust (26.39% each); individuals hold 60 shares each. **No pledge disclosed** in the Feb-2026 buyback PA.
- **Family KMP:** Prakash Kumar Saraogi (MD) and Vinod Kumar Saraogi (NED) are brothers; Gautam Saraogi (CEO & ED) is Prakash's son; Rahul Saraogi (promoter) is not on the board. Classic family firm; CEO is the MD's son. Board chaired by an independent (Srinivasan Sridhar); 4 of 7 directors independent; new ID Sakshi Chopra appointed Nov-2025. No ID resignations found.
- **Remuneration:** CEO Gautam Saraogi Rs 0.9 cr (FY25, flat YoY, 100% salary, below peer median); MD Rs ~1.3 cr annualised (2022 RPT filing). Modest vs PAT of Rs 59 cr. **Not nepotism-priced.**
- **RPTs:** Board states no material RPTs; AOC-2 not applicable. Amounts not itemised in sources I could access.
- **Auditor:** Price Waterhouse Chartered Accountants LLP, 14th–19th AGM term, unmodified opinion FY26. No auditor change.
- **Regulatory:** **Income-Tax Department search 7–11 Oct 2025** at offices, warehouse and stores (Reg 30 filings). One media outlet (JuriShour) reported seizure of ~10 kg gold and Rs 1 cr cash — unverified by the company or any second source; company says "no financial impact ascertained". No SEBI order found. Apr-2026 request to reclassify six promoter-group entities (Corona Creatives/International/Steel, Ava Living LLP, two individuals) with negligible holdings to public — housekeeping.
- **PE exits:** Sequoia/Peak XV fully exited by Jun-2023 (block at Rs 1,135); ICICI Venture sold Rs 190 cr in May-2022. FII 12% → 4% and DII 35% → 24% in the last 12 months, with public rising 3.6% → 16% and retail shareholder count 25k → 36k: institutions are leaving, retail is catching the knife.
- **ESOP dilution:** Share count stable at 5.40 cr (FY22–FY25), 5.26 cr post-buyback; no sweat equity; no meaningful ESOP dilution evident.

## GATE 2 — GUIDANCE & DELIVERY: **FAIL**
| When | Guidance | Delivered |
|---|---|---|
| Start FY26 | 120 net EBO adds | Cut to 80–90 (Oct-25); FY26 actually closed 50+ small stores; ended 802 EBOs |
| Q4 FY26 call (May-26) | ~50 more closures in Q1 FY27, Rs 25 cr savings; FY27 retail area +10–11%; GM 62.5–63.5%; "significant EBITDA margin recovery from Q2 FY27"; positive SSSG by end-FY27 | Q1 FY27: 66 closures; Q2 FY27: 9 opened, 23 closed; retail area +3.3% in H1 (448k sq ft); Q2 GM **60.8%** (−180 bps YoY); Q2 EBITDA margin **25.8%** pre-exceptional vs 30.4% YoY; H1 SSSG **0.2%** |
| Q1 FY27 call (Jul-26) | Inventory days 90–100 by year-end; ad spend 2–3% | Inventory days 94 (company metric) — met |

Explanations shifted from "measured approach" to "festival timing moved LFS dispatches into Q3" to "fabric cost up on geopolitical situation". Rs 9.9 cr of exceptional store write-offs in H1 FY27 on top of Rs 25 cr+ closure costs in FY26. No numeric FY27 SSSG, EBITDA or capex guidance.

## GATE 3 — FUNDAMENTALS: **FAIL (deteriorating, turnaround unproven)**
- **Growth (Rs cr):** Sales FY21 251 → FY23 665 → FY24 763 → FY25 848 → FY26 838 → TTM 831. 5-yr sales CAGR 27% is a COVID-base artefact; 3-yr CAGR 8%; TTM −4%. PAT FY23 83 → FY25 94 → FY26 59 → TTM 41 (3-yr −10%, TTM −54%).
- **Last two quarters:** Q1 FY27 sales 222.8 (flat), PAT 16.5 (−26%); Q2 FY27 sales 217.6 (−3%), PAT 9.0 (−59%).
- **Margins:** OPM (post-Ind AS 116) 32% (FY23–25) → 29% (FY26) → 26% TTM; Q2 FY27 24.2% reported.
- **Returns:** ROCE 19–20% (FY19–20) → 15% (FY25) → 11% (FY26); H1 FY27 annualised ROCE 9.5%, ROE 7.2% (ex-Ind AS).
- **Balance sheet:** Net cash Rs 211 cr (Sep-26); "borrowings" of Rs 530 cr are essentially lease liabilities; interest Rs 50 cr is Ind AS 116 interest. Interest cover (EBIT/interest) ~2x on reported basis, not a solvency issue given no bank debt.
- **Working capital:** Screener inventory days 317 (FY24) → 336 (FY25) → **387 (FY26)**; CCC 302 → 399. Company's own inventory-days metric 100 → 94 (Q2 FY27). Working-capital days 134 (Sep-26). Debtor days 46 (LFS receivables).
- **Cash conversion:** CFO FY22–26 = 33+104+219+199+165 = Rs 720 cr vs PAT Rs 355 cr (post-Ind AS; lease rentals sit in CFF). H1 FY27 pre-Ind AS CFO Rs 52.6 cr vs PAT 25.5 cr — genuine cash generation, no accounting smell. Zero dividend ever; Rs 65 cr buyback at Rs 460 (Feb-26) now 80% above CMP.
- **Capex:** Shift to 700+ sq ft stores, funded internally; target to roughly double retail area in 5 years. No Rs figure given.
- **Moat:** Niche leader in branded women's bottom-wear (~8% share, 93% full-price sales, ASP Rs 827), but SSSG has been flat/negative for ~3 years while Zudio/Westside/online eat the category — the moat is narrowing.

## GATE 4 — VALUATION: **FAIL (not cheap for growth delivered)**
- P/E **33x** TTM (own history: 60–100x post-IPO, so a 5-yr low, but on halved EPS); P/B 1.9x (BV Rs 136); EV/EBITDA ~7.7x reported (incl. lease liabilities) or ~10x on pre-Ind AS EBITDA (~Rs 110 cr). Peers: Trent 84x, Vedant Fashions 31x, Arvind Fashions 37x, Credo 10x.
- **Cheap for a reason:** earnings compressing on flat sales; cash of Rs 211 cr (16% of mcap) is the only cushion.
- **3-yr scenarios:** Bull — PAT recovers to Rs 70 cr, 25x → Rs 1,750 cr (+30%). Base — PAT Rs 50 cr, 22x → Rs 1,100 cr (−18%). Bear — PAT Rs 35 cr, 20x → Rs 700 cr (−48%). Skewed down.

## Re-review triggers
Two consecutive quarters of EBO SSSG >4% **and** EBITDA margin back above 29% **and** no adverse Income-Tax outcome; or price below ~Rs 190 (cash-adjusted P/E <20x).

## Sources
- Screener.in GOCOLORS (standalone/consolidated), quarterly, annual, ratios, shareholding — https://www.screener.in/company/GOCOLORS/
- Q1 FY27 press release & presentation (NSE, 30 Jul 2026); Quartr Q1 FY27 and Q4 FY26 call summaries — https://quartr.com/events/go-fashion-india-limited-gocolors-q1-26-27_F9RnJuYC ; https://quartr.com/events/go-fashion-india-limited-gocolors-q4-25-26_F9RnJVe1
- Q2 FY27 results summary (30 Oct 2026) — https://www.multibagg.ai/market-pulse/articles/go-fashion-q2-profit-decline-ppt-cmvuqabl6001c2hnzzmde4gr1
- Q2 FY26 call summary (store guidance cut 120 → 80–90) — https://quartr.com/events/go-fashion-india-limited-gocolors-q2-25-26_F9RnlJgX
- FY26 Directors' Report (board, auditor, buyback, RPT) — https://www.indiainfoline.com/company/go-fashion-india-ltd/reports/directors-report
- Buyback Public Announcement (SEBI, Feb 2026; promoter holdings) — https://www.sebi.gov.in/sebi_data/commondocs/feb-2026/GO%20Fashion%20(India)%20Limited-PA_p.pdf
- Income-Tax search Reg 30 filings (7 & 13 Oct 2025) — https://nsearchives.nseindia.com/corporate/GOCOLORS_13102025130702_Intimationunderreg30ITsearchcompletedupload.pdf ; JuriShour seizure report (unverified)
- Promoter reclassification request (Apr 2026) — Whalesbook; CEO pay — Simply Wall St (Sep 2025)
- Sequoia exit (Jun 2023) — Business Standard / Business Today
