# Uttam Sugar Mills (NSE: UTTAMSUGAR) — Due diligence, 2 Nov 2026

**Snapshot:** CMP Rs 349 | Mcap Rs 1,332 cr | TTM P/E 14.6 | P/B 1.5 | ROCE 11.4% | ROE 12% | 52-wk 181–401 | Promoter 74.71%, 0% pledged.
Four sugar plants (27,000 TCD; Libberheri-UK, Barkatpur/Shermau/Khaikheri-UP), 122 MW cogen, ~350 KLPD distillery + 40 KLPD grain at subsidiary Uttam Distilleries. Adlakha family; MD Raj Kumar Adlakha (since 2001). CARE A/Stable (upgraded Sep 2025 from BBB in 2022).

## VERDICT: REJECT — G1 WATCH / G2 WATCH / G3 FAIL / G4 FAIL

1. **Earnings are falling while the stock re-rates.** TTM PAT -19%, H1 FY27 EBITDA Rs 49 cr vs 73 cr (-33%), Q1 FY27 PAT Rs 1.3 cr (-91%), Q2 FY27 sales -15%. Yet the stock is +33% in 12 months; P/E has expanded from single digits to 14.6x on depressed earnings.
2. **Ethanol policy has turned against this model.** For ESY 2026-27 OMCs excluded cane juice / syrup / B-heavy ethanol from the tender (only C-heavy and grain allowed). In SS 2025-26 all three UP units ran on B-heavy and Barkatpur on syrup; distillery output rose 32% to 877 lakh BL. Reverting to C-heavy cuts ethanol yield per tonne, pushes more volume into sugar (inventory, working capital, quota dependence) and leaves the 350 KLPD base under-utilised. Grain ethanol margins are thin (maize incentive cut to Rs 68.86/l). Company's own AR concedes ~700 cr litres excess ethanol capacity and 65-75% sector utilisation for 3 years.
3. **Cane and governance frictions.** SS 2025-26 crush fell 25% (floods); FRP up to Rs 365/qtl and SAP +Rs 30 for SS 2026-27 while sugar is ~Rs 4,190/qtl and exports were banned May–Sep 2026. MD remuneration Rs 9.2 cr (FY25: 11.3 cr) = ~7-9% of PBT, 193x median pay.

## GATE 1 — Governance: WATCH
- Promoter holding rose 72.84% (Mar-23) → 74.71% (Sep-26) via creeping acquisition; **no pledge** (BSE Sep-26 filing). Holding co Uttam Adlakha & Sons ~42.7%.
- Board of only 6: MD, one non-family WTD (S.L. Sharma), one non-exec non-independent (G.S. Matta), 3 IDs. Two IDs exited 19 Sep 2024 (term end). No other family member on the board; MD's son Jai Adlakha is a new employee (Rs 3.5 lakh FY26). Relatives listed: wife, two sons, two brothers, two sisters.
- RPTs small: office rent to MD's wife Rs 21 lakh, purchases from Shubham Sugars Rs 38 lakh, preference-share redemptions to promoter entities (Rs 2.5 cr), corporate guarantee from holding co. RPT << 1% of sales. PASS on size.
- **MD pay** Rs 922 lakh (FY26) / Rs 1,126 lakh (FY25) vs PBT Rs 133 / 124 cr; ratio to median 193x. The AGM notice carries Schedule V "inadequate profit" disclosures, i.e. pay needs special-resolution cover. Flag.
- Auditor B.K. Kapur & Co (small Ghaziabad firm, re-appointed to 2030). Emphasis of Matter: Rs 6.6 cr Uttarakhand soft loan unpaid since 2008, interest not accrued since Mar-24. No qualification, no resignation.
- History: CDR proposal considered in 2009; rating only BBB in Sep 2022; sugar-cycle stress but no default found. No SEBI/exchange action found (search budget limited).

## GATE 2 — Guidance & delivery: WATCH
Management gives no numeric guidance; concalls are descriptive. CARE (Sep 2025) expected FY26 PBILDT margin 11.7-11.9% and net debt/PBILDT 2.8-3.0x — delivered 10.4% margin (miss) but debt reduced (CFO Rs 270 cr, borrowings 833 → 722 cr; hit). A reported "400 KLPD by FY27" ambition sits oddly with the AR's own overcapacity warning and CARE's "no major capex" (CWIP only Rs 23 cr). Branded/speciality sugar target 18% → 30% of sales, no timeline.

## GATE 3 — Fundamentals: FAIL
- Sales FY24/25/26: 2,047 / 1,846 / 2,202 cr; PAT 132 / 86 / 101 cr. TTM sales 2,092 (-5%), PAT 91 (-19%). 5-yr growth roughly mid-single-digit sales, low-teens PAT (cycle-driven).
- OPM 13% → 12% → 10%; Q1/Q2 FY27 4.3% / 4.6% (off-season quarters, but worse than last year's 8.0% / 3.9% average).
- ROCE 11%, ROE 12%. Borrowings Rs 722 cr at Mar-26 (D/E 0.82; peak season) vs Rs 72 cr at Sep-26 — Screener's "almost debt-free" is a seasonal artefact. Interest cover ~3.5x FY26, ~4x TTM.
- Working capital: inventory days 227 → 313 → 209; CCC 180-242 days; CC limit Rs 905 cr, 84% average utilisation.
- CFO 33 / 102 / 270 cr vs PAT 132 / 86 / 101 (3-yr CFO 405 vs PAT 319) — cash conversion OK, inventory-driven.
- Recovery slipping (11.58% FY23 → 11.28% FY25 C-heavy equivalent; red rot, CO-0238 replacement). Sugar inventory at Jun-26 only 9.95 lakh qtl vs 17.67 — thin H2 sales cushion.
- Moat: none beyond regional cane catchments and good recovery; price-regulated commodity.

## GATE 4 — Valuation: FAIL
P/E 14.6x TTM (13.3x FY26) vs own history of ~5-10x; P/B 1.5x for 12% ROE; EV/EBITDA ~8.5-10x on TTM EBITDA Rs 205 cr (depending on seasonal debt). Peers: Dalmia 16x, Triveni 20x, Balrampur 34x — Uttam is cheaper but has the weakest policy positioning (highest B-heavy dependence, UP SAP). 3-yr rough: bear EPS 15 × 8 = Rs 120 (-65%); base EPS 28 × 12 = Rs 335 (flat); bull EPS 40 × 14 = Rs 560 (+60%). Asymmetry unfavourable after the rally.

## What would change the view
Ethanol policy reversal allowing B-heavy; sustained recovery >11.5%; H2 FY27 PAT run-rate back to Rs 90-100 cr; stock below ~Rs 220 (P/B ~1.0).

## Sources
- Screener consolidated page: https://www.screener.in/company/UTTAMSUGAR/consolidated/
- CARE Ratings press release 24 Sep 2025: https://www.careratings.com/upload/CompanyFiles/PR/202509120919_Uttam_Sugar_Mills_Limited.pdf
- Annual Report 2025-26 (board, remuneration, RPT note, auditor EoM, MD&A): https://www.uttamsugar.in/adminpanel/product_image/083cff325b2d8e8a446eed989680eb3bAnnual_Report_2025-26_Optimized_website.pdf
- Q1 FY27 investor presentation (11 Aug 2026): https://nsearchives.nseindia.com/corporate/UTTAMSUGAR_11082026170413_PresentationSE.pdf
- BSE shareholding pattern Sep-26 (no pledge): https://www.bseindia.com/stock-share-price/uttam-sugar-mills-ltd/uttamsugar/532729/shareholding-pattern/
- ESY 2026-27 tender excluding sugar-based ethanol: https://www.autocarindia.com/industry/government-bars-sugar-based-ethanol-in-2026-27-tender-report-441078 ; https://bioenergytimes.com/?p=22424 ; ISMA reaction https://knnindia.co.in/news/newsdetails/sectors//isma-hails-ethanol-tender-restrictions-to-protect-domestic-sugar-supplies-flags-preferential-allocation-for-dedicated-plants
- 2009 CDR board record: https://trendlyne.com/equity/board-meeting/UTTAMSUGAR/1459/uttam-sugar-mills-ltd-board_meeting
- Not checked (search budget exhausted): Aug-2026 concall transcript text, Q2 FY27 results PDF detail, litigation databases.
