---
title: "Siyaram Silk: cheap fabric, or cheap stock?"
description: "Siyaram Silk Mills fell 43% in a year while sales grew 15%. A four-gate due diligence in 14 charts: margins, cash, the preference bonus and valuation."
date: "2026-11-03"
author: "Nikhil Bhensdadia"
canonical: "https://niikkkhill.substack.com/p/siyaram-silk-cheap-fabric-or-cheap-stock"
slug: "siyaram-silk-cheap-fabric-or-cheap-stock"
site_name: "MultiBagger Stock"
lang: "en"
og_image_alt: "Siyaram Silk: cheap fabric, or cheap stock? Share price down 43% in a year against sales up 15% in the latest half."
tags: ["Siyaram Silk Mills", "SIYSIL", "Indian small cap", "textile stocks", "fundamental analysis"]
lastUpdated: "2026-11-03"
---

# Siyaram Silk: cheap fabric, or cheap stock?

*The share price fell 43% in a year. Sales grew 15% in the latest half. One of those two numbers is lying, and we went through the filings to find out which.*

---

On 4 November 2025 a share of Siyaram Silk Mills closed at Rs 826. A year later, almost to the day, it trades at about Rs 470.

In those twelve months the company sold 14% more cloth and clothes than the year before, opened about 19 new stores, declared Rs 16 a share of dividends for FY26, and gave every shareholder seven bonus preference shares that pay 9% a year.

So either the market has lost patience with a perfectly good business, or the profit and loss account is hiding something the sales line does not show.

What got us interested:

- A 48-year-old brand that most of small-town India has worn at a wedding, priced at 9.5 times earnings while branded-textile peers Kewal Kiran and Arvind sit at 18 and 29 times.
- Management that guided to "double-digit growth" for FY26 and printed 15.7%. In our sample of 43 small caps this year, that puts them in a very short list.
- A family that just handed itself, and everyone else, Rs 318 crore of IOUs out of reserves in one afternoon (seven preference shares per equity share, allotted on 25 August 2026). We wanted to know whether that was generosity or something else.

This is the post we wished existed before we buy. Fourteen charts, no screenshots, and our own verdict at the end, including the size we intend to buy at.

> **Key Takeaways**
>
> - Siyaram Silk Mills trades at 9.5 times trailing consolidated earnings after a 43% fall in a year, while revenue grew 15% in the latest half. Management met its FY26 guidance and is tracking FY27 guidance on growth and stores, behind on margin with the stronger half still to come.
> - Operating margin has slipped from a 17 to 18% peak in FY22 to 12 to 13%, and FY26 converted only 40% of profit into operating cash as company-owned stores absorbed inventory.
> - The Poddar family, holding 67%, took 12.6% of FY26 profit as pay and engineered a Rs 318 crore 9% preference-share bonus that ranks ahead of equity.
> - We have not bought yet. The plan is a 20% slot in a six-stock portfolio within the week, with dated triggers: 14% EBITDA margin in the December quarter and inventory days under 150 by March.

## How we look at a stock before we look at the price

Every company we consider walks through four doors. Each door is a question answered pass, watch or fail. A fail at the first door ends the review, whatever the price.

![Horizontal bar chart of our stock funnel: 3,946 listed companies screened down to 43 reviewed and 6 selected](charts/01-funnel.png)

The screen is mechanical: liquid, small, cheap on book value, profitable, cash generating. That gets 3,946 listed companies down to 59 in an afternoon. The slow part is the 43 we then read in full, against four questions.

1. Governance. Who owns it, who runs it, who gets paid, and does any money flow sideways to the family. Pledged shares, related-party purchases, relatives in the corner office.
2. Guidance against delivery. Did management say a number out loud, and did they hit it. Two years running.
3. Fundamentals. Growth, margins, cash conversion, working capital. Does profit turn into cash, or into inventory.
4. Valuation, only now. Against peers, against its own history, and against three plausible futures.

Six of the 43 came out the other side. Siyaram was the one we argued about longest.

## What Siyaram actually sells

Siyaram is a fabric company with a growing retail habit.

![Stacked bar chart of Siyaram revenue mix by product, FY22 to FY26: fabric about 78%, garments 15%, yarn 7%](charts/14-revenue-mix.png)

Seventy-eight paise of every revenue rupee is fabric, sold through a dealer network to the tailors and cloth shops that still dress most of India for weddings and office. Siyaram's, J. Hampstead, Oxemberg and Cadini are fabric brands first. Garments and the newer company-owned stores are 15%, yarn and the rest 7%.

Fabric is a volume business with limited pricing power. Retail is where the margin could come from, and retail also eats inventory while it scales. Most of what follows is the tension between those two sentences.

## The ten-year chart behind the de-rating

The chart below sets revenue and profit at 100 in FY17 so both fit on one axis.

![Line chart of Siyaram standalone revenue and profit after tax indexed to FY17, showing revenue rising and profit flat since FY23](charts/02-revenue-vs-profit.png)

Revenue climbed. Profit shot up in the FY22 and FY23 restocking boom, then went sideways. FY23 standalone profit was Rs 252 crore. FY26 was Rs 228 crore, on 15% more revenue.

A market that pays for earnings growth looks at that chart and moves on, and the multiple it pays shrinks (the de-rating). There is no scandal in it. The explanation is in the margins.

## Three lines that show where the margin went

![Gross, operating and net margin, FY17 to TTM](charts/03-margins.png)

The top line has held a 51 to 56% band for a decade, outside the Covid year. Siyaram still buys yarn and sells cloth at roughly the spread it always has. One caution: the quarter just reported printed 48%, five points below the same quarter last year, partly an inventory swing. If that repeats in December it stops being a swing.

The middle line is the problem. Operating margin peaked at 17 to 18% in FY22 (consolidated and standalone), when every dealer in the country restocked at once, and has since settled around 12 to 13%. Some of that is fabric going back to normal. About 150 basis points, by management's own estimate, is the cost of ramping up the ZECODE and DEVO stores.

The net margin line followed the middle one down. In the latest quarter it dipped further, for a reason that has nothing to do with cloth: lower other income and the new preference coupon, both covered in the next section.

## Where every rupee went, last year and this quarter

The whole P&L sits side by side below, FY25 against FY26, so you can see which rungs moved instead of taking our word for it.

![P&L ladder, FY25 vs FY26](charts/04-pnl-ladder-fy.png)

Every rung grew. Profit grew 17%. If you had only seen this chart you would wonder why the stock is down at all.

Now the same ladder for the quarter reported on 27 October, September 2026 against September 2025.

![P&L ladder, Q2 FY27 vs Q2 FY26](charts/05-pnl-ladder-q2.png)

Read it left to right. Revenue up 15%. Gross profit up. EBITDA up 8%. Then the ladder breaks, and profit after tax comes in 14% lower.

Two rungs explain the whole gap. Other income fell from Rs 37 crore to Rs 15 crore, because last year's quarter carried a one-off that did not repeat. Finance cost rose from Rs 9 crore to Rs 12 crore, because from August the company owes a 9% coupon on the new preference shares. One is a base effect. The other is a capital-structure choice the board made. Neither is the fabric business getting worse. A screener shows only the bottom rung, and the bottom rung says minus 14.

## The part most people miss: Siyaram has a bad quarter every year

The June quarter is always weak. The September quarter, when dealers stock up for the wedding and festive season, is always the strongest.

![EBITDA margin by quarter, FY24 to FY27](charts/06-seasonality.png)

The June 2026 quarter printed a 4% EBITDA margin. On its own that looks like a collapse, and the stock traded like one. Look up the column: 3% in June 2024, 5% in June 2025. The September quarter then came in at 14 to 15% for the fourth year in a row (on Screener's basis, which strips out all other income; the company's own EBITDA figure, used in the guidance chart below, includes recurring other income and runs about a point and a half higher).

Anyone who reacts to a single Siyaram quarter will be wrong about half the time. The annual number is the only one worth arguing over.

## Does the profit turn into cash

This is where our enthusiasm cooled.

![Cash from operations vs profit, FY22 to FY26](charts/07-cash-conversion.png)

Over five years Siyaram reported Rs 1,080 crore of profit and collected Rs 757 crore of operating cash. Seventy paise in the rupee. FY25 was excellent. FY26 was the weakest year since FY22, Rs 93 crore of cash against Rs 231 crore of profit, and the next chart says why.

![Debtor days, inventory days, cash conversion cycle](charts/08-working-capital.png)

Inventory days have gone from 143 to 161 since FY23. Debtor days from 70 to 92. The cash conversion cycle, the days between paying for yarn and collecting from the dealer, is now 184, so the company funds half a year of operations before the money comes back. Company-owned stores are the main cause. Every new ZECODE store is stocked before it sells a single shirt.

![Store count: 61 today, 70 by March](charts/09-stores.png)

About 19 stores opened between December and the end of October (the December count comes from a press-release reprint, the October count from the filing), 61 in total, 70 promised by March. The retail bet is real and it is being paid for out of working capital. That is acceptable while the stores work. It is the first number we will check if they do not.

## The family, the pay cheque, and Rs 318 crore

Siyaram is run by the Poddar family. Four Poddars sit on the board as whole-time directors. Together they were paid Rs 28.8 crore in FY26, which is 12.6% of that year's profit, and more than half of it is commission linked to profit before tax. Each earns roughly 200 times the median employee.

That is high for a Rs 2,100 crore company. It is also fully disclosed in the annual report, and managerial pay as a whole has grown slower than profit. We noted it and moved on.

Two things took longer to move past.

The company buys from the family. About Rs 69 crore of FY26 purchases, 2.7% of revenue, came from LLPs owned by the promoter group, and the largest of those relationships nearly doubled in a year. The board certifies every transaction as arm's length, meaning priced as it would be with a stranger. The amounts are small. The direction is what we watch.

Then the preference shares. In August the company issued seven 9% redeemable preference shares for every equity share (two years after a [Rs 108 crore buyback at Rs 650 to 720](https://www.sebi.gov.in/sebi_data/commondocs/aug-2023/Siyaram_Silk_PA_p.pdf), against today's Rs 470), Rs 318 crore in total, straight out of the general reserve. Every shareholder got them pro rata, so nothing was taken from minorities. Now look at who holds 67% of the equity.

![Stacked bar chart of cash returned to Siyaram shareholders by year, FY21 to FY27: dividends, the 2023 buyback and the 2026 preference bonus](charts/10-capital-returns.png)

The family will receive about Rs 19 crore a year in preference coupons and Rs 214 crore at redemption in 2029 and 2031, ranking ahead of the equity, from a company whose operating margin was already sliding and whose stores need working capital. Preference dividends are not tax-deductible, and because the shares sit in debt on the balance sheet, borrowings doubled on paper from Rs 352 crore in March to Rs 719 crore in September. It is a leveraged capital return, and it was engineered at a moment when we would have preferred the cash to stay in the business.

There is also a Rs 45 crore residential building going up on company land in Dombivli. Small, and declared a one-off. Textile companies that start building flats are a pattern we have learned to notice.

On the other side of the ledger: zero shares pledged, an unmodified audit opinion every year we checked (the latest quarterly review adds an emphasis-of-matter note, a flag rather than a qualification, on a small loss-making Italian subsidiary), no SEBI action, and no relative parachuted into the CEO chair. There is a professional layer under the family: a non-family senior president on the board, a non-family CFO, and a deputy CFO promoted this month. Governance is a watch, not a fail. It is also why we size Siyaram at 20% of a six-stock portfolio and not more.

## Guidance against delivery: the door Siyaram walks through cleanly

![Dumbbell chart of Siyaram management guidance against delivered revenue growth, margin and store count, FY26 and H1 FY27](charts/11-guidance.png)

Going into FY26, management guided to double-digit growth. They delivered 15.7%.

In July 2026 they guided to about 12% growth, about 14% EBITDA margin, Rs 100 crore of capex and 70 stores. Half a year in: 15% growth, 13.1% margin with the seasonally strong half still to come, 61 stores and on track.

Of the 43 companies we reviewed this autumn, we can count on one hand those whose management gives a number and then meets it. In small-cap India that is rarer than a clean balance sheet.

## What is it worth

![Horizontal bar chart of price-to-earnings multiples: Arvind, sector median, Kewal Kiran, Siyaram in 2021, its five-year median and today](charts/12-valuation.png)

Nine and a half times trailing consolidated earnings. Kewal Kiran trades at 17.7 times and Arvind at 29 (Screener.in, 2 November 2026), with the textile sector median around 19. Siyaram's own five-year median is 11.7, and it was 14.7 when this de-rating began in late 2021.

Cheap is not the same as mispriced. A business that has grown revenue 5% a year over ten years, whose margins fell five points from peak, deserves a discount. The only question is whether the discount is too large.

![Bar chart of bear, base and bull FY29 value per Siyaram share against the closing price of Rs 473](charts/13-scenarios.png)

| Case | What has to happen | FY29 profit | Multiple | Value per share | Against Rs 470 |
|---|---|---|---|---|---|
| Bear | Margins keep sliding | Rs 190 crore | 8x | about Rs 335 | down 29% |
| Base | Profit compounds 6% a year | Rs 270 crore | 11x | about Rs 655 | up about 38%, plus the 2.6% dividend yield and about Rs 6 a share a year of preference coupons (1.3% on today's price) |
| Bull | Margin back to 15% as stores mature | Rs 330 crore | 13x | about Rs 950 | a double |

The base case alone clears our hurdle for a holding. The bull case is why it gets a portfolio slot rather than a watchlist entry.

## The verdict, and what would change it

| Gate | Verdict | Deciding fact |
|---|---|---|
| Governance | Watch | No pledge, clean audits, but 67% family control, Rs 318 crore preference bonus, Rs 69 crore of family sourcing |
| Guidance vs delivery | Pass | FY26 guide met; FY27 growth and stores on track, margin behind pending H2 |
| Fundamentals | Watch | Revenue up 15% in FY26 and H1 FY27, but profit flat since FY23, five-year cash conversion 70%, inventory days rising |
| Valuation | Pass | 9.5x against an 11.7x own median and peers at 18 to 29x |0

Siyaram gets a 20% slot in our six-stock portfolio. We have not bought yet and plan to within the next week.

What keeps it in the plan: EBITDA margin at 14% or better in the December quarter, and inventory days back under 150 by March.

What takes it out: a second non-core project, promoter-group purchases above 6% of revenue, or any change to the preference-share terms in the family's favour.

What would make us add: two consecutive quarters above 15% margin with growth above 12%. At that point the bull case is simply the trend, and we would pay up for it.

The risk we cannot chart is the one the margin line hints at. ZECODE sells value fashion in the south against Zudio and V-Mart, and we have not yet seen evidence that it has an edge beyond the parent's fabric. If those stores turn out to be a way of converting fabric margin into inventory, the retail story ends and so does the bull case.

We would like to hear the other side. If you own it, or sold it this year, what did we miss?

---

*Who we are: MultiBagger Stock is the research notebook of Nikhil Bhensdadia, a private investor in India who has passed all three levels of the CFA Program, publishing the due diligence behind a six-stock small-cap portfolio. Every stock goes through the four gates described above before it is bought, and every verdict is dated so it can be checked later. Questions and corrections are welcome in the comments or by replying to this email.*

*Disclosure: we do not hold Siyaram Silk Mills at the time of writing. We intend to buy it within the next week, at a 20% weight in a six-stock portfolio, and will say so when we have.*

*This is a record of our research for educational purposes. It is not investment advice or a stock recommendation. The authors are not SEBI-registered investment advisers or research analysts. Consult your financial adviser before buying or selling any security. Figures are from the [FY26 annual report](http://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/annual-reports/2025-2026/Annual-Report-2025-26.pdf), the [27 October 2026 results filing](http://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/SEIntimation_OutcomeofBM27102026.pdf), [press release](http://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/SELetterPressRelease_Q2FY27_F.pdf) and [Q2 FY27 investor presentation](http://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/Investor+Presentation+Q2+FY27.pdf), the [Q1 FY27 concall transcript](http://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/InvestorMeetTranscript05082026.pdf), the 30 September 2026 shareholding pattern on NSE (nsearchives.nseindia.com/corporate/xbrl/SHP_1739027_15102026045628_WEB.xml), the NCLT order on the preference-share scheme as filed with NSE on 29 July 2026 (nsearchives.nseindia.com/corporate/SIYSIL_29072026191629_SEIntimation_CertifiedTrueCopyNCLTOrder.pdf), and [Screener.in](https://www.screener.in/company/SIYSIL/consolidated/), retrieved 2 and 3 November 2026. Ten-year series are standalone; other figures are consolidated unless the chart says otherwise. Price and multiples are the 3 November 2026 close (Rs 473) and will have moved by the time you read this.*
