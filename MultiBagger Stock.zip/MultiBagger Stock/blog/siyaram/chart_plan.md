# Chart plan (Siyaram post) — one axis per chart, fixed palette, direct labels
Palette (validated light): blue #2a78d6 (Siyaram / this year), orange #eb6834 (last year / comparison), aqua #1baf7a, yellow #eda100, grey #9a9890 for de-emphasis. Text #0b0b0b / #52514e. Surface #fcfcfb. Font Noto Sans. PNG 1600x900 @ 200 dpi.

1. funnel.png — our 4-gate funnel: universe -> screen -> 43 DD -> 6 selected (stepped horizontal bars)
2. revenue_vs_profit_indexed.png — FY17..FY26 revenue and PAT indexed to FY17=100 (two lines, one axis)
3. margins.png — gross, operating (EBITDA), net margin lines FY17..TTM, direct labels at ends, peak/trough annotated
4. pnl_ladder_annual.png — grouped columns FY25 vs FY26: Revenue, Gross profit, EBITDA, Depreciation, Interest, PBT, PAT
5. pnl_ladder_q2.png — same ladder Q2 FY26 vs Q2 FY27
6. seasonality.png — EBITDA margin heat strip, rows FY23..FY27, cols Q1..Q4 (sequential one-hue ramp)
7. cash_conversion.png — CFO vs PAT paired bars FY22..FY26 with conversion % labels
8. working_capital.png — debtor days, inventory days, CCC lines FY21..FY26
9. stores.png — ZECODE + DEVO store count, stacked columns by quarter/year, FY27 target marker
10. capital_returns.png — cash returned: dividends, buyback, preference bonus by year (stacked)
11. guidance_scorecard.png — guided vs delivered (FY26, H1 FY27) dot/dumbbell
12. valuation_peers.png — P/E horizontal bars: Siyaram vs peers vs own 5y band
13. scenarios.png — bear/base/bull FY29 price per share vs CMP
