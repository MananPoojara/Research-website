# Substack writing brief: Indian single-stock deep dives (3 Nov 2026)

Method: WebSearch + r.jina.ai (substack.com blocks direct fetch). No Substack post on Siyaram Silk found. Counts are from archive pages, unlabeled; assumed likes/comments/restacks (not verified).

## Posts read

1. [Veefin: Strong Growth, Hidden Red Flags](https://surajsakaria.substack.com/p/episode-1-veefin-solutions-strong) (Suraj Sakaria). Title: "Episode #N: Company | contrast pair | series". Hook: "Veefin Solutions is a B2B fintech company that promises a lot." Flow: what looked good -> receivables -> OCF vs EBITDA -> dilution -> related parties -> ROCE -> monitoring checklist -> disclaimer -> CTA. ~1,400 words; 11 Screener/annual-report screenshots, no drawn charts. 32/17/4.
2. [Psychology of Valuation: PG Electroplast](https://surajsakaria.substack.com/p/the-psychology-of-valuation-pg-electroplast). Title: "Concept — Company as a Case Study". Hook: "There comes a point in every investor's journey when the market delivers a reality check." Framework -> 4-stage price journey -> reverse DCF -> takeaways. ~2,200 words; 3 images (diagram, price chart, reverse-DCF screenshot). 17/8/2.
3. [How to Use Screener.in Like a MicroCap Pro](https://surajsakaria.substack.com/p/how-to-use-screenerin-like-a-microcap). Hook: "Most investors open Screener.in just to skim... But microcap pros?" Metric-by-metric: Why it matters / Example / Where to look / Red flag. ~1,400 words; 10 screenshots. 240/33/43, the publication's top post.
4. [Afcom Holdings: A 12 year plan in action](https://indiancompounders.substack.com/p/afcom-holdings-a-12-year-plan-in) (Indian Compounders). Hook: "the only pure-play airport-to-airport air cargo service based in India." Flow: What Got Me Interested (bullets) -> About -> Model -> Management -> Moat -> Financial quality -> Valuation -> Risks -> Technicals -> Conclusion -> Disclosure -> Disclaimer. ~2,000 words; 3 mostly decorative images. 23/1 (top post).
5. [Man Industries: A turnaround story](https://indiancompounders.substack.com/p/man-industries-a-turnaround-story). Same template; ends with position disclosure. ~1,800 words; 4 images. 6/2/2.
6. [Research #60: Pennar Industries](https://equityedgeresearch.substack.com/p/pennar-industries-ltd) (EquityEdge, 17k+ subs). Opens with self-promo. Key figures -> price vs NIFTY -> business -> 8 financial charts -> SWOT -> peers -> premium pitch. ~2,500 words; 37 images (price lines, financial bars, deck slides). Counts not visible.
7. [The Most Persistent Company in Indian IT](https://bastionresearch.substack.com/p/the-most-persistent-company-in-indian) (Bastion). Pun title, company unnamed. Hook: "This company got listed in 2010. In the 15 years since, this stock has outperformed Apple. Google. Microsoft. Amazon. Meta." Chronological story; no valuation. ~3,800 words; 11 images. Counts not visible.

## Synthesis

**1. Title formulas**
- `Company: A [turnaround / asset play / 12-year plan] story`
- `Company: Strong X, Hidden Y` (contrast pair; best-liked single-stock post above)
- `Company: Deep Value, or Value Trap?` (binary question; Bastion uses it repeatedly)
- `The hidden [niche] monopoly hiding in plain sight` (unnamed-company curiosity)
- `Concept — Company as a Case Study` (reaches readers who do not know the stock)
Siyaram candidate: "Siyaram Silk: Cheap Fabric, or Cheap Stock?"

**2. Hook pattern.** Sentence one: a plain uniqueness or contrast claim. Two: one concrete number. Three: the "but". Then 3-5 "What got me interested" bullets. Never open with promo.

**3. Section flow (chart-heavy, keeps readers to the end)**
1. Hook + "What got me interested" bullets
2. Business in one chart (revenue mix)
3. Story so far: annotated price-event timeline
4. Financial quality: revenue/EBITDA/PAT, margins, OCF vs EBITDA, working-capital days, ROCE
5. The part most people miss (one strong chart)
6. Valuation: implied growth vs guidance, peer table
7. Risks, numbered, each tied to a watch metric
8. What would change my mind / monitoring checklist (drives comments)
9. Position disclosure, disclaimer, one CTA (question + share)

**4. Charts used, and gaps.** Screener screenshots dominate; drawn charts are single-series bars and price lines; deck slides copied in. Gaps: annotated price timeline, OCF-vs-EBITDA overlay, working-capital days vs peers, implied-growth vs guidance, segment-margin bridge, promoter holding vs price. Consistent own-styled charts alone differentiate.

**5. Disclaimer conventions** (verbatim): "This is not investment advice or a stock recommendation." "The author is not a SEBI-registered investment advisor." "We do not recommend buying or selling any stock. You should consult your financial advisor before buying or selling any financial instrument." "for informational and educational purposes only." Registered writers cite "SEBI Registered Research Analyst (INH...)" ([example](https://bastionresearch.substack.com/p/a-hidden-pharma-monopoly-hiding-in)). Position disclosure is standard. Exact SEBI RA wording requirements not verified.

**6. Drop-off causes.** Promo before the hook; dozens of images with no narrative thread; "read more in Premium" interruptions; 2,000+ words without headings; story without valuation; risks as afterthought; generic opener ("X Ltd., founded in 1988, specializes in..."). Target 1,500-2,500 words.
