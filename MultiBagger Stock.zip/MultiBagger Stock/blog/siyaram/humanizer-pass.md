# Humanizer pass, 3 Nov 2026 (file mode)

Scanned siyaram-silk-cheap-fabric-or-cheap-stock.md against the humanizer checklist.

Tells found and fixed:
- Staged run-up ("Rather than tell you that revenue grew and profit fell, here is...") rewritten to state the point.
- Fragment closer ("The next chart says why.") merged into the preceding paragraph.
- Aphoristic closer ("stops being a case and becomes the trend") replaced with a plain consequence.
- Earlier draft tells already removed before this pass: "Not the broker notes. The annual report..." contrast; "It is not a scandal. It is a margin story." split contrast; bold labels on the risk list and scenario bullets.

Checked and left alone (voice, each carries a fact or a reaction):
- "This is where our enthusiasm cooled." (opinion opener, blog voice)
- "Cheap is not the same as mispriced." (real correction of a reader belief, followed by the reason)
- "rather than on the watchlist" (both halves carry information)

No em or en dashes, no triads by rule, no title-case headings, no chatbot residue, no knowledge-cutoff phrasing. Facts, numbers, names and dates unchanged by this pass.

## Final re-check, 3 Nov 2026, on the delivered text (after links, author block, price refresh and reviewer fixes)
Scan of the final markdown: no em or en dashes, no "not X but Y" constructions, no staged openers, no stock AI words from the §12 list, no title-case headings, no bold-label lists, no chatbot residue. The two "Here is..." paragraph openers flagged by the reviewer were reworded; the forward reference "We will come to it" was replaced with the fact it pointed to. Short declarative fragments ("Seventy paise in the rupee.", "The amounts are small. The direction is what we watch.") were read again and kept: each carries a number or a judgement, which the humanizer allows as voice. No facts, numbers, names or dates were changed by this pass.
