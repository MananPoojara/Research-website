import csv, json, os
OUT = "/run/user/1000/gvfs/smb-share:server=192.168.4.50,share=share/Nikhil/Trash/MultiBagger Stock/blog/siyaram/data"
RET = "2026-11-03"
SRC = {
 "screener_consolidated": "https://www.screener.in/company/SIYSIL/consolidated/",
 "screener_standalone": "https://www.screener.in/company/SIYSIL/",
 "screener_expense_schedule_consolidated": "https://www.screener.in/api/company/3093/schedules/?parent=Expenses&section=profit-loss&consolidated=true",
 "screener_pe_chart": "https://www.screener.in/api/company/3093/chart/?q=Price+to+Earning-Median+PE-EPS&days=1825&consolidated=true",
 "screener_price_chart": "https://www.screener.in/api/company/3093/chart/?q=Price-DMA50-DMA200-Volume&days=365&consolidated=true",
 "press_release_q2fy27": "https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/SELetterPressRelease_Q2FY27_F.pdf",
 "results_filing_q2fy27": "https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/SEIntimation_OutcomeofBM27102026.pdf",
 "investor_presentation_q2fy27": "https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/Investor+Presentation+Q2+FY27.pdf",
 "annual_report_fy26": "https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/annual-reports/2025-2026/Annual-Report-2025-26.pdf",
 "annual_report_fy18_mirror": "https://files.tijorifinance.com/insight/india/563/Annual%20Report/AR-18.pdf",
}

# ---------- screener consolidated P&L: FY2016, FY2018..FY2026, TTM (no FY2015/FY2017 consolidated on screener)
CY = ["FY2016","FY2018","FY2019","FY2020","FY2021","FY2022","FY2023","FY2024","FY2025","FY2026","TTM"]
C = dict(
 sales=[1605,1733,1816,1699,1089,1905,2233,2092,2222,2572,2737],
 expenses=[1415,1488,1577,1532,1035,1572,1864,1806,1946,2240,2398],
 operating_profit=[189,245,240,167,54,333,368,286,276,333,339],
 opm_pct=[12,14,13,10,4.9,17,16,14,12,13,12],
 other_income=[15,20,23,34,41,34,40,36,75,83,70],
 interest=[31,34,48,43,30,18,20,20,24,34,38],
 depreciation=[43,61,62,73,61,59,58,55,60,79,76],
 pbt=[130,170,152,85,3,291,331,247,267,303,295],
 tax_pct=[35,35,35,19,-3,26,24,25,26,24,None],
 net_profit=[85,111,99,69,4,216,251,185,197,231,225],
 eps_rs=[18.10,23.64,21.14,14.77,0.76,46.14,53.55,40.72,43.45,50.89,49.61],
 dividend_payout_pct_screener=[12,18,21,58,602,20,21,27,28,31,None],
)
# screener expense schedule (consolidated), % of sales
CX = dict(
 material_cost_pct=[50.65,44.65,44.41,48.40,58.03,47.05,48.43,47.53,48.07,47.06,None],
 manufacturing_cost_pct=[17.25,19.18,18.38,16.99,17.29,19.24,19.03,19.48,19.22,20.23,None],
 employee_cost_pct=[9.18,10.97,10.93,11.52,11.35,8.44,8.07,8.28,8.28,8.25,None],
 other_cost_pct=[11.11,11.06,13.09,13.24,8.40,7.79,7.96,11.01,12.01,11.52,None],
)
# ---------- screener standalone P&L: FY2015..FY2026, TTM
SY = ["FY2015","FY2016","FY2017","FY2018","FY2019","FY2020","FY2021","FY2022","FY2023","FY2024","FY2025","FY2026","TTM"]
S = dict(
 sales=[1496,1609,1570,1733,1815,1698,1088,1903,2229,2087,2220,2569,2733],
 expenses=[1321,1413,1373,1487,1573,1529,1033,1569,1860,1801,1943,2239,2397],
 operating_profit=[174,196,197,246,241,169,55,334,369,286,277,330,336],
 opm_pct=[12,12,13,14,13,10,5,18,17,14,12,13,12],
 other_income=[16,14,25,20,24,34,41,29,40,36,75,83,70],
 interest=[31,31,32,34,48,43,30,18,20,20,24,34,38],
 depreciation=[41,52,55,61,62,73,61,59,58,55,60,79,76],
 pbt=[119,127,136,171,154,88,5,287,332,247,269,300,293],
 tax_pct=[34,34,33,35,35,18,-2,26,24,25,26,24,None],
 net_profit=[79,84,91,112,101,72,5,213,252,185,199,228,223],
 eps_rs=[16.80,17.93,19.41,23.81,21.58,15.30,1.14,45.34,53.73,40.70,43.80,50.27,49.09],
 dividend_payout_pct_screener=[12,12,15,18,20,56,404,20,20,27,27,103,None],
)
# dividend per share, split-adjusted (Q2FY27 investor presentation slide 38; FY26 confirmed by AR FY26 note: 4+3+4 special+5 final)
DPS = {"FY2012":1.5,"FY2013":1.5,"FY2014":1.6,"FY2015":2.0,"FY2016":2.2,"FY2017":3.0,"FY2018":4.2,"FY2019":4.4,"FY2020":8.6,"FY2021":4.6,"FY2022":9.2,"FY2023":11.0,"FY2024":11.0,"FY2025":12.0,"FY2026":16.0}
DPS_SPECIAL = {"FY2020":4.0,"FY2026":4.0}
DIV_OUTLAY_CR = {"FY2021":21.5,"FY2022":43.1,"FY2023":51.6,"FY2024":49.9,"FY2025":54.4,"FY2026":72.5}
BUYBACK_CR = {"FY2024":108}
# presentation slide 30/31 (Rs mn), FY22..FY26
PY = ["FY2022","FY2023","FY2024","FY2025","FY2026"]
P = dict(
 fabric_rev_mn=[15540,17195,17068,18010,20109],
 garment_rev_mn=[2574,3741,2735,2957,3893],
 yarn_others_rev_mn=[917,1357,1069,1236,1691],
 fabric_pct=[82,77,82,81,78], garment_pct=[14,17,13,13,15], yarn_others_pct=[4,6,5,6,7],
 roce_pct_company=[31.8,32.6,23.2,24.4,26.6],
 roe_pct_company=[24.8,24.2,16.2,16.4,16.6],
 debt_equity_x=[0.27,0.17,0.18,0.21,0.24],
 net_debt_mn=[1693,208,1275,226,402],
)
for i,y in enumerate(PY):
    assert P["fabric_rev_mn"][i]+P["garment_rev_mn"][i]+P["yarn_others_rev_mn"][i] == [19031,22293,20872,22203,25693][i], y
# capex (purchase of PPE, CWIP & intangibles), AR FY26 cash flow, Rs lakhs
CAPEX_STD_LAKH = {"FY2025":14263.19,"FY2026":7515.02}
CAPEX_CON_LAKH = {"FY2025":14264.98,"FY2026":7521.95}

# ---------- Q2 FY27 results filing, standalone, Rs lakhs: (Q2FY27, Q1FY27, Q2FY26, H1FY27, H1FY26, FY26)
L = dict(
 revenue=(81347.85,44456.96,70555.39,125804.84,109405.16,256928.49),
 other_income=(1453.91,2168.49,3716.25,3622.40,4911.95,8528.59),
 total_income=(82801.76,46625.45,74271.64,129427.21,114317.11,265257.08),
 materials_consumed=(30822.32,22244.91,25541.35,53067.23,43262.18,99882.43),
 purchases_stock_in_trade=(10074.50,5043.54,8317.54,15118.04,12438.88,28106.23),
 change_in_inventories=(838.20,-10177.74,-1233.49,-9339.54,-6359.52,-6998.96),
 employee=(5873.83,5196.45,5647.79,11070.28,10199.68,21093.28),
 processing_labour=(7191.04,5814.87,8746.31,13005.91,13707.08,31032.05),
 property_dev_cost=(195.33,2455.66,0.0,2650.99,0.0,0.0),
 finance=(1198.08,733.02,889.22,1931.10,1534.28,3420.92),
 depreciation=(1988.97,1795.16,2057.97,3784.13,4039.63,7855.16),
 other_expenses=(14702.01,12056.05,12783.72,26758.06,23336.01,50832.08),
 total_expenses=(72884.28,45161.92,62750.41,118046.20,102158.22,235223.19),
 pbt=(9917.48,1463.53,11521.23,11381.01,12158.89,30033.89),
 current_tax=(2583.00,215.00,2330.00,2798.00,2510.00,7136.00),
 deferred_tax=(-161.18,123.60,493.54,-37.58,490.90,347.57),
 tax_earlier_years=(0,0,0,0,0,-257.90),
 total_tax=(2421.82,338.60,2823.54,2760.42,3000.90,7225.67),
 pat=(7495.66,1124.93,8697.69,8620.59,9157.99,22808.22),
 eps=(16.52,2.48,19.17,19.00,20.19,50.27),
)
exp_keys=["materials_consumed","purchases_stock_in_trade","change_in_inventories","employee","processing_labour","property_dev_cost","finance","depreciation","other_expenses"]
for j in range(6):
    s=sum(L[k][j] for k in exp_keys); assert abs(s-L["total_expenses"][j])<0.05,(j,s)
    assert abs(L["total_income"][j]-L["total_expenses"][j]-L["pbt"][j])<0.05, j
    assert abs(L["pbt"][j]-L["total_tax"][j]-L["pat"][j])<0.05, j
    assert abs(L["current_tax"][j]+L["deferred_tax"][j]+L["tax_earlier_years"][j]-L["total_tax"][j])<0.05, j
# consolidated Q2 filing lines needed for TTM material cost (Rs lakhs): (H1FY27, H1FY26, FY26)
CL = dict(revenue=(125923.97,109512.49,257249.53), materials=(53096.16,43269.56,99925.44), purchases=(15119.30,12461.43,28139.44), inv_change=(-9343.62,-6381.15,-7015.35), property=(2650.99,0.0,0.0))
def matcost(d, j):  # textile material cost: property dev cost is offset inside 'change in inventories' (Note 3), so add it back
    return d["materials"][j]+d["purchases"][j]+d["inv_change"][j]+d["property"][j]
fy26_mc_pct = 100*matcost(CL,2)/CL["revenue"][2]; assert abs(fy26_mc_pct-47.06)<0.01, fy26_mc_pct
ttm_mc = matcost(CL,2)+matcost(CL,0)-matcost(CL,1); ttm_rev = CL["revenue"][2]+CL["revenue"][0]-CL["revenue"][1]
assert abs(ttm_rev/100-2737)<1, ttm_rev
CX["material_cost_pct"][-1] = round(100*ttm_mc/ttm_rev,2)
# FY2017 standalone from AR FY18 comparatives (Rs lakhs): rev 157393.34 (incl. excise duty pre-GST), materials 58101.28, purchases 15231.92, inventory change +527.80
fy17_mc_pct = round(100*(58101.28+15231.92+527.80)/157393.34,2)
fy18_chk = 100*(69224.70+16904.65-8752.99)/173275.58; assert abs(fy18_chk-44.65)<0.01, fy18_chk

# ---------- annual.csv
years = ["FY2015","FY2016","FY2017","FY2018","FY2019","FY2020","FY2021","FY2022","FY2023","FY2024","FY2025","FY2026","TTM"]
def col(d, ylist, y, k):
    return d[k][ylist.index(y)] if y in ylist else None
rows=[]
for y in years:
    r={"fiscal_year":y, "period_end": {"TTM":"2026-09-30"}.get(y, y[2:]+"-03-31")}
    for k in C: r["con_"+k]=col(C,CY,y,k)
    for k in CX: r["con_"+k]=col(CX,CY,y,k)
    if y=="FY2017": r["con_material_cost_pct"]=fy17_mc_pct  # standalone, from AR FY18 (consolidated not available)
    mc=r["con_material_cost_pct"]; r["gross_margin_pct"]= round(100-mc,2) if mc is not None else None
    for k in S: r["std_"+k]=col(S,SY,y,k)
    r["dps_rs"]=DPS.get(y); r["dps_special_included_rs"]=DPS_SPECIAL.get(y)
    r["dividend_payout_pct_calc_std"]= round(100*DPS[y]/r["std_eps_rs"],1) if y in DPS and r["std_eps_rs"] else None
    r["dividend_outlay_cr"]=DIV_OUTLAY_CR.get(y); r["buyback_cr"]=BUYBACK_CR.get(y)
    r["capex_std_cr"]= round(CAPEX_STD_LAKH[y]/100,2) if y in CAPEX_STD_LAKH else None
    r["capex_con_cr"]= round(CAPEX_CON_LAKH[y]/100,2) if y in CAPEX_CON_LAKH else None
    for k in P:
        v=col(P,PY,y,k)
        if k.endswith("_mn") and v is not None: r[k.replace("_mn","_cr")]=round(v/10,1)
        else: r[k]=v
    rows.append(r)
def wcsv(name, rows):
    keys=list(rows[0].keys())
    with open(os.path.join(OUT,name),"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader()
        for r in rows: w.writerow({k:("" if r.get(k) is None else r[k]) for k in keys})
wcsv("annual.csv",rows)

# ---------- quarterly.csv (screener, Rs crore)
Q = ["Sep 2023","Dec 2023","Mar 2024","Jun 2024","Sep 2024","Dec 2024","Mar 2025","Jun 2025","Sep 2025","Dec 2025","Mar 2026","Jun 2026","Sep 2026"]
QL = ["Q2FY24","Q3FY24","Q4FY24","Q1FY25","Q2FY25","Q3FY25","Q4FY25","Q1FY26","Q2FY26","Q3FY26","Q4FY26","Q1FY27","Q2FY27"]
QC = dict(sales=[586,503,648,307,608,571,736,389,706,624,853,446,814], expenses=[498,435,542,297,519,504,625,369,598,556,716,428,697],
 operating_profit=[88,69,106,10,89,66,111,21,107,68,137,18,116], opm_pct=[15,14,16,3.1,15,12,15,5,15,11,16,4.0,14],
 other_income=[12,11,6,24,21,16,14,12,37,16,18,22,15], interest=[5,6,5,5,6,6,8,6,9,10,9,7,12], depreciation=[14,14,14,14,14,15,18,20,21,20,18,18,20],
 pbt=[81,60,93,15,91,62,100,6,115,55,127,14,99], tax_pct=[24,26,26,25,25,26,28,28,25,23,23,24,25], net_profit=[61,44,69,12,68,45,72,5,87,42,98,11,74],
 eps_rs=[13.08,9.79,15.21,2.53,15.03,10.00,15.88,1.02,19.11,9.21,21.55,2.43,16.42])
QS = dict(sales=[585,502,646,307,608,570,736,388,706,623,853,445,813], expenses=[497,433,540,296,519,504,624,368,598,555,719,426,697],
 operating_profit=[88,68,106,10,89,67,112,21,108,68,134,18,116], opm_pct=[15,14,16,3.3,15,12,15,5,15,11,16,4.1,14],
 other_income=[12,11,6,24,21,16,14,12,37,16,18,22,15], interest=[5,6,5,5,6,6,8,6,9,10,9,7,12], depreciation=[14,14,14,14,14,15,18,20,21,20,18,18,20],
 pbt=[81,60,93,16,91,62,100,6,115,55,124,15,99], tax_pct=[24,26,26,24,25,26,28,28,25,23,24,23,24], net_profit=[61,44,69,12,68,46,72,5,87,42,95,11,75],
 eps_rs=[13.10,9.76,15.21,2.65,15.08,10.11,15.97,1.01,19.17,9.24,20.85,2.48,16.52])
qrows=[]
for i,q in enumerate(Q):
    r={"quarter_end":q,"quarter":QL[i]}
    for k in QC: r["con_"+k]=QC[k][i]
    for k in QS: r["std_"+k]=QS[k][i]
    qrows.append(r)
wcsv("quarterly.csv",qrows)

# ---------- q2_pnl_compare.csv (standalone, Rs crore)
def cr(x): return round(x/100,2)
items=[("Revenue from operations","revenue"),("Other income","other_income"),("Total income","total_income"),
 ("Cost of materials consumed","materials_consumed"),("Purchases of stock-in-trade","purchases_stock_in_trade"),
 ("Changes in inventories (incl. property under development)","change_in_inventories"),("Cost towards development of property (one-off Dombivali project, offset in inventories)","property_dev_cost"),
 ("Employee benefits expense","employee"),("Processing and labour charges","processing_labour"),("Other expenses","other_expenses"),
 ("Finance costs","finance"),("Depreciation and amortisation","depreciation"),("Total expenses","total_expenses"),("Profit before tax","pbt"),
 ("Current tax","current_tax"),("Deferred tax","deferred_tax"),("Total tax","total_tax"),("Profit after tax","pat"),("EPS (Rs, not annualised)","eps")]
j27, j26 = 0, 2
crow=[]
for label,k in items:
    a,b=L[k][j26],L[k][j27]
    crow.append({"line_item":label,"Q2FY26":cr(b*0+a) if k!="eps" else a,"Q2FY27":cr(b) if k!="eps" else b,
                 "yoy_change_pct": round(100*(b-a)/abs(a),1) if a and a*b>0 else ""})
def derived(label, f):
    a,b=f(j26),f(j27); crow.append({"line_item":label,"Q2FY26":cr(a),"Q2FY27":cr(b),"yoy_change_pct":round(100*(b-a)/abs(a),1) if a else ""})
mat=lambda j: L["materials_consumed"][j]+L["purchases_stock_in_trade"][j]+L["change_in_inventories"][j]+L["property_dev_cost"][j]
derived("Cost of materials = materials consumed + purchases + change in inventories + property dev cost (textile basis)", mat)
derived("COGS as per investor presentation (= cost of materials excl. property + processing & labour)", lambda j: L["materials_consumed"][j]+L["purchases_stock_in_trade"][j]+L["change_in_inventories"][j]+L["processing_labour"][j])
derived("EBITDA excl. all other income (screener 'Operating Profit' basis) = PBT + finance + depreciation - other income", lambda j: L["pbt"][j]+L["finance"][j]+L["depreciation"][j]-L["other_income"][j])
derived("EBITDA as reported in press release/presentation (incl. recurring other income, excl. non-recurring other income)", lambda j: L["pbt"][j]+L["finance"][j]+L["depreciation"][j]-{0:56.0,2:2380.0}[j])  # non-recurring other income per presentation: Q2FY27 Rs 6 mn, Q2FY26 Rs 238 mn
for lab,f in [("Gross margin % (1 - cost of materials textile basis / revenue)", lambda j: 100*(1-mat(j)/L["revenue"][j])),
              ("EBITDA margin % (screener basis, / revenue)", lambda j: 100*(L["pbt"][j]+L["finance"][j]+L["depreciation"][j]-L["other_income"][j])/L["revenue"][j]),
              ("PAT margin % (/ revenue)", lambda j: 100*L["pat"][j]/L["revenue"][j])]:
    crow.append({"line_item":lab,"Q2FY26":round(f(j26),2),"Q2FY27":round(f(j27),2),"yoy_change_pct":""})
# press release headline figures
for lab,a,b in [("Press release: Total income excl. non-recurring other income (Rs cr)",719,827),("Press release: EBITDA (Rs cr)",121,131),("Press release: EBITDA margin %",16.8,15.8),("Press release: PAT (Rs cr)",87,75),("Press release: PAT margin %",12.1,9.0)]:
    crow.append({"line_item":lab,"Q2FY26":a,"Q2FY27":b,"yoy_change_pct":round(100*(b-a)/a,1) if "margin" not in lab else ""})
assert abs(cr(L["pbt"][0]+L["finance"][0]+L["depreciation"][0]-56)-130.5)<0.1 and abs(cr(L["pbt"][2]+L["finance"][2]+L["depreciation"][2]-2380)-120.9)<0.1
wcsv("q2_pnl_compare.csv",crow)

# ---------- balance_cashflow_ratios.csv
BY = ["FY2016","FY2018","FY2019","FY2020","FY2021","FY2022","FY2023","FY2024","FY2025","FY2026","H1FY27"]
CB = dict(equity_capital=[9]*11, reserves=[498,669,746,753,758,925,1128,1128,1274,1451,1175], borrowings=[408,573,444,433,139,223,163,175,262,352,719],
 other_liabilities=[280,302,303,308,304,356,337,290,343,379,463], total_liabilities=[1196,1553,1502,1503,1210,1513,1637,1602,1888,2192,2367],
 fixed_assets=[414,443,523,552,490,501,480,477,591,593,582], cwip=[5,93,8,4,3,2,5,19,3,14,21], investments=[6,25,17,17,37,38,124,30,207,273,299],
 other_assets=[770,993,954,931,681,972,1027,1077,1088,1311,1463])
CF = dict(cfo=[71,-31,192,201,330,45,235,129,255,93,None], cfi=[-101,-154,-13,-28,-22,-53,-113,68,-248,-69,None], cff=[30,204,-194,-177,-307,8,-123,-194,-10,-23,None], net_cash_flow=[1,19,-15,-4,1,0,0,3,-3,2,None])
CR = dict(debtor_days=[83,89,79,73,87,74,70,82,86,92,None], inventory_days=[149,203,191,191,147,165,143,172,148,161,None], days_payable=[80,86,79,81,102,87,65,60,67,68,None],
 cash_conversion_cycle=[152,207,191,183,133,152,148,193,166,184,None], working_capital_days=[40,56,81,80,118,93,94,115,95,93,None],
 roce_pct=[None,None,17,11,3,29,28,21,20,19,None])  # 8 values on page for 10 columns; mapped to FY19-FY26 (first column and post-gap column blank); matches standalone series
SBY = ["FY2015","FY2016","FY2017","FY2018","FY2019","FY2020","FY2021","FY2022","FY2023","FY2024","FY2025","FY2026","H1FY27"]
SB = dict(equity_capital=[9]*13, reserves=[426,497,587,669,748,758,765,928,1132,1132,1279,1453,1178], borrowings=[309,408,305,573,444,428,139,223,163,175,262,352,719],
 other_liabilities=[236,282,258,301,303,308,304,355,336,290,342,378,462], total_liabilities=[981,1195,1159,1553,1505,1503,1217,1515,1640,1606,1893,2193,2369],
 fixed_assets=[332,398,409,439,519,548,487,498,477,474,589,591,581], cwip=[7,5,36,93,8,4,3,2,5,19,3,14,21], investments=[0,15,0,33,25,25,52,49,135,41,218,280,307],
 other_assets=[641,778,714,989,953,926,676,967,1022,1072,1083,1307,1460])
SF = dict(cfo=[60,81,203,-28,192,205,332,36,235,128,256,93,None], cfi=[-23,-111,-69,-158,-12,-27,-29,-55,-113,68,-248,-69,None], cff=[-38,31,-135,204,-194,-182,-301,19,-123,-194,-10,-23,None], net_cash_flow=[-1,1,-1,18,-15,-4,1,-1,0,2,-2,2,None])
SR = dict(debtor_days=[82,82,71,89,79,73,87,74,70,82,86,92,None], inventory_days=[110,147,156,203,190,190,146,164,143,171,147,160,None], days_payable=[65,79,69,85,79,81,102,87,65,60,67,68,None],
 cash_conversion_cycle=[127,151,157,206,190,182,132,151,148,193,165,184,None], working_capital_days=[46,41,59,56,80,81,116,92,94,115,94,93,None], roce_pct=[21,19,18,19,17,11,3,29,28,20,20,19,None])
for d,yl in [(CB,BY),(SB,SBY)]:
    for i in range(len(yl)):
        assert d["equity_capital"][i]+d["reserves"][i]+d["borrowings"][i]+d["other_liabilities"][i]==d["total_liabilities"][i] or abs(d["equity_capital"][i]+d["reserves"][i]+d["borrowings"][i]+d["other_liabilities"][i]-d["total_liabilities"][i])<=2, (yl[i])
brows=[]
for y in SBY:
    r={"fiscal_year":y,"period_end":{"H1FY27":"2026-09-30"}.get(y,y[2:]+"-03-31")}
    for d,pre in [(CB,"con_"),(CF,"con_"),(CR,"con_")]:
        for k in d: r[pre+k]=col(d,BY,y,k)
    for d,pre in [(SB,"std_"),(SF,"std_"),(SR,"std_")]:
        for k in d: r[pre+k]=col(d,SBY,y,k)
    r["std_capex_cr"]=round(CAPEX_STD_LAKH[y]/100,2) if y in CAPEX_STD_LAKH else None
    r["std_fcf_cr"]=round(r["std_cfo"]-CAPEX_STD_LAKH[y]/100,2) if y in CAPEX_STD_LAKH else None
    brows.append(r)
wcsv("balance_cashflow_ratios.csv",brows)

# ---------- misc.json
SHQ=["Dec 2023","Mar 2024","Jun 2024","Sep 2024","Dec 2024","Mar 2025","Jun 2025","Sep 2025","Dec 2025","Mar 2026","Jun 2026","Sep 2026"]
SH=dict(promoters=[67.45,67.45,67.45,67.45,67.45,67.45,67.45,67.45,67.44,67.45,67.45,67.44], fiis=[1.75,1.56,1.53,1.48,1.93,2.63,2.54,2.61,2.70,2.25,1.96,1.82],
 diis=[3.44,2.93,2.54,2.52,2.52,2.52,2.54,2.51,2.46,2.46,2.51,2.59], public=[27.37,28.07,28.47,28.56,28.11,27.40,27.47,27.44,27.40,27.84,28.09,28.14],
 shareholders=[39855,39722,39091,40141,49729,50467,50614,50827,47437,47660,46029,45262])
for i in range(12): assert abs(SH["promoters"][i]+SH["fiis"][i]+SH["diis"][i]+SH["public"][i]-100)<0.02, SHQ[i]
sh=[{"quarter_end":SHQ[i],**{k:SH[k][i] for k in SH}} for i in range(4,12)]
misc={
 "retrieved_on":RET,"company":{"name":"Siyaram Silk Mills Ltd","nse":"SIYSIL","bse":"503811","face_value_rs":2,"screener_company_id":3093},
 "units_note":"Rs crore unless stated; presentation figures in Rs mn where labelled",
 "price":{"as_of":"2026-11-03","price_rs":469.00,"price_note":"screener NSE price chart point dated 2026-11-03, captured ~14:30 IST (intraday, not official close); screener summary showed Rs 468 at 2:32 pm",
   "prev_close_2026_11_02_rs":468.35,"last_10_closes":[["2026-10-21",504.55],["2026-10-22",490.40],["2026-10-23",476.75],["2026-10-26",481.20],["2026-10-27",460.40],["2026-10-28",450.50],["2026-10-29",456.55],["2026-10-30",447.10],["2026-11-02",468.35],["2026-11-03",469.00]],
   "week52_high_rs":850,"week52_low_rs":433,"week52_note":"screener summary High/Low (intraday basis). Closing-price basis from screener 365-day chart: high 826.35 on 2025-11-04, low 435.80 on 2026-03-30",
   "week52_high_close_rs":826.35,"week52_high_close_date":"2025-11-04","week52_low_close_rs":435.80,"week52_low_close_date":"2026-03-30",
   "market_cap_cr":2123,"stock_pe_consolidated":9.44,"stock_pe_standalone":9.54,"book_value_rs":261,"dividend_yield_pct":2.58,"roce_pct_screener":18.8,"roe_pct_screener":14.9,
   "stock_price_cagr_pct":{"10y":4,"5y":0,"3y":-3,"1y":-39}},
 "pe_band":{"median_pe_5y":11.7,"median_pe_window":"2021-11-04 to 2026-11-02 (screener 1825-day chart, consolidated)","pe_latest_2026_11_02":9.4,
   "pe_recent_points":[["2026-09-04",10.6],["2026-09-11",10.2],["2026-09-18",10.1],["2026-09-25",10.3],["2026-10-01",10.2],["2026-10-09",10.3],["2026-10-16",10.2],["2026-10-23",9.1],["2026-10-30",9.0],["2026-11-02",9.4]],
   "pe_first_points":[["2021-11-04",14.7],["2021-11-12",14.1],["2021-11-18",14.1]],
   "ttm_eps_points":[["2025-01-25",42.78],["2025-05-12",43.44],["2025-07-12",42.72],["2025-07-29",41.93],["2025-11-04",46.02],["2026-01-27",45.22],["2026-05-19",50.89],["2026-07-10",45.01],["2026-07-30",52.29],["2026-10-27",49.61]]},
 "compounded_growth_consolidated_pct":{"sales":{"10y":5,"5y":19,"3y":5,"ttm":14},"profit":{"10y":9,"5y":118,"3y":-6,"ttm":8},"roe":{"10y":None,"5y":19,"3y":16,"last_year":15}},
 "compounded_growth_standalone_pct":{"sales":{"10y":5,"5y":19,"3y":5,"ttm":14},"profit":{"10y":9,"5y":110,"3y":-7,"ttm":6},"roe":{"10y":16,"5y":19,"3y":16,"last_year":15}},
 "stores":{"as_of":"2026-10-27 ('as on date' in Q2FY27 press release)","total":61,"zecode":38,"devo":23,
   "fy27_target_total":70,"zecode_format":{"ownership":"company owned company operated","size_sqft":"6,000-10,000","geography":"South India","investment_per_store_cr":"1.0-1.5","positioning":"fast fashion, Gen Z"},
   "devo_format":{"ownership":"company owned company operated","size_sqft":"2,000-4,000","geography":"North India","investment_per_store_cr":"1.0-1.5","positioning":"mid-premium men's ethnic wear"},
   "history_note":"Q2FY27 presentation gives only the current count. Earlier counts below are from secondary reprints of company press releases (equitybulls.com, arthneeti.com, multibagg.ai via web search); primary PDFs on nsearchives.nseindia.com timed out and were not verified",
   "history_secondary_source":[{"as_of":"Q3FY26 (Jan 2026 press release)","zecode":25,"devo":17,"total":42},{"as_of":"Q4FY26 (May 2026 press release)","zecode":27,"devo":17,"total":44},{"as_of":"Q1FY27 (Jul 2026 press release)","zecode":30,"devo":19,"total":49},{"as_of":"Q2FY27 (27 Oct 2026 press release, primary)","zecode":38,"devo":23,"total":61}]},
 "revenue_mix":{"q2fy27_pct":{"fabric":77,"garments":16,"yarn_and_others":7,"source":"press release / presentation commentary"},
   "annual_rs_mn":{y:{"fabric":P["fabric_rev_mn"][i],"garment":P["garment_rev_mn"][i],"yarn_knitting_others":P["yarn_others_rev_mn"][i],"total":P["fabric_rev_mn"][i]+P["garment_rev_mn"][i]+P["yarn_others_rev_mn"][i]} for i,y in enumerate(PY)},
   "annual_pct":{y:{"fabric":P["fabric_pct"][i],"garment":P["garment_pct"][i],"yarn_knitting_others":P["yarn_others_pct"][i]} for i,y in enumerate(PY)},
   "fy26_growth":{"fabric_pct":11.7,"fabric_volume_growth_pct":10.3,"fabric_value_growth_pct":1.3,"garments_pct":31.7,"garments_volume_growth_pct":41.5,"garments_value_growth_pct":-9.9},
   "exports_share_fy26_pct":10,"exports_rs_lakh_std":{"FY2026":21832.16,"FY2025":21461.39},"domestic_rs_lakh_std":{"FY2026":235096.33,"FY2025":200570.47},
   "brand_wise_revenue":None},
 "guidance_fy27":{"stores_total_by_fy27":70,"revenue_or_margin_guidance":None,"capex_guidance":None,"note":"only store-count target disclosed"},
 "capex_cr":{"FY2025":{"standalone":142.63,"consolidated":142.65},"FY2026":{"standalone":75.15,"consolidated":75.22},"source":"AR FY26 cash flow: Purchase of PPE, WIP and intangibles"},
 "company_reported_ratios":{y:{"roce_pct":P["roce_pct_company"][i],"roe_pct":P["roe_pct_company"][i],"debt_equity_x":P["debt_equity_x"][i],"net_debt_rs_mn":P["net_debt_mn"][i]} for i,y in enumerate(PY)},
 "presentation_pnl_fy25_fy26_rs_mn":{"FY2025":{"revenue":22203,"other_income_recurring":487,"total_income":22690,"cogs":13022,"employee":1827,"other_expenses":4581,"ebitda":3260,"ebitda_margin_pct":14.4,"other_income_non_recurring":266,"depreciation":599,"ebit":2927,"finance_cost":238,"pbt":2689,"tax":702,"pat":1987,"pat_margin_pct":8.8,"eps":43.8},
   "FY2026":{"revenue":25693,"other_income_recurring":567,"total_income":26260,"cogs":15202,"employee":2109,"other_expenses":5083,"ebitda":3866,"ebitda_margin_pct":14.7,"other_income_non_recurring":266,"depreciation":786,"ebit":3346,"finance_cost":342,"pbt":3004,"tax":723,"pat":2281,"pat_margin_pct":8.7,"eps":50.3}},
 "h1fy27_press_release":{"total_income_cr":1293,"total_income_h1fy26_cr":1118,"ebitda_cr":170,"ebitda_h1fy26_cr":153,"ebitda_margin_pct":13.1,"pat_cr":86,"pat_h1fy26_cr":92,"pat_margin_pct":6.7,"eps":19.0},
 "h1fy27_cash_flow_std_rs_mn":{"cfo":744,"cfo_h1fy26":-513,"cfi":-527,"cff":-246,"working_capital_change":-323,"working_capital_change_h1fy26":-1455},
 "dividends":{"dps_rs_split_adjusted":DPS,"special_dividend_included_rs":DPS_SPECIAL,"pct_of_face_value":{"FY2012":75,"FY2013":75,"FY2014":80,"FY2015":100,"FY2016":110,"FY2017":150,"FY2018":210,"FY2019":220,"FY2020":430,"FY2021":230,"FY2022":460,"FY2023":550,"FY2024":550,"FY2025":600,"FY2026":800},
   "fy26_breakup_rs":{"interim_1":4,"interim_2":3,"special_interim":4,"final":5},"dividend_outlay_cr":DIV_OUTLAY_CR,"buyback_cr_post_tax":BUYBACK_CR,"stock_split":"2:10 (Rs 10 to Rs 2) in FY17",
   "fy27_interim_1_rs":4,"fy27_interim_1_outgo_lakh":1814.80},
 "ncrps_bonus":{"description":"9% cumulative non-convertible redeemable preference shares issued as bonus from general reserve (Rs 31,759.06 lakh); allotted 2026-08-25; Series I 4 NCRPS of Rs10 per share redeemed end of year 3, Series II 3 NCRPS of Rs10 per share redeemed end of year 5; shown as non-current borrowings (Rs 3,146.11 mn at Sep-26)","total_issue_cr":318,"q2fy27_dividend_provision_in_finance_cost_lakh":289.15},
 "one_offs":{"dombivali_property_project_h1fy27_cost_lakh":2650.99,"note":"one-off residential property development; cost sits in 'Cost towards development of property' and is offset in 'Changes in inventories' (Note 3)"},
 "shareholding_last_8_quarters_pct":sh,
 "sources":{k:{"url":v,"retrieved":RET} for k,v in SRC.items()},
}
with open(os.path.join(OUT,"misc.json"),"w") as f: json.dump(misc,f,indent=1)
print("ok", [len(x) for x in (rows,qrows,crow,brows)])
