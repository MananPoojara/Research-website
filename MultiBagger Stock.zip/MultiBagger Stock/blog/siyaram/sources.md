# Source links for the Substack editor
Delivered version, 3 Nov 2026 (author's choice): the five company-hosted documents are linked over plain http, the only scheme this machine's link gate can verify for that host; the two NSE documents redirect http to https and are printed as plain URLs. All seven https URLs below were fetched successfully during research on 2 and 3 Nov 2026; switch the anchors to https in the Substack editor if preferred.
- FY26 annual report: https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/annual-reports/2025-2026/Annual-Report-2025-26.pdf
- Shareholding pattern 30 Sep 2026 (NSE XBRL): https://nsearchives.nseindia.com/corporate/xbrl/SHP_1739027_15102026045628_WEB.xml
- Results filing 27 Oct 2026: https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/SEIntimation_OutcomeofBM27102026.pdf
- Q2 FY27 investor presentation: https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/Investor+Presentation+Q2+FY27.pdf
- Q1 FY27 concall transcript: https://prod-siyaram-bucket.s3.ap-south-1.amazonaws.com/images/investor-relationship-doc/communications/2026-2027/InvestorMeetTranscript05082026.pdf
- NCLT order, preference-share scheme: https://nsearchives.nseindia.com/corporate/SIYSIL_29072026191629_SEIntimation_CertifiedTrueCopyNCLTOrder.pdf
- Linked in the post already: Screener.in consolidated page; SEBI 2023 buyback public announcement.

# Extracts behind figures not in data/ (from source/dd/SIYSIL.md, verified 2 Nov 2026 against the filings)
- FY27 guidance (about 12% revenue growth, about 14% EBITDA margin with a 150 bps drag from new retail formats, capex about Rs 100 crore, 70 stores): Q1 FY27 earnings call, 31 Jul 2026, Gaurav Poddar and CFO Surendra Shetty; transcript InvestorMeetTranscript05082026.pdf on the company IR site.
- FY26 guidance ("double-digit growth") and delivery (+15.7%, 61 stores): FY26 annual report and 27 Oct 2026 press release.
- Promoter pay: FY26 annual report, Board's Report annexure under Sec 197(12)/Rule 5 and corporate governance report (pp. 57 and 102): Ramesh D. Poddar Rs 7.50 cr, Pawan D. Poddar 7.22 cr, Shrikishan D. Poddar 7.22 cr, Gaurav P. Poddar 6.84 cr; total Rs 28.79 cr, of which Rs 15.25 cr profit-linked commission; ratios to median employee pay (Rs 3.44 lakh) 218x / 210x / 210x / 199x; standalone PAT Rs 228.08 cr, so 12.6%.
- Related-party purchases: FY26 annual report Note 42 (standalone): purchases from promoter-group enterprises Rs 69.17 cr (Golden Fibres LLP Rs 49.47 cr vs 25.55 cr in FY25); 2.7% of revenue from operations Rs 2,569 cr.
- Preference shares: NCLT Mumbai order 21 Jul 2026 (C.P.(CAA)/13/MB/2026); allotment filing 25 Aug 2026: Series I 4 shares redeemable by 24 Aug 2029, Series II 3 shares by 24 Aug 2031, 9% cumulative, Rs 317.59 cr debited to general reserve; promoter share 67.44% = Rs 214 cr, coupon Rs 19.3 cr a year.
- Dombivli residential project: board approval May 2026, Rs 45 cr, "one-off"; Rs 26.5 cr spent to Sep 2026 and parked in inventories (Q2 FY27 results Note 3).
- Emphasis of matter on Cadini S.R.L. (Italy): consolidated limited review, 27 Oct 2026 results filing. Deputy CFO (Dinesh Kumar Jaithliya) effective 1 Nov 2026: 27 Oct 2026 board outcome.
- Store counts: Dec 2025 42 (25 ZECODE + 17 DEVO) from press-release reprints, unverified; Sep/Oct 2026 61 (38 + 23) from the 27 Oct 2026 press release.
- Peer multiples: Screener.in, 2 Nov 2026: Kewal Kiran 17.7x, Arvind 29x, textile sector median about 19x.
- Promoter pay grew slower than profit: FY26 annual report RPT note, managerial remuneration Rs 31.47 cr vs Rs 29.18 cr in FY25 (+7.95%) against consolidated PAT +17%.
- Preference coupon per equity share: 7 shares x Rs 10 face x 9% = Rs 6.30 a year; 1.3% on Rs 470.
- Borrowings Rs 352 cr (31 Mar 2026) to Rs 719 cr (30 Sep 2026): Screener balance sheet, data/balance_cashflow_ratios.csv; NCRPS classified as non-current borrowings per the Q2 FY27 results notes.
- "48-year-old brand": Siyaram Silk Mills was incorporated in 1978 (company history page and annual report corporate information); 2026 minus 1978 = 48.
- Pay-growth claim base: the +7.95% is total managerial remuneration (RPT note); the four-director FY25 split was not extracted. Reviewer's P2 left open; the direction (pay growth below the +17% PAT growth) holds on the total.
- Price refreshed to the 3 Nov 2026 close, Rs 473 (Screener, 4:01 pm IST); market cap Rs 2,145 cr; consolidated P/E 9.52. Author line: name and CFA Program status as the author supplied it, worded per CFA Institute guidance on candidates (passed all three levels, no designation claimed).
- 3 Nov 2026, author update: not yet bought; intends to buy within the next week at 20% of a six-stock portfolio. Disclosure, Key Takeaways and verdict wording changed accordingly. Chart layout: title/subtitle moved to figure coordinates with fixed spacing; source note lifted off the bottom edge.
