"""Charts for the Siyaram Substack post. Data: blog/siyaram/data/*.csv (screener + filings, 3 Nov 2026)."""
import csv, json, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

D = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(D, "charts"); os.makedirs(OUT, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW, PINK = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"
GREY, INK, INK2, SURF = "#b8b6ae", "#0b0b0b", "#52514e", "#fcfcfb"
plt.rcParams.update({"font.family": "Noto Sans", "font.size": 13, "axes.edgecolor": "#d9d8d2",
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False,
    "axes.spines.right": False, "axes.spines.left": False, "figure.facecolor": SURF, "axes.facecolor": SURF,
    "axes.grid": True, "axes.grid.axis": "y", "grid.color": "#e6e5df", "grid.linewidth": 0.8, "axes.axisbelow": True,
    "legend.frameon": False, "figure.dpi": 100})

def fig(w=16, h=9): return plt.subplots(figsize=(w, h))
def title(ax, t, sub=None):
    # figure-level placement so the gap between title, subtitle and plot is the same on every chart height
    f = ax.figure
    f.text(0.02, 0.955, t, fontsize=20, fontweight="bold", color=INK, va="top")
    if sub: f.text(0.02, 0.905, sub, fontsize=13, color=INK2, va="top")
def source(f, s): f.text(0.02, 0.035, s, fontsize=10, color=INK2, va="bottom")
def save(f, name):
    f.tight_layout(rect=(0, 0.07, 1, 0.86)); f.savefig(os.path.join(OUT, name), dpi=100); plt.close(f); print("wrote", name)
def num(x):
    try: return float(x)
    except: return None

annual = list(csv.DictReader(open(os.path.join(D, "data/annual.csv"))))
quarterly = list(csv.DictReader(open(os.path.join(D, "data/quarterly.csv"))))
bs = list(csv.DictReader(open(os.path.join(D, "data/balance_cashflow_ratios.csv"))))
q2 = {r["line_item"]: r for r in csv.DictReader(open(os.path.join(D, "data/q2_pnl_compare.csv")))}
misc = json.load(open(os.path.join(D, "data/misc.json")))
A = {r["fiscal_year"]: r for r in annual}
B = {r["fiscal_year"]: r for r in bs}
yrs = [f"FY{y}" for y in range(2017, 2027)]
lab = [y.replace("FY20", "FY") for y in yrs]
PRICE = misc["price"]["price_rs"]

# 1 funnel ---------------------------------------------------------------
steps = [("Every listed company above Rs 50 cr", 3946), ("Liquid enough to buy and sell", 1943),
         ("Small: Rs 250 cr to Rs 4,400 cr", 902), ("Cheap on book value", 396), ("Actually profitable", 109),
         ("Generates free cash", 59), ("Read every filing: 4 gates", 43), ("Selected", 6)]
f, ax = fig(16, 9); ax.grid(False)
for i, (s, n) in enumerate(steps):
    y = len(steps) - i
    ax.barh(y, n, color=BLUE if n > 6 else AQUA, height=0.62)
    ax.text(n + 40, y, f"{n:,}", va="center", fontsize=14, fontweight="bold", color=INK)
ax.set_xscale("log"); ax.set_xlim(4, 9000); ax.set_xticks([]); ax.spines["bottom"].set_visible(False)
ax.set_yticks([len(steps) - i for i in range(len(steps))]); ax.set_yticklabels([s for s, _ in steps], fontsize=14, color=INK); ax.tick_params(axis="y", length=0)
title(ax, "3,946 companies in, 6 out", "Our screen, then four hand-checked gates: governance, guidance vs delivery, fundamentals, valuation. Log scale.")
source(f, "Source: our screen on Screener.in data, Oct 2026; 43 full due-diligence reviews, Nov 2026.")
save(f, "01-funnel.png")

# 2 revenue vs profit indexed ------------------------------------------------
rev = [num(A[y]["std_sales"]) for y in yrs]; pat = [num(A[y]["std_net_profit"]) for y in yrs]
ri = [100 * v / rev[0] for v in rev]; pi = [100 * v / pat[0] for v in pat]
f, ax = fig()
ax.plot(lab, ri, color=BLUE, lw=2.5, marker="o", ms=7); ax.plot(lab, pi, color=ORANGE, lw=2.5, marker="o", ms=7)
ax.text(len(lab) - 0.9, ri[-1], f"Revenue {ri[-1]:.0f}", color=BLUE, fontweight="bold", va="center")
ax.text(len(lab) - 0.9, pi[-1], f"Profit {pi[-1]:.0f}", color=ORANGE, fontweight="bold", va="center")
ax.annotate(f"FY23 profit Rs {pat[6]:.0f} cr", (6, pi[6]), xytext=(6.4, pi[6] - 8), color=INK2, arrowprops=dict(arrowstyle="-", color=GREY))
ax.annotate(f"FY26 profit Rs {pat[-1]:.0f} cr", (9, pi[-1]), xytext=(6.6, pi[-1] - 45), color=INK2, arrowprops=dict(arrowstyle="-", color=GREY))
ax.axhline(100, color=GREY, lw=1); ax.set_xlim(-0.3, len(lab) + 0.6)
title(ax, "Sales kept rising. Profit stopped in FY23.", "Standalone revenue and profit after tax, indexed to FY17 = 100. Covid year FY21 is the dip.")
ax.legend(["Revenue", "Profit after tax"], loc="upper left")
source(f, "Source: Screener.in standalone P&L, retrieved 3 Nov 2026.")
save(f, "02-revenue-vs-profit.png")

# 3 margins ------------------------------------------------------------------
yl = yrs + ["TTM"]; ll = lab + ["TTM\nSep-26"]
gm = [num(A[y]["gross_margin_pct"]) for y in yl]; om = [num(A[y]["std_opm_pct"]) for y in yl]
nm = [100 * num(A[y]["std_net_profit"]) / num(A[y]["std_sales"]) for y in yl]
f, ax = fig()
for s, c, n in ((gm, BLUE, "Gross margin"), (om, ORANGE, "Operating (EBITDA) margin"), (nm, AQUA, "Net margin")):
    ax.plot(ll, s, color=c, lw=2.5, marker="o", ms=6); ax.text(len(ll) - 0.8, s[-1], f"{n} {s[-1]:.0f}%", color=c, fontweight="bold", va="center")
ax.annotate("FY22 peak 17%: everyone restocked at once", (5, om[5]), xytext=(1.5, 24), color=INK2, arrowprops=dict(arrowstyle="-", color=GREY))
ax.annotate("Covid year", (4, om[4]), xytext=(2.8, 1), color=INK2, arrowprops=dict(arrowstyle="-", color=GREY))
ax.set_ylim(0, 62); ax.set_xlim(-0.3, len(ll) + 1.8); ax.yaxis.set_major_formatter(FuncFormatter(lambda v, p: f"{v:.0f}%"))
title(ax, "Gross margin held. Operating margin gave back 5 points.", "Standalone margins as % of revenue, FY17 to trailing twelve months. Gross = revenue less material cost.")
source(f, "Source: Screener.in P&L and expense breakdown; FY17 material cost from the FY18 annual report. Retrieved 3 Nov 2026.")
save(f, "03-margins.png")

# 4/5 P&L ladders ---------------------------------------------------------------
def ladder(name, items, a, b, la, lb, t, sub, src):
    f, ax = fig(); x = range(len(items)); w = 0.38
    ax.bar([i - w / 2 for i in x], a, w, color=GREY, label=la); ax.bar([i + w / 2 for i in x], b, w, color=BLUE, label=lb)
    for i, (va, vb) in enumerate(zip(a, b)):
        ax.text(i - w / 2, va + max(b) * 0.012, f"{va:,.0f}", ha="center", fontsize=11, color=INK2)
        ax.text(i + w / 2, vb + max(b) * 0.012, f"{vb:,.0f}", ha="center", fontsize=11, color=INK, fontweight="bold")
        ch = 100 * (vb / va - 1); ax.text(i, -max(b) * 0.075, f"{ch:+.0f}%", ha="center", fontsize=12, color=AQUA if ch >= 0 else ORANGE, fontweight="bold")
    ax.set_xticks(list(x)); ax.set_xticklabels(items); ax.set_ylim(-max(b) * 0.1, max(b) * 1.12); ax.yaxis.set_visible(False); ax.grid(False)
    ax.spines["bottom"].set_visible(False); ax.legend(loc="upper right"); title(ax, t, sub); source(f, src); save(f, name)

items = ["Revenue", "Gross profit", "EBITDA", "Depreciation", "Interest", "Other income", "Profit before tax", "Profit after tax"]
fy25, fy26 = A["FY2025"], A["FY2026"]
a = [num(fy25["con_sales"]), num(fy25["con_sales"]) * num(fy25["gross_margin_pct"]) / 100, num(fy25["con_operating_profit"]), num(fy25["con_depreciation"]), num(fy25["con_interest"]), num(fy25["con_other_income"]), num(fy25["con_pbt"]), num(fy25["con_net_profit"])]
b = [num(fy26["con_sales"]), num(fy26["con_sales"]) * num(fy26["gross_margin_pct"]) / 100, num(fy26["con_operating_profit"]), num(fy26["con_depreciation"]), num(fy26["con_interest"]), num(fy26["con_other_income"]), num(fy26["con_pbt"]), num(fy26["con_net_profit"])]
assert abs(a[2] - a[3] - a[4] + a[5] - a[6]) < 3 and abs(b[2] - b[3] - b[4] + b[5] - b[6]) < 3, "annual ladder does not tie"
ladder("04-pnl-ladder-fy.png", items, a, b, "FY25", "FY26", "Where each rupee went: FY25 against FY26 (Rs crore)",
       "Consolidated. Every rung grew, including profit. Gross profit = revenue less material cost.", "Source: Screener.in consolidated P&L, retrieved 3 Nov 2026.")
g = lambda k, c: num(q2[k][c])
qa = [g("Revenue from operations", "Q2FY26"), g("Revenue from operations", "Q2FY26") - g("Cost of materials = materials consumed + purchases + change in inventories + property dev cost (textile basis)", "Q2FY26"),
      g("Press release: EBITDA (Rs cr)", "Q2FY26"), g("Depreciation and amortisation", "Q2FY26"), g("Finance costs", "Q2FY26"), g("Other income", "Q2FY26"), g("Profit before tax", "Q2FY26"), g("Profit after tax", "Q2FY26")]
qb = [g("Revenue from operations", "Q2FY27"), g("Revenue from operations", "Q2FY27") - g("Cost of materials = materials consumed + purchases + change in inventories + property dev cost (textile basis)", "Q2FY27"),
      g("Press release: EBITDA (Rs cr)", "Q2FY27"), g("Depreciation and amortisation", "Q2FY27"), g("Finance costs", "Q2FY27"), g("Other income", "Q2FY27"), g("Profit before tax", "Q2FY27"), g("Profit after tax", "Q2FY27")]
ladder("05-pnl-ladder-q2.png", items, qa, qb, "Sep 2025 quarter", "Sep 2026 quarter", "The same ladder for the quarter just reported (Rs crore)",
       "Standalone. Revenue, gross profit and EBITDA up. Other income down, interest up, so profit after tax down 14%.",
       "Source: results filing and press release, 27 Oct 2026. EBITDA as the company reports it (includes recurring other income).")

# 6 seasonality --------------------------------------------------------------
Q = {r["quarter"]: num(r["std_opm_pct"]) for r in quarterly}
fys = ["FY24", "FY25", "FY26", "FY27"]; qs = ["Q1 (Jun)", "Q2 (Sep)", "Q3 (Dec)", "Q4 (Mar)"]
f, ax = fig(16, 7); ax.grid(False)
import matplotlib.colors as mc
cmap = mc.LinearSegmentedColormap.from_list("blue", ["#e8f0fb", BLUE])
for i, fy in enumerate(fys):
    for j in range(4):
        v = Q.get(f"Q{j+1}{fy}")
        if v is None: ax.text(j, len(fys) - 1 - i, "n/a", ha="center", va="center", color=INK2); continue
        ax.add_patch(plt.Rectangle((j - 0.48, len(fys) - 1 - i - 0.45), 0.96, 0.9, color=cmap(v / 17)))
        ax.text(j, len(fys) - 1 - i, f"{v:.0f}%", ha="center", va="center", fontsize=18, fontweight="bold", color="white" if v > 9 else INK)
ax.set_xlim(-0.6, 3.6); ax.set_ylim(-0.6, len(fys) - 0.4); ax.set_xticks(range(4)); ax.set_xticklabels(qs, fontsize=14)
ax.set_yticks(range(len(fys))); ax.set_yticklabels(fys[::-1], fontsize=14); ax.spines["bottom"].set_visible(False); ax.tick_params(length=0)
title(ax, "The June quarter is always the bad one", "Standalone EBITDA margin by quarter. Darker = higher. Q1 FY27 at 4% looks like a collapse until you look up the column.")
source(f, "Source: Screener.in quarterly results, retrieved 3 Nov 2026. Q1 FY24 not in the dataset.")
save(f, "06-seasonality.png")

# 7 cash conversion ------------------------------------------------------------
cy = ["FY2022", "FY2023", "FY2024", "FY2025", "FY2026"]; cl = [c.replace("FY20", "FY") for c in cy]
cfo = [num(B[y]["con_cfo"]) for y in cy]; pt = [num(A[y]["con_net_profit"]) for y in cy]
f, ax = fig(); x = range(5); w = 0.38
ax.bar([i - w / 2 for i in x], pt, w, color=GREY, label="Profit after tax"); ax.bar([i + w / 2 for i in x], cfo, w, color=BLUE, label="Cash from operations")
for i in x:
    ax.text(i - w / 2, pt[i] + 4, f"{pt[i]:.0f}", ha="center", fontsize=11, color=INK2); ax.text(i + w / 2, cfo[i] + 4, f"{cfo[i]:.0f}", ha="center", fontsize=11, color=INK, fontweight="bold")
    ax.text(i, -22, f"{100*cfo[i]/pt[i]:.0f}% converted", ha="center", fontsize=12, color=AQUA if cfo[i] >= pt[i] else ORANGE, fontweight="bold")
ax.set_xticks(list(x)); ax.set_xticklabels(cl); ax.set_ylim(-30, 300); ax.yaxis.set_visible(False); ax.grid(False); ax.spines["bottom"].set_visible(False); ax.legend(loc="upper left")
title(ax, "Five years: Rs 1,080 cr of profit, Rs 757 cr of cash", "Consolidated, Rs crore. FY26 was the weakest conversion since FY22.")
source(f, "Source: Screener.in consolidated cash flow and P&L, retrieved 3 Nov 2026.")
save(f, "07-cash-conversion.png")

# 8 working capital --------------------------------------------------------------
wy = ["FY2021", "FY2022", "FY2023", "FY2024", "FY2025", "FY2026"]; wl = [c.replace("FY20", "FY") for c in wy]
dd = [num(B[y]["con_debtor_days"]) for y in wy]; idn = [num(B[y]["con_inventory_days"]) for y in wy]; ccc = [num(B[y]["con_cash_conversion_cycle"]) for y in wy]
f, ax = fig()
for s, c, n in ((ccc, ORANGE, "Cash conversion cycle"), (idn, BLUE, "Inventory days"), (dd, AQUA, "Debtor days")):
    ax.plot(wl, s, color=c, lw=2.5, marker="o", ms=6); ax.text(len(wl) - 0.85, s[-1], f"{n} {s[-1]:.0f}", color=c, fontweight="bold", va="center")
ax.set_xlim(-0.3, len(wl) + 1.6); ax.set_ylim(0, 210)
title(ax, "The money comes back slower every year", "Consolidated working-capital days. Cash conversion cycle = inventory days + debtor days less payable days.")
source(f, "Source: Screener.in ratios, retrieved 3 Nov 2026.")
save(f, "08-working-capital.png")

# 9 stores ----------------------------------------------------------------------
sh = misc["stores"]["history_secondary_source"]; sl = ["Dec 2025", "Mar 2026", "Jun 2026", "Sep 2026", "Mar 2027\ntarget"]
z = [s["zecode"] for s in sh] + [None]; dv = [s["devo"] for s in sh] + [None]
f, ax = fig(16, 8); x = range(5)
ax.bar(x[:4], z[:4], 0.6, color=BLUE, label="ZECODE (value fashion, South)"); ax.bar(x[:4], dv[:4], 0.6, bottom=z[:4], color=AQUA, label="DEVO (men's ethnic, North)")
ax.bar([4], [70], 0.6, color=SURF, edgecolor=GREY, hatch="//", lw=1.5)
for i in range(4): ax.text(i, z[i] + dv[i] + 1.2, f"{z[i]+dv[i]}", ha="center", fontweight="bold", color=INK)
ax.text(4, 71.2, "70", ha="center", fontweight="bold", color=INK2)
ax.set_xticks(list(x)); ax.set_xticklabels(sl); ax.set_ylim(0, 82); ax.yaxis.set_visible(False); ax.grid(False); ax.spines["bottom"].set_visible(False); ax.legend(loc="upper left")
title(ax, "Sixty-one own stores, target seventy by March", "Store count at quarter-end. Each store costs Rs 1 to 1.5 cr and is stocked before it sells.")
source(f, "Source: Q2 FY27 press release (27 Oct 2026) for Sep 2026; earlier quarters from press-release reprints, not independently verified.")
save(f, "09-stores.png")

# 10 capital returns ---------------------------------------------------------------
ky = ["FY2021", "FY2022", "FY2023", "FY2024", "FY2025", "FY2026"]; kl = [c.replace("FY20", "FY") for c in ky] + ["FY27\nso far"]
div = [num(A[y]["dividend_outlay_cr"]) for y in ky] + [4 * 4.537]; bb = [0, 0, 0, 108, 0, 0, 0]; pref = [0] * 6 + [317.6]
f, ax = fig(); x = range(7)
ax.bar(x, div, 0.6, color=BLUE, label="Dividends"); ax.bar(x, bb, 0.6, bottom=div, color=AQUA, label="Buyback (2023, at Rs 650 to 720)")
ax.bar(x, pref, 0.6, bottom=[d + b for d, b in zip(div, bb)], color=ORANGE, label="Bonus preference shares, 9% coupon, redeemed 2029 and 2031")
for i in x:
    t = div[i] + bb[i] + pref[i]; ax.text(i, t + 5, f"{t:.0f}", ha="center", fontweight="bold", color=INK)
ax.set_xticks(list(x)); ax.set_xticklabels(kl); ax.yaxis.set_visible(False); ax.grid(False); ax.spines["bottom"].set_visible(False); ax.legend(loc="upper left"); ax.set_ylim(0, 380)
title(ax, "Cash out to shareholders, Rs crore", "Two thirds of every rupee here goes to the promoter family, which owns 67.44%. The preference shares rank ahead of equity.")
source(f, "Source: annual reports, SEBI buyback letter (Aug 2023), NCLT order and allotment filing (Aug 2026). FY27 = first interim dividend of Rs 4.")
save(f, "10-capital-returns.png")

# 11 guidance scorecard ---------------------------------------------------------------
rows = [("FY26 revenue growth", "double digit (10%+)", 10, 15.7, "%"), ("FY27 revenue growth", "about 12%", 12, 15.0, "% (H1)"),
        ("FY27 EBITDA margin", "about 14%", 14, 13.1, "% (H1)"), ("Sep-26 quarter margin", "about 14%", 14, 15.8, "%"), ("Stores by Mar 2027", "70", 70, 61, " (Sep-26)")]
f, ax = fig(16, 8); ax.grid(False)
for i, (n, gtxt, gv, dv_, u) in enumerate(rows):
    y = len(rows) - i; mx = 80 if "Stores" in n else 20; gx, dx = gv / mx, dv_ / mx
    ax.plot([gx, dx], [y, y], color=GREY, lw=3, zorder=1)
    ax.scatter([gx], [y], s=220, color=GREY, zorder=2); ax.scatter([dx], [y], s=260, color=AQUA if dv_ >= gv else ORANGE, zorder=3)
    ax.text(-0.02, y, n, ha="right", va="center", fontsize=14, color=INK)
    ax.text(gx, y + 0.3, f"guided {gtxt}", ha="center", fontsize=11, color=INK2)
    ax.text(dx, y - 0.36, f"delivered {dv_:g}{u}", ha="center", fontsize=12, fontweight="bold", color=INK)
ax.set_xlim(-0.02, 1.1); ax.set_ylim(0.3, len(rows) + 0.9); ax.axis("off")
title(ax, "What they said, what they did", "Guidance given ahead of FY26 and FY27 (the FY27 numbers from the July 2026 call) against reported figures. Green = met or beaten.")
source(f, "Source: company earnings calls (FY27 guidance from the 31 Jul 2026 call); FY26 annual report; Q2 FY27 press release. Margin guide allows 150 bps drag from new stores.")
save(f, "11-guidance.png")

# 12 valuation ---------------------------------------------------------------------
names = ["Arvind", "Sector median (textiles)", "Kewal Kiran", "Siyaram, Nov 2021", "Siyaram 5-yr median", "Siyaram today"]
vals = [29, 19, 17.7, 14.7, misc["pe_band"]["median_pe_5y"], misc["pe_band"]["pe_latest_2026_11_02"]]
f, ax = fig(16, 8); ax.grid(False); y = range(len(names))[::-1]
ax.barh(list(y), vals, 0.6, color=[GREY, GREY, GREY, BLUE, BLUE, ORANGE])
for yy, n, v in zip(y, names, vals): ax.text(v + 0.4, yy, f"{v:g}x", va="center", fontweight="bold", color=INK); ax.text(-0.5, yy, n, va="center", ha="right", color=INK, fontsize=14)
ax.set_xlim(0, 34); ax.set_yticks([]); ax.set_xticks([]); ax.spines["bottom"].set_visible(False)
title(ax, "Price to trailing earnings", "Siyaram has de-rated from 14.7x to 9.5x in five years. Branded textile peers trade at roughly twice its multiple.")
source(f, "Source: Screener.in, 3 Nov 2026 (peer multiples as of 2 Nov 2026).")
save(f, "12-valuation.png")

# 13 scenarios ----------------------------------------------------------------------
sc = [("Bear\nmargins keep sliding\nPAT Rs 190 cr x 8", 335), ("Today", PRICE), ("Base\n6% profit growth\nPAT Rs 270 cr x 11", 655), ("Bull\nmargin back to 15%\nPAT Rs 330 cr x 13", 950)]
f, ax = fig(16, 8); x = range(4)
ax.bar(x, [v for _, v in sc], 0.55, color=[ORANGE, GREY, BLUE, AQUA])
for i, (n, v) in enumerate(sc):
    ax.text(i, v + 15, f"Rs {v:,.0f}" + ("" if i == 1 else f"  ({100*(v/PRICE-1):+.0f}%)"), ha="center", fontweight="bold", color=INK, fontsize=14)
ax.set_xticks(list(x)); ax.set_xticklabels([n for n, _ in sc], fontsize=12); ax.yaxis.set_visible(False); ax.grid(False); ax.spines["bottom"].set_visible(False); ax.set_ylim(0, 1080)
title(ax, "Three futures for FY29, per share", f"Against today's Rs {PRICE:.0f}. Excludes the 2.6% dividend yield and the preference coupon.")
source(f, "Source: our estimates, Nov 2026. Multiples are inside Siyaram's own 8x to 15x five-year range.")
save(f, "13-scenarios.png")
print("done")

# 14 revenue mix ---------------------------------------------------------------------
my = ["FY2022", "FY2023", "FY2024", "FY2025", "FY2026"]; ml = [c.replace("FY20", "FY") for c in my]
fab = [num(A[y]["fabric_pct"]) for y in my]; gar = [num(A[y]["garment_pct"]) for y in my]; oth = [num(A[y]["yarn_others_pct"]) for y in my]
f, ax = fig(16, 8); x = range(5)
ax.bar(x, fab, 0.6, color=BLUE, label="Fabric (sold through ~1,500 dealers)"); ax.bar(x, gar, 0.6, bottom=fab, color=AQUA, label="Garments and own-brand stores")
ax.bar(x, oth, 0.6, bottom=[a_ + b_ for a_, b_ in zip(fab, gar)], color=GREY, label="Yarn and others")
for i in x:
    ax.text(i, fab[i] / 2, f"{fab[i]:.0f}%", ha="center", va="center", color="white", fontsize=16, fontweight="bold")
    ax.text(i, fab[i] + gar[i] / 2, f"{gar[i]:.0f}%", ha="center", va="center", color="white", fontsize=13, fontweight="bold")
ax.set_xticks(list(x)); ax.set_xticklabels(ml); ax.yaxis.set_visible(False); ax.grid(False); ax.spines["bottom"].set_visible(False); ax.set_ylim(0, 118)
ax.legend(loc="upper left", ncol=3)
title(ax, "Still a fabric company", "Share of revenue by product. Garments grew 32% in FY26 but are still under a fifth of sales.")
source(f, "Source: Siyaram annual reports and Q2 FY27 investor presentation, retrieved 3 Nov 2026.")
save(f, "14-revenue-mix.png")
